var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });

// src/audit.js
var SPORTS = /* @__PURE__ */ new Set(["NFL", "CFB", "MLB", "NHL", "NBA", "NCAAB", "Soccer", "Tennis"]);
var AUDIT_VERSION = "2026-11-03.quality.1";
var REGULATION = { NFL: 4, CFB: 4, NBA: 4, NCAAB: 2, NHL: 3, MLB: 9, Soccer: 2, Tennis: 3 };
var WIDE = { NFL: 21, CFB: 28, MLB: 5, NHL: 3, NBA: 25, NCAAB: 20, Soccer: 3, Tennis: 2 };
function clockSeconds(value) {
  const match = /^(\d{1,3}):(\d{2})$/.exec(String(value || ""));
  if (!match || Number(match[2]) >= 60) return null;
  return Number(match[1]) * 60 + Number(match[2]);
}
__name(clockSeconds, "clockSeconds");
function gameState(game) {
  const raw = game.liveRawStatus || {};
  const scores = (game.teams || []).slice(0, 2).map((team) => Number(team?.[2]));
  const period = Number(raw.period);
  return {
    key: `${game.sport}:${game.id}`,
    sport: game.sport,
    rating: Number(game.score),
    scores,
    margin: Math.abs(scores[0] - scores[1]),
    period: Number.isInteger(period) ? period : null,
    clock: clockSeconds(raw.displayClock),
    phase: String(game.live?.phase || game.status || ""),
    scoreState: String(raw.type?.state || ""),
    sourceState: game.state
  };
}
__name(gameState, "gameState");
function stateBucket(state) {
  const stage = state.period == null ? "unknown" : state.period > REGULATION[state.sport] ? "ot" : state.period >= REGULATION[state.sport] ? "late" : "early";
  const margin = state.margin === 0 ? "tied" : state.margin <= Math.max(1, Math.floor(WIDE[state.sport] / 3)) ? "close" : state.margin >= WIDE[state.sport] ? "wide" : "middle";
  return `${stage}:${margin}`;
}
__name(stateBucket, "stateBucket");
function auditTimeline(summary, sport) {
  const plays = Array.isArray(summary?.plays) ? summary.plays : [];
  if (plays.length < 3 || !["NFL", "CFB", "NBA", "NCAAB", "NHL", "MLB", "Soccer"].includes(sport)) return { checks: 0, findings: [] };
  let sequenceConflicts = 0, clockReversals = 0, scoreRollbacks = 0;
  const examples = [];
  for (let i = 1; i < plays.length; i++) {
    const a = plays[i - 1], b = plays[i], pa = Number(a.period?.number), pb = Number(b.period?.number), ca = clockSeconds(a.clock?.displayValue), cb = clockSeconds(b.clock?.displayValue), wa = Date.parse(a.wallclock || ""), wb = Date.parse(b.wallclock || "");
    if (!Number.isFinite(wa) || !Number.isFinite(wb) || wb < wa) continue;
    const forward = pa === pb && ca !== null && cb !== null && ca - cb >= 10;
    if (forward && Number(b.sequenceNumber) < Number(a.sequenceNumber)) {
      sequenceConflicts++;
      if (examples.length < 3) examples.push({ before: a.id, after: b.id, clock: [a.clock?.displayValue, b.clock?.displayValue] });
    }
    if (pa === pb && ca !== null && cb !== null && cb - ca > 90) clockReversals++;
    if (["NFL", "CFB", "NBA", "NCAAB", "NHL", "Soccer"].includes(sport) && (Number(b.homeScore) < Number(a.homeScore) || Number(b.awayScore) < Number(a.awayScore)) && !/correct|overturn|review/i.test(String(b.text || "") + " " + String(b.type?.text || ""))) scoreRollbacks++;
  }
  const findings = [];
  if (sequenceConflicts >= 2) findings.push(candidate(
    "TIMELINE_SEQUENCE_CONFLICT",
    "low",
    0.68,
    "history",
    { sequenceConflicts, examples },
    "replay should use source chronology, not sequence sort",
    "Play sequence IDs disagree with forward clock and wall-clock order"
  ));
  if (clockReversals >= 2) findings.push(candidate(
    "TIMELINE_CLOCK_ORDER",
    "medium",
    0.75,
    "provider data",
    { clockReversals },
    "play clock normally advances chronologically",
    "Cached play timeline contains backward intervals"
  ));
  if (scoreRollbacks) findings.push(candidate(
    "TIMELINE_SCORE_ROLLBACK",
    "medium",
    0.72,
    "provider data",
    { scoreRollbacks },
    "scoring totals do not decrease without correction",
    "Cached play timeline has unexplained score decreases"
  ));
  return { checks: 3, findings };
}
__name(auditTimeline, "auditTimeline");
var candidate = /* @__PURE__ */ __name((reasonCode, severity, confidence, failureLayer, observed, expected, detail, deterministic = false) => ({ reasonCode, severity, confidence, failureLayer, observed, expected, detail, deterministic }), "candidate");
function comparableMedian(peers) {
  const values = peers.map((row) => Number(row.rating)).filter(Number.isFinite).sort((a, b) => a - b);
  return values.length >= 5 ? values[Math.floor(values.length / 2)] : null;
}
__name(comparableMedian, "comparableMedian");
function auditGame(game, previous = [], peers = [], now = Date.now(), nhlCrosscheck = null, summary = null) {
  const s = gameState(game), p = previous[0] || null, findings = [];
  const rawRef = {
    feedGame: s.key,
    providerPath: game.providerPath || null,
    priorSnapshot: p ? { gameKey: s.key, observedAt: p.observed_at, modelVersion: p.model_version } : null
  };
  let checks = 0;
  const add = /* @__PURE__ */ __name((...args) => findings.push(candidate(...args)), "add");
  checks++;
  if (!Number.isInteger(s.rating) || s.rating < 1 || s.rating > 99)
    add("RATING_OUT_OF_RANGE", "critical", 1, "scoring model", { rating: s.rating }, "integer 1..99", "Published rating is outside the scale", true);
  checks++;
  if (s.scores.length !== 2 || s.scores.some((n) => !Number.isInteger(n) || n < 0))
    add("INVALID_SCORE", "critical", 1, "provider data", { scores: s.scores }, "two nonnegative integer scores", "Published team scores are malformed", true);
  checks++;
  if (s.scoreState && s.scoreState !== "in")
    add("LIVE_STATE_CONFLICT", "high", 1, "provider data", { state: s.scoreState, sourceState: s.sourceState }, "in", "Published live game conflicts with provider state", true);
  checks++;
  if (s.period !== null && (s.period < 1 || s.period > 20))
    add("INVALID_PERIOD", "high", 1, "clock reconciliation", { period: s.period }, "period 1..20", "Provider period is outside a plausible live range", true);
  checks++;
  const regulation = REGULATION[s.sport];
  if (s.period > regulation && /\b\d+(?:st|nd|rd|th)\s+(?:quarter|half|period)\b/i.test(s.phase))
    add("OVERTIME_LABEL", "high", 0.99, "UI", { phase: s.phase, period: s.period }, "OT or later overtime label", "Overtime is presented as regulation", true);
  checks++;
  if (game.scoreboard?.teams?.length === 2) {
    const raw = game.scoreboard.teams.map((team) => Number(team?.[2]));
    if (raw.some((n, i) => Number.isFinite(n) && n !== s.scores[i]))
      add("SCOREBOARD_ENRICHMENT_CONFLICT", "high", 0.95, "provider data", { published: s.scores, scoreboard: raw }, "scores agree", "Canonical enriched and raw scoreboard scores differ", true);
  }
  checks++;
  if (nhlCrosscheck && s.sport === "NHL" && nhlCrosscheck.ageMs <= 9e4 && nhlCrosscheck.scores.every(Number.isFinite) && nhlCrosscheck.scores.some((n, i) => n !== s.scores[i]))
    add("NHL_SOURCE_SCORE_CONFLICT", "high", 0.8, "provider data", { published: s.scores, official: nhlCrosscheck.scores, ageMs: nhlCrosscheck.ageMs }, "ESPN and cached NHL scores agree", "Independent cached NHL play-by-play differs; allow for propagation lag");
  checks++;
  if (p) {
    let prior;
    try {
      prior = JSON.parse(p.normalized_state || "{}");
    } catch {
      add("HISTORY_JSON_CORRUPT", "critical", 1, "history", { observedAt: p.observed_at }, "parseable stored state", "Stored prior state cannot be parsed", true);
    }
    if (prior) {
      const ps = gameState(prior), age = now - Number(p.observed_at);
      if (Number(p.observed_at) > now + 3e4 || age < 0)
        add("HISTORY_FUTURE_TIMESTAMP", "critical", 1, "history", { priorAt: p.observed_at, now }, "snapshot time at or before scan", "Stored observation is from the future", true);
      if (p.state === "completed")
        add("FINAL_TO_LIVE", "critical", 1, "history", { priorState: p.state, currentState: "live" }, "completed state does not resume", "Final game became live again", true);
      const delta = s.rating - ps.rating;
      if (p.state === "upcoming" && s.period === 1 && s.scores.every((n) => n === 0) && delta > 28 && !String(game.moment || game.momentumText || game.upsetText || ""))
        add(
          "KICKOFF_JUMP",
          "medium",
          0.72,
          "scoring model",
          { pregame: ps.rating, live: s.rating },
          "opening live rating follows observed state and context",
          "Large opening rise before a score or known event"
        );
      if (age >= 0 && age <= 6e5) {
        if (ps.period !== null && s.period !== null && s.period < ps.period)
          add("PERIOD_ROLLBACK", "high", 0.85, "clock reconciliation", { previous: ps.period, current: s.period }, "period does not decrease", "Provider period moved backward; possible correction");
        if (ps.period === s.period && ps.clock !== null && s.clock !== null && s.clock - ps.clock > 90 && s.sport !== "Tennis")
          add("CLOCK_ROLLBACK", "medium", 0.75, "clock reconciliation", { previous: ps.clock, current: s.clock }, "clock normally counts down", "Clock gained over 90 seconds within a period");
        const scoreChanged = s.scores.some((n, i) => n !== ps.scores[i]), phaseChanged = s.period !== ps.period;
        const event = String(game.moment || game.momentumText || game.upsetText || "");
        if (Math.abs(delta) >= 24 && !scoreChanged && !phaseChanged && !event && !game.detailStale)
          add(
            delta > 0 ? "UNEXPLAINED_RISE" : "UNEXPLAINED_DROP",
            "medium",
            0.67,
            "scoring model",
            { previousRating: ps.rating, rating: s.rating, scores: s.scores, period: s.period },
            "large same-state change has an event, pressure, or context explanation",
            "No visible scoring or phase change explains the rating move"
          );
      }
    }
  }
  checks++;
  if (!game.detailStale && s.period >= regulation && s.margin >= WIDE[s.sport]) {
    const bound = { NFL: 78, CFB: 76, MLB: 78, NHL: 79, NBA: 77, NCAAB: 75, Soccer: 76, Tennis: 75 }[s.sport];
    if (s.rating > bound && !/championship|final|playoff|overtime|hat trick|record|milestone/i.test(String(game.context || "") + " " + String(game.moment || "")))
      add(
        "LATE_WIDE_MARGIN_HIGH",
        "low",
        0.58,
        "scoring model",
        { rating: s.rating, margin: s.margin, period: s.period },
        `usually below ${bound} absent exceptional stakes or events`,
        "Wide late margin has unusually high excitement; review context before changing score"
      );
  }
  checks++;
  if (/\b(?:currently tied|tie game|one.point game|one.goal game)\b/i.test(String(game.why || "")) && s.margin > 2)
    add("MISLEADING_EXPLANATION", "medium", 0.72, "UI", { why: game.why, margin: s.margin }, "explanation agrees with current score", "Displayed explanation may describe an earlier game state");
  checks++;
  const median = comparableMedian(peers);
  if (median !== null && Math.abs(s.rating - median) >= 27 && !game.detailStale)
    add(
      "SIMILAR_STATE_OUTLIER",
      "low",
      0.54,
      "scoring model",
      { rating: s.rating, bucket: stateBucket(s), peerMedian: median, peerCount: peers.length },
      "inspect stakes and events before interpreting peer spread",
      "Rating differs substantially from similar observed states"
    );
  const timeline = auditTimeline(summary, s.sport);
  checks += timeline.checks;
  findings.push(...timeline.findings);
  return { state: s, stateBucket: stateBucket(s), checks, findings, rawRef, peerMedian: median };
}
__name(auditGame, "auditGame");

// src/dashboard.js
var head = `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#202526"><title>SlateMeter \xB7 Live Audit</title>
<style>
:root{color-scheme:dark;--bg:#202526;--surface:#343a3b;--ink:#f3eee2;--muted:#aeb1a8;--brass:#d5a85b;--blue:#79aee4;--green:#9bcf8a;--red:#ef7567;--line:#5a605d;font-family:'Segoe UI',Arial,sans-serif}
*{box-sizing:border-box}body{margin:0;min-width:320px;color:var(--ink);background:radial-gradient(circle at 50% -30%,#59605d 0,#272d2e 42%,#171b1c 100%);min-height:100vh}
.shell{max-width:1180px;margin:auto;padding:0 22px 48px}.top{min-height:76px;display:flex;align-items:center;gap:18px;border-bottom:1px solid #626763;flex-wrap:wrap}
.brand{display:flex;align-items:center;gap:10px;color:var(--ink);text-decoration:none;font-weight:800;letter-spacing:.1em;font-size:15px}.brand em{font-style:normal;color:#f2cf8a}.brandmark{width:34px;height:34px;border-radius:9px;background:linear-gradient(145deg,#f3cb78,#ad7b3b);display:flex;align-items:end;justify-content:center;gap:3px;padding:7px;box-shadow:inset 1px 1px 2px #ffe8ad,0 2px 4px #111}.brandmark i{width:4px;background:#302617;border-radius:4px}.brandmark i:nth-child(1){height:8px}.brandmark i:nth-child(2){height:14px}.brandmark i:nth-child(3){height:20px}
.topnav{margin-left:auto;display:flex;gap:16px;align-items:center}.topnav a,.linkbutton{color:#d9ebff;font-size:13px}.linkbutton{border:0;background:none;cursor:pointer;text-decoration:underline;padding:0}
h1{font-size:clamp(25px,4vw,38px);letter-spacing:-.035em;margin:28px 0 6px}h2{font-size:19px;margin:0 0 15px}.intro{color:var(--muted);margin:0 0 23px;line-height:1.5}.muted{color:var(--muted)}.mono{font-family:ui-monospace,Consolas,monospace;font-size:12px}.statusline{display:flex;align-items:center;gap:9px;margin:16px 0}.dot{width:10px;height:10px;border-radius:50%;background:var(--green);box-shadow:0 0 0 4px #9bcf8a20}.dot.warn{background:var(--red);box-shadow:0 0 0 4px #ef756720}
.grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px}.tile,.panel,.game,.finding{border:1px solid #69706b;background:linear-gradient(145deg,#454c4a,#2d3332);border-radius:11px;box-shadow:inset 1px 1px 1px #727871,0 5px 10px #0004}.tile{padding:17px}.tile strong{display:block;font-size:27px;color:#f7e2ac}.tile small{display:block;color:var(--muted);margin-top:5px;font-size:12px}.panel{padding:21px;margin-top:18px}.sectionhead{display:flex;justify-content:space-between;gap:12px;align-items:center;flex-wrap:wrap}.sectionhead p{margin:0;color:var(--muted);font-size:12px}.list{display:grid;gap:10px}.game,.finding{padding:15px 17px}.row{display:flex;align-items:flex-start;justify-content:space-between;gap:12px}.title{font-weight:700;font-size:15px}.sub{font-size:12px;color:var(--muted);margin-top:5px;line-height:1.45}.badge{display:inline-flex;align-items:center;padding:4px 8px;border-radius:999px;border:1px solid #657e6b;color:#e8f6e3;background:#2e4937;font-size:11px;font-weight:700;white-space:nowrap}.badge.critical,.badge.high{border-color:#b9635c;background:#5b3330;color:#ffe1d8}.badge.medium{border-color:#b79055;background:#584730;color:#ffedc5}.badge.low{border-color:#728eae;background:#2c4254;color:#d7eaff}.detail{color:#ddd9cd;font-size:13px;line-height:1.5;margin-top:10px}.evidence{color:var(--muted);font-size:12px;line-height:1.5;margin-top:7px;overflow-wrap:anywhere}pre.evidence{white-space:pre-wrap;max-height:420px;overflow:auto}.empty{padding:25px;text-align:center;color:var(--muted);border:1px dashed var(--line);border-radius:8px}.control{display:flex;align-items:center;gap:9px;flex-wrap:wrap}input,button{font:inherit}input{background:#1f2627;color:var(--ink);border:1px solid #75817d;border-radius:6px;padding:10px 12px;min-height:42px}input:focus{outline:2px solid var(--blue)}button.primary{background:linear-gradient(#b1d4f7,#628fc3);border:1px solid #c8e5ff;color:#12263d;font-weight:700;padding:10px 16px;border-radius:6px;cursor:pointer;min-height:42px}.login{max-width:420px;margin:clamp(40px,12vh,110px) auto;padding:27px}.login label{display:block;margin:22px 0 7px;font-weight:700}.login input,.login button{width:100%}.error{color:#ffd1c9}.footer{color:var(--muted);font-size:12px;line-height:1.5;margin-top:26px}
@media(max-width:700px){.shell{padding:0 14px 34px}.top{padding:10px 0}.topnav{margin-left:0;width:100%;justify-content:space-between}.grid{grid-template-columns:repeat(2,minmax(0,1fr))}.tile{padding:13px}.tile strong{font-size:23px}.panel{padding:15px}.row{flex-wrap:wrap}.login{margin:35px auto}}
@media(max-width:520px){.control{width:100%}.control label{width:100%}.control input{flex:1;min-width:0}.control button{flex:1}.control #export{width:100%;flex-basis:100%}}
</style></head><body><div class="shell"><header class="top"><a class="brand" href="https://mmueller091.github.io/sports-radar/" aria-label="SlateMeter home"><span class="brandmark"><i></i><i></i><i></i></span><span>SLATE<em>METER</em></span></a><nav class="topnav"><a href="https://mmueller091.github.io/sports-radar/">Back to games</a>`;
var end = `</div></body></html>`;
function loginHtml(error = false) {
  return `${head}</nav></header><main class="panel login"><h1>Live Audit</h1><p class="intro">Private monitoring dashboard</p>${error ? '<p class="error" role="alert">Incorrect password. Try again.</p>' : ""}<form method="post" action="/session"><label for="password">Dashboard password</label><input id="password" name="password" type="password" autocomplete="current-password" required autofocus><p><button class="primary" type="submit">Open dashboard</button></p></form><p class="footer">The audit runs automatically every three minutes. This dashboard is separate from the public game site.</p></main>${end}`;
}
__name(loginHtml, "loginHtml");
var dashboardHtml = `${head}<form method="post" action="/logout"><button class="linkbutton" type="submit">Sign out</button></form></nav></header>
<main><h1>Live Audit Monitor</h1><p class="intro">Independent checks of live excitement ratings across every supported sport. Observation only.</p>
<div class="statusline"><span class="dot" id="status-dot"></span><strong id="status">Loading monitor status\u2026</strong><span class="mono muted" id="updated"></span></div>
<section class="grid" aria-label="Audit summary"><div class="tile"><strong id="games-checked">\u2014</strong><small>Games checked in latest scan</small></div><div class="tile"><strong id="checks-completed">\u2014</strong><small>Checks completed</small></div><div class="tile"><strong id="clean-games">\u2014</strong><small>Clean games</small></div><div class="tile"><strong id="active-findings">\u2014</strong><small>Active anomalies</small></div></section>
<section class="panel"><div class="sectionhead"><div><h2>Active anomalies</h2><p>Confirmed findings and recoveries appear in the history below.</p></div></div><div class="list" id="findings"></div></section>
<section class="panel"><div class="sectionhead"><div><h2>Games audited for this slate</h2><p>Every observed game is listed, including those with no findings. Dates use New York local time.</p></div><div class="control"><label for="day">Slate date</label><input id="day" type="date"><button class="primary" id="refresh" type="button">Refresh</button><button class="primary" id="export" type="button">Export Nightly Audit</button></div></div><p class="sub" id="night-summary"></p><div class="list" id="games"></div></section>
<section class="panel"><div class="sectionhead"><div><h2>Scoring Quality</h2><p>Review current watchability and sport calibration for the selected slate.</p></div><button class="primary" id="quality-load" type="button">Load Scoring Quality</button></div><p class="sub" id="quality-status" role="status">Computed on demand from retained observations. No provider requests or scoring changes.</p><div class="list" id="quality"></div></section>
<section class="panel"><h2>Finding history</h2><div class="list" id="history"></div></section>
<p class="footer">Checks use observed score, clock, period, source freshness, earlier snapshots, and comparable states. Plausibility findings are review prompts; this monitor never changes production ratings. The report refreshes every minute while this page is open.</p>
</main><script src="/dashboard.js" defer><\/script>${end}`;

// src/dashboard-client.generated.js
var dashboard_client_generated_default = "// DOM-only rendering: provider and finding text is never inserted as HTML.\r\nconst $=id=>document.getElementById(id);\r\nconst fmt=value=>value?new Date(Number(value)).toLocaleString('en-US',{timeZone:'America/New_York',month:'short',day:'numeric',hour:'numeric',minute:'2-digit'}):'\u2014';\r\nconst node=(tag,cls,text)=>{const el=document.createElement(tag);if(cls)el.className=cls;if(text!==undefined)el.textContent=String(text);return el;};\r\nconst clear=el=>{while(el.firstChild)el.firstChild.remove();};\r\nconst empty=(el,message)=>el.append(node('div','empty',message));\r\nconst dayNY=()=>new Intl.DateTimeFormat('en-CA',{timeZone:'America/New_York',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());\r\nfunction findingCard(f) {\r\n  const evidence=f.evidence || {}, card=node('article','finding'),row=node('div','row'),left=node('div');\r\n  left.append(node('div','title',`${f.game_key} \xB7 ${String(f.reason_code || '').replaceAll('_',' ')}`));\r\n  left.append(node('div','sub',`${f.status || 'recorded'} \xB7 First seen ${fmt(f.first_seen)} \xB7 Last seen ${fmt(f.last_seen)} \xB7 ${f.failure_layer || 'unknown layer'}`));\r\n  row.append(left,node('span',`badge ${f.severity || 'medium'}`,String(f.severity || 'medium').toUpperCase()));card.append(row);\r\n  card.append(node('div','detail',evidence.detail || 'Review the recorded evidence.'));\r\n  card.append(node('div','evidence',`Observed: ${JSON.stringify(evidence.observed ?? {})} \xB7 Expected: ${evidence.expected || 'review'} \xB7 Confidence: ${Math.round(Number(f.confidence || 0)*100)}%`));\r\n  return card;\r\n}\r\nfunction gameCard(g,findings) {\r\n  const e=g.latestEvidence || {},s=e.state || {},teams=(s.teams || []).map(t=>t?.[0] || '?').join(' vs '),\r\n    associated=findings.filter(f=>f.game_key===g.game_key || f.evidence?.affectedGames?.includes(g.game_key));\r\n  const card=node('article','game'),row=node('div','row'),left=node('div');\r\n  left.append(node('div','title',teams || g.game_key));\r\n  left.append(node('div','sub',`${g.sport} \xB7 ${g.observations} observations \xB7 ${fmt(g.first_seen)} to ${fmt(g.last_seen)}`));\r\n  row.append(left,node('span',associated.length?'badge medium':'badge',associated.length?`${associated.length} finding${associated.length===1?'':'s'}`:'No findings'));\r\n  card.append(row,node('div','detail',`Rating range ${g.min_rating}\u2013${g.peak_rating} \xB7 Latest recorded ${s.score ?? '\u2014'} \xB7 ${(s.teams || []).map(t=>t?.[2] ?? '\u2014').join('\u2013')}`));\r\n  if(associated.length)card.append(node('div','evidence',associated.map(f=>String(f.reason_code || '').replaceAll('_',' ')).join(' \xB7 ')));\r\n  return card;\r\n}\r\nasync function refresh() {\r\n  try {\r\n    const day=$('day').value || dayNY(),res=await fetch(`/report?date=${encodeURIComponent(day)}`,{credentials:'same-origin',cache:'no-store'});\r\n    if(res.status===401){location.href='/dashboard';return}if(!res.ok)throw new Error(`Report HTTP ${res.status}`);\r\n    const data=await res.json(),run=data.latestRun || {},post=data.postSlate || {},all=post.findings || [],active=data.activeUnresolvedFindings || [];\r\n    const history=(post.events || []).map(event=>({game_key:event.game_key,reason_code:event.reason_code,\r\n      status:event.event,first_seen:event.at,last_seen:event.at,severity:event.evidence?.severity || 'medium',\r\n      failure_layer:event.evidence?.failureLayer || 'unknown',confidence:event.evidence?.confidence || 0,\r\n      evidence:event.evidence}));\r\n    const byReason=new Map();for(const f of [...all,...history])byReason.set(`${f.game_key}|${f.reason_code}`,f);\r\n    const healthy=Boolean(run.finished_at && !run.error && Date.now()-run.finished_at<8*60000);\r\n    $('status-dot').classList.toggle('warn',!healthy);\r\n    $('status').textContent=run.error?'Audit scan failed':healthy?'Monitoring active':'Waiting for scheduled scan';\r\n    $('updated').textContent=`Last successful audit ${fmt(data.lastSuccessfulScan)} \xB7 Feed age ${data.sourceFreshnessMs==null?'\u2014':Math.round(data.sourceFreshnessMs/60000)+' min'}`;\r\n    $('games-checked').textContent=run.games_checked ?? '\u2014';$('checks-completed').textContent=run.checks_completed ?? '\u2014';\r\n    $('clean-games').textContent=run.clean_games ?? '\u2014';$('active-findings').textContent=data.activeUnresolvedCount ?? 0;\r\n    clear($('findings'));if(active.length)active.forEach(f=>$('findings').append(findingCard(f)));else empty($('findings'),'No active anomalies.');\r\n    $('night-summary').textContent=`${post.distinctGames || 0} distinct games \xB7 ${post.scans || 0} scheduled scans \xB7 ${post.checksCompleted || 0} checks \xB7 ${history.filter(f=>f.status==='opened').length} findings opened`;\r\n    clear($('games'));if(post.gameSummaries?.length)post.gameSummaries.forEach(g=>$('games').append(gameCard(g,[...byReason.values()])));else empty($('games'),'No live games have been audited on this night yet. Inactive slates are skipped.');\r\n    clear($('history'));if(history.length)history.forEach(f=>$('history').append(findingCard(f)));else empty($('history'),'No confirmed finding events recorded on this night.');\r\n  } catch(error){$('status-dot').classList.add('warn');$('status').textContent='Dashboard data unavailable';$('updated').textContent=String(error)}\r\n}\r\nasync function init(){\r\n  try{const response=await fetch('/export/dates',{credentials:'same-origin',cache:'no-store'});\r\n    if(response.ok){const dates=await response.json();$('day').value=dates.defaultDate || dayNY();}\r\n    else $('day').value=dayNY();\r\n  }catch{$('day').value=dayNY()}\r\n  await refresh();\r\n}\r\nfunction qualityCard(r){\r\n  const card=node('article','finding');\r\n  card.append(node('div','title',`${r.matchup} \xB7 ${r.rating} \xB7 ${r.scores.join('\u2013')}`));\r\n  card.append(node('div','sub',`${r.gameKey} \xB7 ${fmt(r.observedAt)} \xB7 period ${r.period}, ${r.clockSeconds??'?'}s \xB7 ${r.modelVersion}`));\r\n  card.append(node('div','detail',`${r.classification} \xB7 ${r.confidence} confidence. ${r.suspectedCause}.`));\r\n  card.append(node('div','evidence',`Evidence: ${r.signals.join('; ')||'wide margin / low comeback feasibility'}. Missing: ${r.missingEvidence.join('; ')||'none detected'}.`));\r\n  if(r.sourceEvent)card.append(node('div','evidence',`Source event ${r.sourceEvent.id} \xB7 event time ${fmt(r.sourceEvent.occurredAt)} \xB7 ${r.sourceEvent.text||''}`));\r\n  card.append(node('div','detail',`Next: ${r.recommendedCorrection}. Impact: production ratings 0, alerts 0; candidate impact requires replay.`));\r\n  const details=node('details'),summary=node('summary',null,'Supporting state');details.append(summary,node('pre','evidence',JSON.stringify({state:r.evidence,sourceReference:r.sourceReference},null,2)));card.append(details);\r\n  return card;\r\n}\r\nlet qualityGeneration=0;\r\nfunction invalidateQuality(){qualityGeneration++;clear($('quality'));$('quality-status').textContent='Load quality for the selected date.';}\r\nasync function loadQuality(){\r\n  const generation=++qualityGeneration,date=$('day').value||dayNY();\r\n  $('quality-load').disabled=true;$('quality-status').textContent='Analyzing retained live observations\u2026';\r\n  try{\r\n    const response=await fetch(`/quality?date=${encodeURIComponent(date)}`,{credentials:'same-origin',cache:'no-store'});\r\n    if(response.status===401){location.href='/dashboard';return}if(!response.ok)throw Error(`Quality HTTP ${response.status}`);\r\n    const data=await response.json();if(generation!==qualityGeneration)return;\r\n    const q=data.scoringQuality,el=$('quality');clear(el);\r\n    $('quality-status').textContent=`${data.dateNewYork} \xB7 ${q.modelCohorts.length} scoring model(s). Hypotheses require review; an equivalent 85 across sports is not established. Duration is a sampled estimate. Missing evidence is not uneventful play.`;\r\n    for(const cohort of q.modelCohorts){\r\n      el.append(node('h3',null,`Calibration \xB7 ${cohort.modelVersion}`));\r\n      for(const s of cohort.sports){\r\n        const card=node('article','game');card.append(node('div','title',s.sport==='NCAAB'?'NCAAM':s.sport));\r\n        card.append(node('div','detail',`${s.gamesWithRating} games with ratings \xB7 reaching 70/80/85/90/95: ${Object.values(s.percentageReaching).map(v=>v===null?'unknown':v.toFixed(1)+'%').join(' / ')} \xB7 peak median ${s.peakDistribution.median??'unknown'} \xB7 seconds >85: ${s.estimatedSecondsAbove85??'unknown'}`));\r\n        card.append(node('div','evidence',`${s.decisiveMoments.length} significant observations \xB7 ${s.significantNeverReached85.length} significant games never observed at 85. ${s.comparability85}.`));\r\n        const detail=node('details'),heading=node('summary',null,'Moments, event responses and evidence gaps');detail.append(heading,node('pre','evidence',JSON.stringify({decisiveMoments:s.decisiveMoments,eventResponses:s.eventResponses,significantNeverReached85:s.significantNeverReached85,evidenceGaps:s.evidenceGaps},null,2)));card.append(detail);el.append(card);\r\n      }\r\n    }\r\n    if(!q.modelCohorts.length)empty(el,'No retained live observations. All sport calibration metrics are unavailable.');\r\n    for(const [title,rows] of [['Top 10 potentially overrated games',q.topOverrated],['Top 10 potentially underrated games',q.topUnderrated]]){\r\n      el.append(node('h3',null,title));if(rows.length)rows.forEach(r=>el.append(qualityCard(r)));else empty(el,'No supported candidates; coverage may be incomplete.');\r\n    }\r\n    const details=node('details');details.append(node('summary',null,'Integrity, watchability and simultaneous-game comparisons'),node('pre','evidence',JSON.stringify({integrity:q.integrityProblems,missingEvidence:q.missingEvidence,watchability:q.games.map(g=>({gameKey:g.gameKey,modelVersion:g.modelVersion,...g.watchability})),simultaneous:q.simultaneousPriorityConflicts},null,2)));el.append(details);\r\n  }catch(error){if(generation===qualityGeneration)$('quality-status').textContent=String(error);}\r\n  finally{$('quality-load').disabled=false;}\r\n}\r\n$('quality-load').addEventListener('click',loadQuality);\r\n$('refresh').addEventListener('click',refresh);$('day').addEventListener('change',()=>{invalidateQuality();refresh();});\r\n$('export').addEventListener('click',()=>{const date=$('day').value || dayNY();location.href=`/export?date=${encodeURIComponent(date)}`});\r\ninit();setInterval(refresh,60000);\r\n";

// src/quality.js
var QUALITY_VERSION = "2026-11-03.quality.1";
var QUALITY_SPORTS = ["NFL", "CFB", "NBA", "NCAAB", "NHL", "MLB", "Tennis", "Soccer"];
var THRESHOLDS = [70, 80, 85, 90, 95];
var number = /* @__PURE__ */ __name((v) => v === null || v === void 0 || v === "" || !Number.isFinite(Number(v)) ? null : Number(v), "number");
var time = /* @__PURE__ */ __name((v) => typeof v === "number" ? number(v) : Number.isFinite(Date.parse(v)) ? Date.parse(v) : null, "time");
var bool = /* @__PURE__ */ __name((v) => typeof v === "boolean" ? v : null, "bool");
var pick = /* @__PURE__ */ __name((o, keys) => Object.fromEntries(keys.filter((k) => o?.[k] !== void 0).map((k) => [k, o[k]])), "pick");
var reg = { NFL: 4, CFB: 4, NBA: 4, NCAAB: 2, NHL: 3 };
var wide = { NFL: 17, CFB: 21, NBA: 20, NCAAB: 18, NHL: 3, MLB: 5, Soccer: 3 };
var comeback = { NFL: 14, CFB: 14, NBA: 15, NCAAB: 12, NHL: 2, MLB: 3, Soccer: 2 };
function clockSeconds2(value) {
  const s = String(value ?? "");
  const m = /^(\d+):(\d{2})(?:\.(\d+))?$/.exec(s);
  if (m && +m[2] < 60) return +m[1] * 60 + +m[2] + (m[3] ? Number("0." + m[3]) : 0);
  return /^\d{1,2}\.\d+$/.test(s) ? Number(s) : null;
}
__name(clockSeconds2, "clockSeconds");
var factorPoints = /* @__PURE__ */ __name((g, re) => (g.factors || []).filter((f) => re.test(f.label || "")).reduce((sum, f) => sum + (number(f.points) || 0), 0), "factorPoints");
var historyPoints = /* @__PURE__ */ __name((g) => (g.factors || []).filter((f) => /history|comeback|recovery|erased.*deficit|lead change|trajectory|sustained|win.chance swing/i.test(f.label || "")).reduce((sum, f) => sum + Math.max(0, number(f.points) || 0), 0), "historyPoints");
function eventAtState(game, p, publishedAt) {
  if (!p?.id) return null;
  const status = game.liveRawStatus || {}, scores = (game.teams || []).map((t) => number(t[2]));
  if (number(p.period?.number) !== number(status.period) || scores.length !== 2 || scores.some((x) => x === null) || number(p.awayScore) !== scores[0] || number(p.homeScore) !== scores[1]) return null;
  const eventClock = clockSeconds2(p.clock?.displayValue), currentClock = clockSeconds2(status.displayClock);
  if (currentClock !== null && eventClock !== currentClock) return null;
  const occurredAt = time(p.wallclock);
  if (occurredAt !== null && (publishedAt === null || occurredAt > publishedAt)) return null;
  const text = String(p.text || p.type?.text || "").slice(0, 300);
  if (!p.scoringPlay && !/turnover|intercept|fumble|fourth.down|match point|break point|home run|goal|penalty|strikeout/i.test(text)) return null;
  return {
    id: String(p.id),
    text,
    scoringPlay: p.scoringPlay === true,
    occurredAt,
    timestampKind: occurredAt === null ? "unavailable" : "provider-event-wallclock",
    period: number(p.period?.number),
    clock: p.clock?.displayValue || null
  };
}
__name(eventAtState, "eventAtState");
function captureQualityEvidence(game, { publishedAt = null, observedAt = null } = {}) {
  const g = game || {}, r = g.liveRawSituation || {}, c = g.sourceCompetition || {}, sport = g.sport;
  const ids = (g.teams || []).map((t) => String(t?.[8] ?? ""));
  const possession = String(r.possession?.id ?? r.possession ?? "");
  const market = g.liveUpset?.market || g.liveSurprise?.market || null;
  const sides = (g.teams || []).map((t) => number(t?.[2]));
  const dogIndex = market ? ids.indexOf(String(market.teamId)) : -1;
  const context = String(g.context || "");
  const publication = time(publishedAt);
  const batting = String(r.battingTeamId ?? (["away", "home"].includes(r.battingSide) ? ids[r.battingSide === "away" ? 0 : 1] : "") ?? "");
  const quality = {
    version: QUALITY_VERSION,
    source: "canonical-at-publication",
    publishedAt: publication,
    observedAt: time(observedAt),
    possession: ids.includes(possession) && possession ? possession : null,
    down: number(r.down),
    distance: number(r.distance),
    yardsToEndzone: number(r.yardsToEndzone),
    timeouts: [number(r.awayTimeouts), number(r.homeTimeouts)],
    fouls: r.fouls ?? null,
    bonus: r.bonus ?? null,
    shotClock: number(r.shotClock),
    outs: number(r.outs),
    bases: [bool(r.onFirst), bool(r.onSecond), bool(r.onThird)],
    battingTeamId: batting && ids.includes(batting) ? batting : null,
    powerPlayTeamId: r.powerPlayTeamId && ids.includes(String(r.powerPlayTeamId)) ? String(r.powerPlayTeamId) : null,
    goaliePulled: bool(r.goaliePulled),
    pressure: r.pressure?.verified === true ? pick(r.pressure, ["source", "observedAt", "shots", "attempts", "expectedGoals"]) : null,
    noHitBid: bool(r.noHitBid),
    bestOf: number(c.format?.regulation?.periods ?? c.format?.bestOf),
    matchPoint: bool(r.matchPoint ?? r.isMatchPoint),
    breakPoint: bool(r.breakPoint ?? r.isBreakPoint),
    breakOfServe: bool(r.breakOfServe),
    tiebreak: bool(r.tiebreak ?? r.isTiebreak),
    grandSlam: /wimbledon|australian open|french open|roland garros|us open/i.test(context),
    stakes: /playoff|postseason|elite (?:8|eight)|sweet (?:16|sixteen)|final four|world series|super bowl|stanley cup final|nba finals|national championship/i.test(context),
    championship: /world series|super bowl|stanley cup final|nba finals|national championship|grand slam final/i.test(context),
    market: market ? pick(market, ["teamId", "teamName", "spread", "source", "quotedAt"]) : null,
    underdogMargin: dogIndex >= 0 && sides.every((x) => x !== null) ? sides[dogIndex] - sides[1 - dogIndex] : null,
    underdogProbability: number(g.liveUpset?.currentProbability ?? g.liveSurprise?.currentProbability),
    winProbability: number(g.live?.winProbability),
    historyPoints: historyPoints(g),
    stakesPoints: factorPoints(g, /postseason|championship|final round/i),
    event: eventAtState(g, r.lastPlay, publication),
    evidenceQuality: g.evidenceQuality ?? null,
    scoringPartial: g.scoringPartial === true,
    rejected: Boolean(g.detailStale || g.timingUncertain || g.liveUpdateRejected || g.basketballUpdateRejected || g.summaryLifecycleRejected || g.scoringHistoryRejected),
    // Acquisition/scan/event time is NOT a provider publication timestamp.
    providerPublication: null,
    providerPublicationLatencyMs: null
  };
  return quality;
}
__name(captureQualityEvidence, "captureQualityEvidence");
function point(observation, game) {
  const g = observation.state || {}, raw = g.liveRawStatus || {}, at = time(observation.observedAt);
  const q = { ...observation.qualityEvidence || captureQualityEvidence(g, { publishedAt: observation.feedUpdatedAt, observedAt: at }) };
  if (g.factors) q.historyPoints = historyPoints(g);
  const scores = (observation.scores || g.teams?.map((t) => t[2]) || []).map(number);
  const period = number(observation.period ?? raw.period), clock = number(observation.clockSeconds) ?? clockSeconds2(raw.displayClock);
  const rating = number(observation.rating), sport = game.sport === "NCAAM" ? "NCAAB" : game.sport;
  const publication = q.publishedAt ?? time(observation.feedUpdatedAt);
  const gaps = [];
  gaps.push(...observation.sourceReference?.missingSituationFields || []);
  if (observation.sourceReference?.excludedHistory?.length) gaps.push(`${observation.sourceReference.excludedHistory.length} earlier contradictory archive events excluded`);
  if (!observation.qualityEvidence) gaps.push("Legacy observation lacks structured quality evidence");
  if (publication === null) gaps.push("Publication timestamp unavailable");
  if (q.evidenceQuality !== "complete") gaps.push("Complete scoring evidence not established");
  const integrity = (observation.auditCandidates || []).filter((f) => f.deterministic).map((f) => f.reasonCode);
  if (rating !== null && (!Number.isInteger(rating) || rating < 1 || rating > 99)) integrity.push("INVALID_RATING");
  if (scores.length !== 2 || scores.some((n) => n === null || n < 0)) integrity.push("INVALID_SCORE");
  if (at !== null && publication !== null && (publication > at || at - publication > 18e4)) gaps.push("Publication is future-dated or stale");
  if (q.rejected || q.scoringPartial) gaps.push("Rejected, stale or partial scoring evidence");
  return {
    gameKey: game.gameKey,
    matchup: game.matchup || game.gameKey,
    sport,
    observedAt: at,
    publishedAt: publication,
    modelVersion: observation.scoringVersion || "unknown",
    feedRevision: observation.feedRevision || null,
    runId: observation.runId ?? null,
    rating,
    scores,
    period,
    clockSeconds: clock,
    phase: g.live?.phase || g.status || null,
    margin: scores.length === 2 && scores.every((x) => x !== null) ? Math.abs(scores[0] - scores[1]) : null,
    q,
    gaps,
    integrity,
    live: g.state !== "completed" && g.state !== "upcoming",
    historical: observation.provenance === "causal-reconstruction",
    event: observation.sourceEvent || q.event,
    sourceReference: observation.sourceReference || { rawInputReferences: observation.rawInputReferences || [] }
  };
}
__name(point, "point");
function inspect(p, history) {
  const { sport, period, clockSeconds: t, margin: m, q } = p, signals = [], gaps = [...p.gaps];
  const late = reg[sport] && period >= reg[sport], ot = reg[sport] && period > reg[sport];
  const need = /* @__PURE__ */ __name((test, label) => {
    if (!test) gaps.push(label);
  }, "need");
  if (["NFL", "CFB"].includes(sport)) {
    need(q.possession, "Possession unavailable");
    need(q.down !== null && q.distance !== null, "Down/distance unavailable");
    need(q.yardsToEndzone !== null, "Field position unavailable");
    need(q.timeouts.every((n) => n !== null), "Timeouts unavailable");
    need(t !== null, "Remaining clock unavailable");
    if ((ot || late && t !== null && t <= 120) && m !== null && m <= 8 && q.possession && q.down !== null && q.distance !== null && q.yardsToEndzone !== null)
      signals.push("Decisive football possession");
    if (late && m <= 8 && q.down === 4 && q.yardsToEndzone !== null && q.yardsToEndzone <= 40) signals.push("Meaningful fourth down");
  } else if (["NBA", "NCAAB"].includes(sport)) {
    need(q.possession, "Possession unavailable");
    need(q.fouls !== null, "Foul evidence unavailable");
    need(q.bonus !== null, "Bonus evidence unavailable");
    need(q.shotClock !== null, "Shot clock unavailable");
    if (late && t !== null && t > 0 && t <= 120 && m !== null && m <= 3) signals.push(q.possession ? "Decisive basketball possession" : "Late one-possession game; possession unknown");
  } else if (sport === "NHL") {
    need(q.powerPlayTeamId !== null, "Manpower advantage not verified");
    need(q.goaliePulled !== null, "Goalie status unavailable");
    need(q.pressure !== null, "Advanced pressure unavailable; experiment disabled");
    if (ot && m === 0) signals.push("Tied hockey overtime");
    if (late && t !== null && t <= 300 && m === 1) signals.push("Late one-goal opportunity");
    if (m !== null && m <= 2 && q.powerPlayTeamId) signals.push("Verified manpower advantage");
    if (late && m <= 2 && q.goaliePulled === true) signals.push("Verified pulled goalie");
  } else if (sport === "MLB") {
    need(q.outs !== null, "Outs unavailable");
    need(q.bases.every((b) => b !== null), "Baserunners unavailable");
    need(q.battingTeamId, "Batting side unavailable");
    need(q.noHitBid !== null, "No-hit evidence unavailable");
    const battingIndex = q.battingTeamId ? p.teamIds?.indexOf(q.battingTeamId) : -1;
    const deficit = battingIndex >= 0 ? p.scores[1 - battingIndex] - p.scores[battingIndex] : null;
    if (period >= 7 && q.outs !== null && q.outs < 3 && q.bases.every((b) => b !== null) && deficit !== null && deficit >= 0 && deficit <= q.bases.filter(Boolean).length + 1)
      signals.push("Late tying/winning run at plate or on base");
    if (period >= 6 && q.noHitBid === true) signals.push("Verified no-hit bid");
  } else if (sport === "Tennis") {
    need(q.bestOf !== null, "Match format unavailable");
    need(q.matchPoint !== null, "Match-point evidence unavailable");
    need(q.breakOfServe !== null, "Break-of-serve evidence unavailable");
    need(q.tiebreak !== null, "Tiebreak evidence unavailable");
    if (q.bestOf !== null && period === q.bestOf && m <= 1) signals.push("Verified deciding set");
    if (q.matchPoint === true) signals.push("Verified match point");
    if (q.tiebreak === true) signals.push("Verified tiebreak");
    if (q.breakOfServe === true) signals.push("Verified break of serve");
    if (q.grandSlam && signals.length) signals.push("Grand Slam stakes");
  } else if (sport === "Soccer") {
    need(q.possession, "Possession unavailable");
    gaps.push("Aggregate, red-card and shot-pressure coverage not established");
    if (period >= 2 && t !== null && t >= 80 * 60 && m <= 1) signals.push("Late close soccer game");
  }
  const elapsedLate = sport === "MLB" ? period >= 7 : sport === "Soccer" ? period >= 2 && t >= 80 * 60 : late;
  const impossible = ["NBA", "NCAAB"].includes(sport) && late && t !== null && t <= 5 && m >= 7;
  if (q.market && q.underdogMargin !== null && q.underdogMargin >= -3 && q.underdogMargin <= (["NFL", "CFB"].includes(sport) ? 8 : 6) && !impossible && (q.underdogProbability === null || q.underdogProbability >= 0.05) && (sport === "NCAAB" && period >= 2 || ["NBA", "NFL", "CFB"].includes(sport) && period >= 3)) signals.push("Credible observed underdog threat");
  if (!q.market) gaps.push("Verified pregame underdog expectation unavailable");
  if (q.championship && signals.length) signals.push("Championship stakes with current leverage");
  const prior = history.filter((x) => x.modelVersion === p.modelVersion && x.margin !== null);
  const deficits = [0, 1].map((i) => Math.max(0, ...prior.map((x) => x.scores[1 - i] - x.scores[i])));
  if (comeback[sport] && m <= { NFL: 8, CFB: 8, NBA: 3, NCAAB: 3, NHL: 1, MLB: 1, Soccer: 1 }[sport] && p.scores.length === 2 && p.scores.every(Number.isFinite) && deficits.some((d, i) => d >= comeback[sport] && d - (p.scores[1 - i] - p.scores[i]) >= 0.75 * comeback[sport])) signals.push("Substantial comeback observed so far");
  const leader = /* @__PURE__ */ __name((x) => x.scores?.length === 2 ? Math.sign(x.scores[0] - x.scores[1]) : 0, "leader");
  const previousLeader = [...prior].reverse().find((x) => leader(x) !== 0);
  if (previousLeader && leader(p) !== 0 && leader(p) !== leader(previousLeader)) signals.push("Observed lead change");
  if (["NBA", "NCAAB"].includes(sport) && t !== null && prior.some((x) => x.period === period && x.clockSeconds !== null && x.clockSeconds >= t && x.clockSeconds - t <= 180 && [0, 1].some((i) => p.scores[i] - x.scores[i] >= 8 && p.scores[1 - i] === x.scores[1 - i])))
    signals.push("Observed unanswered run within three game minutes");
  const wideLate = elapsedLate && m !== null && wide[sport] !== void 0 && m >= wide[sport];
  const leadingIndex = p.scores[0] > p.scores[1] ? 0 : p.scores[1] > p.scores[0] ? 1 : -1;
  const clockExhaustible = ["NFL", "CFB"].includes(sport) && late && !ot && t !== null && t <= 30 && m > 0 && leadingIndex >= 0 && q.possession === p.teamIds?.[leadingIndex] && q.timeouts[1 - leadingIndex] === 0 && q.down !== null && q.down <= 3;
  const probabilityBoundary = ["NBA", "NCAAB"].includes(sport) && t !== null && t <= 10 && m >= 4 ? 0.98 : 0.995;
  const leaderProbability = q.winProbability === null || leadingIndex < 0 ? null : leadingIndex === 1 ? q.winProbability : 1 - q.winProbability;
  const securedBasketball = ["NBA", "NCAAB"].includes(sport) && late && t !== null && t <= 10 && m >= 3 && leaderProbability >= 0.95 && q.possession === p.teamIds?.[leadingIndex];
  const settled = clockExhaustible || securedBasketball || q.winProbability !== null && (q.winProbability >= probabilityBoundary || q.winProbability <= 1 - probabilityBoundary) && late && t !== null && t <= 30;
  const high = p.rating >= 85 && (wideLate || impossible || settled);
  const intermissionSoon = reg[sport] && period < reg[sport] && t !== null && t <= 30;
  const lateRunwayUnknown = late && t !== null && t <= 30 && (["NFL", "CFB"].includes(sport) && !q.possession || ["NBA", "NCAAB"].includes(sport) && m > 3 && (q.winProbability === null || q.winProbability < 0.1 || q.winProbability > 0.9));
  if (lateRunwayUnknown) gaps.push("Late comeback feasibility not established; withhold underrated classification");
  return {
    signals,
    gaps,
    wideLate,
    impossible,
    settled,
    high,
    low: !intermissionSoon && !lateRunwayUnknown && !impossible && !settled && p.rating !== null && p.rating < 85 && (signals.some((s) => /Decisive|Meaningful|overtime|Late tying|no-hit|match point|Credible|Substantial|Championship/.test(s)) || sport === "Tennis" && signals.includes("Verified deciding set") && (q.tiebreak === true || q.grandSlam) || sport === "NHL" && signals.includes("Late one-goal opportunity") && (q.goaliePulled === true || q.powerPlayTeamId !== null))
  };
}
__name(inspect, "inspect");
function finding(p, a, direction) {
  const missing = a.gaps.length > 0, blocked = p.integrity.length > 0 || p.q.rejected || p.q.scoringPartial || p.q.evidenceQuality !== "complete";
  return {
    gameKey: p.gameKey,
    matchup: p.matchup,
    sport: p.sport,
    direction,
    classification: p.integrity.length ? "confirmed_integrity_failure" : blocked ? "missing_or_unreliable_evidence" : "calibration_hypothesis",
    confidence: blocked ? "low" : missing ? "medium" : "high",
    modelVersion: p.modelVersion,
    observedAt: p.observedAt,
    publishedAt: p.publishedAt,
    period: p.period,
    clockSeconds: p.clockSeconds,
    scores: p.scores,
    rating: p.rating,
    signals: a.signals,
    evidence: { margin: p.margin, ...p.q },
    sourceReference: p.sourceReference,
    sourceEvent: p.event,
    missingEvidence: a.gaps,
    integrityProblems: p.integrity,
    suspectedCause: direction === "overrated" ? p.q.historyPoints > 0 ? "Past excitement may be retained after current leverage fades" : "High current rating despite low observed comeback feasibility" : "Current leverage or underdog threat may be recognized too weakly or too late",
    recommendedCorrection: blocked ? "Repair evidence before calibrating; replay the accepted observation" : direction === "overrated" ? "Replay decay and current feasibility separately from earned historical drama" : "Review causal event response and sport scale against matched complete-evidence games",
    estimatedImpact: {
      productionScoreDelta: 0,
      productionAlertsDelta: 0,
      candidateScoreDelta: null,
      candidateAlerts: null,
      reviewDistanceTo85: 85 - p.rating,
      explanation: "Audit only. A calibrated candidate and chronological eligibility replay are required to estimate a scoring or alert change."
    }
  };
}
__name(finding, "finding");
function percentile(a, q) {
  const s = a.filter(Number.isFinite).sort((a2, b) => a2 - b);
  return s.length ? s[Math.floor((s.length - 1) * q)] : null;
}
__name(percentile, "percentile");
function calibration(games, sport, model) {
  let group = games.filter((g) => g.sport === sport && (model === void 0 || g.modelVersion === model));
  if (model === void 0) {
    const unique = /* @__PURE__ */ new Map();
    for (const g of group) {
      const old = unique.get(g.gameKey);
      if (!old) unique.set(g.gameKey, { ...g });
      else unique.set(g.gameKey, {
        ...g,
        peakRating: old.peakRating === null ? g.peakRating : g.peakRating === null ? old.peakRating : Math.max(old.peakRating, g.peakRating),
        coveredSeconds: old.coveredSeconds + g.coveredSeconds,
        estimatedSecondsAbove85: old.estimatedSecondsAbove85 + g.estimatedSecondsAbove85,
        unknownIntervalSeconds: old.unknownIntervalSeconds + g.unknownIntervalSeconds,
        decisiveMoments: [...old.decisiveMoments, ...g.decisiveMoments],
        eventResponses: [...old.eventResponses, ...g.eventResponses],
        evidenceGaps: [.../* @__PURE__ */ new Set([...old.evidenceGaps, ...g.evidenceGaps])],
        significant: old.significant || g.significant
      });
    }
    group = [...unique.values()];
  }
  const peaks = group.map((g) => g.peakRating).filter(Number.isFinite);
  return {
    sport,
    modelVersion: model ?? "all (see model cohorts)",
    gamesObserved: group.length,
    gamesWithRating: peaks.length,
    percentageReaching: Object.fromEntries(THRESHOLDS.map((t) => [t, peaks.length ? 100 * peaks.filter((p) => p >= t).length / peaks.length : null])),
    peakDistribution: { min: peaks.length ? Math.min(...peaks) : null, p25: percentile(peaks, 0.25), median: percentile(peaks, 0.5), p75: percentile(peaks, 0.75), max: peaks.length ? Math.max(...peaks) : null },
    estimatedSecondsAbove85: group.some((g) => g.coveredSeconds > 0) ? group.reduce((s, g) => s + g.estimatedSecondsAbove85, 0) : null,
    coveredSeconds: group.reduce((s, g) => s + g.coveredSeconds, 0),
    unknownIntervalSeconds: group.reduce((s, g) => s + g.unknownIntervalSeconds, 0),
    decisiveMoments: group.flatMap((g) => g.decisiveMoments),
    eventResponses: group.flatMap((g) => g.eventResponses),
    significantNeverReached85: group.filter((g) => g.significant && g.peakRating !== null && g.peakRating < 85).map((g) => ({ gameKey: g.gameKey, peakRating: g.peakRating, evidence: g.decisiveMoments[0], coverage: "Retained sampled window only" })),
    evidenceGaps: [...new Set(group.flatMap((g) => g.evidenceGaps))],
    comparability85: peaks.length ? "Unvalidated: sampled, selected games and unequal evidence coverage cannot establish an equivalent 85" : "No live evidence; equivalence unavailable"
  };
}
__name(calibration, "calibration");
function buildScoringQuality(inputGames = []) {
  const games = [], over = [], under = [], points = [], integrity = [], missing = [];
  for (const game of inputGames) {
    const seen = /* @__PURE__ */ new Set(), ps = [];
    for (const observation of [...game.observations || []].sort((a, b) => (time(a.observedAt) ?? 0) - (time(b.observedAt) ?? 0))) {
      const p = point(observation, game);
      p.teamIds = (observation.state?.teams || []).map((t) => String(t?.[8] ?? ""));
      if (!p.live || !QUALITY_SPORTS.includes(p.sport)) continue;
      const key = p.feedRevision ? `${p.modelVersion}|${p.feedRevision}` : `${p.modelVersion}|${p.observedAt}|${observation.sourceEvent?.id ?? ""}`;
      if (seen.has(key)) continue;
      seen.add(key);
      ps.push(p);
    }
    for (const modelVersion of new Set(ps.map((p) => p.modelVersion))) {
      const history = [], decisiveMoments = [], eventResponses = [], pending = [], evidenceGaps = /* @__PURE__ */ new Set();
      let coveredSeconds = 0, unknownIntervalSeconds = 0, estimatedSecondsAbove85 = 0;
      for (const p of ps.filter((p2) => p2.modelVersion === modelVersion)) {
        const a = inspect(p, history), prior = history.at(-1);
        p.assessment = a;
        points.push(p);
        a.gaps.forEach((x) => evidenceGaps.add(x));
        if (p.integrity.length) integrity.push({ gameKey: p.gameKey, observedAt: p.observedAt, codes: p.integrity, classification: "confirmed_integrity_failure" });
        if (a.high) over.push(finding(p, a, "overrated"));
        if (a.low) under.push(finding(p, a, "underrated"));
        if (a.signals.length) decisiveMoments.push({
          gameKey: p.gameKey,
          observedAt: p.observedAt,
          publishedAt: p.publishedAt,
          period: p.period,
          clockSeconds: p.clockSeconds,
          scores: p.scores,
          rating: p.rating,
          signals: a.signals,
          evidenceGaps: a.gaps,
          sourceReference: p.sourceReference,
          sourceEvent: p.event
        });
        if (prior && !p.historical && !prior.historical) {
          const dt = p.publishedAt !== null && prior.publishedAt !== null ? (p.publishedAt - prior.publishedAt) / 1e3 : null;
          if (p.publishedAt !== null && prior.publishedAt !== null && dt > 0 && dt <= 360 && p.rating !== null && prior.rating !== null && !p.q.rejected && !prior.q.rejected && !p.integrity.length && !prior.integrity.length && p.observedAt !== null && prior.observedAt !== null && p.observedAt >= p.publishedAt && prior.observedAt >= prior.publishedAt && p.observedAt - p.publishedAt <= 18e4 && prior.observedAt - prior.publishedAt <= 18e4) {
            coveredSeconds += dt;
            if (prior.rating > 85) estimatedSecondsAbove85 += dt;
          } else if (dt > 0 && Number.isFinite(dt)) unknownIntervalSeconds += dt;
        }
        if (p.event && !pending.some((e) => e.event.id === p.event.id) && !eventResponses.some((e) => e.event.id === p.event.id)) {
          const eventTime = time(p.event.occurredAt), before = [...history].reverse().find((x) => x.publishedAt !== null && eventTime !== null && x.publishedAt < eventTime);
          pending.push({ event: p.event, eventTime, baseline: before?.rating ?? null, gameKey: p.gameKey, firstObservedAt: p.observedAt, observationsUntilChange: 0 });
        }
        for (let i = pending.length - 1; i >= 0; i--) {
          const e = pending[i];
          e.observationsUntilChange++;
          if (e.baseline !== null && p.rating !== null && p.rating - e.baseline >= 3 && p.publishedAt !== null && p.publishedAt >= e.eventTime) {
            eventResponses.push({
              ...e,
              rating: p.rating,
              responsePublishedAt: p.publishedAt,
              eventToObservedRiseMs: p.publishedAt - e.eventTime,
              status: "observed association; causality unproven",
              resolution: "Audit cadence; event time is not provider publication time"
            });
            pending.splice(i, 1);
          }
        }
        history.push(p);
      }
      eventResponses.push(...pending.map((e) => ({ ...e, eventToObservedRiseMs: null, status: e.baseline === null ? "unavailable: no reliable pre-event publication" : "right-censored: no observed 3-point rise" })));
      const ratings = history.map((p) => p.rating).filter((x) => x !== null), sport = history[0]?.sport || game.sport;
      games.push({
        gameKey: game.gameKey,
        matchup: game.matchup,
        sport,
        modelVersion,
        observations: history.length,
        peakRating: ratings.length ? Math.max(...ratings) : null,
        coveredSeconds,
        estimatedSecondsAbove85,
        unknownIntervalSeconds,
        decisiveMoments,
        eventResponses,
        significant: decisiveMoments.length > 0,
        evidenceGaps: [...evidenceGaps],
        watchability: {
          earlyDramaThenBlowout: history.some((p, i) => p.assessment.wideLate && history.slice(0, i).some((x) => x.rating >= 85)),
          lateEmergence: history.some((p, i) => p.assessment.signals.length > 0 && history.slice(0, i).some((x) => !x.assessment.signals.length)),
          competitiveUnderdog: history.some((p) => p.assessment.signals.includes("Credible observed underdog threat")),
          closeButSettled: history.some((p) => p.assessment.settled),
          retainedHistoryDuringBlowout: history.some((p) => p.assessment.wideLate && p.q.historyPoints > 0)
        }
      });
      if (evidenceGaps.size) missing.push({ gameKey: game.gameKey, modelVersion, classification: "missing_or_unreliable_evidence", gaps: [...evidenceGaps] });
    }
  }
  const top = /* @__PURE__ */ __name((rows3, dir) => {
    const sorted = rows3.sort((a, b) => (dir === "overrated" ? b.rating - a.rating : a.rating - b.rating) || String(a.gameKey).localeCompare(String(b.gameKey)));
    const unique = /* @__PURE__ */ new Map();
    for (const r of sorted) if (!unique.has(r.gameKey)) unique.set(r.gameKey, r);
    return [...unique.values()].slice(0, 10);
  }, "top");
  const concurrent = /* @__PURE__ */ new Map();
  for (const p of points.filter((p2) => !p2.historical && (p2.feedRevision || p2.runId !== null))) {
    const key = p.modelVersion + "|" + (p.feedRevision || p.runId);
    if (!concurrent.has(key)) concurrent.set(key, []);
    concurrent.get(key).push(p);
  }
  const simultaneous = [];
  for (const ps of concurrent.values()) {
    const eligible = ps.filter((p) => p.rating !== null && !p.integrity.length && !p.q.rejected && p.publishedAt !== null && p.observedAt - p.publishedAt >= 0 && p.observedAt - p.publishedAt <= 18e4);
    if (eligible.length < 2) continue;
    const highest = Math.max(...eligible.map((p) => p.rating)), leaders = eligible.filter((p) => p.rating === highest), challengers = eligible.filter((p) => p.assessment.low && p.rating < highest);
    if (leaders.some((p) => p.assessment.high) && challengers.length) simultaneous.push({
      observedAt: leaders[0].observedAt,
      feedRevision: leaders[0].feedRevision,
      leaders: leaders.map((p) => ({ gameKey: p.gameKey, rating: p.rating, scores: p.scores })),
      challengers: challengers.map((p) => ({ gameKey: p.gameKey, rating: p.rating, signals: p.assessment.signals })),
      classification: "calibration_hypothesis"
    });
  }
  return {
    version: QUALITY_VERSION,
    mode: "observation-only",
    methodology: {
      denominator: "Unique observed live games within each model cohort; never completed ratings",
      timeAbove85: "Left-held sampled estimate strictly >85, fresh publications <=6 minutes apart; gaps and replay duration excluded",
      reaction: "First observed >=3-point rise after a timestamped event with a pre-event baseline; association only, otherwise censored/unavailable",
      provenance: "Observed production and causal reconstructions must be reported separately",
      providerToPublicationLatency: "Unavailable unless verified provider publication timestamps exist; no acquisition-time substitution",
      costs: "No added provider/AI requests, schedules, storage rows or notifications"
    },
    topOverrated: top(over, "overrated"),
    topUnderrated: top(under, "underrated"),
    calibration: QUALITY_SPORTS.map((s) => calibration(games, s)),
    modelCohorts: [...new Set(games.map((g) => g.modelVersion))].map((model) => ({
      modelVersion: model,
      sports: QUALITY_SPORTS.map((s) => calibration(games, s, model)),
      topOverrated: top(over.filter((r) => r.modelVersion === model), "overrated"),
      topUnderrated: top(under.filter((r) => r.modelVersion === model), "underrated")
    })),
    games,
    simultaneousPriorityConflicts: simultaneous,
    integrityProblems: integrity,
    missingEvidence: missing,
    confirmedScoringDefects: [],
    limitations: [
      "Candidate lists are review prompts, not objective labels or evidence of delivered alerts.",
      "Final closeness never establishes earlier live excitement. Missing states do not establish uneventful play.",
      "No causal attribution or precise event/publication latency from sparse audit samples. No sport-equivalence claim from selected archives."
    ]
  };
}
__name(buildScoringQuality, "buildScoringQuality");

// src/export.js
var dateFormatter = new Intl.DateTimeFormat("en-US", { timeZone: "America/New_York", year: "numeric", month: "2-digit", day: "2-digit" });
function slateDateNY(value) {
  const at = typeof value === "number" ? value : Date.parse(String(value || ""));
  if (!Number.isFinite(at)) return null;
  const parts = Object.fromEntries(dateFormatter.formatToParts(at).map((part) => [part.type, part.value]));
  return `${parts.year}-${parts.month}-${parts.day}`;
}
__name(slateDateNY, "slateDateNY");
function midnightNY(date) {
  const noon = Date.parse(`${date}T12:00:00Z`);
  const localHour = Number(new Intl.DateTimeFormat("en-US", { timeZone: "America/New_York", hour: "2-digit", hourCycle: "h23" }).format(noon));
  return Date.parse(`${date}T00:00:00Z`) - (localHour - 12) * 36e5;
}
__name(midnightNY, "midnightNY");
function nextDay(date) {
  return new Date(Date.parse(`${date}T12:00:00Z`) + 864e5).toISOString().slice(0, 10);
}
__name(nextDay, "nextDay");
function previousDay(date) {
  return new Date(Date.parse(`${date}T12:00:00Z`) - 864e5).toISOString().slice(0, 10);
}
__name(previousDay, "previousDay");
var rows = /* @__PURE__ */ __name(async (statement) => (await statement.all()).results || [], "rows");
var parse = /* @__PURE__ */ __name((value) => {
  try {
    return JSON.parse(value);
  } catch {
    return null;
  }
}, "parse");
var sensitive = /password|secret|api.?key|auth(?:orization)?|bearer|credential|cookie|private.?key|token/i;
function scrub(value, key = "") {
  if (sensitive.test(key)) return "[REDACTED]";
  if (Array.isArray(value)) return value.map((item) => scrub(item));
  if (value && typeof value === "object") return Object.fromEntries(Object.entries(value).map(([k, v]) => [k, scrub(v, k)]));
  if (typeof value !== "string") return value;
  if (/\bBearer\s+\S+|\b(?:api[_-]?key|access[_-]?token|password|secret)=/i.test(value)) return "[REDACTED]";
  if (/^https?:\/\//i.test(value)) {
    try {
      const url = new URL(value);
      if (!["site.api.espn.com", "api-web.nhle.com"].includes(url.hostname)) return "[EXTERNAL_URL_REDACTED]";
      const event = url.searchParams.get("event");
      return `${url.origin}${url.pathname}${event ? `?event=${encodeURIComponent(event)}` : ""}`;
    } catch {
      return "[INVALID_URL_REDACTED]";
    }
  }
  return value;
}
__name(scrub, "scrub");
async function defaultSlateDate(env, feed, now = Date.now()) {
  const candidates = await rows(env.DB.prepare(`SELECT DISTINCT slate_date FROM live_audit_observations
    WHERE slate_date IS NOT NULL ORDER BY slate_date DESC LIMIT 30`));
  const unfinished = new Set((feed?.games || []).filter((game) => ["live", "upcoming"].includes(game.state)).map((game) => slateDateNY(game.startTime)).filter(Boolean));
  const availableDates = candidates.map((row) => row.slate_date);
  const defaultDate = availableDates.find((date) => !unfinished.has(date)) || previousDay(slateDateNY(now));
  return { defaultDate, availableDates, timeZone: "America/New_York" };
}
__name(defaultSlateDate, "defaultSlateDate");
async function gameKeys(env, date) {
  const out = [];
  let after = "";
  for (; ; ) {
    const batch = await rows(env.DB.prepare(`SELECT DISTINCT game_key FROM live_audit_observations
      WHERE slate_date=? AND game_key>? ORDER BY game_key LIMIT 100`).bind(date, after));
    if (!batch.length) break;
    out.push(...batch.map((row) => row.game_key));
    after = batch.at(-1).game_key;
    if (batch.length < 100) break;
  }
  return out;
}
__name(gameKeys, "gameKeys");
async function gameObservations(env, date, key) {
  const out = [];
  let after = -1;
  for (; ; ) {
    const batch = await rows(env.DB.prepare(`SELECT run_id,game_key,observed_at,slate_date,sport,state_bucket,rating,
      score_a,score_b,period,clock_seconds,evidence FROM live_audit_observations
      WHERE slate_date=? AND game_key=? AND observed_at>? ORDER BY observed_at LIMIT 300`).bind(date, key, after));
    if (!batch.length) break;
    out.push(...batch);
    after = batch.at(-1).observed_at;
    if (batch.length < 300) break;
  }
  return out;
}
__name(gameObservations, "gameObservations");
function compactSnapshot(row) {
  const state = parse(row.normalized_state) || {};
  return scrub({
    observedAt: row.observed_at,
    state: row.state,
    rating: row.rating,
    scores: [row.score_a, row.score_b],
    period: Number(row.phase) || null,
    clock: row.clock,
    modelVersion: row.model_version,
    phaseLabel: state.live?.phase || state.status || null,
    explanation: state.why || null,
    moment: state.moment || null,
    factors: state.factors || [],
    momentumText: state.momentumText || null,
    rawInputReference: { table: "sports_snapshots", gameKey: row.game_key, observedAt: row.observed_at }
  });
}
__name(compactSnapshot, "compactSnapshot");
async function snapshotContext(env, key, times) {
  const selected = /* @__PURE__ */ new Map();
  for (const at of [...new Set(times)].sort((a, b) => a - b)) {
    const batch = await rows(env.DB.prepare(`SELECT game_key,observed_at,state,rating,score_a,score_b,phase,clock,
      normalized_state,model_version FROM sports_snapshots WHERE game_key=? AND observed_at>=? AND observed_at<=?
      ORDER BY observed_at LIMIT 160`).bind(key, at - 10 * 6e4, at + 10 * 6e4));
    for (const row of batch) selected.set(row.observed_at, compactSnapshot(row));
  }
  const final = await env.DB.prepare(`SELECT game_key,observed_at,state,rating,score_a,score_b,phase,clock,
    normalized_state,model_version FROM sports_snapshots WHERE game_key=? AND state='completed'
    ORDER BY observed_at DESC LIMIT 1`).bind(key).first();
  if (final) selected.set(final.observed_at, compactSnapshot(final));
  return [...selected.values()].sort((a, b) => a.observedAt - b.observedAt);
}
__name(snapshotContext, "snapshotContext");
function mergeFindings(gameKey, observations, stored, events) {
  const map = /* @__PURE__ */ new Map();
  for (const observation of observations) for (const candidate2 of observation.auditCandidates || []) {
    const id = candidate2.reasonCode;
    if (!map.has(id)) map.set(id, {
      gameKey,
      reasonCode: id,
      firstSeen: observation.observedAt,
      lastSeen: observation.observedAt,
      observationsDetected: 0,
      events: [],
      status: "watch",
      ...candidate2
    });
    const entry = map.get(id);
    entry.lastSeen = observation.observedAt;
    entry.observationsDetected++;
  }
  for (const row of stored) {
    const evidence = parse(row.evidence) || {}, id = row.reason_code;
    const entry = map.get(id) || { gameKey, reasonCode: id, events: [], observationsDetected: 0 };
    Object.assign(entry, {
      firstSeen: row.first_seen,
      lastSeen: row.last_seen,
      resolvedAt: row.resolved_at,
      status: row.status,
      severity: row.severity,
      confidence: row.confidence,
      failureLayer: row.failure_layer,
      observed: evidence.observed ?? entry.observed,
      expected: evidence.expected ?? entry.expected,
      detail: evidence.detail ?? entry.detail,
      deterministic: evidence.deterministic ?? entry.deterministic,
      affectedGames: evidence.affectedGames || [gameKey],
      supportingEvidence: evidence.rawInputReferences || []
    });
    map.set(id, entry);
  }
  for (const event of events) {
    const evidence = parse(event.evidence) || {}, id = event.reason_code;
    const entry = map.get(id) || { gameKey, reasonCode: id, events: [], observationsDetected: 0 };
    entry.events.push({ at: event.at, type: event.event, evidence: scrub(evidence) });
    entry.firstSeen = Math.min(entry.firstSeen || event.at, event.at);
    entry.lastSeen = Math.max(entry.lastSeen || event.at, event.at);
    entry.severity ||= evidence.severity;
    entry.confidence ||= evidence.confidence;
    entry.failureLayer ||= evidence.failureLayer;
    entry.observed ||= evidence.observed;
    entry.expected ||= evidence.expected;
    entry.detail ||= evidence.detail;
    entry.deterministic ??= evidence.deterministic;
    entry.affectedGames ||= evidence.affectedGames || [gameKey];
    if (!stored.some((row) => row.reason_code === id)) entry.status = event.event === "recovered" ? "recovered" : "open";
    map.set(id, entry);
  }
  return [...map.values()].map((item) => scrub({
    ...item,
    classification: item.deterministic ? "confirmed_integrity_failure" : "heuristic_concern",
    corroborated: item.deterministic || item.events.some((event) => event.type === "opened")
  })).sort((a, b) => (a.firstSeen || 0) - (b.firstSeen || 0));
}
__name(mergeFindings, "mergeFindings");
function markdownEscape(value) {
  return String(value ?? "").replace(/[|\r\n]/g, " ").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
__name(markdownEscape, "markdownEscape");
function renderSummary(data) {
  const m = data.metadata, h = data.sourceHealth;
  const lines = [
    `# SlateMeter nightly audit \u2014 ${m.slateDateNewYork}`,
    "",
    "This archive is an observation-only audit export for ChatGPT and Codex investigation. Heuristic concerns are review prompts, not verified scoring defects.",
    "",
    `- Generated: ${m.generatedAt}`,
    `- Original slate date: ${m.slateDateNewYork} (America/New_York; games finishing after midnight stay with this date)`,
    `- Audit version: ${m.auditVersion}`,
    `- Scoring model versions: ${m.scoringModelVersions.join(", ") || "unavailable"}`,
    `- Games monitored: ${m.gamesMonitored}`,
    `- Slate scans with game observations: ${m.totalScans}`,
    `- Scheduled runs in observed window: ${h.scheduledRuns}`,
    `- Findings: ${m.findingsCount} (${m.integrityFailures} deterministic integrity failures, ${m.heuristicConcerns} heuristic concerns)`,
    `- Missing observation intervals: ${m.missingObservationIntervals}`,
    `- Coverage gaps: ${data.coverageGaps.length}`,
    "",
    "## Source health",
    "",
    `- Completed scan runs: ${h.completedRuns}; failed runs: ${h.failedRuns}`,
    `- Maximum feed age at scan: ${h.maxFeedAgeMs == null ? "unknown" : Math.round(h.maxFeedAgeMs / 1e3) + " seconds"}`,
    `- Audit provider requests: ${h.providerRequests}`,
    "",
    "## Every monitored game",
    "",
    "| Game | Sport | Start (New York slate) | Observations | Rating range | Findings |",
    "| --- | --- | --- | ---: | --- | ---: |"
  ];
  for (const game of data.games) lines.push(`| ${markdownEscape(game.matchup || game.gameKey)} | ${markdownEscape(game.sport)} | ${markdownEscape(game.startTime || "unknown")} | ${game.observations.length} | ${game.minRating ?? "\u2014"}\u2013${game.maxRating ?? "\u2014"} | ${game.findings.length} |`);
  if (!data.games.length) lines.push("| No live games observed | \u2014 | \u2014 | 0 | \u2014 | 0 |");
  lines.push("", "## Findings", "");
  for (const finding2 of data.findings) lines.push(`- **${markdownEscape(finding2.severity || "unknown")} \xB7 ${markdownEscape(finding2.reasonCode)} \xB7 ${markdownEscape(finding2.gameKey)}** \u2014 ${markdownEscape(finding2.classification)}, ${markdownEscape(finding2.status)}. ${markdownEscape(finding2.detail || "")} First ${new Date(finding2.firstSeen).toISOString()}; last ${new Date(finding2.lastSeen).toISOString()}.`);
  if (!data.findings.length) lines.push("No findings recorded for these games.");
  lines.push("", "## Coverage gaps and missing observations", "");
  for (const gap of data.coverageGaps) lines.push(`- ${markdownEscape(gap.gameKey || "slate")}: ${markdownEscape(gap.code)} \u2014 ${markdownEscape(gap.detail)}`);
  if (!data.coverageGaps.length) lines.push("No coverage gaps detected in retained audit observations.");
  if (data.scoringQuality) lines.push(...qualitySummary(data.scoringQuality));
  lines.push(
    "",
    "## Investigation guide",
    "",
    "Use `findings.json` for the full timestamped observations, rating deltas, finding evidence, recovery events, and stored scoring snapshots around each anomaly. Inspect provider and clock issues before proposing a scoring change. Preserve current scoring behavior until a separate fix is tested.",
    ""
  );
  return lines.join("\n");
}
__name(renderSummary, "renderSummary");
async function buildNightlyExport(env, date, { feed = null, now = Date.now() } = {}) {
  const keys = await gameKeys(env, date), games = [], coverageGaps = [];
  const feedGames = new Map((feed?.games || []).map((game) => [`${game.sport}:${game.id}`, game]));
  const runIds = /* @__PURE__ */ new Set();
  let firstAt = Infinity, lastAt = -Infinity, missingIntervals = 0;
  for (const key of keys) {
    const raw = await gameObservations(env, date, key), observations = [];
    for (const row of raw) {
      const evidence = parse(row.evidence) || {};
      observations.push(scrub({
        runId: row.run_id,
        observedAt: row.observed_at,
        slateDate: row.slate_date,
        rating: row.rating,
        ratingChange: observations.length ? row.rating - observations.at(-1).rating : null,
        scores: [row.score_a, row.score_b],
        period: row.period,
        clockSeconds: row.clock_seconds,
        stateBucket: row.state_bucket,
        state: evidence.state || null,
        scoringVersion: evidence.scoringVersion || null,
        auditVersion: evidence.auditVersion || null,
        feedRevision: evidence.feedRevision || null,
        qualityEvidence: evidence.qualityEvidence || null,
        feedUpdatedAt: evidence.feedUpdatedAt || null,
        sourceFreshnessMs: evidence.sourceFreshnessMs || null,
        rawInputReferences: evidence.rawInputReferences || [],
        auditCandidates: evidence.auditCandidates || []
      }));
      runIds.add(row.run_id);
      firstAt = Math.min(firstAt, row.observed_at);
      lastAt = Math.max(lastAt, row.observed_at);
    }
    for (let i = 1; i < observations.length; i++) if (observations[i].observedAt - observations[i - 1].observedAt > 6 * 6e4) {
      missingIntervals++;
      coverageGaps.push({
        gameKey: key,
        code: "OBSERVATION_GAP",
        from: observations[i - 1].observedAt,
        to: observations[i].observedAt,
        detail: `${Math.round((observations[i].observedAt - observations[i - 1].observedAt) / 6e4)} minutes between audit observations`
      });
    }
    const first = observations[0], state = first?.state || {}, startTime = state.startTime || feedGames.get(key)?.startTime || null;
    if (!startTime) coverageGaps.push({ gameKey: key, code: "START_TIME_MISSING", detail: "Original scheduled start time was not retained" });
    else if (slateDateNY(startTime) !== date) coverageGaps.push({ gameKey: key, code: "SLATE_DATE_CONFLICT", detail: "Original start time disagrees with stored slate date" });
    if (feedGames.get(key)?.state === "live") coverageGaps.push({ gameKey: key, code: "SLATE_STILL_LIVE", detail: "Game remained live at export time; this is a partial slate export" });
    const stored = await rows(env.DB.prepare("SELECT * FROM live_audit_findings WHERE game_key=?").bind(key));
    const events = await rows(env.DB.prepare("SELECT * FROM live_audit_events WHERE game_key=? ORDER BY at").bind(key));
    const findings2 = mergeFindings(key, observations, stored, events);
    const times = findings2.flatMap((f) => [f.firstSeen, f.lastSeen, ...f.events.map((e) => e.at)]).filter(Number.isFinite);
    const snapshots = await snapshotContext(env, key, times);
    const scores = observations.map((item) => item.rating).filter(Number.isFinite);
    games.push({
      gameKey: key,
      sport: key.split(":")[0],
      matchup: (state.teams || []).map((team) => team?.[0]).join(" vs ") || key,
      startTime,
      slateDateNewYork: date,
      currentState: feedGames.get(key)?.state || "not in current feed",
      firstObservedAt: first?.observedAt || null,
      lastObservedAt: observations.at(-1)?.observedAt || null,
      minRating: scores.length ? Math.min(...scores) : null,
      maxRating: scores.length ? Math.max(...scores) : null,
      observations,
      findings: findings2,
      surroundingScoringSnapshots: snapshots
    });
  }
  if (!keys.length) coverageGaps.push({ code: "NO_LIVE_OBSERVATIONS", detail: "No live games were monitored for this original New York slate date" });
  const start = Number.isFinite(firstAt) ? firstAt - 18e4 : midnightNY(date), end2 = Number.isFinite(lastAt) ? lastAt + 18e4 : midnightNY(nextDay(date));
  const runs = await rows(env.DB.prepare("SELECT * FROM live_audit_runs WHERE started_at>=? AND started_at<=? ORDER BY started_at LIMIT 1000").bind(start, end2));
  const ages = runs.map((run) => run.feed_updated_at ? run.started_at - run.feed_updated_at : null).filter(Number.isFinite);
  const globalRows = await rows(env.DB.prepare(`SELECT * FROM live_audit_findings
    WHERE game_key='feed' OR game_key LIKE 'sport:%'`));
  const globalEvents = await rows(env.DB.prepare(`SELECT * FROM live_audit_events WHERE at>=? AND at<=?
    AND (game_key='feed' OR game_key LIKE 'sport:%') ORDER BY at`).bind(start, end2));
  const globalKeys = /* @__PURE__ */ new Set([
    ...globalRows.filter((row) => row.first_seen <= end2 && row.last_seen >= start).map((row) => row.game_key),
    ...globalEvents.map((row) => row.game_key)
  ]);
  const globalFindings = [...globalKeys].flatMap((key) => mergeFindings(
    key,
    [],
    globalRows.filter((row) => row.game_key === key && row.first_seen <= end2 && row.last_seen >= start),
    globalEvents.filter((row) => row.game_key === key)
  ));
  const findings = [...games.flatMap((game) => game.findings), ...globalFindings];
  const scoringModelVersions = [...new Set([...runs.map((run) => run.model_version), ...games.flatMap((game) => game.observations.map((o) => o.scoringVersion))].filter(Boolean))];
  if (runs.some((run) => run.error)) coverageGaps.push({ code: "SCAN_FAILURE", detail: `${runs.filter((run) => run.error).length} scheduled audit runs failed during the observed window` });
  const sourceHealth = {
    scheduledRuns: runs.length,
    completedRuns: runs.filter((run) => run.finished_at && !run.error).length,
    failedRuns: runs.filter((run) => run.error).length,
    maxFeedAgeMs: ages.length ? Math.max(...ages) : null,
    providerRequests: runs.reduce((sum, run) => sum + Number(run.provider_requests || 0), 0),
    runErrors: runs.filter((run) => run.error).map((run) => ({ at: run.started_at, error: run.error })),
    providerAndSportFindings: globalFindings
  };
  const data = scrub({
    metadata: {
      schemaVersion: 2,
      auditVersion: AUDIT_VERSION,
      generatedAt: new Date(now).toISOString(),
      slateDateNewYork: date,
      timeZone: "America/New_York",
      scoringModelVersions,
      totalScans: runIds.size,
      gamesMonitored: games.length,
      findingsCount: findings.length,
      integrityFailures: findings.filter((f) => f.classification === "confirmed_integrity_failure").length,
      heuristicConcerns: findings.filter((f) => f.classification === "heuristic_concern").length,
      missingObservationIntervals: missingIntervals,
      complete: !coverageGaps.length
    },
    sourceHealth,
    coverageGaps,
    games,
    findings,
    scoringQuality: buildScoringQuality(games)
  });
  return { data, summary: renderSummary(data) };
}
__name(buildNightlyExport, "buildNightlyExport");
function qualitySummary(q) {
  const fmt = /* @__PURE__ */ __name((v) => v === null || v === void 0 ? "unavailable" : typeof v === "number" ? String(Math.round(v * 10) / 10) : markdownEscape(v), "fmt");
  const lines = [
    "",
    "## Scoring Quality",
    "",
    "Potential outliers require review. Missing evidence is not proof that nothing happened. Ratings and alerts are unchanged.",
    "",
    `Method: ${q.methodology.denominator}. ${q.methodology.timeAbove85}.`,
    "",
    "| Sport | Games with ratings | Reached 70 / 80 / 85 / 90 / 95 (%) | Peak median | Estimated seconds >85 |",
    "| --- | ---: | --- | ---: | ---: |"
  ];
  for (const s of q.calibration) lines.push(`| ${s.sport === "NCAAB" ? "NCAAM" : s.sport} | ${s.gamesWithRating} | ${Object.values(s.percentageReaching).map(fmt).join(" / ")} | ${fmt(s.peakDistribution.median)} | ${fmt(s.estimatedSecondsAbove85)} |`);
  if (q.modelCohorts.length > 1) lines.push("", "Multiple model versions are present. Compare the separate modelCohorts in findings.json; the overview is not a release baseline.");
  for (const [label, rows3] of [["Top 10 potentially overrated games", q.topOverrated], ["Top 10 potentially underrated games", q.topUnderrated]]) {
    lines.push("", `### ${label}`, "");
    if (!rows3.length) lines.push("No supported candidates in the retained window; this does not establish scoring correctness.");
    for (const r of rows3) lines.push(`- **${markdownEscape(r.matchup)} (${r.gameKey})**: ${r.scores.join("-")}, period ${r.period}, clock ${fmt(r.clockSeconds)}s, rating ${r.rating}; observed ${r.observedAt === null ? "unavailable" : new Date(r.observedAt).toISOString()}; model ${markdownEscape(r.modelVersion)}. ${r.classification}, ${r.confidence} confidence. Evidence: ${markdownEscape(r.signals.join("; ") || "wide margin / low comeback feasibility")}. Suspected cause: ${r.suspectedCause}. Correction: ${r.recommendedCorrection}. Missing: ${markdownEscape(r.missingEvidence.join("; "))}. Impact: production 0 rating points / 0 alerts; candidate impact unknown until replay.`);
  }
  lines.push(
    "",
    "### Evidence and calibration limits",
    "",
    `- Integrity failures: ${q.integrityProblems.length}; game/model evidence-gap groups: ${q.missingEvidence.length}; simultaneous priority conflicts: ${q.simultaneousPriorityConflicts.length}.`,
    "- Full game/model cohorts, decisive moment timestamps and ratings, censored event responses, watchability checks, and significant games never observed at 85 are in findings.json \u2192 scoringQuality.",
    "- An equivalent 85 across sports is not established. Retained samples and retrospective archives have different coverage.",
    `- Provider-to-publication latency: ${q.methodology.providerToPublicationLatency}.`
  );
  return lines;
}
__name(qualitySummary, "qualitySummary");

// src/zip.js
var encoder = new TextEncoder();
var table = Uint32Array.from({ length: 256 }, (_, n) => {
  let c = n;
  for (let i = 0; i < 8; i++) c = c & 1 ? 3988292384 ^ c >>> 1 : c >>> 1;
  return c >>> 0;
});
function crc32(bytes2) {
  let crc = 4294967295;
  for (const byte of bytes2) crc = table[(crc ^ byte) & 255] ^ crc >>> 8;
  return (crc ^ 4294967295) >>> 0;
}
__name(crc32, "crc32");
function u16(view, offset, value) {
  view.setUint16(offset, value, true);
}
__name(u16, "u16");
function u32(view, offset, value) {
  view.setUint32(offset, value, true);
}
__name(u32, "u32");
function zipEntries(entries) {
  const files = entries.map(([name, text]) => ({ name: encoder.encode(name), data: encoder.encode(text) }));
  const localLength = files.reduce((sum, file) => sum + 30 + file.name.length + file.data.length, 0);
  const centralLength = files.reduce((sum, file) => sum + 46 + file.name.length, 0);
  const out = new Uint8Array(localLength + centralLength + 22), view = new DataView(out.buffer);
  let cursor = 0, central = localLength;
  for (const file of files) {
    const offset = cursor, crc = crc32(file.data);
    u32(view, cursor, 67324752);
    u16(view, cursor + 4, 20);
    u16(view, cursor + 6, 2048);
    u16(view, cursor + 8, 0);
    u16(view, cursor + 10, 0);
    u16(view, cursor + 12, 0);
    u32(view, cursor + 14, crc);
    u32(view, cursor + 18, file.data.length);
    u32(view, cursor + 22, file.data.length);
    u16(view, cursor + 26, file.name.length);
    u16(view, cursor + 28, 0);
    cursor += 30;
    out.set(file.name, cursor);
    cursor += file.name.length;
    out.set(file.data, cursor);
    cursor += file.data.length;
    u32(view, central, 33639248);
    u16(view, central + 4, 20);
    u16(view, central + 6, 20);
    u16(view, central + 8, 2048);
    u16(view, central + 10, 0);
    u16(view, central + 12, 0);
    u16(view, central + 14, 0);
    u32(view, central + 16, crc);
    u32(view, central + 20, file.data.length);
    u32(view, central + 24, file.data.length);
    u16(view, central + 28, file.name.length);
    u16(view, central + 30, 0);
    u16(view, central + 32, 0);
    u16(view, central + 34, 0);
    u16(view, central + 36, 0);
    u32(view, central + 38, 0);
    u32(view, central + 42, offset);
    central += 46;
    out.set(file.name, central);
    central += file.name.length;
  }
  u32(view, central, 101010256);
  u16(view, central + 4, 0);
  u16(view, central + 6, 0);
  u16(view, central + 8, files.length);
  u16(view, central + 10, files.length);
  u32(view, central + 12, centralLength);
  u32(view, central + 16, localLength);
  u16(view, central + 20, 0);
  return out;
}
__name(zipEntries, "zipEntries");

// src/index.js
var json = /* @__PURE__ */ __name((body, status = 200) => new Response(JSON.stringify(body), { status, headers: { "content-type": "application/json", "cache-control": "no-store" } }), "json");
var dateOnly = /* @__PURE__ */ __name((value) => /^\d{4}-\d{2}-\d{2}$/.test(value || "") && !Number.isNaN(Date.parse(`${value}T00:00:00Z`)) && (/* @__PURE__ */ new Date(`${value}T00:00:00Z`)).toISOString().slice(0, 10) === value, "dateOnly");
function newYorkMidnight(date) {
  const noon = Date.parse(`${date}T12:00:00Z`);
  const hour = Number(new Intl.DateTimeFormat("en-US", { timeZone: "America/New_York", hour: "2-digit", hourCycle: "h23" }).format(noon));
  return Date.parse(`${date}T00:00:00Z`) - (hour - 12) * 36e5;
}
__name(newYorkMidnight, "newYorkMidnight");
var html = /* @__PURE__ */ __name((body, status = 200, headers = {}) => new Response(body, { status, headers: {
  "content-type": "text/html; charset=utf-8",
  "cache-control": "no-store",
  "x-content-type-options": "nosniff",
  "referrer-policy": "no-referrer",
  "content-security-policy": "default-src 'none'; script-src 'self'; style-src 'unsafe-inline'; connect-src 'self'; form-action 'self'; base-uri 'none'",
  ...headers
} }), "html");
var bytes = /* @__PURE__ */ __name((value) => new TextEncoder().encode(value), "bytes");
var hex = /* @__PURE__ */ __name((buffer) => [...new Uint8Array(buffer)].map((byte) => byte.toString(16).padStart(2, "0")).join(""), "hex");
async function signature(secret, payload) {
  const key = await crypto.subtle.importKey("raw", bytes(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  return hex(await crypto.subtle.sign("HMAC", key, bytes(payload)));
}
__name(signature, "signature");
function equal(a, b) {
  if (a.length !== b.length) return false;
  let mismatch = 0;
  for (let i = 0; i < a.length; i++) mismatch |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return mismatch === 0;
}
__name(equal, "equal");
async function authorized(request, env) {
  if (!env.AUDIT_READ_TOKEN) return false;
  if (equal(request.headers.get("Authorization") || "", `Bearer ${env.AUDIT_READ_TOKEN}`)) return true;
  const value = /(?:^|;\s*)slatemeter_audit=([^;]+)/.exec(request.headers.get("Cookie") || "")?.[1] || "";
  const [version, at, sig] = value.split(".");
  if (version !== "v1" || !/^\d{13}$/.test(at) || !/^[a-f0-9]{64}$/.test(sig || "") || Date.now() - Number(at) > 432e5 || Number(at) > Date.now() + 3e4) return false;
  return equal(sig, await signature(env.AUDIT_READ_TOKEN, `v1.${at}`));
}
__name(authorized, "authorized");
var rows2 = /* @__PURE__ */ __name(async (statement) => (await statement.all()).results || [], "rows");
var compact = /* @__PURE__ */ __name((game) => ({
  id: game.id,
  sport: game.sport,
  state: game.state,
  score: game.score,
  baseScore: game.baseScore,
  openingScore: game.openingScore,
  teams: game.teams,
  startTime: game.startTime,
  context: game.context,
  line: game.line,
  why: game.why,
  moment: game.moment,
  momentumText: game.momentumText,
  upsetText: game.upsetText,
  factors: game.factors,
  detailStale: game.detailStale,
  footballSituation: game.footballSituation,
  baseballSituation: game.baseballSituation,
  liveRawStatus: game.liveRawStatus,
  live: game.live,
  status: game.status
}), "compact");
var blob = /* @__PURE__ */ __name((value) => JSON.stringify(value), "blob");
async function feedFromD1(env) {
  const row = await env.DB.prepare("SELECT payload FROM sports_feed WHERE id=1").first();
  if (!row) return null;
  const feed = JSON.parse(row.payload);
  if (feed.revision) {
    const parts = await rows2(env.DB.prepare("SELECT payload FROM sports_feed_parts WHERE revision=? ORDER BY part").bind(feed.revision));
    if (parts.length !== feed.parts) throw new Error("Incomplete canonical feed parts");
    feed.games = parts.flatMap((part) => JSON.parse(part.payload));
  }
  return feed;
}
__name(feedFromD1, "feedFromD1");
function cachedNhlCrosschecks(resources, game, now) {
  const away = String(game.teams?.[0]?.[1] || ""), home = String(game.teams?.[1]?.[1] || "");
  const match = resources.find((row) => {
    const p = row.parsed;
    return p?.awayTeam?.abbrev === away && p?.homeTeam?.abbrev === home && Math.abs(Date.parse(p.startTimeUTC || p.gameDate || game.startTime) - Date.parse(game.startTime)) < 6 * 36e5;
  });
  return match ? {
    scores: [Number(match.parsed.awayTeam.score), Number(match.parsed.homeTeam.score)],
    ageMs: now - match.updated_at,
    source: match.key
  } : null;
}
__name(cachedNhlCrosschecks, "cachedNhlCrosschecks");
function watchCandidate(code, observed, expected, detail, layer = "provider data") {
  return { reasonCode: code, severity: "high", confidence: 0.88, failureLayer: layer, observed, expected, detail, deterministic: false };
}
__name(watchCandidate, "watchCandidate");
async function applyFindings(env, candidates, active, now, scannedKeys) {
  const writes = [], events = [];
  const seen = /* @__PURE__ */ new Set();
  for (const { gameKey, finding: finding2, evidence } of candidates) {
    const id = `${gameKey}|${finding2.reasonCode}`;
    if (seen.has(id)) continue;
    seen.add(id);
    const prior = active.get(id), consecutive = prior && prior.status !== "recovered" ? prior.consecutive + 1 : 1;
    const status = finding2.deterministic || consecutive >= 2 ? "open" : "watch";
    const item = { ...finding2, ...evidence, affectedGames: evidence.affectedGames || [gameKey], likelyFailureLayer: finding2.failureLayer };
    writes.push(env.DB.prepare(`INSERT INTO live_audit_findings
      (game_key,reason_code,first_seen,last_seen,resolved_at,status,consecutive,severity,confidence,failure_layer,evidence)
      VALUES (?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(game_key,reason_code) DO UPDATE SET
      first_seen=CASE WHEN live_audit_findings.status='recovered' THEN excluded.first_seen ELSE live_audit_findings.first_seen END,
      last_seen=excluded.last_seen,resolved_at=NULL,status=excluded.status,consecutive=excluded.consecutive,
      severity=excluded.severity,confidence=excluded.confidence,failure_layer=excluded.failure_layer,evidence=excluded.evidence`).bind(gameKey, finding2.reasonCode, now, now, null, status, consecutive, finding2.severity, finding2.confidence, finding2.failureLayer, blob(item)));
    if (status === "open" && prior?.status !== "open") events.push({ gameKey, reasonCode: finding2.reasonCode, event: "opened", evidence: item });
  }
  for (const [id, prior] of active) {
    if (seen.has(id) || !scannedKeys.has(prior.game_key)) continue;
    if (prior.status === "open" && prior.consecutive > 0) {
      writes.push(env.DB.prepare("UPDATE live_audit_findings SET status='recovering',consecutive=0,last_seen=? WHERE game_key=? AND reason_code=?").bind(now, prior.game_key, prior.reason_code));
    } else {
      writes.push(env.DB.prepare("UPDATE live_audit_findings SET status='recovered',resolved_at=?,last_seen=?,consecutive=0 WHERE game_key=? AND reason_code=?").bind(now, now, prior.game_key, prior.reason_code));
      if (prior.status === "recovering") events.push({ gameKey: prior.game_key, reasonCode: prior.reason_code, event: "recovered", evidence: JSON.parse(prior.evidence) });
    }
  }
  for (const event of events) writes.push(env.DB.prepare("INSERT INTO live_audit_events(at,game_key,reason_code,event,evidence) VALUES (?,?,?,?,?)").bind(now, event.gameKey, event.reasonCode, event.event, blob(event.evidence)));
  for (let i = 0; i < writes.length; i += 50) await env.DB.batch(writes.slice(i, i + 50));
  return { writes: writes.length, events };
}
__name(applyFindings, "applyFindings");
async function scan(env, now = Date.now()) {
  const started = now;
  const inserted = await env.DB.prepare("INSERT INTO live_audit_runs(started_at) VALUES (?)").bind(started).run();
  const runId = inserted.meta.last_row_id;
  try {
    const feed = await feedFromD1(env), feedAt = Date.parse(feed?.updatedAt || ""), age = now - feedAt;
    const games = (feed?.games || []).filter((game) => game?.state === "live" && SPORTS.has(game.sport));
    const active = new Map((await rows2(env.DB.prepare("SELECT * FROM live_audit_findings WHERE status!='recovered' LIMIT 2000"))).map((row) => [`${row.game_key}|${row.reason_code}`, row]));
    const nhlResources = games.some((game) => game.sport === "NHL") ? (await rows2(env.DB.prepare("SELECT key,payload,updated_at FROM sports_resources WHERE updated_at>? AND key LIKE '%/gamecenter/%/play-by-play' LIMIT 40").bind(now - 12e4))).map((row) => {
      try {
        return { ...row, parsed: JSON.parse(row.payload) };
      } catch {
        return row;
      }
    }) : [];
    const candidates = [], observations = [], scannedKeys = /* @__PURE__ */ new Set(["feed"]);
    let checks = 0;
    if (games.length && (!feed || !Number.isFinite(feedAt) || age > 54e4))
      candidates.push({
        gameKey: "feed",
        finding: watchCandidate(
          "FEED_STALE",
          { updatedAt: feed?.updatedAt || null, ageMs: age },
          "canonical feed refreshed within 9 minutes",
          "Source publication is delayed"
        ),
        evidence: { scoringVersion: feed?.modelVersion || null, rawInputReferences: ["sports_feed:1"] }
      });
    if (games.length && feed?.sourceErrors?.length)
      candidates.push({
        gameKey: "feed",
        finding: watchCandidate(
          "SOURCE_ERRORS",
          { count: feed.sourceErrors.length },
          "no provider source errors",
          "Canonical refresh reported provider failures"
        ),
        evidence: { scoringVersion: feed.modelVersion, rawInputReferences: feed.sourceErrors.slice(0, 12) }
      });
    checks += 2;
    const peerCache = /* @__PURE__ */ new Map();
    for (const game of games) {
      const key = `${game.sport}:${game.id}`, state = gameState(game), bucket = stateBucket(state);
      scannedKeys.add(key);
      const priorAudit = await env.DB.prepare(`SELECT observed_at,rating,evidence FROM live_audit_observations
        WHERE game_key=? ORDER BY observed_at DESC LIMIT 1`).bind(key).first();
      const snapshot = await env.DB.prepare(`SELECT observed_at,state,normalized_state,model_version FROM sports_snapshots
        WHERE game_key=? AND observed_at<? ORDER BY observed_at DESC LIMIT 1`).bind(key, feedAt - 3e4).first();
      const prior = priorAudit && priorAudit.observed_at >= Number(snapshot?.observed_at || 0) ? {
        observed_at: priorAudit.observed_at,
        state: "live",
        model_version: JSON.parse(priorAudit.evidence).scoringVersion,
        normalized_state: JSON.stringify(JSON.parse(priorAudit.evidence).state)
      } : snapshot;
      if (!peerCache.has(`${game.sport}|${bucket}`)) {
        const samples = await rows2(env.DB.prepare(`SELECT game_key,rating FROM live_audit_observations WHERE sport=? AND state_bucket=?
          AND observed_at>? ORDER BY observed_at DESC LIMIT 100`).bind(game.sport, bucket, now - 7 * 864e5));
        const distinct = /* @__PURE__ */ new Map();
        for (const row of samples) if (!distinct.has(row.game_key)) distinct.set(row.game_key, row);
        peerCache.set(`${game.sport}|${bucket}`, [...distinct.values()].slice(0, 30));
      }
      const cross = cachedNhlCrosschecks(nhlResources, game, now);
      const peers = peerCache.get(`${game.sport}|${bucket}`).filter((row) => row.game_key !== key);
      const summaryKey = game.providerPath ? `https://site.api.espn.com/apis/site/v2/sports/${game.providerPath}/summary?event=${encodeURIComponent(game.id)}` : null;
      const summaryRow = summaryKey ? await env.DB.prepare("SELECT payload,updated_at FROM sports_resources WHERE key=?").bind(summaryKey).first() : null;
      let summary = null;
      try {
        if (summaryRow && now - summaryRow.updated_at < 18e4) summary = JSON.parse(summaryRow.payload);
      } catch {
      }
      const result = auditGame(game, prior ? [prior] : [], peers, now, cross, summary);
      checks += result.checks;
      const evidence = {
        at: now,
        state: compact(game),
        auditVersion: AUDIT_VERSION,
        qualityEvidence: captureQualityEvidence(game, { publishedAt: feedAt, observedAt: now }),
        scoringVersion: feed?.modelVersion || game.modelVersion || null,
        feedRevision: String(feed?.revision || feedAt),
        feedUpdatedAt: feed?.updatedAt || null,
        sourceFreshnessMs: age,
        rawInputReferences: [
          result.rawRef,
          ...summaryRow ? [{ source: summaryKey, updatedAt: summaryRow.updated_at }] : [],
          ...cross ? [{ source: cross.source, ageMs: cross.ageMs }] : []
        ],
        auditCandidates: result.findings
      };
      observations.push(env.DB.prepare(`INSERT INTO live_audit_observations
        (run_id,game_key,observed_at,slate_date,sport,state_bucket,rating,score_a,score_b,period,clock_seconds,evidence)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`).bind(
        runId,
        key,
        now,
        slateDateNY(game.startTime) || slateDateNY(now),
        game.sport,
        bucket,
        state.rating,
        state.scores[0],
        state.scores[1],
        state.period,
        state.clock,
        blob(evidence)
      ));
      for (const finding2 of result.findings) candidates.push({ gameKey: key, finding: finding2, evidence });
      if (game.detailStale || age > 18e4) candidates.push({
        gameKey: key,
        finding: watchCandidate(
          "GAME_SOURCE_STALE",
          { detailStale: game.detailStale, feedAgeMs: age },
          "fresh canonical game and summary",
          "Live source data is stale"
        ),
        evidence
      });
    }
    for (const sport of SPORTS) {
      scannedKeys.add(`sport:${sport}`);
      const group = candidates.filter((item) => item.finding.reasonCode === "LATE_WIDE_MARGIN_HIGH" && item.evidence.state.sport === sport);
      if (group.length >= 3) candidates.push({
        gameKey: `sport:${sport}`,
        finding: {
          reasonCode: "SPORT_WIDE_MARGIN_BIAS",
          severity: "medium",
          confidence: 0.7,
          failureLayer: "scoring model",
          observed: { gameCount: group.length, ratings: group.map((item) => item.evidence.state.score) },
          expected: "review comparable late wide-margin games and stakes",
          detail: "Several live games in this sport show the same high-rating pattern",
          deterministic: false
        },
        evidence: { scoringVersion: feed.modelVersion, affectedGames: group.map((item) => item.gameKey), rawInputReferences: group.map((item) => item.evidence.rawInputReferences[0]) }
      });
    }
    for (let i = 0; i < observations.length; i += 50) await env.DB.batch(observations.slice(i, i + 50));
    const applied = await applyFindings(env, candidates, active, now, scannedKeys);
    const flagged = new Set(candidates.flatMap((x) => x.gameKey.startsWith("sport:") ? x.evidence.affectedGames || [] : x.gameKey === "feed" ? [] : [x.gameKey]));
    const writes = 1 + observations.length + applied.writes + 1;
    await env.DB.prepare(`UPDATE live_audit_runs SET finished_at=?,feed_updated_at=?,feed_revision=?,model_version=?,
      games_checked=?,checks_completed=?,clean_games=?,flagged_games=?,provider_requests=0,storage_writes=?,notifications=0
      WHERE id=?`).bind(
      Date.now(),
      Number.isFinite(feedAt) ? feedAt : null,
      String(feed?.revision || ""),
      feed?.modelVersion || null,
      games.length,
      checks,
      games.length - flagged.size,
      flagged.size,
      writes,
      runId
    ).run();
    const clock = new Date(now);
    if (clock.getUTCHours() === 0 && clock.getUTCMinutes() < 3) {
      await env.DB.prepare("DELETE FROM live_audit_observations WHERE observed_at<?").bind(now - 14 * 864e5).run();
      await env.DB.prepare("DELETE FROM live_audit_runs WHERE started_at<?").bind(now - 14 * 864e5).run();
    }
    return {
      runId,
      gamesChecked: games.length,
      checksCompleted: checks,
      cleanGames: games.length - flagged.size,
      flaggedGames: flagged.size,
      sourceFreshnessMs: age,
      alertsOpened: applied.events.filter((e) => e.event === "opened").length,
      recoveries: applied.events.filter((e) => e.event === "recovered").length,
      providerRequests: 0,
      storageWrites: writes,
      notifications: 0
    };
  } catch (error) {
    await env.DB.prepare("UPDATE live_audit_runs SET finished_at=?,error=? WHERE id=?").bind(Date.now(), String(error).slice(0, 500), runId).run().catch(() => {
    });
    throw error;
  }
}
__name(scan, "scan");
async function report(env, date) {
  const latest = await env.DB.prepare("SELECT * FROM live_audit_runs ORDER BY id DESC LIMIT 1").first();
  const lastSuccessful = await env.DB.prepare("SELECT finished_at FROM live_audit_runs WHERE error IS NULL AND finished_at IS NOT NULL ORDER BY id DESC LIMIT 1").first();
  const unresolved = await rows2(env.DB.prepare("SELECT * FROM live_audit_findings WHERE status IN ('open','recovering') ORDER BY last_seen DESC LIMIT 200"));
  const games = latest?.id ? await rows2(env.DB.prepare("SELECT game_key,evidence FROM live_audit_observations WHERE run_id=? ORDER BY game_key LIMIT 300").bind(latest.id)) : [];
  const events = await rows2(env.DB.prepare("SELECT at,game_key,reason_code,event,evidence FROM live_audit_events ORDER BY at DESC LIMIT 100"));
  const output = {
    latestRun: latest,
    lastSuccessfulScan: lastSuccessful?.finished_at || null,
    sourceFreshnessMs: latest?.feed_updated_at ? Date.now() - latest.feed_updated_at : null,
    activeUnresolvedCount: unresolved.length,
    activeUnresolvedFindings: unresolved.map((row) => ({ ...row, evidence: JSON.parse(row.evidence) })),
    games: games.map((row) => ({ gameKey: row.game_key, evidence: JSON.parse(row.evidence) })),
    recentAlertEvents: events.map((row) => ({ ...row, evidence: JSON.parse(row.evidence) }))
  };
  if (date) {
    const next = new Date(Date.parse(`${date}T12:00:00Z`) + 864e5).toISOString().slice(0, 10);
    const start = newYorkMidnight(date), end2 = newYorkMidnight(next);
    const runs = await rows2(env.DB.prepare("SELECT * FROM live_audit_runs WHERE started_at>=? AND started_at<? ORDER BY id LIMIT 500").bind(start, end2));
    const dailyEvents = await rows2(env.DB.prepare("SELECT at,game_key,reason_code,event,evidence FROM live_audit_events WHERE at>=? AND at<? ORDER BY at LIMIT 300").bind(start, end2));
    const gameSummaries = await rows2(env.DB.prepare(`SELECT game_key,sport,COUNT(*) observations,MIN(rating) min_rating,
      MAX(rating) peak_rating,MIN(observed_at) first_seen,MAX(observed_at) last_seen
      FROM live_audit_observations WHERE observed_at>=? AND observed_at<? GROUP BY game_key,sport ORDER BY game_key LIMIT 300`).bind(start, end2));
    const latestEvidence = await rows2(env.DB.prepare(`SELECT o.game_key,o.evidence FROM live_audit_observations o
      JOIN (SELECT game_key,MAX(observed_at) last_at FROM live_audit_observations
        WHERE observed_at>=? AND observed_at<? GROUP BY game_key) last
      ON last.game_key=o.game_key AND last.last_at=o.observed_at ORDER BY o.game_key LIMIT 300`).bind(start, end2));
    const evidenceByGame = new Map(latestEvidence.map((row) => [row.game_key, JSON.parse(row.evidence)]));
    const historicalFindings = await rows2(env.DB.prepare(`SELECT f.* FROM live_audit_findings f
      WHERE f.first_seen<? AND f.last_seen>=? AND
      (f.status IN ('open','recovering') OR EXISTS
        (SELECT 1 FROM live_audit_events e WHERE e.game_key=f.game_key AND e.reason_code=f.reason_code AND e.event='opened'))
      ORDER BY f.last_seen DESC LIMIT 300`).bind(end2, start));
    output.postSlate = {
      dateNewYork: date,
      scans: runs.length,
      gamesChecked: runs.reduce((n, r) => n + r.games_checked, 0),
      checksCompleted: runs.reduce((n, r) => n + r.checks_completed, 0),
      scanErrors: runs.filter((r) => r.error).map((r) => r.error),
      distinctGames: gameSummaries.length,
      gameSummaries: gameSummaries.map((row) => ({ ...row, latestEvidence: evidenceByGame.get(row.game_key) || null })),
      findings: historicalFindings.map((row) => ({ ...row, evidence: JSON.parse(row.evidence) })),
      events: dailyEvents.map((row) => ({ ...row, evidence: JSON.parse(row.evidence) }))
    };
  }
  return output;
}
__name(report, "report");
var index_default = {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname === "/session" && request.method === "POST") {
      if (!env.AUDIT_READ_TOKEN || Number(request.headers.get("Content-Length") || 0) > 1024)
        return html(loginHtml(true), 401);
      const form = await request.formData().catch(() => null);
      const supplied = String(form?.get("password") || "");
      if (!equal(supplied, env.AUDIT_READ_TOKEN)) return html(loginHtml(true), 401);
      const at = String(Date.now()), sig = await signature(env.AUDIT_READ_TOKEN, `v1.${at}`);
      return new Response(null, { status: 303, headers: {
        Location: "/dashboard",
        "Set-Cookie": `slatemeter_audit=v1.${at}.${sig}; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=43200`,
        "Cache-Control": "no-store"
      } });
    }
    if (url.pathname === "/logout" && request.method === "POST")
      return new Response(null, { status: 303, headers: {
        Location: "/dashboard",
        "Set-Cookie": "slatemeter_audit=; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=0",
        "Cache-Control": "no-store"
      } });
    if (request.method !== "GET") return json({ error: "Read only" }, 405);
    if (url.pathname === "/" || url.pathname === "/dashboard")
      return html(await authorized(request, env) ? dashboardHtml : loginHtml());
    if (url.pathname === "/dashboard.js") return new Response(dashboard_client_generated_default, { headers: {
      "content-type": "text/javascript; charset=utf-8",
      "cache-control": "public, max-age=3600",
      "x-content-type-options": "nosniff"
    } });
    if (url.pathname === "/health") {
      const latest = await env.DB.prepare("SELECT started_at,finished_at,error,games_checked,checks_completed FROM live_audit_runs ORDER BY id DESC LIMIT 1").first().catch(() => null);
      return json({ ok: Boolean(latest?.finished_at && !latest.error), scheduledCron: "*/3 * * * *", latestRun: latest });
    }
    if (!["/report", "/export", "/export/dates", "/quality"].includes(url.pathname)) return json({ error: "Not found" }, 404);
    if (!await authorized(request, env))
      return json({ error: "Unauthorized" }, 401);
    if (url.pathname === "/export/dates") {
      const feed = await feedFromD1(env);
      return json(await defaultSlateDate(env, feed));
    }
    const date = url.searchParams.get("date");
    if (date && !dateOnly(date)) return json({ error: "date must be YYYY-MM-DD (New York)" }, 400);
    if (url.pathname === "/quality") {
      const feed = await feedFromD1(env);
      const selected = date || (await defaultSlateDate(env, feed)).defaultDate;
      const { data } = await buildNightlyExport(env, selected, { feed });
      return json({ dateNewYork: selected, scoringQuality: data.scoringQuality });
    }
    if (url.pathname === "/export") {
      const feed = await feedFromD1(env);
      const selected = date || (await defaultSlateDate(env, feed)).defaultDate;
      const { data, summary } = await buildNightlyExport(env, selected, { feed });
      const zip = zipEntries([["summary.md", summary], ["findings.json", JSON.stringify(data, null, 2)]]);
      return new Response(zip, { headers: {
        "content-type": "application/zip",
        "cache-control": "no-store",
        "content-disposition": `attachment; filename="slatemeter-audit-${selected}.zip"`,
        "x-content-type-options": "nosniff"
      } });
    }
    return json(await report(env, date));
  },
  async scheduled(event, env, ctx) {
    ctx.waitUntil(scan(env).catch((error) => console.error("Live audit failed", String(error))));
  }
};
export {
  index_default as default,
  scan
};
//# sourceMappingURL=index.js.map
