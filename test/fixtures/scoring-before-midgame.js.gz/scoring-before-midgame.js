/* Shared scoring module; supports classic browser scripts and Worker/Node bundling. */
(function (root) {
  const SPORT_FLOOR = 32;
  const SCHEDULE_SCARCITY = {NFL:10,MLB:0,NHL:5,CFB:8,NBA:5,NCAAB:3,Tennis:2,Soccer:4};
  const SPORT_BASE = Object.fromEntries(
    Object.entries(SCHEDULE_SCARCITY).map(([sport,points]) => [sport,SPORT_FLOOR + points])
  );

  const NFL_DIVISIONS = {
    BUF:'AFC East',MIA:'AFC East',NE:'AFC East',NYJ:'AFC East',
    BAL:'AFC North',CIN:'AFC North',CLE:'AFC North',PIT:'AFC North',
    HOU:'AFC South',IND:'AFC South',JAX:'AFC South',TEN:'AFC South',
    DEN:'AFC West',KC:'AFC West',LAC:'AFC West',LV:'AFC West',
    DAL:'NFC East',NYG:'NFC East',PHI:'NFC East',WSH:'NFC East',
    CHI:'NFC North',DET:'NFC North',GB:'NFC North',MIN:'NFC North',
    ATL:'NFC South',CAR:'NFC South',NO:'NFC South',TB:'NFC South',
    ARI:'NFC West',LAR:'NFC West',SF:'NFC West',SEA:'NFC West'
  };

  const NHL_DIVISIONS = {
    BOS:'Atlantic Division',BUF:'Atlantic Division',DET:'Atlantic Division',FLA:'Atlantic Division',
    MTL:'Atlantic Division',OTT:'Atlantic Division',TB:'Atlantic Division',TOR:'Atlantic Division',
    CAR:'Metropolitan Division',CBJ:'Metropolitan Division',NJ:'Metropolitan Division',
    NYI:'Metropolitan Division',NYR:'Metropolitan Division',PHI:'Metropolitan Division',
    PIT:'Metropolitan Division',WSH:'Metropolitan Division',
    CHI:'Central Division',COL:'Central Division',DAL:'Central Division',MIN:'Central Division',
    NSH:'Central Division',STL:'Central Division',UTA:'Central Division',WPG:'Central Division',
    ANA:'Pacific Division',CGY:'Pacific Division',EDM:'Pacific Division',LA:'Pacific Division',
    LAK:'Pacific Division',SJ:'Pacific Division',SJS:'Pacific Division',SEA:'Pacific Division',
    VAN:'Pacific Division',VGK:'Pacific Division'
  };

  const NBA_DIVISIONS = {
    BOS:'Atlantic Division',BKN:'Atlantic Division',NY:'Atlantic Division',NYK:'Atlantic Division',
    PHI:'Atlantic Division',TOR:'Atlantic Division',
    CHI:'Central Division',CLE:'Central Division',DET:'Central Division',IND:'Central Division',
    MIL:'Central Division',
    ATL:'Southeast Division',CHA:'Southeast Division',MIA:'Southeast Division',
    ORL:'Southeast Division',WSH:'Southeast Division',
    DEN:'Northwest Division',MIN:'Northwest Division',OKC:'Northwest Division',
    POR:'Northwest Division',UTA:'Northwest Division',
    GS:'Pacific Division',GSW:'Pacific Division',LAC:'Pacific Division',
    LAL:'Pacific Division',PHX:'Pacific Division',SAC:'Pacific Division',
    DAL:'Southwest Division',HOU:'Southwest Division',MEM:'Southwest Division',
    NO:'Southwest Division',NOP:'Southwest Division',SA:'Southwest Division',SAS:'Southwest Division'
  };

  const MLB_DIVISIONS = {
    BAL:'AL East',BOS:'AL East',NYY:'AL East',TB:'AL East',TOR:'AL East',
    CWS:'AL Central',CHW:'AL Central',CLE:'AL Central',DET:'AL Central',
    KC:'AL Central',KCR:'AL Central',MIN:'AL Central',
    ATH:'AL West',OAK:'AL West',HOU:'AL West',LAA:'AL West',SEA:'AL West',TEX:'AL West',
    ATL:'NL East',MIA:'NL East',NYM:'NL East',PHI:'NL East',WSH:'NL East',
    CHC:'NL Central',CIN:'NL Central',MIL:'NL Central',PIT:'NL Central',STL:'NL Central',
    ARI:'NL West',COL:'NL West',LAD:'NL West',SD:'NL West',SDP:'NL West',
    SF:'NL West',SFG:'NL West'
  };

  const LEAGUE_DIVISIONS = {
    NFL:NFL_DIVISIONS,
    NHL:NHL_DIVISIONS,
    NBA:NBA_DIVISIONS,
    MLB:MLB_DIVISIONS
  };

  const CONTEXT_WEIGHTS = {
    former_captain_return:10,
    first_game_back:10,
    former_star_return:8,
    star_injury_return:8,
    championship_rematch:8,
    playoff_rematch:6,
    rivalry:7,
    major_trade_storyline:6,
    historic_streak:6,
    season_debut:5,
    milestone_chase:5,
    playoff_race:5,
    coach_return:4,
    star_hot_streak:4,
    notable_recent_performance:2,
    team_win_streak:3,
    elite_efficiency_profile:4,
    strength_of_schedule:3,
    confirmed_key_starters:4,
    ace_pitching_matchup:5,
    star_absence:-5,
    multiple_stars_out:-8
  };

  const CONTEXT_LABELS = {
    former_captain_return:'Former captain returns',
    first_game_back:'First game back against former team',
    former_star_return:'Former star returns',
    star_injury_return:'Star player returns from injury',
    championship_rematch:'Championship rematch',
    playoff_rematch:'Playoff rematch',
    rivalry:'Rivalry context',
    major_trade_storyline:'Major trade storyline',
    historic_streak:'Historic streak',
    season_debut:'Notable season debut',
    milestone_chase:'Major milestone chase',
    playoff_race:'Playoff race implications',
    coach_return:'Coach returns to former team',
    star_hot_streak:'Star player hot streak',
    notable_recent_performance:'Recent notable performance',
    team_win_streak:'Team winning streak',
    elite_efficiency_profile:'Elite efficiency profile',
    strength_of_schedule:'Battle-tested schedule',
    confirmed_key_starters:'Confirmed key starters',
    ace_pitching_matchup:'Confirmed ace pitching matchup',
    star_absence:'Notable star absence',
    multiple_stars_out:'Multiple major absences'
  };

  const CLOSE_MARGIN = {
    NFL:14,
    MLB:3,
    NHL:3,
    CFB:14,
    NBA:12,
    NCAAB:12,
    Tennis:3,
    Soccer:3
  };

  const api = {SPORT_FLOOR,SCHEDULE_SCARCITY,SPORT_BASE,NFL_DIVISIONS,NHL_DIVISIONS,NBA_DIVISIONS,MLB_DIVISIONS,LEAGUE_DIVISIONS,CONTEXT_WEIGHTS,CONTEXT_LABELS,CLOSE_MARGIN};
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api;
  } else {
    (root.SportsRadarScoring ||= {}).shared_config = api;
  }
})(globalThis);

/* Shared scoring module; supports classic browser scripts and Worker/Node bundling. */
(function (root) {
  const {LEAGUE_DIVISIONS} = typeof module !== 'undefined' && module.exports
    ? require('./config.js')
    : root.SportsRadarScoring.shared_config;

  function recordFor(competitor) {
    const records =
      competitor?.records ||
      competitor?.team?.records ||
      [];

    const overall =
      records.find(item =>
        /overall|total/i.test(
          `${item.type || ''} ${item.name || ''} ${item.abbreviation || ''}`
        )
      ) ||
      records[0];

    return (
      overall?.summary ||
      competitor?.record?.summary ||
      (
        typeof competitor?.record === 'string'
          ? competitor.record
          : ''
      )
    );
  }

  function rankFor(competitor, sport) {
    if (!['CFB','NCAAB'].includes(sport)) {
      return null;
    }

    const rank =
      Number(
        competitor?.curatedRank?.current ??
        competitor?.team?.rank
      );

    return (
      Number.isFinite(rank) &&
      rank >= 1 &&
      rank <= 25
    )
      ? rank
      : null;
  }

  function divisionFor(sport,competitors) {
    const map =
      LEAGUE_DIVISIONS[sport];

    if (
      !map ||
      !Array.isArray(competitors) ||
      competitors.length !== 2
    ) {
      return '';
    }

    const divisions =
      competitors.map(item =>
        map[
          String(
            item.team?.abbreviation ||
            item.abbreviation ||
            ''
          ).toUpperCase()
        ]
      );

    return (
      divisions[0] &&
      divisions[0] === divisions[1]
    )
      ? divisions[0]
      : '';
  }

  function recordStats(competitor) {
    const match =
      String(
        recordFor(competitor)
      ).match(
        /^(\d+)-(\d+)(?:-(\d+))?/
      );

    if (!match) {
      return null;
    }

    const wins =
      Number(match[1]);

    const losses =
      Number(match[2]);

    const ties =
      Number(match[3] || 0);

    const games =
      wins +
      losses +
      ties;

    return games
      ? {
          wins,
          losses,
          ties,
          games,
          pct:
            (
              wins +
              ties / 2
            ) /
            games
        }
      : null;
  }

  function winningRecord(competitor) {
    const record =
      recordStats(competitor);

    return Boolean(
      record &&
      record.pct > .5
    );
  }

  function proRecordFactors(sport,competitors) {
    if (
      !['MLB','NHL','NBA']
        .includes(sport)
    ) {
      return [];
    }

    const records =
      competitors.map(
        recordStats
      );

    if (
      records.length !== 2 ||
      !records.every(Boolean)
    ) {
      return [];
    }

    const minimumGames = {
      MLB:8,
      NHL:4,
      NBA:4
    }[sport] || 4;

    const mature =
      records.every(
        record =>
          record.games >=
          minimumGames
      );

    const bothWinning =
      records.every(
        record =>
          record.pct > .5
      );

    const bothAtLeastEven =
      records.every(
        record =>
          record.pct >= .5
      );

    const bothBelow =
      records.every(
        record =>
          record.pct < .5
      );

    const factors = [];

    factors.push(
      ...proTeamQualityFactors(
        sport,
        records
      )
    );

    if (bothWinning) {
      factors.push({
        label:'Both winning records',
        points:mature ? 7 : 3
      });

      if (
        Math.abs(
          records[0].pct -
          records[1].pct
        ) <= .1
      ) {
        factors.push({
          label:'Evenly matched winning records',
          points:mature ? 3 : 2
        });
      }
    } else if (bothAtLeastEven) {
      factors.push({
        label:'Both teams at least .500',
        points:mature ? 4 : 2
      });
    } else if (bothBelow) {
      factors.push({
        label:'Both teams below .500',
        points:mature ? -4 : -2
      });
    }

    if (
      records.some(
        record =>
          record.losses === 0 &&
          record.games >= 3
      )
    ) {
      factors.push({
        label:'Unbeaten team',
        points:4
      });
    }

    if (
      records.some(
        record =>
          record.wins === 0 &&
          record.games >= 3
      )
    ) {
      factors.push({
        label:'Winless team',
        points:-3
      });
    }

    return factors;
  }

  function proTeamQualityFactors(sport,records) {
    if (
      !['MLB','NHL','NBA'].includes(sport) ||
      !Array.isArray(records) ||
      records.length !== 2 ||
      !records.every(Boolean)
    ) {
      return [];
    }

    const priorGames = 6;
    const adjusted = records.map(record =>
      ((record.pct * record.games) + (.5 * priorGames)) /
      (record.games + priorGames)
    );
    const average =
      adjusted.reduce((sum,value) => sum + value,0) /
      adjusted.length;
    const factors = [];
    let points = 0;

    if (average >= .70) points = 10;
    else if (average >= .64) points = 7;
    else if (average >= .58) points = 4;
    else if (average >= .54) points = 2;

    if (points) {
      factors.push({
        label:'Adjusted team quality',
        points
      });
    }

    if (adjusted.every(value => value >= .64)) {
      factors.push({
        label:'Both teams have strong adjusted quality',
        points:3
      });
    }

    if (adjusted.every(value => value >= .70)) {
      factors.push({
        label:'Both teams have elite adjusted quality',
        points:2
      });
    }

    return factors;
  }

  const api = {recordFor,rankFor,divisionFor,recordStats,winningRecord,proRecordFactors,proTeamQualityFactors};
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api;
  } else {
    (root.SportsRadarScoring ||= {}).shared_records = api;
  }
})(globalThis);

/* Shared scoring module; supports classic browser scripts and Worker/Node bundling. */
(function (root) {
  function parseLine(raw, competition, sport) {
    if (!raw) return null;

    const listed =
      raw.close ||
      raw.closing ||
      raw;

    const totalValue =
      listed.overUnder ??
      listed.over_under ??
      listed.total?.overUnder ??
      listed.total?.value;

    const total =
      totalValue == null ||
      totalValue === ''
        ? NaN
        : Number(totalValue);

    const details =
      String(
        listed.details ||
        listed.displayValue ||
        ''
      ).trim();

    const isMoneyline =
      /[+-]\d{3,}\b/.test(details) &&
      !/[+-]\d+\.\d+/.test(details);

    let spread =
      isMoneyline
        ? ''
        : String(
            listed.spread?.displayValue ||
            details
          ).trim();

    if (
      !spread &&
      listed.spread != null &&
      Number.isFinite(Number(listed.spread)) &&
      (
        !isMoneyline ||
        Math.abs(Number(listed.spread)) <= 10
      )
    ) {
      const amount =
        Math.abs(
          Number(listed.spread)
        );

      const home =
        (competition?.competitors || [])
          .find(
            team =>
              team.homeAway === 'home'
          );

      const away =
        (competition?.competitors || [])
          .find(
            team =>
              team.homeAway === 'away'
          );

      const favored =
        listed.homeTeamOdds?.favorite
          ? home
          : listed.awayTeamOdds?.favorite
            ? away
            : null;

      if (favored) {
        spread =
          amount === 0
            ? 'PK'
            : `${favored.team?.abbreviation || favored.abbreviation || 'Favorite'} -${amount}`;
      }
    }

    if (
      !spread &&
      !details &&
      !Number.isFinite(total)
    ) {
      return null;
    }

    return {
      spread:spread || '',
      moneyline:isMoneyline ? details : '',
      total:Number.isFinite(total) ? total : null,
      provider:
        listed.provider?.name ||
        raw.provider?.name ||
        '',
      verifiedClose:Boolean(
        raw.close ||
        raw.closing
      )
    };
  }

  function lineFromSummary(summary, sport) {
    const competition =
      summary?.header?.competitions?.[0];

    return parseLine(
      summary?.pickcenter?.[0] ||
      competition?.odds?.[0] ||
      summary?.odds?.[0],
      competition,
      sport
    );
  }

  function listedSpread(competition) {
    const spread =
      parseLine(
        competition?.odds?.[0],
        competition,
        'NFL'
      )?.spread || '';

    const match =
      spread.match(
        /[+-](\d+(?:\.\d+)?)/
      );

    return match
      ? Number(match[1])
      : null;
  }

  function numberFromLine(value) {
    if (
      value === null ||
      value === undefined ||
      value === ''
    ) {
      return null;
    }

    const n =
      Number(
        String(value)
          .replace(
            /[^+\-.\d]/g,
            ''
          )
      );

    return Number.isFinite(n)
      ? n
      : null;
  }

  function moneylinePrices(raw) {
    if (!raw) {
      return [];
    }

    const odds =
      raw.close ||
      raw.closing ||
      raw;

    const candidates = [
      odds.homeTeamOdds?.moneyLine,
      odds.awayTeamOdds?.moneyLine,
      odds.homeTeamOdds?.moneyline,
      odds.awayTeamOdds?.moneyline,
      odds.moneyline?.home?.close?.odds,
      odds.moneyline?.away?.close?.odds,
      odds.moneyline?.home?.open?.odds,
      odds.moneyline?.away?.open?.odds,
      odds.moneyLine?.home?.close?.odds,
      odds.moneyLine?.away?.close?.odds,
      odds.moneyLine?.home?.open?.odds,
      odds.moneyLine?.away?.open?.odds
    ];

    const details =
      String(
        odds.details ||
        odds.displayValue ||
        ''
      ).match(
        /[+-]\d{3,4}\b/g
      ) || [];

    return [
      ...new Set(
        [
          ...candidates,
          ...details
        ]
          .map(numberFromLine)
          .filter(value =>
            value !== null &&
            Math.abs(value) >= 100
          )
      )
    ];
  }

  function spreadMarketPoints(spread) {
    return Math.round(5 / (1 + (spread / 6) ** 2));
  }

  function pregameMarketFactor(sport,competition) {
    const raw =
      competition?.odds?.[0];

    if (!raw) {
      return null;
    }

    if (
      ['NBA','CFB','NCAAB']
        .includes(sport)
    ) {
      const spread =
        listedSpread(competition);
      const points = spread === null
        ? 0
        : spreadMarketPoints(spread);
      return points ? {
        label:points >= 4
          ? 'Very close projected spread'
          : 'Competitive projected spread',
        points
      } : null;
    }

    if (
      ['NHL','MLB']
        .includes(sport)
    ) {
      const prices =
        moneylinePrices(raw);

      if (!prices.length) {
        return null;
      }

      const shortest =
        Math.min(
          ...prices.map(
            value =>
              Math.abs(value)
          )
        );

      if (shortest <= 125) {
        return {
          label:'Near pick’em market',
          points:5
        };
      }

      if (shortest <= 150) {
        return {
          label:'Competitive betting market',
          points:3
        };
      }
    }

    return null;
  }

  function underdogCandidate(sport,competition,raw) {
    if (
      !raw ||
      !competition?.competitors ||
      competition.competitors.length !== 2
    ) {
      return null;
    }

    const odds =
      raw.close ||
      raw.closing ||
      raw;

    const sides =
      ['home','away']
        .map(side => {
          const competitor =
            competition.competitors
              .find(
                item =>
                  item.homeAway === side
              );

          if (!competitor) {
            return null;
          }

          const spread =
            numberFromLine(
              odds.pointSpread
                ?.[side]
                ?.close
                ?.line ??
              odds.pointSpread
                ?.[side]
                ?.open
                ?.line
            );

          const moneyline =
            numberFromLine(
              odds.moneyline
                ?.[side]
                ?.close
                ?.odds ??
              odds.moneyline
                ?.[side]
                ?.open
                ?.odds
            );

          return {
            side,
            competitor,
            spread,
            moneyline
          };
        })
        .filter(Boolean);

    if (
      sides.length !== 2
    ) {
      return null;
    }

    const spreadMinimum = ({
      NFL:7,
      // Ramp CFB impact through ten instead of creating a +9.5/+10 cliff.
      CFB:7,
      NBA:8,
      NCAAB:8
    })[sport];

    const moneylineMinimum = ({
      MLB:180,
      NHL:180,
      Soccer:250,
      Tennis:180
    })[sport];

    let pick =
      spreadMinimum
        ? sides.find(
            item =>
              item.spread !== null &&
              item.spread >=
              spreadMinimum
          )
        : null;

    let type =
      pick
        ? 'spread'
        : '';

    if (
      !pick &&
      spreadMinimum
    ) {
      const amount =
        Math.abs(
          numberFromLine(
            odds.spread
          ) ??
          numberFromLine(
            odds.details
              ?.match(
                /[+-]\d+(?:\.\d+)?/
              )?.[0]
          ) ??
          0
        );

      if (
        amount >=
        spreadMinimum
      ) {
        pick =
          sides.find(
            item =>
              odds[
                `${item.side}TeamOdds`
              ]?.underdog === true ||
              odds[
                `${item.side}TeamOdds`
              ]?.favorite === false
          );

        if (pick) {
          pick = {
            ...pick,
            spread:amount
          };

          type =
            'spread';
        }
      }
    }

    if (
      !pick &&
      moneylineMinimum
    ) {
      pick =
        sides.find(
          item =>
            item.moneyline !== null &&
            item.moneyline >=
            moneylineMinimum
        );

      if (pick) {
        type =
          'moneyline';
      }
    }

    if (!pick) {
      return null;
    }

    const value =
      type === 'spread'
        ? pick.spread
        : pick.moneyline;

    const minimum =
      type === 'spread'
        ? spreadMinimum
        : moneylineMinimum;

    const teamIndex =
      competition.competitors
        .indexOf(
          pick.competitor
        );

    return {
      side:
        pick.side,

      teamId:
        String(
          pick.competitor.team?.id ||
          pick.competitor.id ||
          ''
        ),

      teamIndex,

      teamName:
        pick.competitor.team?.displayName ||
        pick.competitor.team?.name ||
        'The underdog',

      type,
      value,

      strength:
        Math.min(
          1,
          Math.max(
            0,
            (
              value -
              minimum
            ) /
            (
              type === 'spread'
                ? minimum
                : 200
            )
          )
        ),

      activation:
        sport === 'CFB' && type === 'spread'
          ? Math.min(1,Math.max(0,(value - 7) / 3))
          : 1,

      description:
        type === 'spread'
          ? `${value}-point underdog`
          : `+${value} moneyline underdog`
    };
  }

  const api = {parseLine,lineFromSummary,listedSpread,numberFromLine,moneylinePrices,spreadMarketPoints,pregameMarketFactor,underdogCandidate};
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api;
  } else {
    (root.SportsRadarScoring ||= {}).shared_market = api;
  }
})(globalThis);

/* Shared scoring module; supports classic browser scripts and Worker/Node bundling. */
(function (root) {
  function normalizedTime(sport,competition) {
    const status =
      competition?.status || {};

    const period =
      Number(
        status.period || 0
      );

    const total = ({
      NFL:4,
      CFB:4,
      NHL:3,
      NBA:4,
      NCAAB:2,
      MLB:9,
      Soccer:2,
      Tennis:3
    })[sport] || 4;

    if (!period) return {progress:0,elapsedSeconds:null,remainingSeconds:null};

    if (sport === 'MLB') {
      const detail =
        String(
          status.type?.detail ||
          status.type?.shortDetail ||
          ''
        ).toLowerCase();

      const half =
        /bottom|bot\b/.test(detail)
          ? .75
          : /top\b/.test(detail)
            ? .25
            : .5;

      const elapsed = (period - 1) + half;
      return {elapsedSeconds:elapsed * 20 * 60,remainingSeconds:null,progress:Math.max(
        0,
        Math.min(
          1,
          elapsed /
          9
        )
      )};
    }

    if (sport === 'Tennis') {
      const bestOf =
        Number(
          competition?.format?.regulation?.periods ||
          competition?.format?.bestOf ||
          total
        ) ||
        total;

      const elapsed = (period - 1) + .5;
      return {elapsedSeconds:null,remainingSeconds:null,progress:Math.max(
        0,
        Math.min(
          .98,
          elapsed /
          Math.max(
            1,
            bestOf
          )
        )
      )};
    }

    const length = ({
      NFL:15,
      CFB:15,
      NHL:20,
      NBA:12,
      NCAAB:20,
      Soccer:45
    })[sport];

    const display = String(status.displayClock || '').trim();
    const colon = display.match(/^(\d+):(\d+(?:\.\d+)?)$/);
    const decimal = display.match(/^(\d+\.\d+)$/);
    const soccer = display.match(/^(\d+)'?(?:\+(\d+)'?)?$/);
    const numeric = Number(status.clock);
    let elapsedSeconds = null;
    let remainingSeconds = null;
    if (sport === 'Soccer') {
      const minute = soccer ? Number(soccer[1]) + Number(soccer[2] || 0) : null;
      elapsedSeconds = soccer?.[2] ? minute * 60
        : Number.isFinite(numeric) && status.clock != null ? numeric
        : minute !== null ? minute * 60
        : colon ? (Number(colon[1]) * 60 + Number(colon[2])) : null;
    } else {
      remainingSeconds = colon ? Number(colon[1]) * 60 + Number(colon[2])
        : decimal ? Number(decimal[1])
        : Number.isFinite(numeric) && status.clock != null ? numeric : null;
      if (remainingSeconds !== null) {
        if (status.clockMode === 'elapsed') {
          elapsedSeconds = ((period - 1) * length * 60) + remainingSeconds;
          remainingSeconds = Math.max(0,length * 60 - remainingSeconds);
        } else {
          elapsedSeconds = ((period - 1) * length * 60) + Math.max(0,length * 60 - remainingSeconds);
        }
      }
    }
    const elapsedPeriods = elapsedSeconds === null ? period - .5 : elapsedSeconds / (length * 60);
    return {elapsedSeconds,remainingSeconds,progress:Math.max(0,Math.min(1,elapsedPeriods / total))};
  }

  function gameProgress(sport,competition) {
    return normalizedTime(sport,competition).progress;
  }

  function eventPosition(sport,competition) {
    const time = normalizedTime(sport,competition);
    const regulationMinutes = {NFL:60,CFB:60,NHL:60,NBA:48,NCAAB:40,MLB:180,Soccer:90}[sport];
    return time.elapsedSeconds !== null && regulationMinutes
      ? time.elapsedSeconds / (regulationMinutes * 60) : time.progress;
  }

  function ordinal(value) {
    const n =
      Number(value);

    return `${n}${
      n % 100 >= 11 &&
      n % 100 <= 13
        ? 'th'
        : (
            {
              1:'st',
              2:'nd',
              3:'rd'
            }[n % 10] ||
            'th'
          )
    }`;
  }

  function livePhase(sport,status,format={}) {
    const detail =
      String(
        status?.type?.detail ||
        status?.type?.shortDetail ||
        ''
      ).trim();

    const period =
      Number(
        status?.period || 0
      );

    if (
      sport === 'MLB'
    ) {
      const half =
        detail.match(
          /\b(top|bottom|bot)\b/i
        )?.[1] ||
        status?.inningHalf;

      return (
        half &&
        period
      )
        ? `${/^bot/i.test(half) ? 'Bottom' : 'Top'} ${ordinal(period)}`
        : detail ||
          (
            period
              ? `${ordinal(period)} inning`
              : 'Live'
          );
    }

    if (
      sport === 'Tennis'
    ) {
      return (
        detail ||
        (
          period
            ? `${ordinal(period)} set`
            : 'Live'
        )
      );
    }

    const regulationPeriods = sport === 'NCAAB'
      ? Number(format?.regulation?.periods) || 2
      : ({NFL:4,CFB:4,NBA:4,NHL:3})[sport];
    const overtime = regulationPeriods && period > regulationPeriods
      ? period - regulationPeriods : 0;
    const overtimeLabel = overtime === 1 ? 'OT' : `${overtime}OT`;

    if (/halftime|intermission|end of/i.test(detail)) {
      return overtime
        ? detail.replace(/\b\d+(?:st|nd|rd|th)?\s+(?:quarter|half|period)\b/gi,overtimeLabel)
        : detail;
    }

    const clock = String(status?.displayClock || '').trim();
    if (regulationPeriods && period) {
      const unit = sport === 'NHL' ? 'period'
        : sport === 'NCAAB' && regulationPeriods === 2 ? 'half' : 'quarter';
      return `${clock && /^\d+:\d+$/.test(clock) ? `${clock} · ` : ''}${
        overtime ? overtimeLabel : `${ordinal(period)} ${unit}`
      }`;
    }

    return (
      detail ||
      (
        clock &&
        clock !== '0.0'
          ? clock
          : 'Live'
      )
    );
  }

  function clockSeconds(status) {
    return normalizedTime('NBA',{status:{...status,period:status?.period || 1}}).remainingSeconds;
  }

  const api = {normalizedTime,gameProgress,eventPosition,ordinal,livePhase,clockSeconds};
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api;
  } else {
    (root.SportsRadarScoring ||= {}).shared_time = api;
  }
})(globalThis);

/* Shared scoring module; supports classic browser scripts and Worker/Node bundling. */
(function (root) {
  const {lineFromSummary,parseLine} = typeof module !== 'undefined' && module.exports
    ? require('./market.js')
    : root.SportsRadarScoring.shared_market;
  const {ordinal,clockSeconds} = typeof module !== 'undefined' && module.exports
    ? require('./time.js')
    : root.SportsRadarScoring.shared_time;

  function defensiveFinishFactor(sport,summary) {
    if (!['NFL','CFB'].includes(sport)) return null;
    const competition = summary?.header?.competitions?.[0];
    const teams = competition?.competitors || [];
    const home = teams.find(team => team.homeAway === 'home');
    const away = teams.find(team => team.homeAway === 'away');
    if (!home || !away) return null;

    const drives = [...(summary?.drives?.previous || []),...(summary?.drives?.current ? [summary.drives.current] : [])];
    const plays = summary?.plays?.length ? summary.plays : drives.flatMap(drive =>
      (drive.plays || []).map(play => ({...play,driveTeam:drive.team?.id})));
    const textFor = play => String(play?.text || play?.shortText || '');
    const administrative = play => /kneel|end of (?:game|quarter|period)|timeout|two.minute warning/i.test(textFor(play));
    const offenseFor = play => String(play?.start?.team?.id || play?.driveTeam || '');
    const turnover = /intercept(?:ed|ion)|fumble.*(?:lost|recover)|turnover on downs|defensive stop/i;

    // Match the adapter's existing decisive-scoring award. A finish gets one kind of credit.
    const scoring = summary?.scoringPlays?.length ? summary.scoringPlays : plays.filter(play => play.scoringPlay === true);
    const lastScore = scoring.at(-1);
    const scoringText = `${lastScore?.clock?.displayValue || ''} ${textFor(lastScore)}`;
    if (/(0:00|last second|game[- ]winning)/i.test(scoringText) &&
        /field goal|goal|home run|touchdown/i.test(scoringText)) return null;

    for (let index = plays.length - 1; index >= 0; index--) {
      const play = plays[index];
      const text = textFor(play);
      if (administrative(play) || play.scoringPlay) continue;
      const fourthDown = Number(play.start?.down) === 4 || /\b4th\b|fourth.down/i.test(text);
      if (!turnover.test(text) && !(fourthDown && /incomplete|stopped|no gain|sack/i.test(text))) continue;
      if (/nullified|no play|overturned/i.test(text)) continue;

      const offense = offenseFor(play);
      const offenseHome = offense === String(home.team?.id);
      if (!offense || (!offenseHome && offense !== String(away.team?.id))) continue;
      const finalMargin = Number(home.score) - Number(away.score);
      if (!Number.isFinite(finalMargin) || (offenseHome ? finalMargin >= 0 : finalMargin <= 0)) continue;
      const previous = plays[index - 1];
      const homeScore = Number(play.homeScore ?? previous?.homeScore);
      const awayScore = Number(play.awayScore ?? previous?.awayScore);
      const deficit = offenseHome ? awayScore - homeScore : homeScore - awayScore;
      if (!Number.isFinite(deficit) || deficit < 0 || deficit > 8) continue;

      const later = plays.slice(index + 1).filter(item => !administrative(item));
      // Reject another chance for the trailing offense, another score/turnover,
      // or an unknown later possession. Ordinary winning-team clock runouts are fine.
      if (later.some(item => !offenseFor(item) || offenseFor(item) === offense || item.scoringPlay || turnover.test(textFor(item)))) continue;
      const changedPossession = play.end?.team?.id && String(play.end.team.id) !== offense;
      const lostBall = /intercept(?:ed|ion)|turnover on downs|fumble.*lost/i.test(text) || changedPossession || fourthDown;
      if (!lostBall && !/defensive stop.*(?:seal|end.*game)|(?:seal|end.*game).*defensive stop/i.test(text)) continue;

      const period = Number(play.period?.number || play.period || 0);
      const clock = String(play.clock?.displayValue || '').match(/^(\d+):(\d{2})$/);
      const seconds = clock ? Number(clock[1]) * 60 + Number(clock[2]) : Infinity;
      const late = period > 4 || (period === 4 && seconds <= 120);
      const explicitFinal = period >= 4 && /final (?:meaningful )?possession|seals? (?:the )?(?:game|win)|game[- ]sealing/i.test(text);
      if (!late && !explicitFinal) continue;

      const endZone = /intercept(?:ed|ion)/i.test(text) && /end zone|endzone/i.test(text);
      const yards = Number(play.start?.yardsToEndzone);
      const redZone = (Number.isFinite(yards) && yards >= 0 && yards <= 20) || /goal.to.go|\band goal\b|red zone/i.test(text);
      return {label:'Decisive defensive finish',points:endZone ? 14 : redZone ? 12 : 9};
    }
    return null;
  }

  function footballStagnationImpact(
    sport,
    summary,
    progress,
    state='live'
  ) {
    if (
      !['NFL','CFB'].includes(sport) ||
      !summary ||
      (state !== 'completed' && !(sport === 'NFL' && state === 'live' && progress >= .65))
    ) {
      return {
        points:0,
        text:''
      };
    }

    const p =
      state === 'completed'
        ? 1
        : Math.max(
            0,
            Math.min(
              1,
              Number(progress) || 0
            )
          );

    const competition =
      summary?.header
        ?.competitions?.[0];

    const scores =
      (competition?.competitors || [])
        .map(team =>
          Number(team?.score)
        )
        .filter(Number.isFinite);

    const combinedScore =
      scores.length === 2
        ? scores[0] + scores[1]
        : null;

    const normalize =
      value =>
        String(value || '')
          .toLowerCase()
          .replace(
            /[^a-z0-9]/g,
            ''
          );

    const statMaps =
      (summary?.boxscore?.teams || [])
        .map(team =>
          new Map(
            (team.statistics || [])
              .map(stat => [
                normalize(
                  stat.name ||
                  stat.abbreviation ||
                  stat.label ||
                  stat.displayName
                ),
                stat
              ])
              .filter(([name]) =>
                Boolean(name)
              )
          )
        );

    const findStat =
      (map,names) => {
        for (const name of names) {
          const stat =
            map.get(
              normalize(name)
            );

          if (stat) {
            return stat;
          }
        }

        return null;
      };

    const numberValue =
      stat => {
        if (!stat) {
          return null;
        }

        const direct =
          Number(stat.value);

        if (
          Number.isFinite(direct)
        ) {
          return direct;
        }

        const match =
          String(
            stat.displayValue ?? ''
          ).match(
            /-?\d+(?:\.\d+)?/
          );

        return match
          ? Number(match[0])
          : null;
      };

    const efficiency =
      stat => {
        if (!stat) {
          return null;
        }

        const text =
          String(
            stat.displayValue ?? ''
          );

        const match =
          text.match(
            /(\d+)\s*[-/]\s*(\d+)/
          );

        if (match) {
          const made =
            Number(match[1]);

          const attempts =
            Number(match[2]);

          return {
            rate:
              attempts
                ? made / attempts
                : 0,
            attempts
          };
        }

        const value =
          numberValue(stat);

        if (value === null) {
          return null;
        }

        return {
          rate:
            Math.max(
              0,
              Math.min(
                1,
                value > 1
                  ? value / 100
                  : value
              )
            ),
          attempts:null
        };
      };

    const average =
      values => {
        const usable =
          values.filter(
            Number.isFinite
          );

        return usable.length
          ? usable.reduce(
              (sum,value) =>
                sum + value,
              0
            ) /
            usable.length
          : null;
      };

    const yardsPerPlay =
      average(
        statMaps.map(map =>
          numberValue(
            findStat(
              map,
              [
                'yardsPerPlay',
                'yardsPerPlayAverage'
              ]
            )
          )
        )
      );

    const thirdDowns =

      statMaps
        .map(map =>
          efficiency(
            findStat(
              map,
              [
                'thirdDownEff',
                'thirdDownEfficiency'
              ]
            )
          )
        )
        .filter(Boolean);

    const thirdDownRate =
      thirdDowns.length
        ? average(
            thirdDowns.map(
              item =>
                item.rate
            )
          )
        : null;

    const redZones =
      statMaps
        .map(map =>
          efficiency(
            findStat(
              map,
              [
                'redZoneAttempts',
                'redZoneEfficiency',
                'redZoneEff'
              ]
            )
          )
        )
        .filter(Boolean);

    const redZoneAttempts =
      redZones.length &&
      redZones.every(item =>
        Number.isFinite(
          item.attempts
        )
      )
        ? redZones.reduce(
            (sum,item) =>
              sum +
              item.attempts,
            0
          )
        : null;

    const redZoneTouchdowns =
      redZoneAttempts !== null
        ? redZones.reduce(
            (sum,item) =>
              sum +
              item.rate *
              item.attempts,
            0
          )
        : null;

    const drives = [
      ...(summary?.drives?.previous || []),
      ...(
        state === 'completed' && summary?.drives?.current
          ? [summary.drives.current]
          : []
      )
    ].filter(drive =>
      drive &&
      drive.isCurrent !== true &&
      !/end of (?:half|game)|kneel/i
        .test(
          String(
            drive.result ||
            drive.description ||
            ''
          )
        )
    );

    const puntRate =
      drives.length >= 4
        ? drives.filter(drive =>
            /punt/i.test(
              String(
                drive.result ||
                drive.description ||
                ''
              )
            )
          ).length /
          drives.length
        : null;

    const puntTotal =
      (summary?.boxscore?.players || [])
        .flatMap(block =>
          (block.statistics || [])
            .filter(group =>
              group.name === 'punting'
            )
            .flatMap(group =>
              (group.athletes || [])
                .map(athlete =>
                  Number(
                    athlete.stats?.[0]
                  ) || 0
                )
            )
        )
        .reduce(
          (sum,value) =>
            sum + value,
          0
        );

    const clamp01 =
      value =>
        Math.max(
          0,
          Math.min(
            1,
            value
          )
        );

    const signals = [];

    if (
      combinedScore !== null
    ) {
      const total =
        [
          lineFromSummary(
            summary,
            sport
          )?.total,
          parseLine(
            competition?.odds?.[0],
            competition,
            sport
          )?.total,
          parseLine(
            summary?.odds?.[0],
            competition,
            sport
          )?.total
        ].find(value =>
          Number.isFinite(value) &&
          value > 0
        );

      const expectedLowEnd =
        (
          total !== undefined
            ? total
            : sport === 'CFB'
              ? 28
              : 22
        ) * p;

      signals.push({
        label:'very little scoring',
        weight:.30,
        value:
          expectedLowEnd
            ? clamp01(
                (
                  expectedLowEnd -
                  combinedScore
                ) /
                expectedLowEnd
              )
            : 0
      });
    }

    if (
      yardsPerPlay !== null
    ) {
      signals.push({
        label:'low yards per play',
        weight:.25,
        value:
          clamp01(
            (
              4.9 -
              yardsPerPlay
            ) /
            1.4
          )
      });
    }

    if (
      puntRate !== null
    ) {
      signals.push({
        label:'repeated empty possessions',
        weight:.20,
        value:
          clamp01(
            (
              puntRate -
              .35
            ) /
            .40
          )
      });
    } else if (
      puntTotal
    ) {
      signals.push({
        label:'repeated punts',
        weight:.15,
        value:
          clamp01(
            (
              puntTotal -
              6
            ) / 6
          )
      });
    }

    if (
      redZoneAttempts !== null
    ) {
      const expected =
        (
          sport === 'CFB'
            ? 5
            : 4
        ) *
        p;

      const fewOpportunities =
        expected
          ? clamp01(
              (
                expected -
                redZoneAttempts
              ) /
              expected
            )
          : 0;

      const failedConversions =
        redZoneAttempts
          ? clamp01(
              (
                .5 -
                redZoneTouchdowns /
                redZoneAttempts
              ) / .5
            ) *
            clamp01(
              redZoneAttempts / 3
            )
          : 0;

      signals.push({
        label:
          failedConversions > fewOpportunities
            ? 'poor red-zone touchdown conversion'
            : 'few scoring opportunities',
        weight:.15,
        value:
          Math.max(
            fewOpportunities,
            failedConversions
          )
      });
    }

    if (
      thirdDownRate !== null
    ) {
      signals.push({
        label:'poor third-down offense',
        weight:.10,
        value:
          clamp01(
            (
              .34 -
              thirdDownRate
            ) /
            .22
          )
      });
    }

    const scoringPlays =
      summary?.scoringPlays || [];

    if (
      scoringPlays.length >= 4
    ) {
      signals.push({
        label:'no touchdowns',
        weight:.10,
        value:
          scoringPlays.some(play =>
            /touchdown/i.test(
              `${play.text || ''} ${play.type?.text || ''}`
            )
          )
            ? 0
            : 1
      });
    }

    // Low scoring by itself is not enough. Require several independent signs
    // that both offenses are failing to create meaningful action.
    const meaningful =
      signals.filter(
        signal =>
          signal.value >= .35
      );

    if (
      (state === 'live' ? meaningful.filter(signal => signal.label !== 'no touchdowns').length : meaningful.length) < 3
    ) {
      return {
        points:0,
        text:''
      };
    }

    const totalWeight =
      signals.reduce(
        (sum,signal) =>
          sum +
          signal.weight,
        0
      );

    let index =
      totalWeight
        ? signals.reduce(
            (sum,signal) =>
              sum +
              signal.value *
              signal.weight,
            0
          ) /
          totalWeight
        : 0;

    // Defensive playmaking can make a low-scoring game entertaining, so
    // turnovers, sacks, fourth-down drama, blocks and explosive plays soften
    // the penalty without erasing genuine prolonged stagnation.
    let action = 0;

    const defensivePlays =
      summary?.plays?.length
        ? summary.plays
        : (summary?.drives?.previous || [])
            .flatMap(drive =>
              drive.plays || []
            );

    for (
      const play of
      defensivePlays
    ) {
      const text =
        String(
          play.text ||
          play.shortText ||
          play.type?.text ||
          ''
        ).toLowerCase();

      if (state === 'live' && /no play|nullified|overturned/i.test(text)) continue;

      if (
        /intercept(?:ed|ion)|fumble.*(?:lost|recover)/
          .test(text)
      ) {
        action += .75;

        const returnYards =
          Number(
            text.match(
              /return(?:ed)?(?: for)?\s+(\d+)\s+yards/
            )?.[1] || 0
          );

        if (
          returnYards >= 20
        ) {
          action += 3;
        }

        if (
          Number(
            play.period?.number ||
            play.period
          ) >= 4 &&
          Number.isFinite(
            Number(play.homeScore)
          ) &&
          Number.isFinite(
            Number(play.awayScore)
          ) &&
          Math.abs(
            Number(play.homeScore) -
            Number(play.awayScore)
          ) <= 8
        ) {
          action += 2;
        }
      }

      if (
        /\bsack(?:ed)?\b/
          .test(text)
      ) {
        action += .5;
      }

      if (
        (state === 'live'
          ? /turnover on downs|stopped on fourth|fourth.down stop/.test(text) ||
            (Number(play.start?.down) === 4 && /incomplete|no gain|sack/.test(text))
          : /turnover on downs|4th down|fourth down|stopped on fourth/.test(text))
      ) {
        action += 2;
      }

      if (
        /blocked (?:punt|field goal|kick)|\bsafety\b/
          .test(text)
      ) {
        action += 5;
      }

      if (
        /defensive touchdown|interception return.*touchdown|fumble return.*touchdown/
          .test(text)
      ) {
        action += 8;
      }

      const yards =
        Number(
          play.statYardage ??
          play.yards ??
          play.statYards
        );

      if (
        Number.isFinite(yards) &&
        Math.abs(yards) >= 20
      ) {
        action += 1;
      }
    }

    const severeCompleted =
      meaningful.length >= 5;

    if (state === 'live') {
      // Boxscore evidence may cover more plays than a partial play feed.
      // Take the larger evidence estimate; never add the same action twice.
      const statAction = statMaps.reduce((sum,map) => sum + [
        [['turnovers'],.75], [['sacks'],.5], [['fourthDownStops'],2],
        [['blockedKicks','kicksBlocked'],5], [['safeties'],5],
        [['defensiveTouchdowns'],8], [['explosivePlays'],1]
      ].reduce((value,[names,weight]) => value+Math.max(0,numberValue(findStat(map,names)) || 0)*weight,0),0);
      action = Math.max(action,statAction);
    }

    index *=
      1 -
      Math.min(
        state === 'live' ? 1 : severeCompleted
          ? .9
          : .25,
        state === 'live' ? action / 12 : severeCompleted
          ? action / 24
          : action / 40
      );

    if (
      index < .45
    ) {
      return {
        points:0,
        text:''
      };
    }

    const progressMultiplier =
      state === 'completed'
        ? 1
        : clamp01((p-.65)/.20);

    const cap =
      state === 'live' ? 10 : severeCompleted
        ? 36
        : 20;

    const points =
      Math.max(
        state === 'live' ? 0 : 1,
        Math.round(
          cap *
          progressMultiplier *
          index
        )
      );

    const strongest =
      [...signals]
        .sort(
          (a,b) =>
            b.value -
            a.value
        )
        .filter(
          signal =>
            signal.value >= .35
        )
        .slice(0,3)
        .map(
          signal =>
            signal.label
        );

    return {
      points,
      text:
        `Offensive stagnation: ${strongest.join(', ')}`
    };
  }

  function footballMarginCloseness(gap) {
    if (
      gap === null ||
      !Number.isFinite(Number(gap))
    ) {
      return 0;
    }

    const points =
      Math.max(
        0,
        Number(gap)
      );

    const anchors = [
      [0,1],
      [3,.98],
      [8,.90],
      [9,.82],
      [11,.72],
      [14,.58],
      [16,.52],
      [24,.28],
      [32,0]
    ];

    if (points <= anchors[0][0]) {
      return anchors[0][1];
    }

    for (
      let i = 1;
      i < anchors.length;
      i++
    ) {
      if (points <= anchors[i][0]) {
        const [x0,y0] = anchors[i-1];
        const [x1,y1] = anchors[i];
        const t =
          (points - x0) /
          (x1 - x0);

        return (
          y0 +
          (y1 - y0) * t
        );
      }
    }

    return 0;
  }

  function footballCompetitorId(item) {
    return String(
      item?.team?.id ||
      item?.id ||
      ''
    );
  }

  function footballCompetitorAbbreviation(item) {
    return String(
      item?.team?.abbreviation ||
      item?.abbreviation ||
      ''
    ).toUpperCase();
  }

  function footballSituationFieldPosition(
    situation,
    holderAbbr
  ) {
    const text =
      `${situation?.possessionText || ''} ${situation?.downDistanceText || ''} ${situation?.shortDownDistanceText || ''}`
        .toUpperCase();

    const match =
      text.match(
        /\b([A-Z]{2,4})\s+(\d{1,2})\b/
      );

    if (!match) {
      return /\b50\b/.test(text)
        ? 50
        : null;
    }

    const code = match[1];
    const yard = Number(match[2]);

    if (
      !Number.isFinite(yard) ||
      yard < 0 ||
      yard > 50
    ) {
      return null;
    }

    return code === holderAbbr
      ? yard
      : 100 - yard;
  }

  function footballLiveCloseness(
    sport,
    gap,
    progress,
    context=null
  ) {
    const points =
      Number(gap);

    if (
      !['NFL','CFB'].includes(sport) ||
      !Number.isFinite(points)
    ) {
      return null;
    }

    const p =
      Math.max(
        0,
        Math.min(
          1,
          Number(progress) || 0
        )
      );

    const requiredPossessions =
      points <= 0
        ? 0
        : Math.ceil(
            points / 8
          );

    const fullGamePossessions =
      sport === 'CFB'
        ? 12.5
        : 10.5;

    let possessionAdjustment = 0;
    let possessionState = '';
    let fieldPosition = null;

    const competition =
      context?.competition ||
      context ||
      null;

    const situation =
      context?.situation ||
      competition?.situation ||
      {};

    const competitors =
      competition?.competitors ||
      [];

    if (
      points > 0 &&
      competitors.length === 2
    ) {
      const scored =
        competitors
          .map(item => ({
            item,
            score:Number(item?.score)
          }))
          .filter(item =>
            Number.isFinite(item.score)
          );

      if (scored.length === 2) {
        const trailing =
          scored[0].score < scored[1].score
            ? scored[0].item
            : scored[1].score < scored[0].score
              ? scored[1].item
              : null;

        const holderId =
          String(
            situation?.possession?.id ||
            situation?.possession ||
            ''
          );

        const trailingId =
          footballCompetitorId(
            trailing
          );

        if (
          trailing &&
          holderId &&
          trailingId
        ) {
          if (holderId === trailingId) {
            possessionAdjustment += .45;
            possessionState = 'trailing';

            const holderAbbr =
              footballCompetitorAbbreviation(
                trailing
              );

            fieldPosition =
              footballSituationFieldPosition(
                situation,
                holderAbbr
              );

            if (
              fieldPosition !== null &&
              fieldPosition >= 70
            ) {
              possessionAdjustment += .25;
            }
          } else if (p >= .9 && (sport !== 'NFL' || competitors.some(item => footballCompetitorId(item) === holderId))) {
            possessionAdjustment -= .35;
            possessionState = 'leading';
          }
        }
      }
    }

    let expectedPossessions =
      Math.max(
        0,
        fullGamePossessions *
          (1 - p) +
          .5 +
          possessionAdjustment
      );

    // NFL timeout information changes the available runway, not a flat bonus.
    // Missing/invalid fields leave the established possession estimate intact.
    const runway = sport === 'NFL' ? footballClockRunway(competition,situation) : null;
    if (runway) expectedPossessions = runway.expectedPossessions;

    const possessionSlack =
      expectedPossessions -
      requiredPossessions;

    const comebackFeasibility =
      requiredPossessions === 0
        ? 1
        : 1 /
          (
            1 +
            Math.exp(
              -2 *
              (
                possessionSlack +
                .8
              )
            )
          );

    const marginClose =
      footballMarginCloseness(
        points
      );

    const close =
      marginClose *
      (
        .45 +
        .55 *
        comebackFeasibility
      );

    return {
      close,
      marginClose,
      comebackFeasibility,
      requiredPossessions,
      expectedPossessions,
      possessionSlack,
      possessionAdjustment,
      possessionState,
      fieldPosition
    };
  }

  function footballTimeouts(competition,situation,team) {
    const value = situation?.[`${team?.homeAway}Timeouts`] ?? team?.timeouts;
    if (value === null || value === undefined || value === '' || typeof value === 'boolean') return null;
    const count = Number(value);
    return Number.isInteger(count) && count >= 0 && count <= 3 ? count : null;
  }

  function footballClockRunway(competition,situation=competition?.situation) {
    const status = competition?.status;
    const seconds = clockSeconds(status);
    if (Number(status?.period) !== 4 || seconds === null || seconds > 180) return null;
    const teams = competition?.competitors || [];
    if (teams.length !== 2 || teams.some(t => t.score == null || !Number.isFinite(Number(t.score)))) return null;
    const trailing = teams.find(t => Number(t.score) < Number(teams.find(other => other !== t).score));
    const holder = teams.find(t => footballCompetitorId(t) === String(situation?.possession?.id || situation?.possession || ''));
    if (!trailing || !holder || holder === trailing) return null;
    const timeouts = footballTimeouts(competition,situation,trailing);
    const down = Number(situation?.down);
    if (timeouts === null || down < 1 || down > 4 || !Number.isInteger(down)) return null;
    // Estimate a stop without a first down. The two-minute warning supplies
    // one clock stop; whether the clock is running is often absent, so reserve
    // only the intervals after the remaining scrimmage downs (conservative).
    const snaps = 4-down;
    const stops = timeouts + (seconds > 120 ? 1 : 0);
    const drain = 6*snaps + 40*Math.max(0,snaps-stops);
    const remaining = Math.max(0,seconds-drain-8); // punt/change of possession
    return {timeouts,remaining,expectedPossessions:remaining === 0 ? 0 : Math.min(1.4,.25+remaining/100)};
  }

  function footballRunwayPenalty(
    gap,
    progress,
    footballState
  ) {
    if (
      !footballState ||
      gap === null ||
      !Number.isFinite(Number(gap))
    ) {
      return 0;
    }

    const points = Number(gap);
    const p =
      Math.max(
        0,
        Math.min(
          1,
          Number(progress) || 0
        )
      );

    const possessionMismatch =
      Math.max(
        0,
        footballState.requiredPossessions -
        footballState.expectedPossessions
      );

    const lowFeasibility =
      Math.max(
        0,
        .55 -
        footballState.comebackFeasibility
      ) / .55;

    const runwayPenalty =
      points >= 9
        ? lowFeasibility *
          16 *
          (.5 + .5 * p) +
          Math.min(
            8,
            possessionMismatch * 4
          )
        : 0;

    const marginPenalty =
      points >= 17
        ? Math.min(
            14,
            (
              (points - 16) /
              16
            ) *
            10 *
            (.5 + .5 * p)
          )
        : 0;

    return Math.min(
      28,
      Math.round(
        runwayPenalty +
        marginPenalty
      )
    );
  }

  function footballFieldPosition(
    game,
    holder,
    spot,
    downText
  ) {
    const text =
      `${spot || ''} ${downText || ''}`
        .toUpperCase();

    const match =
      text.match(
        /\b([A-Z]{2,4})\s+(\d{1,2})\b/
      );

    if (!match) {
      return /\b50\b/.test(text)
        ? 50
        : null;
    }

    const code =
      match[1];

    const yard =
      Number(match[2]);

    if (
      !Number.isFinite(yard) ||
      yard < 0 ||
      yard > 50
    ) {
      return null;
    }

    const holderAbbr =
      String(
        holder?.[1] || ''
      ).toUpperCase();

    return code === holderAbbr
      ? yard
      : 100 - yard;
  }

  function footballSituationImpact(
    game,
    competition,
    status,
    situation,
    progress,
    scoreGap,
    options=null
  ) {
    const possessionId =
      String(
        situation.possession?.id ||
        situation.possession ||
        ''
      );

    const holder =
      game.teams.find(team =>
        String(
          team[8] || ''
        ) ===
        possessionId
      );

    const down =
      Number(
        situation.down
      );

    const distance =
      Number(
        situation.distance
      );

    const downText =
      String(
        situation.downDistanceText ||
        situation.shortDownDistanceText ||
        (
          down >= 1 &&
          down <= 4
            ? `${ordinal(down)} & ${Number.isFinite(distance) ? distance : 'goal'}`
            : ''
        )
      ).trim();

    const spot =
      String(
        situation.possessionText ||
        ''
      ).trim();

    const redZone =
      situation.isRedZone === true ||
      (
        /\b(?:[A-Z]{2,4}\s)?(?:[1-9]|1\d|20)\b/
          .test(spot) &&
        /red zone/i
          .test(
            String(
              situation.shortText ||
              situation.text ||
              ''
            )
          )
      );

    const goalToGo =
      situation.isGoalToGo === true ||
      /&\s*goal/i
        .test(downText);

    const fieldPosition =
      footballFieldPosition(
        game,
        holder,
        spot,
        downText
      );

    const lateOneScore =
      progress >= .72 &&
      scoreGap <= 8;

    const competitive =
      scoreGap <= 14;

    const holderIndex = holder ? game.teams.indexOf(holder) : -1;
    const holderScore = Number(game.teams?.[holderIndex]?.[2]);
    const opponentScore = Number(game.teams?.[1-holderIndex]?.[2]);
    // A goal-line possession matters most when it can tie or change the lead.
    const offenseTrailingOrTied = holderIndex >= 0 && Number.isFinite(holderScore) && Number.isFinite(opponentScore) && holderScore <= opponentScore;
    const offenseCanTieOrLead = offenseTrailingOrTied && holderScore + 7 >= opponentScore;
    const nfl = game.sport === 'NFL';
    const seconds = clockSeconds(status);
    const period = Number(status?.period);
    const runway = nfl ? footballClockRunway({...competition,status},situation) : null;

    let points = 0;
    let fourthPoints = 0;
    const reasons = [];

    if (redZone) {
      const goalLine = goalToGo && fieldPosition !== null && fieldPosition >= 95;
      const redZonePoints = offenseCanTieOrLead
        ? (goalLine ? 5 : lateOneScore ? 4 : 3)
        : offenseTrailingOrTied
          ? (goalLine ? 3 : 2)
          : 0;
      points += redZonePoints;

      if (redZonePoints) reasons.push(
        goalLine
          ? `${holder?.[0] || 'The offense'} is goal-to-go at the doorstep`
          : `${holder?.[0] || 'The offense'} is in the red zone`
      );
    }

    if (
      down === 4 &&
      downText
    ) {
      let fourth = 1;

      if (
        competitive &&
        (
          redZone ||
          fieldPosition > 50
        )
      ) {
        fourth++;
      }

      if (
        competitive &&
        Number.isFinite(distance) &&
        distance <= 2
      ) {
        fourth += 2;
      }

      if (lateOneScore) {
        fourth += 3;
      }

      if (competitive && redZone) {
        fourth += 1;
      } else if (
        competitive &&
        fieldPosition !== null &&
        fieldPosition >= 70
      ) {
        fourth += 1;
      }

      if (competitive && goalToGo) {
        fourth += 2;
      }

      if (
        progress >= .9 &&
        lateOneScore
      ) {
        fourth += 2;
      }

      fourth =
        Math.min(
          10,
          fourth
        );

      if (nfl) {
        const urgent = period >= 4 && (period > 4 || (seconds !== null && seconds <= 240));
        const liveDrive = offenseTrailingOrTied && scoreGap <= 8;
        fourth = urgent && liveDrive
          ? (seconds !== null && seconds <= 120 ? 10 : 7) + (fieldPosition >= 65 ? 1 : 0)
          : urgent && scoreGap <= 8 && holderIndex >= 0
            ? (runway?.remaining === 0 ? 2 : 6)
            : competitive ? Math.min(3,1 + (distance > 0 && distance <= 2 ? 1 : 0) + (fieldPosition >= 70 ? 1 : 0)) : 1;
      }

      fourthPoints = fourth;
      points += fourth;

      reasons.push(
        fourth > 1
          ? `${downText} is a pivotal down`
          : downText
      );
    }

    if (
      !redZone &&
      fieldPosition !== null &&
      fieldPosition >= 80 &&
      scoreGap <= 8 &&
      offenseTrailingOrTied
    ) {
      points += 2;

      reasons.push(
        `${holder?.[0] || 'The offense'} is deep in opponent territory`
      );
    }

    if (lateOneScore && !nfl) {
      points +=
        progress >= .9
          ? 4
          : 2;

      reasons.push(
        `It is a one-possession game late in the ${Number(status?.period) >= 4 ? 'fourth quarter' : 'game'}`
      );
    }

    if (
      seconds !== null &&
      Number(status?.period) >= 4 &&
      seconds <= 120 &&
      scoreGap <= 8 && !nfl
    ) {
      points += 2;

      reasons.push(
        'The game is in a two-minute decision window'
      );
    }

    // A live tying or winning possession has leverage even when the leader's
    // win probability has grown. Share the existing situation cap with the
    // clock, field-position and fourth-down bonuses rather than stacking them.
    if (nfl && lateOneScore) {
      const direction = holderIndex < 0 ? 1 : offenseTrailingOrTied ? 4 : runway?.remaining === 0 ? 0 : 2;
      points = Math.max(points,direction);
      if (direction) reasons.push(offenseTrailingOrTied ? 'A tying or winning possession is available late' : 'A late one-possession game');
    }
    const decisiveDrive =
      Number(status?.period) >= 4 &&
      holderIndex >= 0 &&
      (nfl ? holderScore <= opponentScore : holderScore < opponentScore) &&
      scoreGap <= 8;
    const clockUrgency = seconds === null || (nfl && seconds <= 0)
      ? 0
      : Math.max(0,Math.min(1,(240 - seconds) / 120));
    const driveUrgency = Number(status?.period) > 4
      ? (nfl ? (options?.overtime?.canWin ? 1 : .35) : Math.max(.6,seconds === null ? 1 : clockUrgency))
      : clockUrgency;
    let driveLeverage = null;
    if (decisiveDrive && driveUrgency > 0) {
      const positionBonus = goalToGo && fieldPosition >= 95
        ? 3
        : redZone
          ? 2
          : fieldPosition >= (nfl && scoreGap <= 3 && (!options?.overtime?.active || options.overtime.fieldGoalWins) ? 58 : 70)
            ? 2
            : fieldPosition > 50
              ? 1
              : 0;
      const drivePoints = Math.round(
        driveUrgency * ((nfl && scoreGap === 0 ? 10 : scoreGap >= 4 ? 9 : 8) + positionBonus)
      );
      driveLeverage = {urgency:driveUrgency,positionBonus};
      points = Math.max(points,drivePoints + Math.min(2,fourthPoints));
      reasons.push(
        `${holder?.[0] || 'The trailing team'} has a ${scoreGap >= 4 ? 'tying or winning TD' : !nfl ? 'tying or winning score' : scoreGap === 0 ? 'go-ahead scoring' : scoreGap === 3 ? 'tying FG or winning TD' : 'winning FG or TD'} drive in progress`
      );
    }

    // Explicit pending tries only: last-play touchdown/try text can be stale.
    if (nfl && situation.isTwoPointAttempt === true && holderIndex >= 0 &&
        period >= 4 && (period > 4 || (seconds !== null && seconds <= 180))) {
      const deficit = opponentScore-holderScore;
      if ([1,2,9,10].includes(deficit)) {
        points = 12;
        driveLeverage = {urgency:1,positionBonus:2};
        reasons.push(deficit === 1 ? 'Two-point try to take the lead' : deficit === 2 ? 'Two-point try to tie' : 'Two-point try needed to stay within one possession');
      }
    }

    return {
      points:
        Math.min(
          12,
          points
        ),

      note:
        [
          holder
            ? `${holder[1] || holder[0]} ball`
            : '',
          downText,
          spot &&
          !downText.includes(spot)
            ? spot
            : ''
        ]
          .filter(Boolean)
          .join(' · '),

      reasons,
      decisiveDrive:driveLeverage
    };
  }

  function footballMilestone(summary) {
    for (
      const block of
      summary?.boxscore?.players ||
      []
    ) {
      for (
        const group of
        block.statistics ||
        []
      ) {
        if (
          !/pass/i.test(
            group.name ||
            group.displayName ||
            ''
          )
        ) {
          continue;
        }

        const touchdowns =
          (group.labels || [])
            .findIndex(label =>
              /^TD$|^PASS TD$/i
                .test(label)
            );

        if (
          touchdowns < 0
        ) {
          continue;
        }

        const passer =
          (group.athletes || [])
            .filter(entry =>
              Number(
                entry.stats?.[touchdowns]
              ) >= 3
            )
            .sort((a,b) =>
              Number(b.stats?.[touchdowns]) -
              Number(a.stats?.[touchdowns])
            )[0];

        if (passer) {
          const count =
            Number(
              passer.stats[touchdowns]
            );

          return {
            text:
              `${passer.athlete?.displayName || 'A quarterback'} has thrown ${count} touchdown passes`,
            points:
              count >= 5
                ? 12
                : count >= 4
                  ? 8
                  : 5
          };
        }
      }
    }

    return null;
  }

  function footballGameState({sport,gameState,gap,progress,context:footballContext}) {
    const footballState =
      ['NFL','CFB'].includes(sport) &&
      gameState === 'live'
        ? footballLiveCloseness(
            sport,
            gap,
            progress,
            footballContext
          )
        : null;

    return {
      footballState,
      marginClose:footballState?.close,
      comebackViability:footballState?.comebackFeasibility,
      widePenalty:footballState ? footballRunwayPenalty(gap,progress,footballState) : undefined,
      limitedRunway:Boolean(footballState)
    };
  }

  function footballEventShock({text,positioned,i,play}) {
    let value = 0;
    let label = '';
    if (/touchdown|\btd\b/.test(text) && /\b(?:[4-9]\d|1\d\d)[ -]?(?:yard|yd)s?\b/.test(text)) { value=5; label='40-plus-yard touchdown'; }
    return value ? {value,label} : null;
  }

  function footballSituation({game,competition,status,situation,progress,scoreGap}) {
    return footballSituationImpact(game,competition,status,situation,progress,scoreGap);
  }

  const api = {defensiveFinishFactor,footballStagnationImpact,footballMarginCloseness,footballCompetitorId,footballCompetitorAbbreviation,footballSituationFieldPosition,footballLiveCloseness,footballRunwayPenalty,footballFieldPosition,footballSituationImpact,footballMilestone,footballGameState,footballEventShock,footballSituation,footballTimeouts,footballClockRunway};
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api;
  } else {
    (root.SportsRadarScoring ||= {}).shared_football = api;
  }
})(globalThis);

/* Shared scoring module; supports classic browser scripts and Worker/Node bundling. */
(function (root) {
  const {NFL_DIVISIONS} = typeof module !== 'undefined' && module.exports
    ? require('../shared/config.js')
    : root.SportsRadarScoring.shared_config;
  const {recordStats} = typeof module !== 'undefined' && module.exports
    ? require('../shared/records.js')
    : root.SportsRadarScoring.shared_records;
  const {listedSpread} = typeof module !== 'undefined' && module.exports
    ? require('../shared/market.js')
    : root.SportsRadarScoring.shared_market;
  const {footballGameState,footballSituationImpact,footballMilestone,footballEventShock,footballStagnationImpact,footballFieldPosition,footballClockRunway} = typeof module !== 'undefined' && module.exports
    ? require('../shared/football.js')
    : root.SportsRadarScoring.shared_football;
  const {clockSeconds} = typeof module !== 'undefined' && module.exports
    ? require('../shared/time.js')
    : root.SportsRadarScoring.shared_time;

  function nflOvertime(competition,summary) {
    const period = Number(competition?.status?.period);
    const ordinary = {active:period > 4,suddenDeath:false,canWin:false,fieldGoalWins:false};
    if (!ordinary.active) return ordinary;
    const holder = String(competition?.situation?.possession?.id || competition?.situation?.possession || '');
    const teams = competition?.competitors || [];
    const offense = teams.find(t => String(t.team?.id || t.id || '') === holder);
    const defense = teams.find(t => t !== offense);
    if (!holder || teams.length !== 2 || !offense || !defense || offense.score == null || defense.score == null) return ordinary;
    const deficit = Number(defense.score)-Number(offense.score);
    if (!Number.isFinite(deficit)) return ordinary;
    // Use completed, identifiable OT offensive drives. Period alone and the
    // provider's format.overtime metadata say nothing about possession rights.
    const completed = (summary?.drives?.previous || []).filter(d => {
      const plays = d.plays || [];
      const startPeriod = Number(d.start?.period?.number ?? plays[0]?.period?.number);
      return startPeriod > 4 && startPeriod <= period && d.isCurrent !== true &&
        d.result && !/end of|kickoff/i.test(d.result) &&
        plays.some(p => String(p.start?.team?.id || '') === String(d.team?.id || '') &&
          p.start?.team?.id && !/kickoff|timeout|end of/i.test(p.type?.text || p.text || ''));
    });
    const possessed = new Set(completed.map(d => String(d.team?.id || '')));
    const otherHadBall = possessed.has(String(defense.team?.id || defense.id || ''));
    const suddenDeath = deficit === 0 && otherHadBall && possessed.has(holder);
    const year = Number(summary?.header?.season?.year || competition?.season?.year);
    const seasonType = Number(summary?.header?.season?.type || competition?.season?.type);
    const postseason = seasonType === 3;
    // Historical inputs can identify the pre-2025 regular-season / pre-2022
    // postseason opening-TD rule. Unknown year uses today's two-opportunity rule.
    const openingTdWins = year > 0 && (seasonType === 2 || postseason) && year < (postseason ? 2022 : 2025);
    return {active:true,suddenDeath,canWin:deficit >= 0 && deficit <= 7 && (otherHadBall || openingTdWins),
      fieldGoalWins:deficit >= 0 && deficit < 3 && otherHadBall};
  }

  function nflSituation(args) {
    const overtime = nflOvertime(args.competition,args.summary);
    const result = footballSituationImpact(args.game,args.competition,args.status,args.situation,args.progress,args.scoreGap,{overtime});
    const {game,competition,status,situation,scoreGap} = args;
    const holderId = String(situation.possession?.id || situation.possession || '');
    const holder = game.teams.find(team => String(team[8] || '') === holderId);
    const opponent = game.teams.find(team => team !== holder);
    const deficit = holder && opponent ? Number(opponent[2])-Number(holder[2]) : NaN;
    const seconds = clockSeconds(status);
    const regulation = Number(status?.period) === 4;
    const criticalTry = situation.isTwoPointAttempt === true && [1,2].includes(deficit) &&
      regulation && seconds !== null && seconds >= 0 && seconds <= 120;
    // Strengthen the existing competitive floor, never an independent award.
    // Headroom keeps an already compelling upset/stakes state from receiving
    // the same raw increase as a generic decisive possession.
    const base = Number(game.baseScore);
    if (Number.isFinite(base) && (criticalTry || (regulation && seconds > 0 &&
        seconds <= 180 && result.decisiveDrive && deficit >= 0 && deficit <= 8))) {
      const position = footballFieldPosition(game,holder,situation.possessionText,
        situation.downDistanceText || situation.shortDownDistanceText);
      const goal = (situation.isGoalToGo === true || /&\s*goal/i.test(situation.downDistanceText || situation.shortDownDistanceText || '')) &&
        position !== null && position >= 90;
      const territory = position === null ? 0 : Math.max(0,Math.min(1,(position-25)/55));
      const winningRange = deficit < 3 && position !== null && position >= 58;
      let consequence = winningRange ? .80 : .70 + .06*territory;
      // Estimate whether a failed fourth down leaves another possession using
      // the same timeout/runoff math as the existing leading-possession model.
      const afterFailure = footballClockRunway({...competition,status},
        {...situation,possession:opponent?.[8],down:1});
      const finalFourth = Number(situation.down) === 4 && deficit > 0 &&
        (afterFailure ? afterFailure.remaining <= 15 : seconds <= 60);
      if (finalFourth) {
        const distance = Number(situation.distance);
        const shortness = Number.isFinite(distance) && distance > 0
          ? Math.max(0,Math.min(1,(10-distance)/9)) : 0;
        consequence = Math.max(consequence,.82+.04*shortness);
      }
      if (goal) consequence = Math.max(consequence,.86);
      if (criticalTry) consequence = deficit === 1 ? .90 : .86;
      // A full-field march with only seconds left is not a viable drive. A
      // goal-line snap or explicit try can still decide matters immediately.
      const yardsNeeded = position === null ? 75 : Math.max(0,(scoreGap <= 3 ? 65 : 100)-position);
      const viability = criticalTry || goal ? 1 : Math.min(1,seconds/(8+.65*yardsNeeded));
      const urgency = criticalTry ? 1 : result.decisiveDrive.urgency;
      result.competitiveFloor = Math.round(Math.max(0,99-base)*consequence*urgency*viability);
    }
    if (overtime.canWin) result.reasons.push(overtime.suddenDeath ? 'Sudden-death overtime: next score wins' : 'This overtime possession can win the game');
    return result;
  }

  function nflGameState(args) {
    const result = footballGameState(args);
    if (args.gameState !== 'live' || !result.footballState || args.gap == null ||
        !Number.isFinite(args.gap) || args.gap < 0 || args.gap > 8 || args.progress < .75) return result;
    const competition = args.context?.competition || args.context;
    const status = competition?.status;
    const seconds = clockSeconds(status);
    const overtime = nflOvertime(competition,args.context?.summary);
    const state = result.footballState;
    const urgency = Number(status?.period) === 4 && seconds !== null
      ? (seconds > 0 ? Math.max(0,Math.min(1,(600-seconds)/480)) : 0)
      : overtime.canWin ? 1 : 0;
    // Calibrate state watchability, independently of the last play. Direction
    // and timeout runway gate this increase; field position stays in situation.
    const directional = args.gap === 0 || state.possessionState === 'trailing'
      ? 1 : state.possessionState === 'leading' ? state.comebackFeasibility*.4 : .2;
    result.closeCeiling = 14+16*Math.max(0,Math.min(1,args.progress)) + 12*urgency*directional;
    return result;
  }

  function nflDivisionFor(competitors) {
    const divisions =
      competitors.map(item =>
        NFL_DIVISIONS[
          String(
            item.team?.abbreviation ||
            ''
          ).toUpperCase()
        ]
      );

    return (
      divisions.length === 2 &&
      divisions[0] &&
      divisions[0] === divisions[1]
    )
      ? divisions[0]
      : '';
  }

  function nflSpreadPoints(spread) {
    return Math.round(7 * Math.exp(-((spread / 7.5) ** 2)));
  }

  function unbeatenStartImpact(sport,gameState,teams) {
    if (sport !== 'NFL' || gameState !== 'completed' || teams.length !== 2) return 0;
    const scores = teams.map(team => Number(team.score ?? team[2]));
    if (!scores.every(Number.isFinite) || scores[0] === scores[1]) return 0;
    const loser = teams[scores[0] < scores[1] ? 0 : 1];
    const record = String(loser.pregameRecord || '').match(/^(\d+)-(\d+)(?:-(\d+))?$/);
    if (!record || Number(record[1]) < 4 || Number(record[2]) !== 0) return 0;
    return Math.round(Math.min(10,4 + .75 * (Number(record[1]) - 4)));
  }

  function nflPregame(sport,competition,competitors,postseason,factors,reason) {
    if (sport === 'NFL') {
      const division =
        nflDivisionFor(
          competitors
        );

      const records =
        competitors.map(
          recordStats
        );

      const knownRecords =
        !postseason &&
        records.length === 2 &&
        records.every(Boolean);

      const bothWinning =
        knownRecords &&
        records.every(
          record =>
            record.pct > .5
        );

      if (division) {
        factors.push({
          label:`${division} matchup`,
          points:4
        });

        if (bothWinning) {
          factors.push({
            label:'Division race between winning teams',
            points:3
          });
        }

        reason +=
          ` · ${division} rivals`;
      }

      if (bothWinning) {
        factors.push({
          label:'Both winning records',
          points:14
        });

        if (
          Math.abs(
            records[0].pct -
            records[1].pct
          ) <= .1
        ) {
          factors.push({
            label:'Evenly matched winning records',
            points:4
          });
        }

        reason +=
          ' · both teams winning';
      } else if (
        knownRecords &&
        records.every(
          record =>
            record.pct >= .5
        )
      ) {
        factors.push({
          label:'Both teams at least .500',
          points:5
        });
      } else if (
        knownRecords &&
        records.every(
          record =>
            record.pct < .5
        )
      ) {
        factors.push({
          label:'Both teams below .500',
          points:-7
        });
      }

      if (
        knownRecords &&
        records.some(
          record =>
            record.wins === 0 &&
            record.games >= 3
        )
      ) {
        factors.push({
          label:'Winless team',
          points:-5
        });
      }

      if (
        knownRecords &&
        records.some(
          record =>
            record.losses === 0 &&
            record.games >= 3
        )
      ) {
        factors.push({
          label:'Unbeaten team',
          points:7
        });
      }

      const spread =
        listedSpread(
          competition
        );

      const spreadPoints = spread === null
        ? 0
        : nflSpreadPoints(spread);
      if (spreadPoints) {
        const tight = spreadPoints >= 5;
        factors.push({
          label:tight
            ? 'Tight projected spread'
            : 'Competitive projected spread',
          points:spreadPoints
        });

        reason += tight
          ? ' · close line'
          : ' · competitive line';
      }
    }

    return reason;
  }

  const nflModel = {
    pregame:nflPregame,
    gameState:nflGameState,
    situation:nflSituation,
    milestone:footballMilestone,
    completedResult:(sport,gameState,teams) => ({
      label:'Ended unbeaten start',points:unbeatenStartImpact(sport,gameState,teams)
    }),
    eventShock:footballEventShock,
    history:{threshold:7,units:'points',stagnation:footballStagnationImpact}
  };

  const api = {nflDivisionFor,nflSpreadPoints,unbeatenStartImpact,nflPregame,nflModel,nflOvertime};
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api;
  } else {
    (root.SportsRadarScoring ||= {}).sports_nfl = api;
  }
})(globalThis);

/* Shared scoring module; supports classic browser scripts and Worker/Node bundling. */
(function (root) {
  const {pregameMarketFactor} = typeof module !== 'undefined' && module.exports
    ? require('./market.js')
    : root.SportsRadarScoring.shared_market;
  const {proRecordFactors,divisionFor} = typeof module !== 'undefined' && module.exports
    ? require('./records.js')
    : root.SportsRadarScoring.shared_records;

  function marketPregame(sport,competition,factors,reason) {
    if (['MLB','NHL','NBA','CFB','NCAAB'].includes(sport)) {
      const market =
        pregameMarketFactor(
          sport,
          competition
        );

      if (market) {
        factors.push(market);

        reason +=
          market.points >= 5
            ? ' · near pick’em'
            : ' · competitive market';
      }
    }

    return reason;
  }

  function proPregame(sport,competition,competitors,postseason,factors,reason,detail) {
    if (
      ['MLB','NHL','NBA']
        .includes(sport)
    ) {
      const recordFactors = postseason ? [] :
        proRecordFactors(
          sport,
          competitors
        );

      factors.push(
        ...recordFactors
      );

      const division =
        divisionFor(
          sport,
          competitors
        );

      const bothWinning =
        recordFactors.some(
          item =>
            item.label ===
            'Both winning records'
        );

      if (division) {
        factors.push({
          label:`${division} matchup`,
          points:3
        });

        const meaningfulDivisionRace =
          bothWinning &&
          /playoff|postseason|wild card|race|elimination|clinching/
            .test(detail);

        if (meaningfulDivisionRace) {
          factors.push({
            label:'Division matchup between winning teams',
            points:2
          });
        }

        reason +=
          ` · ${division} matchup`;
      }

      if (bothWinning) {
        reason +=
          ' · both teams winning';
      }

    }

    return marketPregame(sport,competition,factors,reason);
  }

  const api = {marketPregame,proPregame};
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api;
  } else {
    (root.SportsRadarScoring ||= {}).shared_pregame = api;
  }
})(globalThis);

/* Shared scoring module; supports classic browser scripts and Worker/Node bundling. */
(function (root) {
  const {proPregame} = typeof module !== 'undefined' && module.exports
    ? require('../shared/pregame.js')
    : root.SportsRadarScoring.shared_pregame;

  function mlbLiveMarginCloseness(gap,progress) {
    if (gap === null || !Number.isFinite(Number(gap))) return 0;
    const p = Math.max(0,Math.min(1,Number(progress) || 0));
    const tolerance = 6.5 - 3.6 * p;
    return Math.max(0,1 - Number(gap) / tolerance);
  }

  function runnerOn(
    situation,
    base
  ) {
    const value =
      situation?.[`on${base}`] ??
      situation?.runners
        ?.[base.toLowerCase()];

    return (
      value === undefined ||
      value === null
    )
      ? null
      : Boolean(value);
  }

  function sideScores(
    game,
    competition
  ) {
    const byId =
      new Map(
        game.teams.map(
          team => [
            String(
              team[8] || ''
            ),
            Number(team[2])
          ]
        )
      );

    const result = {};

    for (
      const item of
      competition?.competitors ||
      []
    ) {
      const side =
        item.homeAway;

      const id =
        String(
          item.team?.id ||
          item.id ||
          ''
        );

      const direct =
        Number(
          item.score
        );

      const fallback =
        byId.get(id);

      if (side) {
        result[side] =
          Number.isFinite(direct)
            ? direct
            : fallback;
      }
    }

    return result;
  }

  function baseballSituationImpact(
    game,
    competition,
    status,
    situation,
    progress,
    scoreGap
  ) {
    const bases = {
      first:
        runnerOn(
          situation,
          'First'
        ),
      second:
        runnerOn(
          situation,
          'Second'
        ),
      third:
        runnerOn(
          situation,
          'Third'
        )
    };

    const occupied =
      Object.entries(bases)
        .filter(
          ([,value]) =>
            value
        )
        .map(
          ([base]) =>
            base
        );

    const outs =
      Number(
        situation.outs
      );

    const hasOuts =
      situation.outs !== undefined &&
      situation.outs !== null &&
      Number.isInteger(outs) &&
      outs >= 0 &&
      outs <= 2;

    const inning =
      Number(
        status?.period || 0
      );

    const detail =
      String(
        status?.type?.detail ||
        status?.type?.shortDetail ||
        ''
      ).toLowerCase();

    const half =
      /bottom|bot\b/.test(detail)
        ? 'bottom'
        : /top\b/.test(detail)
          ? 'top'
          : '';

    const battingSide =
      half === 'bottom'
        ? 'home'
        : half === 'top'
          ? 'away'
          : '';

    const scores =
      sideScores(
        game,
        competition
      );

    const battingScore =
      battingSide
        ? Number(
            scores[battingSide]
          )
        : NaN;

    const fieldingScore =
      battingSide
        ? Number(
            scores[
              battingSide === 'home'
                ? 'away'
                : 'home'
            ]
          )
        : NaN;

    const differential =
      Number.isFinite(battingScore) &&
      Number.isFinite(fieldingScore)
        ? battingScore -
          fieldingScore
        : null;
    const countText = String(situation.count || `${situation.balls ?? ''}-${situation.strikes ?? ''}`);
    const fullCount = /^3-2$/.test(countText.trim());

    if (Number.isFinite(outs) && outs >= 3) {
      return {points:0,note:'3 outs',reasons:[],bases,competitiveFloor:0};
    }

    let points = 0;
    const reasons = [];

    if (occupied.length) {
      const occupiedText =
        occupied.length === 3
          ? `${occupied[0]}, ${occupied[1]}, and ${occupied[2]}`
          : occupied.join(' and ');

      reasons.push(
        `Runners on ${occupiedText}`
      );
    }

    if (
      occupied.length === 3
    ) {
      points +=
        scoreGap <= 2
          ? (inning >= 7 ? 4 : 2)
          : scoreGap <= 4
            ? 1
            : 0;

      if (scoreGap <= 4) reasons.push('The bases are loaded');
    }

    if (
      (
        bases.second ||
        bases.third
      ) &&
      inning >= 7 &&
      scoreGap <= 2 &&
      differential !== null &&
      differential <= 0
    ) {
      points +=
        inning >= 9
          ? 6
          : 4;

      reasons.push(
        'The tying or go-ahead run is in scoring position late'
      );
    }

    if (
      bases.third &&
      inning >= 9 &&
      scoreGap <= 1
    ) {
      points += 2;

      reasons.push(
        'A critical run is 90 feet away'
      );
    }

    if (
      half === 'bottom' &&
      inning >= 9 &&
      differential === 0
    ) {
      points += 7;

      reasons.push(
        'The home team has a walk-off opportunity'
      );
    } else if (
      half === 'bottom' &&
      inning >= 9 &&
      differential === -1 &&
      occupied.length
    ) {
      points += 5;

      reasons.push(
        'The tying run is on base in the bottom of the ninth or later'
      );
    }

    if (
      hasOuts &&
      outs === 2 &&
      occupied.length &&
      inning >= 7 &&
      scoreGap <= 2
    ) {
      points += 2;

      reasons.push(
        'The inning has reached a two-out pressure spot'
      );
    }

    if (inning >= 7 && scoreGap <= 2 && hasOuts && outs === 2 && fullCount) {
      points += 3;
      reasons.push('A full count with two outs raises the plate appearance leverage');
    }

    if (inning >= 7 && scoreGap <= 2 && differential !== null && differential <= 0) {
      if (differential === 0) {
        points += occupied.length ? 3 : 4;
        reasons.push(occupied.length ? 'The go-ahead run is on base' : 'The go-ahead run is at the plate');
      } else {
        const runsToTie = Math.abs(differential);
        if (occupied.length >= runsToTie) {
          points += 3;
          reasons.push('The tying run is on base');
        } else if (occupied.length + 1 === runsToTie) {
          points += 4;
          reasons.push('The tying run is at the plate');
        } else if (occupied.length + 2 === runsToTie && (situation.onDeck || situation.onDeckBatter || situation.nextBatter)) {
          points += 2;
          reasons.push('The tying run is on deck');
        }
      }
    }

    const decisivePlateAppearance = inning >= 9 &&
      (half === 'bottom' || half === 'top' && differential < 0) &&
      differential !== null && differential <= 0 &&
      -differential <= occupied.length + 1 && scoreGap <= 3;
    const competitiveFloor = decisivePlateAppearance
      ? Math.min(20,15 + (hasOuts && outs === 2 ? 2 : 0) +
          (fullCount ? 2 : 0) + (occupied.length ? 1 : 0) +
          (bases.second || bases.third ? 1 : 0))
      : 0;

    return {
      points:
        Math.min(
          12,
          points
        ),

      note:
        hasOuts
          ? `${outs} ${outs === 1 ? 'out' : 'outs'}`
          : '',

      reasons,
      bases,
      competitiveFloor
    };
  }

  function noHitBid(summary) {
    const competitors =
      summary?.header
        ?.competitions?.[0]
        ?.competitors ||
      [];

    for (
      const block of
      summary?.boxscore?.players ||
      []
    ) {
      const opponent =
        competitors.find(item =>
          String(
            item.team?.id ||
            ''
          ) !==
          String(
            block.team?.id ||
            ''
          )
        );

      if (
        !opponent ||
        Number(opponent.hits) !== 0 ||
        opponent.hits == null
      ) {
        continue;
      }

      for (
        const group of
        block.statistics ||
        []
      ) {
        const labels =
          group.labels || [];

        const innings =
          labels.indexOf('IP');

        const hits =
          labels.indexOf('H');

        if (
          innings < 0 ||
          hits < 0
        ) {
          continue;
        }

        const pitcher =
          (group.athletes || [])
            .find(entry =>
              Number.parseFloat(
                entry.stats?.[innings]
              ) >= 6 &&
              Number(
                entry.stats?.[hits]
              ) === 0
            );

        if (pitcher) {
          return {
            text:
              `${pitcher.athlete?.displayName || 'A pitcher'} has thrown ${Math.floor(Number.parseFloat(pitcher.stats[innings]))} hitless innings in a no-hit bid`,
            points:14
          };
        }
      }
    }

    return null;
  }

  function baseballPerformanceMilestone(summary) {
    const candidates = [];

    const noHit =
      noHitBid(summary);

    if (noHit) {
      candidates.push(noHit);
    }

    for (
      const block of
      summary?.boxscore?.players ||
      []
    ) {
      for (
        const group of
        block.statistics ||
        []
      ) {
        const labels =
          group.labels || [];

        const homeRuns =
          labels.findIndex(label =>
            /^HR$|^HOME RUNS$/i
              .test(label)
          );

        const strikeouts =
          labels.findIndex(label =>
            /^K$|^SO$|^STRIKEOUTS$/i
              .test(label)
          );

        for (
          const entry of
          group.athletes ||
          []
        ) {
          const name =
            entry.athlete?.displayName ||
            'A player';

          if (
            homeRuns >= 0
          ) {
            const count =
              Number(
                entry.stats?.[homeRuns]
              );

            if (
              count >= 2
            ) {
              candidates.push({
                text:
                  count >= 3
                    ? `${name} has hit ${count} home runs`
                    : `${name} has hit 2 home runs and is one away from a rare three-homer game`,
                points:
                  count >= 4
                    ? 14
                    : count >= 3
                      ? 12
                      : 6
              });
            }
          }

          if (
            strikeouts >= 0 &&
            /pitch/i.test(
              `${group.name || ''} ${group.displayName || ''}`
            )
          ) {
            const count =
              Number(
                entry.stats?.[strikeouts]
              );

            if (
              count >= 10
            ) {
              candidates.push({
                text:
                  `${name} has struck out ${count} batters`,
                points:
                  count >= 15
                    ? 12
                    : 7
              });
            }
          }
        }
      }
    }

    return candidates
      .sort(
        (a,b) =>
          b.points -
          a.points
      )[0] ||
      null;
  }

  function baseballGameState({sport,gameState,gap,progress,context:footballContext}) {
    const liveSituation = footballContext?.situation || footballContext?.competition?.situation || {};
    const liveStatus = footballContext?.competition?.status || {};
    const inning = Number(liveStatus.period || liveStatus.inning || 0);
    const inningHalf = String(liveSituation.halfInning || liveSituation.inningHalf || liveSituation.lastPlay?.type?.text || `${liveStatus.type?.detail || ''} ${liveStatus.type?.shortDetail || ''}`).toLowerCase();
    const homeTrailing = Array.isArray(footballContext?.teams) && footballContext.teams.length === 2 &&
      Number(footballContext.teams[0][2]) < Number(footballContext.teams[1][2]);
    const guaranteedMlbAtBat = sport === 'MLB' && inning >= 8 &&
      (homeTrailing && /bottom|middle|home/.test(inningHalf) || !homeTrailing && /top|away/.test(inningHalf));
    return {
      marginClose:gameState === 'live' ? mlbLiveMarginCloseness(gap,progress) : undefined,
      minimumComebackViability:guaranteedMlbAtBat ? .9 : 0
    };
  }

  function baseballEventShock({text,positioned,i,play}) {
    let value = 0;
    let label = '';
    if (/\bhome run\b/.test(text) && (/\b(?:tying|go[- ]ahead|game[- ]tying|takes the lead|puts .* ahead)\b.{0,45}\bhome run\b|\bhome run\b.{0,45}\b(?:ties|takes the lead|goes ahead|go[- ]ahead)\b/.test(text) || (()=>{const before=positioned.slice(0,i).reverse().find(item=>Number.isFinite(Number(item.play.homeScore))&&Number.isFinite(Number(item.play.awayScore)));const afterHome=Number(play.homeScore);const afterAway=Number(play.awayScore);if(!before||!Number.isFinite(afterHome)||!Number.isFinite(afterAway))return false;const beforeMargin=Number(before.play.homeScore)-Number(before.play.awayScore);const afterMargin=afterHome-afterAway;return afterMargin===0||beforeMargin===0||beforeMargin*afterMargin<0;})())) { value=6; label='Tying or go-ahead home run'; }
    return value ? {value,label} : null;
  }

  const mlbModel = {
    unit:'run',duration:180,inningEventAge:true,postseasonScarcity:6,championshipContext:true,
    pregame:proPregame,
    gameState:baseballGameState,
    situation:({game,competition,status,situation,progress,scoreGap}) =>
      baseballSituationImpact(game,competition,status,situation,progress,scoreGap),
    milestone:baseballPerformanceMilestone,
    earlyEventShock:baseballEventShock,
    contextAnchors:championship => championship
      ? [[0,.58],[.25,.50],[.5,.40],[.75,.30],[.9,.24],[1,.22]] : null,
    history:{threshold:3,units:'runs'}
  };

  const api = {mlbLiveMarginCloseness,runnerOn,sideScores,baseballSituationImpact,noHitBid,baseballPerformanceMilestone,baseballGameState,baseballEventShock,mlbModel};
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api;
  } else {
    (root.SportsRadarScoring ||= {}).sports_mlb = api;
  }
})(globalThis);

/* Shared scoring module; supports classic browser scripts and Worker/Node bundling. */
(function (root) {
  const {listedSpread} = typeof module !== 'undefined' && module.exports
    ? require('./market.js')
    : root.SportsRadarScoring.shared_market;

  function collegePregame(sport,competition,competitors,postseason,factors,reason,rankingRules) {
    const ranks =
      ['CFB','NCAAB']
        .includes(sport)
        ? competitors
            .map(item =>
              Number(
                item.curatedRank?.current ||
                item.team?.rank
              )
            )
            .filter(rank =>
              rank > 0 &&
              rank <= 25
            )
        : [];

    // A ranking adds interest only when the matchup can plausibly compete.
    // Two ranked teams retain some importance even with a wider line.
    const rankingFactors = [];
    const rankingSpread = listedSpread(competition);
    const competitiveness = rankingSpread === null
      ? null
      : 1 / (1 + (rankingSpread / 10) ** 2);

    if (ranks.length === 2) {
      rankingFactors.push({
        label:'Two ranked teams',
        points:
          rankingRules.twoRankedPoints
      });

      rankingRules.matchup({ranks,competitors,postseason,factors,rankingFactors});

      reason +=
        ' · two ranked teams';
    } else if (
      ranks.length === 1
    ) {
      rankingFactors.push({
        label:'Ranked team',
        points:
          rankingRules.rankedPoints
      });

      if (ranks[0] <= 10) {
        rankingFactors.push({label:'Top 10 team',points:rankingRules.topTenPoints});
      }

      reason +=
        ' · ranked team';
    }

    if (rankingFactors.length) {
      const multiplier = ranks.length === 2
        ? .15 + .85 * (competitiveness ?? .7)
        : competitiveness ?? .35;
      let rawPoints = 0;
      let scaledPoints = 0;
      for (const factor of rankingFactors) {
        rawPoints += factor.points;
        const next = Math.round(rawPoints * multiplier);
        if (next > scaledPoints) {
          factors.push({...factor,points:next - scaledPoints});
        }
        scaledPoints = next;
      }
    }

    return reason;
  }

  const api = {collegePregame};
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api;
  } else {
    (root.SportsRadarScoring ||= {}).shared_college = api;
  }
})(globalThis);

/* Shared scoring module; supports classic browser scripts and Worker/Node bundling. */
(function (root) {
  const {clockSeconds} = typeof module !== 'undefined' && module.exports
    ? require('./time.js')
    : root.SportsRadarScoring.shared_time;

  function basketballLiveCloseness(sport,gap,progress,context={}) {
    if (!['NBA','NCAAB'].includes(sport) || !Number.isFinite(Number(gap))) return null;
    const points = Math.max(0,Number(gap));
    const marginClose = Math.max(0,1-points/24);
    const status = context.competition?.status || context.status || {};
    const seconds = clockSeconds(status);
    if (seconds === null) return {close:marginClose,marginClose,comebackFeasibility:1,expectedPossessions:null,requiredPossessions:Math.ceil(points/3)};
    const regulationPeriods = sport === 'NCAAB' ? 2 : 4;
    const periodLength = sport === 'NCAAB' ? 20 : 12;
    const period = Number(status.period || 0);
    const remaining = period > regulationPeriods ? seconds : seconds + Math.max(0,regulationPeriods-period) * periodLength * 60;
    const situation = context.situation || context.competition?.situation || {};
    const teams = context.teams || [];
    const scores = teams.map(team=>Number(Array.isArray(team) ? team[2] : team.score));
    const trailingIndex = scores.length === 2 && scores[0] !== scores[1] ? (scores[0] < scores[1] ? 0 : 1) : -1;
    const trailingId = trailingIndex >= 0 ? String(Array.isArray(teams[trailingIndex]) ? teams[trailingIndex][8] || '' : teams[trailingIndex].team?.id || teams[trailingIndex].id || '') : '';
    const possessionId = String(situation.possession?.id || situation.possession || '');
    let expectedPossessions = remaining / 24 + .5;
    if (possessionId && trailingId) expectedPossessions += possessionId === trailingId ? .65 : -.65;
    const timeoutSource = situation.timeoutsRemaining || situation.timeouts || {};
    const rawCompetitor = (context.competition?.competitors || []).find(item=>String(item.team?.id || item.id || '')===trailingId);
    const trailingSide = rawCompetitor?.homeAway || (Array.isArray(teams[trailingIndex]) ? teams[trailingIndex]?.[7] : teams[trailingIndex]?.homeAway) || '';
    const rawTimeouts = rawCompetitor?.timeoutsRemaining ?? rawCompetitor?.timeouts?.remaining ?? rawCompetitor?.timeouts;
    const trailingTimeouts = Number(timeoutSource[trailingId] ?? timeoutSource[trailingSide] ?? situation[`${trailingSide}TimeoutsRemaining`] ?? rawTimeouts);
    if (Number.isFinite(trailingTimeouts)) expectedPossessions += Math.min(2,Math.max(0,trailingTimeouts)) * .4;
    expectedPossessions = Math.max(0,expectedPossessions);
    const requiredPossessions = Math.ceil(points/3);
    const slack = expectedPossessions-requiredPossessions;
    const comebackFeasibility = requiredPossessions === 0 ? 1 : 1/(1+Math.exp(-2*(slack+.4)));
    const close = marginClose * (.25 + .75*comebackFeasibility);
    return {close,marginClose,comebackFeasibility,expectedPossessions,requiredPossessions,slack};
  }

  function basketballSituationImpact(game,status,progress,scoreGap,situation={}) {
    let points = 0;
    const reasons = [];
    const seconds = clockSeconds(status);
    const regulationPeriods = game.sport === 'NCAAB' ? 2 : 4;
    const possessionId = String(situation.possession?.id || situation.possession || '');
    const holderIndex = possessionId ? game.teams.findIndex(team => String(team[8] || '') === possessionId) : -1;
    const holder = holderIndex >= 0 ? game.teams[holderIndex] : null;
    const other = holderIndex >= 0 ? game.teams[1-holderIndex] : null;
    const holderScore = holder ? Number(holder[2]) : NaN;
    const otherScore = other ? Number(other[2]) : NaN;
    const finalPossession = seconds !== null &&
      Number(status?.period) >= regulationPeriods &&
      scoreGap <= 3 && holder &&
      Number.isFinite(holderScore) && Number.isFinite(otherScore) &&
      holderScore <= otherScore && seconds < 40
        ? {urgency:Math.max(0,Math.min(1,(40-seconds)/28))}
        : null;

    if (progress >= .78 && scoreGap <= 6) {
      if (scoreGap === 0) points += progress >= .9 ? 9 : 6;
      else if (scoreGap <= 3) points += progress >= .9 ? 7 : 5;
      else points += 3;
      reasons.push(scoreGap === 0 ? 'The game is tied late' : `It is a ${scoreGap}-point game late`);
    }

    if (seconds !== null && Number(status?.period) >= regulationPeriods && seconds <= 24 && scoreGap <= 3) {
      if (holder && Number.isFinite(holderScore) && Number.isFinite(otherScore) && holderScore <= otherScore) {
        points += 5;
        reasons.push(`${holder[0]} has a potential tying or go-ahead final possession`);
      } else {
        points += 3;
        reasons.push('The game may come down to the final possession');
      }
    }

    if (Number(status?.period) > regulationPeriods) {
      points += 6;
      reasons.push('The game is in overtime');
    }

    return {points:Math.min(12,points),note:holder ? `${holder[1] || holder[0]} possession` : '',reasons,
      competitiveFloor:finalPossession ? Math.round(20*finalPossession.urgency) : 0,
      finalPossession};
  }

  function basketballScoringMilestone(
    summary,
    sport
  ) {
    const threshold =
      sport === 'NCAAB'
        ? 30
        : 40;

    let leader = null;

    for (
      const block of
      summary?.boxscore?.players ||
      []
    ) {
      for (
        const group of
        block.statistics ||
        []
      ) {
        const points =
          (group.labels || [])
            .findIndex(label =>
              /^PTS$|^POINTS$/i
                .test(label)
            );

        if (
          points < 0
        ) {
          continue;
        }

        for (
          const entry of
          group.athletes ||
          []
        ) {
          const count =
            Number(
              entry.stats?.[points]
            );

          if (
            count >= threshold &&
            (
              !leader ||
              count > leader.count
            )
          ) {
            leader = {
              count,
              name:
                entry.athlete?.displayName ||
                'A player'
            };
          }
        }
      }
    }

    if (!leader) {
      return null;
    }

    const rare =
      leader.count >=
      (
        sport === 'NCAAB'
          ? 40
          : 50
      );

    return {
      text:
        `${leader.name} has scored ${leader.count} points`,
      points:
        rare
          ? 12
          : 7
    };
  }

  const api = {basketballLiveCloseness,basketballSituationImpact,basketballScoringMilestone};
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api;
  } else {
    (root.SportsRadarScoring ||= {}).shared_basketball = api;
  }
})(globalThis);

/* Shared scoring module; supports classic browser scripts and Worker/Node bundling. */
(function (root) {
  const {proPregame,marketPregame} = typeof module !== 'undefined' && module.exports
    ? require('../shared/pregame.js')
    : root.SportsRadarScoring.shared_pregame;
  const {collegePregame} = typeof module !== 'undefined' && module.exports
    ? require('../shared/college.js')
    : root.SportsRadarScoring.shared_college;
  const {basketballLiveCloseness,basketballSituationImpact,basketballScoringMilestone} = typeof module !== 'undefined' && module.exports
    ? require('../shared/basketball.js')
    : root.SportsRadarScoring.shared_basketball;

  function basketballLeadChanges({sport,state,flipPositions,currentProgress,basketballDramaBucket,basketballLatePhase,factors,details}) {
    /*
     * Basketball lead changes are common early and become meaningful
     * only as leverage rises. Ignore first-half flips, lightly value
     * middle-game flips, and heavily weight changes in the closing
     * portion of the game.
     */
    const weightedLeadChanges =
      flipPositions.reduce(
        (sum,position) => {
          if (
            position === null ||
            !Number.isFinite(position) ||
            position < .5
          ) {
            return sum;
          }

          if (position < .75) {
            return sum + .5;
          }

          if (position < .875) {
            return sum + 1.5;
          }

          if (position < .95) {
            return sum + 3;
          }

          return sum + 4;
        },
        0
      );

    const leadChangePoints =
      Math.min(
        state === 'completed'
          ? 12
          : 10,
        Math.round(
          weightedLeadChanges
        )
      );

    if (leadChangePoints) {
      const lateLeadChanges =
        flipPositions.filter(
          position =>
            Number.isFinite(position) &&
            position >= .75
        ).length;

      factors.push({
        label:
          lateLeadChanges
            ? `${lateLeadChanges} late lead change${lateLeadChanges === 1 ? '' : 's'}`
            : 'Second-half lead changes',
        points:
          leadChangePoints,
        bucket:
          basketballDramaBucket
      });

      details.push(
        lateLeadChanges
          ? `the lead changed ${lateLeadChanges} time${lateLeadChanges === 1 ? '' : 's'} in the ${basketballLatePhase}`
          : 'the lead changed after halftime'
      );
    }

    /*
     * A burst of lead changes in a short late window is more dramatic
     * than the same number spread across the game. For live games use
     * the most recent 12.5% of regulation; for completed games use the
     * final 12.5% outright.
     */
    const clusterStart =
      state === 'completed'
        ? .875
        : Math.max(
            .75,
            currentProgress -
            .125
          );

    const clusteredLateFlips =
      flipPositions.filter(
        position =>
          Number.isFinite(position) &&
          position >=
          clusterStart
      ).length;

    if (clusteredLateFlips >= 2) {
      const clusterPoints =
        clusteredLateFlips >= 5
          ? 7
          : clusteredLateFlips === 4
            ? 6
            : clusteredLateFlips === 3
              ? 4
              : 2;

      factors.push({
        label:'Late back-and-forth lead changes',
        points:
          clusterPoints,
        bucket:
          basketballDramaBucket
      });

      details.push(
        `${clusteredLateFlips} lead changes came in a compressed late-game window`
      );
    }
  }

  function basketballLateTies({basketball,tiePositions,basketballDramaBucket,basketballLatePhase,factors,details}) {
    if (basketball) {
      const lateTies =
        tiePositions.filter(
          position =>
            position >= .75
        );

      if (lateTies.length) {
        const lastLateTie =
          lateTies.at(-1);

        const tiePoints =
          lastLateTie >= .95
            ? Math.min(
                4,
                2 +
                lateTies.length
              )
            : Math.min(
                3,
                lateTies.length
              );

        factors.push({
          label:
            lateTies.length === 1
              ? 'Late tie'
              : `${lateTies.length} late ties`,
          points:
            tiePoints,
          bucket:
            basketballDramaBucket
        });

        details.push(
          lastLateTie >= .95
            ? 'the game was tied in the final 5% of regulation'
            : `the game was tied ${lateTies.length} time${lateTies.length === 1 ? '' : 's'} in the ${basketballLatePhase}`
        );
      }
    }

  }

  function basketballRankedMatchup({ranks,rankingFactors}) {
    if (ranks.every(rank => rank <= 10)) {
      rankingFactors.push({label:'Both top 10',points:6});
    } else if (ranks.every(rank => rank <= 20)) {
      rankingFactors.push({label:'Both top 20',points:3});
    }
    if (ranks.some(rank => rank <= 10)) {
      rankingFactors.push({label:'Top 10 team',points:3});
    }
  }

  function basketballPregame(sport,competition,competitors,postseason,factors,reason,detail) {
    if (sport === 'NBA') return proPregame(sport,competition,competitors,postseason,factors,reason,detail);
    reason = marketPregame(sport,competition,factors,reason);
    return collegePregame(sport,competition,competitors,postseason,factors,reason,{
      twoRankedPoints:9,rankedPoints:4,topTenPoints:3,matchup:basketballRankedMatchup
    });
  }

  function basketballGameState({sport,gameState,gap,progress,context:footballContext,closeLimit}) {
    const basketballState =
      ['NBA','NCAAB'].includes(sport) && gameState === 'live'
        ? basketballLiveCloseness(sport,gap,progress,footballContext || {})
        : null;

    // Completed NBA margins use the existing wider curve and gradual penalty;
    // live NBA/NCAAB closeness uses remaining possessions and comeback feasibility.
    const completedNba = sport === 'NBA' && gameState === 'completed';
    return {
      basketballState,
      completedCloseLimit:completedNba ? 24 : closeLimit,
      marginClose:basketballState?.close,
      comebackViability:basketballState?.comebackFeasibility,
      stateBase:completedNba ? 23 : undefined,
      closeCeiling:completedNba ? 35 : undefined,
      widePenalty:completedNba
        ? gap !== null && gap >= 20
          ? Math.min(28,Math.round(2 + (gap - 20) * 1.1))
          : 0
        : basketballState
          ? gap !== null && gap >= 4 && basketballState.comebackFeasibility < .45
            ? Math.min(14,Math.round((.45-basketballState.comebackFeasibility)/.45 * 14 * (.5+.5*progress)))
            : 0
          : undefined,
      limitedRunway:Boolean(basketballState && basketballState.comebackFeasibility < .45)
    };
  }

  function basketballEventShock({text,positioned,i,play}) {
    let value = 0;
    let label = '';
    if (/buzzer[- ]beater|at the buzzer|game[- ]tying three|ties the game with (?:a )?three|three.{0,30}(?:ties|tie) the game/.test(text)) { value=10; label='Buzzer-beater or tying three'; }
    return value ? {value,label} : null;
  }

  const nbaModel = {
    duration:48,pregame:basketballPregame,
    gameState:basketballGameState,
    situation:({game,status,progress,scoreGap,situation}) =>
      basketballSituationImpact(game,status,progress,scoreGap,situation),
    milestone:basketballScoringMilestone,
    eventShock:basketballEventShock,
    history:{threshold:10,units:'points',dramaBucket:'basketball-late-drama',dramaCap:15,
      latePhase:'fourth quarter',leadChanges:basketballLeadChanges,lateTies:basketballLateTies}
  };

  const ncaabModel = {
    ...nbaModel,duration:40,
    history:{...nbaModel.history,latePhase:'final 10 minutes'}
  };

  const api = {basketballLeadChanges,basketballLateTies,basketballRankedMatchup,basketballPregame,basketballGameState,basketballEventShock,nbaModel,ncaabModel};
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api;
  } else {
    (root.SportsRadarScoring ||= {}).sports_basketball = api;
  }
})(globalThis);

/* Shared scoring module; supports classic browser scripts and Worker/Node bundling. */
(function (root) {
  const {marketPregame} = typeof module !== 'undefined' && module.exports
    ? require('../shared/pregame.js')
    : root.SportsRadarScoring.shared_pregame;
  const {collegePregame} = typeof module !== 'undefined' && module.exports
    ? require('../shared/college.js')
    : root.SportsRadarScoring.shared_college;
  const {recordFor,rankFor} = typeof module !== 'undefined' && module.exports
    ? require('../shared/records.js')
    : root.SportsRadarScoring.shared_records;
  const {footballGameState,footballLiveCloseness,footballTimeouts,footballCompetitorId,footballSituationFieldPosition,footballMilestone,footballEventShock,footballStagnationImpact} = typeof module !== 'undefined' && module.exports
    ? require('../shared/football.js')
    : root.SportsRadarScoring.shared_football;
  const {clockSeconds} = typeof module !== 'undefined' && module.exports
    ? require('../shared/time.js')
    : root.SportsRadarScoring.shared_time;

  const unit = value => Math.max(0,Math.min(1,value));

  function cfbPossession(competition,situation=competition?.situation) {
    const teams = competition?.competitors || [];
    const id = String(situation?.possession?.id || situation?.possession || '');
    const offense = id && teams.find(t => footballCompetitorId(t) === id);
    const defense = teams.find(t => t !== offense);
    if (teams.length !== 2 || !offense || !defense || teams.some(t => t.score == null || t.score === '' || !Number.isFinite(Number(t.score)))) return null;
    const abbr = String(offense.team?.abbreviation || offense.abbreviation || '').toUpperCase();
    const otherAbbr = String(defense.team?.abbreviation || defense.abbreviation || '').toUpperCase();
    const text = `${situation?.possessionText || ''} ${situation?.downDistanceText || situation?.shortDownDistanceText || ''}`.toUpperCase();
    const spot = text.match(/\b([A-Z][A-Z0-9]{1,6})\s+(\d{1,2})\b/);
    let position = footballSituationFieldPosition(situation,abbr);
    // College abbreviations can exceed four letters. Validate the side before
    // interpreting provider text; an unrelated abbreviation is not territory.
    if (spot) position = [abbr,otherAbbr].includes(spot[1]) && Number(spot[2]) <= 50
      ? (spot[1] === abbr ? Number(spot[2]) : 100-Number(spot[2])) : null;
    return {offense,defense,deficit:Number(defense.score)-Number(offense.score),position};
  }

  function cfbClockRunway(competition,situation=competition?.situation) {
    const seconds = clockSeconds(competition?.status);
    const possession = cfbPossession(competition,situation);
    if (Number(competition?.status?.period) !== 4 || seconds === null || seconds < 0 || seconds > 900 || !possession) return null;
    const {offense,defense,deficit,position} = possession;
    const trailing = deficit >= 0 ? offense : defense;
    const timeouts = footballTimeouts(competition,situation,trailing);
    const down = Number(situation?.down);
    let remaining = seconds;
    let offensiveTimeouts = timeouts ?? 0;
    if (deficit < 0) {
      if (timeouts === null || !Number.isInteger(down) || down < 1 || down > 4) return null;
      // Conditional stop, not a guaranteed next possession. NCAA's two-minute
      // timeout began in 2024; do not grant it to historical/unknown seasons.
      const year = Number(competition?.season?.year);
      const warning = year >= 2024 && seconds > 120 ? 1 : 0;
      const stops = timeouts + warning;
      const snaps = 4-down;
      remaining = Math.max(0,seconds-6*snaps-40*Math.max(0,snaps-stops)-8);
      offensiveTimeouts = Math.max(0,timeouts-Math.max(0,snaps-warning));
    }
    // In-bounds first downs stop the college clock in the last two minutes.
    // This is an opportunity estimate, not an assumed scoring drive. Unknown
    // field position budgets a full 75 yards; no text-derived timeout counts.
    const yards = deficit >= 0 ? Math.max(0,100-(position ?? 25)) : 75;
    const driveSeconds = 12 + (remaining <= 120 ? .42 : .60)*yards;
    const usable = remaining + offensiveTimeouts*5;
    // Hurry-up cycles must not extrapolate to seven possessions in a quarter.
    // Pace budget includes the current drive plus a fractional emergency chance.
    const paceBudget = 14*remaining/3600+1.5;
    const expectedPossessions = remaining <= 0 ? 0 : Math.min(paceBudget,
      Math.min(1,usable/driveSeconds) + Math.max(0,usable-driveSeconds)/145);
    return {remaining,timeouts,offensiveTimeouts,expectedPossessions:expectedPossessions*(deficit < 0 ? .78 : 1),driveSeconds};
  }

  function cfbMarginCloseness(gap) {
    const anchors = [[0,1],[3,.99],[7,.95],[10,.87],[14,.76],[17,.64],[21,.49],[28,.28],[35,.10],[42,0]];
    for (let i=1;i<anchors.length;i++) {
      if (gap <= anchors[i][0]) {
        const [x,y] = anchors[i-1], [nextX,nextY] = anchors[i];
        return y+(nextY-y)*unit((gap-x)/(nextX-x));
      }
    }
    return 0;
  }

  function cfbLiveCloseness(sport,gap,progress,context=null) {
    if (gap == null || !Number.isFinite(Number(gap)) || Number(gap) < 0) return null;
    gap = Number(gap);
    const state = footballLiveCloseness('CFB',gap,progress,context);
    const competition = context?.competition || context;
    const situation = context?.situation || competition?.situation;
    const possession = cfbPossession(competition,situation);
    const p = unit(Number(progress) || 0);
    const runway = cfbClockRunway(competition,situation);
    const expectedPossessions = runway?.expectedPossessions ?? Math.max(0,14*(1-p)+.5+state.possessionAdjustment);
    // Fractional scoring opportunities avoid an artificial 8-to-9 point cliff
    // while still charging for the conversion needed at an eight-point margin.
    const requiredPossessions = gap > 0 ? Math.max(1,gap/7) : 0;
    const possessionSlack = expectedPossessions-requiredPossessions;
    const comebackFeasibility = gap === 0 ? 1 : expectedPossessions === 0 ? 0 : 1/(1+Math.exp(-2.8*(possessionSlack+.45)));
    const marginClose = cfbMarginCloseness(gap);
    return {...state,requiredPossessions,expectedPossessions,possessionSlack,comebackFeasibility,marginClose,
      possessionState:gap > 0 && possession ? (possession.deficit > 0 ? 'trailing' : 'leading') : '',
      fieldPosition:possession?.deficit > 0 ? possession.position : null,
      close:marginClose*(.20+.80*comebackFeasibility),runway};
  }

  function cfbGameState(args) {
    if (args.gameState !== 'live') return footballGameState(args);
    const state = cfbLiveCloseness('CFB',args.gap,args.progress,args.context);
    if (!state) return {};
    const competition = args.context?.competition || args.context;
    const possession = cfbPossession(competition,args.context?.situation || competition?.situation);
    const seconds = clockSeconds(competition?.status);
    const urgency = Number(competition?.status?.period) === 4 && seconds > 0 ? unit((660-seconds)/540) : 0;
    const direction = possession?.deficit >= 0 ? 1 : possession ? state.comebackFeasibility*.45 : .2;
    const mismatch = Math.max(0,state.requiredPossessions-state.expectedPossessions);
    return {footballState:state,marginClose:state.close,comebackViability:state.comebackFeasibility,
      contextViability:.15+.85*state.comebackFeasibility,
      uncertaintyCeiling:state.comebackFeasibility,
      closeCeiling:14+16*unit(args.progress)+10*urgency*direction,
      widePenalty:args.gap >= 9 ? Math.round(Math.min(30,20*(1-state.comebackFeasibility)*unit(args.progress)+4*mismatch)) : 0,
      limitedRunway:true};
  }

  function cfbOvertime(competition,summary) {
    const period = Number(competition?.status?.period);
    const basic = {active:period > 4,response:false,decisive:false,shootout:false};
    const possession = cfbPossession(competition);
    if (!basic.active || !possession) return basic;
    const {offense,defense,deficit} = possession;
    // Only completed offensive series in THIS extra period establish order.
    // Older OT drives, period number, and pending/current drives do not.
    const completed = (summary?.drives?.previous || []).filter(d =>
      d.isCurrent !== true && d.result && !/end of|kickoff/i.test(d.result) &&
      Number(d.start?.period?.number ?? d.plays?.[0]?.period?.number) === period &&
      d.plays?.some(p => String(p.start?.team?.id || '') === String(d.team?.id || '') &&
        p.start?.team?.id && !/kickoff|timeout|end of/i.test(p.type?.text || p.text || '')));
    const year = Number(summary?.header?.season?.year || competition?.season?.year);
    const explicitTry = competition?.situation?.isTwoPointAttempt === true;
    const shootout = explicitTry && ((year >= 2021 && period >= 7) || (year >= 2019 && year < 2021 && period >= 9));
    const own = completed.filter(d => String(d.team?.id) === footballCompetitorId(offense));
    const other = completed.filter(d => String(d.team?.id) === footballCompetitorId(defense));
    const pendingResponseTry = explicitTry && !shootout && own.length === 1 && other.length === 1 &&
      completed.indexOf(own[0]) > completed.indexOf(other[0]) && /touchdown/i.test(own[0].result);
    const response = other.length === 1 && (own.length === 0 || pendingResponseTry);
    return {...basic,response,shootout,decisive:response && deficit >= 0 && deficit <= (shootout ? 2 : 8)};
  }

  function cfbSituation({game,competition,status,situation,summary}) {
    const current = {...competition,status,situation};
    const possession = cfbPossession(current);
    const result = {points:0,note:'',reasons:[],competitiveFloor:0};
    if (!possession) return result;
    const {offense,defense,deficit,position} = possession;
    const down = Number(situation.down), distance = Number(situation.distance);
    const seconds = clockSeconds(status), period = Number(status.period);
    const overtime = cfbOvertime(current,summary);
    const tryState = situation.isTwoPointAttempt === true;
    const goal = (situation.isGoalToGo === true || /&\s*goal/i.test(situation.downDistanceText || situation.shortDownDistanceText || '')) && position !== null && position >= 90;
    result.note = [offense.team?.abbreviation ? `${offense.team.abbreviation} ball` : '',situation.downDistanceText || situation.shortDownDistanceText,situation.possessionText].filter(Boolean).join(' · ');
    // Early fourth downs and tries are modest; late consequences replace them.
    result.points = tryState ? 2 : down === 4 ? Math.min(3,1+(distance > 0 && distance <= 2 ? 1 : 0)+(position >= 70 ? 1 : 0)) : 0;
    let consequence = 0, viability = 1, urgency = 0;
    const criticalTry = tryState && [1,2].includes(deficit) && period === 4 && seconds !== null && seconds >= 0 && seconds <= 150;
    if (period === 4 && deficit >= 0 && deficit <= 8 && (seconds > 0 || criticalTry)) {
      urgency = criticalTry ? 1 : unit((600-seconds)/480);
      const winningRange = deficit < 3 && position !== null && position >= 60;
      consequence = winningRange ? .84 : .73+.06*unit(((position ?? 25)-25)/55);
      const afterFailure = cfbClockRunway(current,{...situation,possession:footballCompetitorId(defense),down:1});
      const finalFourth = down === 4 && deficit > 0 && (afterFailure ? afterFailure.remaining <= 15 : seconds <= 45);
      if (finalFourth) consequence = Math.max(consequence,.87+.03*(Number.isFinite(distance) && distance > 0 ? unit((10-distance)/9) : 0));
      if (goal) consequence = Math.max(consequence,.91);
      if (criticalTry) consequence = deficit === 1 ? .95 : .92;
      if (game.championshipStakes && (criticalTry || finalFourth || goal)) consequence = Math.min(.98,consequence+.04);
      const ranks = [rankFor(offense,'CFB'),rankFor(defense,'CFB')];
      // Matchup significance scales the decisive interaction's remaining
      // headroom; it is not another permanent ranked-team live award.
      if (ranks.every(Boolean)) consequence = Math.min(.98,consequence+.04*Math.pow((26-Math.max(...ranks))/25,2));
      const yards = Math.max(0,(deficit < 3 ? 65 : 100)-(position ?? 25));
      viability = criticalTry || goal ? 1 : Math.min(1,seconds/(10+.42*yards));
      if (urgency > 0) result.reasons.push(criticalTry ? 'Critical two-point try to tie or win' : finalFourth ? 'Final meaningful fourth down' : goal ? 'Decisive goal-to-go snap' : 'A viable tying or winning possession');
    }
    if (overtime.active && Math.abs(deficit) <= 8 && (deficit >= 0 || tryState)) {
      urgency = 1;
      consequence = overtime.decisive ? (overtime.shootout || tryState ? .97 : .94) : .82;
      // A championship maximum requires observed response rights, not merely OT.
      const championship = game.championshipStakes;
      if (overtime.decisive && championship && (tryState || goal || down === 4)) consequence = 1;
      result.reasons.push(overtime.decisive ? 'Overtime response: this possession can decide the game' : 'College overtime possession; response rights unconfirmed');
    }
    if (urgency > 0) {
      result.points = Math.max(result.points,Math.round(12*urgency*viability));
      if (Number.isFinite(Number(game.baseScore))) result.competitiveFloor = Math.round(Math.max(0,99-Number(game.baseScore))*consequence*urgency*viability);
    }
    return result;
  }

  function cfbUpsetImpact(candidate,teams,gameState,progress,sport,competition) {
    if (gameState !== 'live' || !candidate) return null;
    if (candidate.type !== 'spread' || !Number.isFinite(Number(candidate.value))) return null;
    const index = teams.findIndex(t => String(t.id || t[8] || t.team?.id || '') === candidate.teamId);
    const i = index >= 0 ? index : candidate.teamIndex;
    if (teams.length !== 2 || ![0,1].includes(i)) return {points:0,text:''};
    const margin = Number(teams[i].score ?? teams[i][2])-Number(teams[1-i].score ?? teams[1-i][2]);
    if (!Number.isFinite(margin) || progress < (margin > 0 ? .35 : .7)) return {points:0,text:''};
    const state = cfbLiveCloseness('CFB',Math.abs(margin),progress,competition);
    const x = unit((Number(candidate.value)-7)/23);
    const magnitude = x*x*(3-2*x);
    const competitors = competition?.competitors || [];
    const dog = competitors.find(t => footballCompetitorId(t) === candidate.teamId);
    const favorite = competitors.find(t => t !== dog);
    const favoriteRank = rankFor(favorite,'CFB'), dogRank = rankFor(dog,'CFB');
    const rankThreat = favoriteRank && dog ? ((26-favoriteRank)/25)*unit(((dogRank || 35)-favoriteRank)/20) : 0;
    const possessionWeight = margin < 0 ? (state.possessionState === 'trailing' ? 1 : state.possessionState === 'leading' ? .65 : .8) : 1;
    const fieldWeight = margin < 0 && state.possessionState === 'trailing' && state.fieldPosition !== null
      ? 1+.08*unit((state.fieldPosition-50)/50) : 1;
    const viability = state.comebackFeasibility*Math.exp(-Math.pow(Math.abs(margin)/(margin < 0 ? 8 : 22),1.6))*possessionWeight*fieldWeight*(margin > 0 ? 1.25 : 1);
    // Qualification is unchanged. A qualifying +7 now has half activation,
    // ramping smoothly to full at +10 instead of receiving zero live tension.
    const activation = .5+.5*unit(candidate.activation ?? 1);
    const points = Math.min(36,Math.round((12+16*magnitude+6*rankThreat*unit((progress-.5)/.4))*(.35+.65*unit(progress))*viability*activation));
    return {points,text:points ? `${candidate.teamName}, a ${candidate.description}, ${margin > 0 ? 'leads' : margin === 0 ? 'is tied' : 'remains within reach'} in a viable upset` : ''};
  }

  function cfbPregame(sport,competition,competitors,postseason,factors,reason) {
    reason = marketPregame(sport,competition,factors,reason);
    return collegePregame(sport,competition,competitors,postseason,factors,reason,{
      twoRankedPoints:28,rankedPoints:11,topTenPoints:5,matchup:cfbRankedMatchup
    });
  }

  function cfbRankedMatchup({ranks,competitors,postseason,factors,rankingFactors}) {
    if (
      ranks.every(
        rank =>
          rank <= 20
      )
    ) {
      rankingFactors.push({
        label:'Both top 20',
        points:4
      });
    }

    if (
      ranks.some(
        rank =>
          rank <= 10
      )
    ) {
      rankingFactors.push({
        label:'Top 10 team',
        points:5
      });
    }

    const records =
      competitors
        .map(recordFor)
        .map(value =>
          String(value)
            .match(
              /^(\d+)-(\d+)/
            )
        );

    if (
      !postseason &&
      records.every(match =>
        match &&
        Number(match[1]) >
        Number(match[2])
      )
    ) {
      factors.push({
        label:'Both winning records',
        points:3
      });
    }

    if (
      !postseason &&
      records.some(match =>
        match &&
        Number(match[1]) >= 4 &&
        Number(match[2]) === 0
      )
    ) {
      factors.push({
        label:'Unbeaten team',
        points:4
      });
    }
  }

  // Completed rules are deliberately independent of possession/runway/live OT.
  function cfbCompletedUpset(candidate,teams,gameState,progress,sport,competition) {
    if (!candidate || candidate.type !== 'spread' || !Number.isFinite(Number(candidate.value))) return null;
    const competitors = competition?.competitors || [];
    const index = teams.findIndex(t => String(t.id || t[8] || t.team?.id || '') === candidate.teamId);
    const i = index >= 0 ? index : candidate.teamIndex;
    if (teams.length !== 2 || ![0,1].includes(i)) return {points:0,text:''};
    const margin = Number(teams[i].score ?? teams[i][2])-Number(teams[1-i].score ?? teams[1-i][2]);
    if (!Number.isFinite(margin) || margin <= 0) return {points:0,text:''};
    const magnitude = unit((Number(candidate.value)-7)/23);
    const dog = competitors.find(t => footballCompetitorId(t) === candidate.teamId);
    const favorite = dog && competitors.find(t => t !== dog);
    const favoriteRank = rankFor(favorite,'CFB'), dogRank = rankFor(dog,'CFB');
    const rank = favoriteRank ? (26-favoriteRank)/25*unit(((dogRank || 35)-favoriteRank)/20) : 0;
    const significance = 6+16*magnitude+6*rank*(.35+.65*magnitude);
    const quality = unit((28-margin)/25);
    // Extraordinary expectation reversals matter most in close games. The
    // convex magnitude saturates at +30; squared quality leaves blowout result
    // credit unchanged. Verified late pull-aways still use the existing path
    // floor, which consumes this contribution rather than awarding it twice.
    const extraordinary = quality*quality*(20*Math.pow(magnitude,1.5)+3*rank*(.35+.65*magnitude));
    const points = Math.round(significance*(.25+.75*quality)+extraordinary);
    return {points,text:`${candidate.teamName} won outright as a ${candidate.description}; result significance is scaled by competitiveness`};
  }

  function cfbCompletedPath(summary,competition) {
    // Missing clocks must not become fabricated mid-quarter timestamps. Require
    // a consistent scoring ledger ending at the actual final before retention.
    const plays = summary?.scoringPlays?.length ? summary.scoringPlays : (summary?.plays || []).filter(p => p.scoringPlay === true);
    const moments = [];
    let valid = plays.length >= 3;
    let previous = {home:0,away:0,position:0};
    let lastCompetitivePosition = 0, competitiveShare = 0, comeback = 0;
    let homeDeficit = 0, awayDeficit = 0;
    for (const play of plays) {
      const period = Number(play.period?.number ?? play.period);
      const seconds = clockSeconds({displayClock:play.clock?.displayValue,clock:play.clock?.value});
      const home = Number(play.homeScore), away = Number(play.awayScore);
      if (play.homeScore == null || play.awayScore == null || play.homeScore === '' || play.awayScore === '' ||
          !Number.isFinite(home) || !Number.isFinite(away) || !Number.isInteger(period) || period < 1 ||
          seconds === null || seconds < 0 || seconds > 900) {valid=false;continue;}
      const position = Math.min(1,((period-1)*900+900-seconds)/3600);
      const homeGain=home-previous.home, awayGain=away-previous.away;
      if (position < previous.position || homeGain < 0 || awayGain < 0 || homeGain > 8 || awayGain > 8 || (homeGain > 0 && awayGain > 0)) valid=false;
      if (Math.abs(previous.home-previous.away) <= 8) {
        competitiveShare += Math.max(0,position-previous.position);
        lastCompetitivePosition = position;
      }
      const margin = home-away;
      homeDeficit = Math.max(homeDeficit,-margin);
      awayDeficit = Math.max(awayDeficit,margin);
      if (margin >= 0) comeback = Math.max(comeback,homeDeficit);
      if (margin <= 0) comeback = Math.max(comeback,awayDeficit);
      previous = {home,away,position};
      moments.push(previous);
    }
    const home = competition?.competitors?.find(t => t.homeAway === 'home');
    const away = competition?.competitors?.find(t => t.homeAway === 'away');
    if (!home || !away || home.score == null || away.score == null || Number(home.score)!==previous.home || Number(away.score)!==previous.away) valid=false;
    if (Math.abs(previous.home-previous.away) <= 8) {
      competitiveShare += 1-previous.position;
      lastCompetitivePosition=1;
    }
    return {valid,lastCompetitivePosition,competitiveShare:unit(competitiveShare),comeback,moments};
  }

  function cfbCompletedHistory(summary,history,{game,finishPoints=0}) {
    if (!game || game.sport !== 'CFB' || game.state !== 'completed') return history;
    const competition = game.sourceCompetition || summary?.header?.competitions?.[0];
    const scores = (competition?.competitors || []).map(t => t.score == null || t.score === '' ? NaN : Number(t.score));
    if (scores.length !== 2 || !scores.every(Number.isFinite)) return history;
    const gap = Math.abs(scores[0]-scores[1]);
    const path = cfbCompletedPath(summary,competition);
    const status = competition?.status || {};
    const detail = `${status.type?.detail || ''} ${status.type?.shortDetail || ''}`;
    const depthText = detail.match(/\b(\d+)\s*OT\b/i);
    const period = Number(status.period);
    const depth = Number.isInteger(period) && period > 4 ? period-4 : depthText ? Number(depthText[1]) : /\bot\b|overtime/i.test(detail) ? 1 : 0;
    const year = Number(game.sourceEvent?.season?.year || summary?.header?.season?.year);
    const shootoutStart = year >= 2021 ? 7 : year >= 2019 ? 9 : Infinity;
    const tries = new Set((summary?.plays || []).filter(p => Number(p.period?.number ?? p.period) >= shootoutStart &&
      /two[ -]point|2[ -]point/i.test(`${p.type?.text || ''} ${p.text || ''}`)).map(p => p.id || JSON.stringify(p)));
    const shootout = depth >= shootoutStart-4 && tries.size >= 2;
    const stagnation = history.factors.filter(f => f.label === 'Offensive stagnation').reduce((sum,f)=>sum+f.points,0);
    const positiveHistory = history.points-stagnation;
    const existing = Number(game.score)+history.points+finishPoints;
    if (!Number.isFinite(existing)) return history;
    const adjustments = [];
    let total = existing;
    // Existing generic OT, histories, upset and finishing awards all consume
    // this floor. No per-OT addition; successive targets approach 96.
    if (depth > 0 && gap <= 8) {
      const stakes = game.factors.filter(f => /stakes|consequence|advancement|elimination/i.test(f.label)).reduce((sum,f)=>sum+Math.max(0,f.points),0);
      const overlap = Math.max(0,stakes-8);
      if (overlap) {adjustments.push({label:'Completed OT correlated stakes cap',points:-overlap});total-=overlap;}
      const target = Math.min(99,78+18*(1-Math.exp(-.85*(depth-1)))+(shootout?2:0)+Math.min(8,stakes*.5))+stagnation;
      const delta = Math.max(0,Math.round(target-total));
      if (delta) {adjustments.push({label:`Completed ${depth}OT${shootout?' conversion shootout':''} depth retention`,points:delta});total+=delta;}
    }
    // A late window is mandatory: neither an early comeback nor WP sample
    // order alone can rescue a full-half blowout. History informs a floor,
    // rather than earning a second comeback/lead-change award.
    if (path.valid && path.lastCompetitivePosition >= .75) {
      const late = unit((path.lastCompetitivePosition-.75)/.20);
      const evidence = unit(positiveHistory/25);
      const magnitude = unit(path.comeback/21);
      const marginWeight = 1-unit((gap-21)/21);
      let target = 0;
      if (gap > 8 && path.competitiveShare >= .35) target = (35+30*late+12*magnitude+8*evidence)*marginWeight;
      if (gap <= 8 && path.comeback >= 14) target = 65+18*magnitude+5*evidence;
      target += stagnation;
      const delta = Math.max(0,Math.round(target-total));
      if (delta) {adjustments.push({label:'Completed competitive path retention',points:delta});total+=delta;}
    }
    // Completed stakes are already present. Cap their contribution when the
    // verified path offers no late contest, including ranked upset blowouts.
    if (gap >= 21 && path.valid && path.lastCompetitivePosition < .75) {
      const stakes = game.factors.filter(f => /stakes|consequence|advancement|elimination/i.test(f.label)).reduce((sum,f)=>sum+Math.max(0,f.points),0);
      const reduction = Math.min(Math.max(0,stakes-5),Math.max(0,total-1));
      if (reduction) {adjustments.push({label:'Completed stakes limited by noncompetitive path',points:-reduction});total-=reduction;}
    }
    // Clamping a negative final-margin base must not erase even the small,
    // competitiveness-gated result contribution. This cannot create a classic.
    const resultFloor = 1+(Number(game.upsetPoints)||0)+stagnation;
    if (resultFloor > total) adjustments.push({label:'Completed upset result retention',points:Math.round(resultFloor-total)});
    return adjustments.length ? {points:history.points+adjustments.reduce((sum,f)=>sum+f.points,0),
      text:[history.text,...adjustments.map(f=>f.label)].filter(Boolean).join('; '),factors:[...history.factors,...adjustments]} : history;
  }

  const cfbModel = {
    pregame:cfbPregame,
    // Scoreboards usually put season metadata on the event, not competition.
    // Preserve it through the core's existing live context without mutating feeds.
    prepareCompetition:(competition,event) => ({...competition,season:competition?.season || event?.season}),
    gameState:cfbGameState,
    liveCloseness:cfbLiveCloseness,
    upset:(...args) => args[2] === 'completed' ? cfbCompletedUpset(...args) : cfbUpsetImpact(...args),
    completedHistory:cfbCompletedHistory,
    decisiveStakes:detail => /\b(?:college football playoff|cfp)\b(?!\s+(?:race|berth|spot|picture|contention|hunt|rematch))|\b(?:national|conference) championship\b(?!\s+rematch)/i.test(detail),
    decisiveFloor:true,
    situation:cfbSituation,
    milestone:footballMilestone,
    eventShock:footballEventShock,
    history:{threshold:10,units:'points',stagnation:footballStagnationImpact}
  };

  const api = {cfbPregame,cfbRankedMatchup,cfbModel,cfbClockRunway,cfbOvertime,cfbLiveCloseness,cfbMarginCloseness};
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api;
  } else {
    (root.SportsRadarScoring ||= {}).sports_cfb = api;
  }
})(globalThis);

/* Shared scoring module; supports classic browser scripts and Worker/Node bundling. */
(function (root) {
  function tennisSituationImpact(game,competition,summary,status,progress) {
    const situation = competition?.situation || summary?.header?.competitions?.[0]?.situation || summary?.situation || {};
    const text = [status?.type?.detail,status?.type?.shortDetail,situation?.displayValue,situation?.description,situation?.pointScore,situation?.score].filter(Boolean).join(' ');
    const period = Number(status?.period || 0);
    const bestOf = Number(competition?.format?.regulation?.periods || competition?.format?.bestOf || (period >= 5 ? 5 : 3));
    const sets = game.teams.map(team => Number(team[2]));
    const deciding = /deciding|final set|fifth set|third set/i.test(text) && period >= bestOf ||
      period >= bestOf && sets.length === 2 && sets.every(Number.isFinite) && Math.abs(sets[0]-sets[1]) <= 1;
    const late = Math.max(0,Math.min(1,(progress-.45)/.5));
    const tiebreak = situation.tiebreak === true || situation.isTiebreak === true || /tie.?break/i.test(text);
    const matchPoint = situation.matchPoint === true || situation.isMatchPoint === true || /match point/i.test(text);
    let points = 0;
    const reasons = [];

    if (matchPoint) {
      points = Math.max(points,Math.round((deciding ? 10 : 6) + 2*late + (tiebreak ? 1 : 0)));
      reasons.push('The match is at match point');
    } else if (situation.setPoint === true || situation.isSetPoint === true || /set point/i.test(text)) {
      points = Math.max(points,Math.round(4 + 2*late + (deciding ? 2 : 0)));
      reasons.push('The current set is at set point');
    }

    if (situation.breakPoint === true || situation.isBreakPoint === true || /break point/i.test(text)) {
      points = Math.max(points,Math.round(2 + 2*late + (deciding ? 1 : 0)));
      reasons.push('A break point is in progress');
    }

    if (tiebreak) {
      points = Math.max(points,Math.round(4 + 2*late + (deciding ? 2 : 0)));
      reasons.push('The match is in a tiebreak');
    }

    if (/\bdeuce\b/i.test(text)) {
      points = Math.max(points,Math.round(1 + late + (deciding ? 1 : 0)));
      reasons.push('The current game is at deuce');
    }

    if (deciding && progress >= .75) {
      points = Math.max(points,5);
      reasons.push('The match is deep in a deciding set');
    }

    return {points:Math.min(12,points),note:text.slice(0,80),reasons,
      competitiveFloor:matchPoint && deciding ? (tiebreak ? 20 : 19) : 0};
  }

  function tennisMajor(detail) {
    return /wimbledon|australian open|french open|roland garros|us open/.test(detail)
      ? {factor:{label:'Major tournament',points:18},reason:'Tennis major'}
      : null;
  }

  const tennisModel = {
    unit:'set',majorTournament:tennisMajor,
    situation:({game,competition,summary,status,progress}) =>
      tennisSituationImpact(game,competition,summary,status,progress),
    history:{threshold:2,units:'sets'}
  };

  const api = {tennisSituationImpact,tennisMajor,tennisModel};
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api;
  } else {
    (root.SportsRadarScoring ||= {}).sports_tennis = api;
  }
})(globalThis);

/* Shared scoring module; supports classic browser scripts and Worker/Node bundling. */
(function (root) {
  const {CONTEXT_WEIGHTS,CONTEXT_LABELS} = typeof module !== 'undefined' && module.exports
    ? require('./config.js')
    : root.SportsRadarScoring.shared_config;

  function eventSignalText(event, competition, context) {
    return [
      event?.name,
      event?.shortName,
      (competition?.notes || [])
        .map(note => note.headline)
        .join(' '),
      competition?.series?.summary,
      competition?.series?.title,
      competition?.series?.type,
      event?.season?.type?.name,
      event?.season?.type?.slug,
      event?.season?.slug,
      context
    ]
      .filter(Boolean)
      .join(' ')
      .toLowerCase();
  }

  function normalizeContextType(value) {
    return String(value || '')
      .trim()
      .toLowerCase()
      .replace(
        /[\s-]+/g,
        '_'
      );
  }

  function pregameContextFactors(event,competition) {
    const sources = [
      event?.sportsRadarContextFactors,
      competition?.sportsRadarContextFactors,
      event?.sportsRadarContext,
      competition?.sportsRadarContext,
      event?.contextFactors,
      competition?.contextFactors
    ];

    const items =
      sources
        .flatMap(source =>
          Array.isArray(source)
            ? source
            : Array.isArray(source?.factors)
              ? source.factors
              : []
        )
        .filter(Boolean);

    const candidates = [];
    for (const item of items) {
      if (
        item?.verified === false
      ) {
        continue;
      }

      const confidence =
        Number(
          item?.confidence
        );

      if (
        Number.isFinite(confidence) &&
        confidence < .7
      ) {
        continue;
      }

      const type =
        normalizeContextType(
          item?.type
        );

      const points =
        CONTEXT_WEIGHTS[type];

      if (
        !Number.isFinite(points)
      ) {
        continue;
      }

      candidates.push({
        type,

        label:
          String(
            item?.label ||
            CONTEXT_LABELS[type] ||
            type
          ).trim(),

        text:
          String(
            item?.text ||
            item?.description ||
            item?.label ||
            CONTEXT_LABELS[type] ||
            ''
          ).trim(),

        points,

        dedupeKey:
          String(
            item?.dedupeKey ||
            (
              [
                'former_captain_return',
                'first_game_back',
                'former_star_return'
              ].includes(type)
                ? 'former-team-return'
                : [
                    'championship_rematch',
                    'playoff_rematch'
                  ].includes(type)
                  ? 'rematch'
                  : type
            )
          )
      });
    }

    candidates.sort(
      (a,b) =>
        Math.abs(b.points) -
        Math.abs(a.points)
    );

    const factors = [];
    const seen = new Set();

    let positiveRemaining = 22;
    let negativeRemaining = 10;

    for (const item of candidates) {
      if (
        !item.label ||
        seen.has(item.dedupeKey)
      ) {
        continue;
      }

      seen.add(item.dedupeKey);

      let points =
        item.points;

      if (points > 0) {
        points =
          Math.min(
            points,
            positiveRemaining
          );

        positiveRemaining -=
          points;
      } else if (points < 0) {
        points =
          -Math.min(
            Math.abs(points),
            negativeRemaining
          );

        negativeRemaining -=
          Math.abs(points);
      }

      if (!points) {
        continue;
      }

      factors.push({
        label:item.label,
        points,
        contextType:item.type,
        contextText:item.text
      });
    }

    return factors;
  }

  function aggregateScoreFromText(value) {
    const text =
      String(value || '')
        .toLowerCase();

    const match =
      text.match(
        /(?:aggregate(?: score)?|on aggregate)[^0-9]{0,12}(\d+)\D{1,5}(\d+)/
      ) ||
      text.match(
        /(\d+)\s*[-–:]\s*(\d+)[^.;]{0,24}(?:on aggregate|aggregate score)/
      );

    return match
      ? [
          Number(match[1]),
          Number(match[2])
        ]
      : null;
  }

  function specificStakesFactors(sport,detail) {
    const text =
      String(detail || '')
        .toLowerCase();

    const factors = [];

    if (
      /\bgame\s*(?:7|seven)\b|\bdeciding game\b/
        .test(text)
    ) {
      factors.push({
        label:'Deciding game',
        points:12
      });
    } else if (
      /\belimination game\b|\bwin or go home\b|\bwinner advances\b|\bmust[- ]win\b/
        .test(text)
    ) {
      factors.push({
        label:'Elimination stakes',
        points:9
      });
    }

    if (
      /\bclinches?\b|\bclinching (?:game|opportunity|scenario)\b|\bcan clinch\b/
        .test(text)
    ) {
      factors.push({
        label:'Clinching opportunity',
        points:6
      });
    }

    if (
      sport === 'Soccer' &&
      /\bsecond leg\b|\b2nd leg\b|\bon aggregate\b|\baggregate score\b/
        .test(text)
    ) {
      const aggregate =
        aggregateScoreFromText(text);

      const closeAggregate =
        aggregate &&
        Math.abs(
          aggregate[0] -
          aggregate[1]
        ) <= 1;

      factors.push({
        label:
          closeAggregate
            ? 'Close aggregate tie'
            : 'Second-leg consequences',
        points:
          closeAggregate
            ? 7
            : 4
      });
    }

    return factors;
  }

  function singleEliminationRound(sport,detail) {
    if (sport === 'NFL') {
      return /\bwild[- ]card\b(?!\s+(?:race|berth|spot|picture|contention|hunt))|\bdivisional (?:round|playoff)\b|\b(?:afc|nfc|conference) championship\b|\bsuper bowl\b(?!\s+rematch)/.test(detail);
    }
    if (sport === 'CFB') {
      return /\b(?:college football playoff|cfp)\b(?!\s+(?:race|berth|spot|picture|contention|hunt))|\bnational championship\b(?!\s+rematch)/.test(detail);
    }
    return sport === 'NCAAB' &&
      /\bncaa (?:tournament|championship)\b|\bmarch madness\b|\bfirst four\b|\bsweet (?:16|sixteen)\b|\belite (?:8|eight)\b|\bfinal four\b|\bnational championship\b/.test(detail);
  }

  function isPostseasonGame(sport,event,competition,detail) {
    return Number(event?.season?.type?.id ?? event?.season?.type) === 3 ||
      singleEliminationRound(sport,detail) ||
      /\bworld series\b|\bsuper bowl\b|\bstanley cup final\b|\b(?:nba|wnba) finals\b|\bnational championship\b|\bconference (?:finals?|championship)\b|\b(?:quarterfinal|semifinal|knockout)\b|\b(?:wild[- ]card|divisional) (?:round|game|playoff)\b|\b(?:playoffs?|postseason) (?:game|round|series)\b/.test(detail) ||
      (sport === 'CFB' && /\bbowl\b/.test(detail)) ||
      /^(?:postseason|playoffs?)$/.test(String(event?.season?.type?.name || '').toLowerCase());
  }

  function playoffSeriesLeverage(sport,competition,detail) {
    if (!['MLB','NHL','NBA'].includes(sport)) return null;
    const seriesData = competition?.series || {};
    const series = String([seriesData.summary,seriesData.title,seriesData.type].filter(Boolean).join(' ')).toLowerCase();
    if (!isPostseasonGame(sport,{},competition,detail) && !series) return null;
    const game = Number(detail.match(/\bgame\s*([1-7])\b/)?.[1] || series.match(/\bgame\s*([1-7])\b/)?.[1] || seriesData.gameNumber || 0);
    const winsMatch = series.match(/\b([0-3])\s*[-–]\s*([0-3])\b/);
    const structuredWins = [seriesData.homeWins ?? seriesData.homeTeamWins,seriesData.awayWins ?? seriesData.awayTeamWins].map(value=>value == null ? NaN : Number(value));
    const wins = winsMatch ? [Number(winsMatch[1]),Number(winsMatch[2])] : structuredWins.every(Number.isFinite) ? structuredWins : [];
    const bestOf = Number(seriesData.bestOf || series.match(/best[- ]of[- ]([357])/i)?.[1] || 7);
    const clinchWins = Number(seriesData.winsRequired || Math.ceil(bestOf / 2));
    const winsNeeded = seriesData.winsNeeded;
    const clinchOpportunity = (Array.isArray(winsNeeded) ? winsNeeded : Object.values(winsNeeded && typeof winsNeeded === 'object' ? winsNeeded : {value:winsNeeded})).some(value=>value !== null && value !== undefined && Number.isFinite(Number(value)) && Number(value) <= 1);
    const deciding = seriesData.winnerTakeAll === true || game === bestOf || /\bdeciding game\b|\bwinner[- ]take[- ]all\b/.test(detail) ||
      (wins.length === 2 && wins[0] === wins[1] && wins[0] === clinchWins - 1);
    const clinchChance = Number(seriesData.clinchChance);
    const elimination = seriesData.eliminationRisk === true || seriesData.clinchChance === true || Number.isFinite(clinchChance) && clinchChance >= .5 || clinchOpportunity || /\belimination game\b|\bwin or go home\b|\bmust[- ]win\b|\bcan clinch\b|\bclinching (?:game|opportunity|scenario)\b|\bclinches?\b/.test(detail) ||
      (wins.length === 2 && Math.max(...wins) >= clinchWins - 1);
    const tiedGameFive = game === 5 && wins.length === 2 && wins[0] === 2 && wins[1] === 2;
    const points = deciding ? 16 : elimination ? 10 : tiedGameFive ? 5 : ({2:2,3:3,4:4,5:4,6:4}[game] || 0);
    return points ? {label:deciding ? 'Playoff winner-take-all' : elimination ? 'Playoff elimination / clinch' : 'Playoff series leverage',points} : null;
  }

  function championshipSeriesFactors(sport,competition,detail) {
    const championship =
      (sport === 'MLB' && /\bworld series\b/.test(detail)) ||
      (sport === 'NBA' && /\bnba finals\b/.test(detail)) ||
      (sport === 'NHL' && /\bstanley cup finals?\b/.test(detail));
    if (!championship) return null;

    const seriesLeverage = playoffSeriesLeverage(sport,competition,detail);
    const game = Number(detail.match(/\bgame\s*([1-7])\b/)?.[1] || 0);
    const series = String(competition?.series?.summary || '').toLowerCase();
    const record = series.match(/\b([0-3])\s*[-–]\s*([0-3])\b/);
    const wins = record ? [Number(record[1]),Number(record[2])] : [];
    // One prestige factor and one highest applicable leverage factor.
    // Neither postseason scarcity nor the generic series-opener stacks here.
    const deciding = game === 7 || /\bgame seven\b|\bdeciding game\b|\bwinner[- ]take[- ]all\b/.test(detail) ||
      (wins.length === 2 && wins.every(value => value === 3));
    const elimination = /\belimination game\b|\bwin or go home\b|\bmust[- ]win\b|\bcan clinch\b|\bclinching (?:game|opportunity|scenario)\b|\bclinches?\b/.test(detail) ||
      wins.some(value => value === 3);
    const leverage = seriesLeverage?.points ?? (deciding ? 16 : elimination ? 10 : ({2:1,3:3,4:5,5:6,6:7}[game] || 0));
    return [
      {label:sport === 'MLB' ? 'World Series' : sport === 'NHL' ? 'Championship' : 'Final round',points:sport === 'MLB' ? 50 : 45},
      ...(leverage ? [{
        label:deciding ? 'Championship winner-take-all' : elimination ? 'Championship elimination / clinch' : 'Championship series leverage',
        points:leverage
      }] : [])
    ];
  }

  function completedStakesImpact(
    sport,
    event,
    competition,
    context
  ) {
    const detail =
      eventSignalText(
        event,
        competition,
        context
      );

    let stage = null;
    let consequence = null;

    if (
      /world series|super bowl|stanley cup final|champions league final|national championship|grand slam final/
        .test(detail)
    ) {
      stage = {
        label:'Championship stakes',
        points:18
      };
    } else if (
      /\bnba finals\b|\bwnba finals\b|\bleague final\b|\bchampionship series\b|\btitle series\b|\bfinals\b/
        .test(detail)
    ) {
      stage = {
        label:'Final-round stakes',
        points:15
      };
    } else if (
      /conference final|conference championship|\bsemifinal\b|\bsemi-final\b/
        .test(detail)
    ) {
      stage = {
        label:'Semifinal stakes',
        points:13
      };
    } else if (
      /playoff|postseason|wild card|divisional round|quarterfinal|knockout/
        .test(detail) ||
      singleEliminationRound(sport,detail) ||
      Number(
        event?.season?.type?.id ??
        event?.season?.type
      ) === 3
    ) {
      stage = {
        label:'Postseason stakes',
        points:10
      };
    }

    if (
      /\bgame\s*(?:7|seven)\b|\bdeciding game\b|\bwinner[- ]take[- ]all\b/
        .test(detail) ||
      /super bowl|national championship|champions league final|grand slam final/
        .test(detail)
    ) {
      consequence = {
        label:'Winner-take-all consequence',
        points:10
      };
    } else if (
      /\bwinner advances\b|\badvances? to\b|\badvanced to\b|\beliminates?\b|\beliminated\b|\bloser (?:is )?eliminated\b/
        .test(detail)
    ) {
      consequence = {
        label:'Advancement or elimination decided',
        points:8
      };
    } else if (
      /\bwinner (?:wins|takes) (?:the )?(?:division|league|conference)\b/
        .test(detail) ||
      /\b(?:wins|won|clinches|clinched|secures|secured|captures|captured|takes|took)\b[^.;]{0,50}\b(?:division|league|conference) (?:title|championship)\b/
        .test(detail) ||
      /\b(?:division|league|conference) (?:title|championship) (?:decided|clinched|secured|won)\b/
        .test(detail)
    ) {
      consequence = {
        label:'Division or conference title decided',
        points:8
      };
    } else if (
      /\b(?:clinches|clinched|secures|secured|earns|earned)\b[^.;]{0,40}\bplayoff berth\b/
        .test(detail) ||
      /\bplayoff berth\b[^.;]{0,30}\b(?:clinched|secured|earned|decided)\b/
        .test(detail)
    ) {
      consequence = {
        label:'Playoff berth decided',
        points:7
      };
    } else if (
      /\bwinner (?:takes|gets) (?:the )?(?:first place|top seed|no\.?\s*1 seed|number one seed)\b/
        .test(detail) ||
      /\b(?:clinches|clinched|secures|secured|takes|took|wins|won)\b[^.;]{0,45}\b(?:first place|top seed|no\.?\s*1 seed|number one seed)\b/
        .test(detail) ||
      /\b(?:first place|top seed|no\.?\s*1 seed|number one seed)\b[^.;]{0,30}\b(?:decided|clinched|secured|won)\b/
        .test(detail)
    ) {
      consequence = {
        label:'First place or major seeding decided',
        points:6
      };
    } else if (
      /\b(?:clinched|secured|captured|earned)\b/
        .test(detail) &&
      !/\b(?:can|could|may|might) clinch\b|\bclinching (?:opportunity|scenario)\b/
        .test(detail)
    ) {
      consequence = {
        label:'Competitive consequence clinched',
        points:5
      };
    } else if (
      /\bavoids? elimination\b|\bstays? alive\b|\bsurvives? elimination\b/
        .test(detail)
    ) {
      consequence = {
        label:'Elimination survival',
        points:5
      };
    }

    if (!consequence && singleEliminationRound(sport,detail)) {
      consequence = {label:'Advancement or elimination decided',points:8};
    }

    const factors = [];
    let remaining = 24;

    for (const factor of [stage,consequence]) {
      if (
        !factor ||
        remaining <= 0
      ) {
        continue;
      }

      const points =
        Math.min(
          factor.points,
          remaining
        );

      if (points) {
        factors.push({
          ...factor,
          points
        });

        remaining -=
          points;
      }
    }

    return {
      points:
        24 -
        remaining,
      factors
    };
  }

  function contextWeightFor(
    progress,
    gameState,
    anchors
  ) {
    if (
      gameState === 'completed'
    ) {
      return .05;
    }

    const p =
      Math.max(
        0,
        Math.min(
          1,
          Number(progress) || 0
        )
      );

    for (
      let i = 1;
      i < anchors.length;
      i++
    ) {
      if (
        p <= anchors[i][0]
      ) {
        const [
          x0,
          y0
        ] = anchors[i-1];

        const [
          x1,
          y1
        ] = anchors[i];

        const t =
          (
            p -
            x0
          ) /
          (
            x1 -
            x0
          );

        return (
          y0 +
          (
            y1 -
            y0
          ) *
          t
        );
      }
    }

    return .06;
  }

  const api = {eventSignalText,normalizeContextType,pregameContextFactors,aggregateScoreFromText,specificStakesFactors,singleEliminationRound,isPostseasonGame,playoffSeriesLeverage,championshipSeriesFactors,completedStakesImpact,contextWeightFor};
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api;
  } else {
    (root.SportsRadarScoring ||= {}).shared_context = api;
  }
})(globalThis);

/* Shared scoring module; supports classic browser scripts and Worker/Node bundling. */
(function (root) {
  const {aggregateScoreFromText} = typeof module !== 'undefined' && module.exports
    ? require('../shared/context.js')
    : root.SportsRadarScoring.shared_context;
  const {normalizedTime} = typeof module !== 'undefined' && module.exports
    ? require('../shared/time.js')
    : root.SportsRadarScoring.shared_time;

  function soccerSituationImpact(competition,summary,status,progress,scoreGap) {
    const situation =
      competition?.situation ||
      summary?.situation ||
      {};

    const text = [
      status?.type?.detail,
      status?.type?.shortDetail,
      status?.displayClock,
      situation?.description,
      situation?.displayValue,
      ...(competition?.notes || []).map(note => note.headline),
      competition?.series?.summary,
      competition?.series?.title
    ]
      .filter(Boolean)
      .join(' ')
      .toLowerCase();

    const cardCounts = (summary?.boxscore?.teams || []).map(team => ({
      id:String(team.team?.id || team.id || ''),
      count:(team.statistics || [])
        .filter(stat => /redcards|red cards|\brc\b/i.test(
          `${stat.name || ''} ${stat.displayName || ''} ${stat.abbreviation || ''}`))
        .reduce((sum,stat) => sum + (Number(stat.value ?? stat.displayValue) || 0),0)
    }));
    const cardsById = new Map(cardCounts.filter(team => team.id).map(team => [team.id,team.count]));
    const teamRedCards = cardCounts.reduce((sum,team) => sum + team.count,0);
    const scoredTeams = (competition?.competitors || [])
      .map(item => ({id:String(item.team?.id || item.id || ''),score:Number(item.score)}));
    const haveCardDirection = scoredTeams.length === 2 &&
      scoredTeams.every(team => team.id && Number.isFinite(team.score)) &&
      scoredTeams[0].score !== scoredTeams[1].score &&
      scoredTeams.some(team => cardsById.has(team.id));

    let points = 0;
    const reasons = [];

    if (
      teamRedCards > 0 ||
      /\bred card\b|\bsent off\b|\bdown to (?:ten|10)\b/.test(text)
    ) {
      const generic = progress >= .55 && scoreGap <= 1 ? 5 : 3;
      const leader = haveCardDirection
        ? scoredTeams[scoredTeams[0].score > scoredTeams[1].score ? 0 : 1]
        : null;
      const trailer = haveCardDirection
        ? scoredTeams[scoredTeams[0].score < scoredTeams[1].score ? 0 : 1]
        : null;
      const cardDifference = leader
        ? ((cardsById.get(leader.id) || 0) - (cardsById.get(trailer.id) || 0))
        : 0;
      points += scoreGap <= 1 && progress >= .55 && cardDifference !== 0
        ? (cardDifference > 0 ? 7 : 2)
        : generic;

      reasons.push(
        'A red card has changed the match conditions'
      );
    }

    const aggregate =
      aggregateScoreFromText(text);

    if (aggregate) {
      const aggregateGap =
        Math.abs(
          aggregate[0] -
          aggregate[1]
        );

      if (aggregateGap <= 1) {
        points +=
          progress >= .7
            ? 6
            : 4;

        reasons.push(
          aggregateGap === 0
            ? 'The knockout tie is level on aggregate'
            : 'The knockout tie is separated by one goal on aggregate'
        );
      }
    }

    if (
      /penalty shootout|penalties|shootout/
        .test(text)
    ) {
      points += 10;

      reasons.push(
        'The match is being decided by penalties'
      );
    } else if (
      (/stoppage time|added time|90'?\+\d+/.test(text) ||
        Number(status?.period) === 2 && normalizedTime('Soccer',{status}).elapsedSeconds > 90 * 60) &&
      scoreGap <= 1
    ) {
      points += 3;

      reasons.push(
        'A close match is in stoppage time'
      );
    }

    return {
      points:Math.min(12,points),
      note:'',
      reasons
    };
  }

  function soccerScoringMilestone(summary) {
    for (
      const block of
      summary?.boxscore?.players ||
      []
    ) {
      for (
        const group of
        block.statistics ||
        []
      ) {
        const goals =
          (group.labels || [])
            .findIndex(label =>
              /^G$|^GOALS$/i
                .test(label)
            );

        if (
          goals < 0
        ) {
          continue;
        }

        const scorer =
          (group.athletes || [])
            .filter(entry =>
              Number(
                entry.stats?.[goals]
              ) >= 2
            )
            .sort(
              (a,b) =>
                Number(
                  b.stats?.[goals]
                ) -
                Number(
                  a.stats?.[goals]
                )
            )[0];

        if (scorer) {
          const count =
            Number(
              scorer.stats[goals]
            );

          return {
            text:
              count >= 3
                ? `${scorer.athlete?.displayName || 'A player'} has a hat trick`
                : `${scorer.athlete?.displayName || 'A player'} has scored twice`,
            points:
              count >= 3
                ? 12
                : 6
          };
        }
      }
    }

    return null;
  }

  function soccerPressureWeight(points,scoreGap,dangerous,competition) {
    if (scoreGap === 1 && dangerous.length) {
      const teams = (competition?.competitors || [])
        .map(item => ({id:String(item.team?.id || item.id || ''),score:Number(item.score)}));
      if (teams.length === 2 && teams.every(team => team.id && Number.isFinite(team.score))) {
        const trailingId = teams[teams[0].score < teams[1].score ? 0 : 1].id;
        const leadingId = teams[teams[0].score > teams[1].score ? 0 : 1].id;
        const trailing = dangerous.filter(play => play.teamId === trailingId).length;
        const leading = dangerous.filter(play => play.teamId === leadingId).length;
        points = Math.round(points * (1 + .4*trailing/dangerous.length - .6*leading/dangerous.length));
      }
    }

    return points;
  }

  const soccerModel = {
    unit:'goal',duration:90,
    situation:({competition,summary,status,progress,scoreGap}) =>
      soccerSituationImpact(competition,summary,status,progress,scoreGap),
    milestone:soccerScoringMilestone,
    pressure:{maxGap:1,weight:soccerPressureWeight},
    history:{threshold:2,units:'goals'}
  };

  const api = {soccerSituationImpact,soccerScoringMilestone,soccerPressureWeight,soccerModel};
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api;
  } else {
    (root.SportsRadarScoring ||= {}).sports_soccer = api;
  }
})(globalThis);

/* Shared scoring module; supports classic browser scripts and Worker/Node bundling. */
(function (root) {
  const {gameProgress} = typeof module !== 'undefined' && module.exports
    ? require('./time.js')
    : root.SportsRadarScoring.shared_time;

  function normalizeWinProbability(value) {
    if (
      value === null ||
      value === undefined ||
      value === ''
    ) {
      return null;
    }

    let probability =
      Number(value);

    if (
      !Number.isFinite(probability)
    ) {
      return null;
    }

    if (
      probability > 1 &&
      probability <= 100
    ) {
      probability /= 100;
    }

    return (
      probability >= 0 &&
      probability <= 1
    )
      ? probability
      : null;
  }

  function winProbabilitySeries(summary) {
    return (
      summary?.winprobability ||
      []
    )
      .map(item =>
        normalizeWinProbability(
          item?.homeWinPercentage ??
          item?.homeWinProbability ??
          item?.homeWinPct ??
          item?.value
        )
      )
      .filter(
        value =>
          value !== null
      );
  }

  function winProbabilityImpact(summary,progress,state='live',sport='') {
    const competition =
      summary?.header?.competitions?.[0];

    const summaryStatus =
      competition?.status?.type;

    const estimate =
      (summary?.winprobability || [])
        .filter(item => normalizeWinProbability(
          item?.homeWinPercentage ?? item?.homeWinProbability ??
          item?.homeWinPct ?? item?.value
        ) !== null)
        .at(-1);

    const estimatePlay =
      estimate?.playId == null
        ? null
        : (summary?.plays || []).find(play =>
            String(play.id) === String(estimate.playId)
          );

    // A prediction for an earlier score or a finished game is not a live
    // estimate. Keep valid one-sided predictions, even in close games.
    const scoreChanged =
      estimatePlay &&
      (competition?.competitors || []).some(team => {
        const value = team.homeAway === 'home'
          ? estimatePlay.homeScore
          : team.homeAway === 'away'
            ? estimatePlay.awayScore
            : null;
        return value != null && team.score != null &&
          Number.isFinite(Number(value)) &&
          Number.isFinite(Number(team.score)) &&
          Number(value) !== Number(team.score);
      });

    const estimatePeriod =
      Number(estimatePlay?.period?.number || 0);

    const estimateProgress =
      sport && estimatePeriod
        ? gameProgress(sport,{
            status:{
              period:estimatePeriod,
              displayClock:estimatePlay.clock?.displayValue,
              type:{detail:estimatePlay.period?.displayValue}
            }
          })
        : null;

    if (
      state !== 'live' ||
      summaryStatus?.completed === true ||
      summaryStatus?.state === 'post' ||
      summaryStatus?.state === 'pre' ||
      scoreChanged ||
      /end (?:of )?game/i.test(
        `${estimatePlay?.type?.text || ''} ${estimatePlay?.text || ''}`
      ) ||
      (
        estimateProgress !== null &&
        Math.abs(Number(progress) - estimateProgress) > .05
      )
    ) {
      return {
        points:0,
        text:'',
        probability:null,
        uncertainty:null
      };
    }

    const series =
      winProbabilitySeries(summary);

    if (!series.length) {
      return {
        points:0,
        text:'',
        probability:null,
        uncertainty:null
      };
    }

    const probability =
      series.at(-1);

    const uncertainty =
      Math.max(
        0,
        1 -
        2 *
        Math.abs(
          probability -
          .5
        )
      );

    const p =
      Math.max(
        0,
        Math.min(
          1,
          Number(progress) || 0
        )
      );

    const leverageWeight =
      .35 +
      .65 *
      Math.pow(
        p,
        1.5
      );

    const bonus =
      Math.round(
        16 *
        uncertainty *
        leverageWeight
      );

    let penalty = 0;

    if (
      p >= .55 &&
      uncertainty < .35
    ) {
      penalty =
        Math.round(
          (
            (
              .35 -
              uncertainty
            ) /
            .35
          ) *
          12 *
          (
            .4 +
            .6 * p
          )
        );
    }

    const points =
      Math.max(
        -8,
        Math.min(
          16,
          bonus -
          penalty
        )
      );

    const pct =
      Math.round(
        probability *
        100
      );

    let text = '';

    if (
      uncertainty >= .8
    ) {
      text =
        `Win probability is nearly even (${pct}% / ${100-pct}%)`;
    } else if (
      uncertainty >= .55 &&
      p >= .65
    ) {
      text =
        `The outcome is still highly uncertain (${pct}% / ${100-pct}%)`;
    } else if (
      points < 0
    ) {
      text =
        `The feed estimates a one-sided outcome (${pct}% / ${100-pct}%)`;
    }

    return {
      points,
      text,
      probability,
      uncertainty
    };
  }

  const api = {normalizeWinProbability,winProbabilitySeries,winProbabilityImpact};
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api;
  } else {
    (root.SportsRadarScoring ||= {}).shared_probability = api;
  }
})(globalThis);

/* Shared scoring module; supports classic browser scripts and Worker/Node bundling. */
(function (root) {
  const {footballLiveCloseness} = typeof module !== 'undefined' && module.exports
    ? require('./football.js')
    : root.SportsRadarScoring.shared_football;

  function upsetImpact(
    candidate,
    teams,
    gameState,
    progress,
    sport='',
    competition=null
  ) {
    if (
      !candidate ||
      gameState === 'upcoming'
    ) {
      return {
        points:0,
        text:''
      };
    }

    const index =
      teams.findIndex(team =>
        candidate.teamId &&
        String(
          team.id ||
          team[8] ||
          ''
        ) ===
        candidate.teamId
      );

    const teamIndex =
      index >= 0
        ? index
        : candidate.teamIndex;

    if (
      teamIndex < 0 ||
      teamIndex > 1 ||
      teams.length !== 2
    ) {
      return {
        points:0,
        text:''
      };
    }

    const score =
      Number(
        teams[teamIndex].score ??
        teams[teamIndex][2]
      );

    const other =
      Number(
        teams[1-teamIndex].score ??
        teams[1-teamIndex][2]
      );

    if (
      !Number.isFinite(score) ||
      !Number.isFinite(other)
    ) {
      return {
        points:0,
        text:''
      };
    }

    const margin =
      score -
      other;

    const activation = Number.isFinite(candidate.activation)
      ? candidate.activation
      : 1;
    const scaled = points => Math.round(points * activation);

    if (
      gameState === 'completed'
    ) {
      return margin > 0
        ? {
            points:
              scaled(Math.min(
                22,
                18 +
                Math.round(
                  4 *
                  candidate.strength
                )
              )),

            text:
              `${candidate.teamName} won outright after entering as a ${candidate.description}`
          }
        : {
            points:0,
            text:''
          };
    }

    if (
      margin > 0 &&
      progress >= .35
    ) {
      return {
        points:
          scaled(Math.min(
            18,
            7 +
            Math.round(
              7 *
              progress
            ) +
            Math.round(
              4 *
              candidate.strength
            )
          )),

        text:
          `${candidate.teamName}, a ${candidate.description}, leads ${score}–${other}`
      };
    }

    if (
      margin === 0 &&
      progress >= .7
    ) {
      return {
        points:
          scaled(Math.min(
            12,
            4 +
            Math.round(
              5 *
              progress
            ) +
            Math.round(
              2 *
              candidate.strength
            )
          )),

        text:
          `${candidate.teamName}, a ${candidate.description}, is tied ${score}–${other} late`
      };
    }

    if (
      margin < 0 &&
      progress >= .7 &&
      ['NFL','CFB'].includes(sport)
    ) {
      const footballState = footballLiveCloseness(
        sport,-margin,progress,competition
      );
      const tiedPoints = Math.min(12,
        4 + Math.round(5 * progress) + Math.round(2 * candidate.strength)
      );
      // The margin curve measures upset threat, while the ordinary state
      // score handles game closeness. Possession and remaining chances decide
      // how much of the tied upset bonus is still in play.
      const possessionWeight = footballState.possessionState === 'trailing'
        ? 1
        : footballState.possessionState === 'leading'
          ? .68
          : .8;
      const fieldWeight = footballState.possessionState === 'trailing' &&
        footballState.fieldPosition !== null
          ? 1 + .08 * Math.max(0,(footballState.fieldPosition - 50) / 50)
          : 1;
      const marginWeight = Math.exp(-Math.pow(-margin / 10,1.6));
      const points = scaled(Math.round(
        tiedPoints * marginWeight * footballState.comebackFeasibility *
        possessionWeight * fieldWeight
      ));
      return {
        points,
        text:points
          ? `${candidate.teamName}, a ${candidate.description}, trails ${score}–${other} but remains an upset threat`
          : ''
      };
    }

    return {
      points:0,
      text:''
    };
  }

  const api = {upsetImpact};
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api;
  } else {
    (root.SportsRadarScoring ||= {}).shared_upset = api;
  }
})(globalThis);

/* Shared scoring module; supports classic browser scripts and Worker/Node bundling. */
(function (root) {
  const {proPregame} = typeof module !== 'undefined' && module.exports
    ? require('../shared/pregame.js')
    : root.SportsRadarScoring.shared_pregame;

  const {clockSeconds} = typeof module !== 'undefined' && module.exports
    ? require('../shared/time.js') : root.SportsRadarScoring.shared_time;
  const {eventSignalText,isPostseasonGame,playoffSeriesLeverage} = typeof module !== 'undefined' && module.exports
    ? require('../shared/context.js') : root.SportsRadarScoring.shared_context;
  const {upsetImpact} = typeof module !== 'undefined' && module.exports
    ? require('../shared/upset.js') : root.SportsRadarScoring.shared_upset;

  function nhlLiveMarginCloseness(gap,progress=0,situation={}) {
    if (
      gap === null ||
      !Number.isFinite(Number(gap))
    ) {
      return 0;
    }

    const goals =
      Math.max(
        0,
        Number(gap)
      );

    if (goals <= 1) return 1 - .1 * goals;
    const p = Math.max(0,Math.min(1,Number(progress) || 0));
    // Continuous deficit/runway decay. Manpower buys limited runway, not a
    // separate closeness bonus; even six-on-four cannot rescue a dead game.
    const extra = Math.min(.45,(situation.trailingGoaliePulled ? .22 : 0) +
      (situation.trailingPowerPlay ? .23 : 0));
    // Preserve meaningful third-period runway at exactly two goals without
    // lifting larger deficits. Both the time activation and margin taper are
    // continuous, so this does not restore the former two/three-goal cliff.
    const third = Math.max(0,Math.min(1,(p-.67)/.1));
    const thirdRamp = third*third*(3-2*third);
    const secondsRemaining = Math.max(0,(1-p)*3600);
    const twoGoalRunway = 1.6*(1-Math.exp(-Math.pow(secondsRemaining/500,1.8))) *
      Math.exp(-Math.pow(Math.max(0,goals-2)/.32,2)) * thirdRamp;
    const runway = 2.1 - 1.85 * p + extra + twoGoalRunway;
    return .9 * Math.exp(-Math.pow(goals - 1,1.35) / runway);
  }

  function smoothNhlTarget(seconds,anchors) {
    const s=Math.max(0,Math.min(1200,Number(seconds) || 0));
    for(let i=1;i<anchors.length;i++) {
      const high=anchors[i-1],low=anchors[i];
      if(s<=high[0] && s>=low[0]) {
        const x=(high[0]-s)/(high[0]-low[0]);
        const eased=x*x*(3-2*x);
        return high[1]+(low[1]-high[1])*eased;
      }
    }
    return s>anchors[0][0] ? anchors[0][1] : anchors.at(-1)[1];
  }

  function hockeyOnIceState(
    summary,
    teams
  ) {
    const onIce =
      summary?.onIce || [];

    const blocks =
      summary?.boxscore?.players ||
      [];

    if (
      onIce.length !== 2
    ) {
      return null;
    }

    const goalieIds =
      new Map(
        blocks.map(block => [
          String(
            block.team?.id ||
            ''
          ),

          new Set(
            (block.statistics || [])
              .filter(group =>
                /goalie/i.test(
                  group.name ||
                  group.displayName ||
                  ''
                )
              )
              .flatMap(group =>
                (group.athletes || [])
                  .map(entry =>
                    String(
                      entry.athleteid ||
                      entry.athleteId ||
                      entry.athlete?.id ||
                      ''
                    )
                  )
              )
          )
        ])
      );

    const sides =
      onIce.map(side => {
        const id =
          String(
            side.teamId ||
            side.team?.id ||
            ''
          );

        const entries =
          side.entries || [];

        const goalies =
          goalieIds.get(id) ||
          new Set();

        const hasGoalie =
          entries.some(entry =>
            goalies.has(
              String(
                entry.athleteid ||
                entry.athleteId ||
                entry.athlete?.id ||
                ''
              )
            )
          );

        return {
          id,
          count:
            entries.length,
          hasGoalie,
          goalieKnown:goalies.size > 0,
          skaters:entries.length - (hasGoalie ? 1 : 0),
          name:
            teams.find(team =>
              String(
                team[8] || ''
              ) === id
            )?.[0] ||
            'A team'
        };
      });

    let powerPlayTeam = null;
    let powerPlayTeamId = null;
    let powerPlayAdvantage = 0;
    let pulledGoalieTeam = null;
    let pulledGoalieTeamId = null;

    if (sides.every(side => side.goalieKnown && side.count >= 4)) {
      const high = sides[0].skaters > sides[1].skaters ? sides[0] : sides[1];
      const low = high === sides[0] ? sides[1] : sides[0];
      // Removing a goalie alone is not a penalty advantage.
      powerPlayAdvantage = Math.max(0,high.skaters-low.skaters-(high.hasGoalie ? 0 : 1));
      if (powerPlayAdvantage) {
        powerPlayTeam = high.name;
        powerPlayTeamId = high.id;
      }
    }

    const noGoalie =
      sides.find(side =>
        side.goalieKnown && !side.hasGoalie &&
        side.count >= 5
      );

    const withGoalie =
      sides.find(side =>
        side.hasGoalie
      );

    if (
      noGoalie &&
      withGoalie
    ) {
      pulledGoalieTeam =
        noGoalie.name;
      pulledGoalieTeamId = noGoalie.id;
    }

    return {
      sides,
      powerPlayTeam,
      powerPlayTeamId,
      powerPlayAdvantage,
      pulledGoalieTeam,
      pulledGoalieTeamId
    };
  }

  function hockeyPowerPlay(
    summary,
    teams
  ) {
    const state =
      hockeyOnIceState(
        summary,
        teams
      );

    return (
      state?.powerPlayTeam ||
      null
    );
  }

  function hockeyOvertime(event,competition,summary,context='') {
    const status = competition?.status || {};
    const detail = `${status.type?.detail || ''} ${status.type?.shortDetail || ''}`;
    const signal = eventSignalText(event,competition,context) + ' ' + eventSignalText(summary?.header,competition,'');
    const postseason = isPostseasonGame('NHL',event,competition,signal) ||
      Number(summary?.header?.season?.type?.id ?? summary?.header?.season?.type) === 3;
    const shootout = /shootout|\bSO\b/i.test(detail) || (!postseason && Number(status.period) >= 5);
    const depth = shootout ? 0 : Math.max(0,Number(status.period || 0)-3,
      Number(detail.match(/(\d+)\s*OT\b/i)?.[1] || (/overtime|\bOT\b/i.test(detail) ? 1 : 0)));
    const leverage = playoffSeriesLeverage('NHL',competition,signal);
    const deciding = /game\s*7|deciding|winner.take.all/i.test(signal) || /deciding/i.test(leverage?.label || '');
    return {shootout,depth,postseason,deciding,final:/stanley cup final/i.test(signal)};
  }

  function hockeySituationImpact(game,competition,summary,status,progress,scoreGap) {
    const state = summary ? hockeyOnIceState(summary,game.teams) : null;
    const scores = game.teams.map(team => Number(team[2]));
    const trailing = scores.length === 2 && scores.every(Number.isFinite) && scores[0] !== scores[1]
      ? String(game.teams[scores[0] < scores[1] ? 0 : 1][8] || '') : '';
    const pulled = Boolean(trailing && state?.pulledGoalieTeamId === trailing);
    const powerPlay = Boolean(trailing && state?.powerPlayTeamId === trailing);
    const advantage = powerPlay || scoreGap === 0 ? state?.powerPlayAdvantage || 0 : 0;
    const seconds = clockSeconds(status);
    const late = Number(status?.period) === 3 && seconds !== null;
    const ot = hockeyOvertime(game.sourceEvent,{...competition,status},summary);
    let target = 0;
    let note = '';
    if (ot.shootout) { target=82; note='Shootout'; }
    else if (ot.depth && scoreGap === 0) {
      target = ot.postseason ? Math.min(97,90 + 3 * (ot.depth-1)) : 80;
      if (ot.postseason && ot.deciding) target=Math.max(target,96);
      if (ot.postseason && ot.final) target=Math.max(target,95);
      if (ot.postseason && ot.final && ot.deciding) target=99;
      note=ot.postseason ? `Playoff sudden-death ${ot.depth > 1 ? ot.depth : ''}OT` : '3-on-3 overtime';
    } else if (late && scoreGap <= 1) {
      if (scoreGap === 0) target=Math.round(smoothNhlTarget(seconds,[
        [1200,52],[720,58],[600,65],[300,77],[120,84],[60,88],[0,90]
      ]));
      else if (seconds <= 60) target=78;
      else if (seconds <= 120) target=74;
      else if (seconds <= 300) target=69;
      if (seconds <= 300 && powerPlay) target=Math.max(target,scoreGap === 0 ? 84 : 82);
      if (seconds <= 180 && advantage >= 2) target=Math.max(target,89);
      if (seconds <= 180 && pulled) target=Math.max(target,powerPlay ? 91 : 85);
      note = pulled ? (powerPlay ? 'Pulled the goalie with a power play' : 'Pulled the goalie')
        : advantage >= 2 ? 'Two-skater advantage' : powerPlay ? 'Trailing-team power play' : '';
    } else if (late && scoreGap === 2 && seconds <= 180 && (pulled || powerPlay)) {
      target = pulled && powerPlay ? 55 : 46;
      note='Two-goal comeback with extra manpower';
    }
    if (target && !ot.depth && !ot.shootout) {
      if (ot.postseason) target=Math.min(96,target+(ot.final ? 5 : 2));
      target=Math.min(96,target+Math.round(hockeyPressure(summary,progress,scoreGap,competition).points/2));
    }
    if (!note && state?.powerPlayTeam) note=`${state.powerPlayTeam} power play`;
    if (!note && state?.pulledGoalieTeam) note=`${state.pulledGoalieTeam} pulled the goalie`;
    const viability=nhlLiveMarginCloseness(scoreGap,progress,{trailingGoaliePulled:pulled,trailingPowerPlay:powerPlay});
    const points=Math.round((powerPlay ? 5 : pulled ? 3 : state?.powerPlayTeam ? (scoreGap === 0 ? 4 : 1) : 0)*viability);
    const base=Number(game.baseScore);
    return {points,note,reasons:note ? [note] : [],
      competitiveFloor:Number.isFinite(base) && target ? Math.max(0,target-base) : 0,
      competitiveTarget:target,manpower:{pulled,powerPlay,advantage},overtime:ot};
  }

  function hockeyGoalMilestone(summary) {
    for (
      const block of
      summary?.boxscore?.players ||
      []
    ) {
      for (
        const group of
        block.statistics ||
        []
      ) {
        if (
          /goalie/i.test(
            group.name ||
            group.displayName ||
            ''
          )
        ) {
          continue;
        }

        const goals =
          (group.labels || [])
            .indexOf('G');

        if (
          goals < 0
        ) {
          continue;
        }

        const scorer =
          (group.athletes || [])
            .filter(entry =>
              Number(
                entry.stats?.[goals]
              ) >= 2
            )
            .sort(
              (a,b) =>
                Number(
                  b.stats[goals]
                ) -
                Number(
                  a.stats[goals]
                )
            )[0];

        if (scorer) {
          const count =
            Number(
              scorer.stats[goals]
            );

          const name =
            scorer.athlete?.displayName ||
            'A player';

          return {
            scorerName:name,
            text:
              count >= 3
                ? `${name} has a hat trick (${count} goals)`
                : `${name} has 2 goals and is one away from a hat trick`,
            points:
              count >= 3
                ? 6
                : 3
          };
        }
      }
    }

    return null;
  }

  function hockeyGameState({gameState,gap,progress,context}) {
    const teams = context?.teams?.[0]?.[0] ? context.teams :
      (context?.competition?.competitors || []).map(item => [item.team?.displayName || '', '', item.score, '', '', '', null, '', String(item.team?.id || '')]);
    const state = context?.summary ? hockeyOnIceState(context.summary,teams) : null;
    const scores = teams.map(team => Number(team[2]));
    const trailing = scores.length === 2 && scores[0] !== scores[1]
      ? String(teams[scores[0] < scores[1] ? 0 : 1][8] || '') : '';
    const marginClose=nhlLiveMarginCloseness(gap,progress,{
      trailingGoaliePulled:Boolean(trailing && state?.pulledGoalieTeamId === trailing),
      trailingPowerPlay:Boolean(trailing && state?.powerPlayTeamId === trailing)
    });
    const seconds=clockSeconds(context?.competition?.status);
    const finalMinute=Number(context?.competition?.status?.period) === 3 && seconds !== null
      ? Math.max(0,Math.min(1,(120-seconds)/60)) : 0;
    const twoGoalWeight=Math.exp(-Math.pow((Number(gap)-2)/.32,2));
    const lateTwoGoalPenalty=Math.round(3*finalMinute*finalMinute*(3-2*finalMinute)*twoGoalWeight);
    return gameState === 'live' ? {marginClose,minimumComebackViability:gap === 1 ? .82 : 0,
      // Avoid the generic integer-margin penalty reintroducing a cliff at 3.
      widePenalty:gap == null || !Number.isFinite(gap) ? 0 :
        Math.round(20*progress*(1-marginClose)*Math.min(1,Math.max(0,gap-1)/4))+lateTwoGoalPenalty}
      : {};
  }

  function hockeyLiveMilestone(summary,{scoreGap,progress,status}) {
    const milestone=hockeyGoalMilestone(summary);
    if (!milestone) return {points:0,text:''};
    let points=milestone.points * nhlLiveMarginCloseness(scoreGap,progress);
    if (milestone.points === 6) {
      // A completed hat trick is an event, not a permanent live surcharge.
      const goals=(summary.scoringPlays?.length ? summary.scoringPlays : (summary.plays || []).filter(p=>p.scoringPlay))
        .filter(p=>String(p.text || '').toLowerCase().includes(milestone.scorerName.toLowerCase()));
      const latest=goals.at(-1);
      const postseason=hockeyOvertime(null,{status},summary).postseason;
      const now=hockeyElapsed(status,postseason);
      const then=hockeyElapsed({period:latest?.period?.number,displayClock:latest?.clock?.displayValue,clockMode:hockeyPlayClockMode(summary)},postseason);
      const age=now !== null && then !== null ? now-then : NaN;
      points*=Number.isFinite(age) ? Math.max(0,1-age/180) : .5;
    }
    return {...milestone,points:Math.round(points)};
  }

  function hockeyUpset(candidate,teams,state,progress,sport,competition) {
    const impact=upsetImpact(candidate,teams,state,progress,sport,competition);
    if (!impact.points) return impact;
    // +180 is modest; +250 stronger, +300 major, extreme prices approach 22.
    const value=Number(candidate.value) || 180;
    const magnitude=Math.min(22,4+18*(1-Math.exp(-Math.max(0,value-180)/210)));
    const oldMaximum=Math.min(22,18+Math.round(4*candidate.strength));
    return {...impact,points:Math.round(impact.points*magnitude/oldMaximum)};
  }

  // Physical elapsed time is local to NHL scoring. Display/timeline geometry
  // remains unchanged; regulation and playoff periods are twenty minutes.
  function hockeyElapsed(status,postseason=true) {
    const period=Number(status?.period?.number ?? status?.period);
    // Parse the raw clock once; the generic parser uses NBA period lengths
    // when given clockMode=elapsed, so NHL applies that mode locally below.
    const seconds=clockSeconds({...status,clockMode:undefined});
    if (!(period > 0) || seconds === null) return null;
    const length=period <= 3 || postseason ? 1200 : 300;
    const elapsed=status.clockMode === 'elapsed' ? seconds : length-seconds;
    return (period<=3 ? (period-1)*1200 : 3600+(period-4)*length)+elapsed;
  }

  function hockeyPlayClockMode(summary) {
    // Archived NHL play clocks count UP, unlike scoreboard clocks. Infer this
    // only from provider sequence numbers or an increasing goal ledger; never
    // assume arbitrary recent-record ordering is chronological.
    const plays=summary?.plays || [];
    const sequenced=plays.length>1 && plays.every(p=>p.sequenceNumber != null && Number.isFinite(Number(p.sequenceNumber)));
    const ordered=sequenced ? [...plays].sort((a,b)=>Number(a.sequenceNumber)-Number(b.sequenceNumber))
      : summary?.scoringPlays?.length ? summary.scoringPlays : plays.filter(p=>p.scoringPlay);
    let up=0,down=0;
    for(let i=1;i<ordered.length;i++) {
      const a=ordered[i-1],b=ordered[i];
      if(Number(a.period?.number || a.period)!==Number(b.period?.number || b.period)) continue;
      if(!sequenced && !(Number(b.homeScore)>=Number(a.homeScore) && Number(b.awayScore)>=Number(a.awayScore))) continue;
      const first=clockSeconds({displayClock:a.clock?.displayValue,clock:a.clock?.value});
      const second=clockSeconds({displayClock:b.clock?.displayValue,clock:b.clock?.value});
      if(first===null || second===null) continue;
      if(second>first) up++; else if(second<first) down++;
    }
    return up>down ? 'elapsed' : 'remaining';
  }

  function hockeyPressure(summary,progress,gap,competition) {
    if (!summary || gap > 2) return {points:0,reasons:[]};
    const postseason=hockeyOvertime(null,competition,summary).postseason;
    const now=hockeyElapsed(competition?.status || summary.header?.competitions?.[0]?.status,postseason);
    const plays=summary.plays || [];
    const clockMode=hockeyPlayClockMode(summary);
    const timed=plays.map(play => ({play,time:hockeyElapsed({period:play.period?.number || play.period,displayClock:play.clock?.displayValue,clock:play.clock?.value,clockMode},postseason)}));
    const hasTime=now !== null && timed.some(item => item.time !== null);
    const recent=hasTime ? timed.filter(item => item.time !== null && now-item.time >= 0 && now-item.time <= 90).map(item=>item.play) : plays.slice(-18);
    const dangerous=recent.filter(play => !play.scoringPlay && /shot on goal|saved by|\bsave\b|breakaway|penalty shot|hit (?:the )?(?:post|crossbar)|off (?:the )?(?:post|crossbar)|big chance|close range|point-blank/i.test(play.text || play.shortText || play.type?.text || ''));
    const competitors=competition?.competitors || summary.header?.competitions?.[0]?.competitors || [];
    const trailing=competitors.length === 2 && Number(competitors[0].score) !== Number(competitors[1].score)
      ? String(competitors[Number(competitors[0].score)<Number(competitors[1].score) ? 0 : 1].team?.id || '') : '';
    let trailingCount=0,leadingCount=0,premium=0;
    for (const play of dangerous) {
      const text=play.text || play.shortText || play.type?.text || '';
      let id=String(play.team?.id || play.teamId || '');
      // Standalone save records identify the defending team, not the shooter.
      if (/^(?:save\b|.* makes (?:a )?save)/i.test(text) && !/shot|breakaway|saved by/i.test(text)) {
        id=String(competitors.find(c => String(c.team?.id) !== id)?.team?.id || '');
      }
      if (trailing && id) { if (id === trailing) trailingCount++; else leadingCount++; }
      if (/breakaway|penalty shot|post|crossbar|point-blank|big chance/i.test(text)) premium++;
    }
    const known=trailingCount+leadingCount;
    const direction=known ? .45+1.1*trailingCount/known : 1;
    const activity=Math.min(7,dangerous.length*.8+Math.min(3,premium*1.2));
    const leverage=(.3+.7*progress)*nhlLiveMarginCloseness(gap,progress);
    const points=Math.min(7,Math.round(activity*direction*leverage));
    return {points,reasons:points ? [`${dangerous.length} dangerous chances ${hasTime ? 'in the last 90 seconds' : 'in recent records'}${trailingCount > leadingCount ? ', led by the trailing team' : ''}`] : []};
  }

  function hockeyCompletedResult(sport,state,teams,event,competition,context) {
    if (state !== 'completed') return null;
    const ot=hockeyOvertime(event,competition,null,context);
    const points=ot.shootout ? 9 : ot.depth ? (ot.postseason ? Math.min(28,18+4*(ot.depth-1)) : 13) : 0;
    return points ? {label:ot.shootout ? 'Shootout finish' : `${ot.postseason ? 'Playoff sudden-death' : 'Overtime'} winner${ot.depth>1 ? ` (${ot.depth}OT)` : ''}`,points} : null;
  }

  function hockeyCompletedHistory(summary,history,{game,finishPoints=0}={}) {
    const ot=hockeyOvertime(game?.sourceEvent,game?.sourceCompetition,summary);
    if (!ot.shootout && !ot.depth) return history;
    const floor=ot.shootout ? 61 : ot.postseason
      ? [0,78,85,90,93][Math.min(4,ot.depth)]
      : 63;
    const existing=Number(game?.score)+history.points+Number(finishPoints || 0);
    const delta=Number.isFinite(existing) ? Math.max(0,Math.round(floor-existing)) : 0;
    if (!delta) return history;
    const factor={label:`Completed ${ot.shootout ? 'shootout' : ot.postseason ? `${ot.depth}OT playoff` : 'overtime'} floor`,points:delta};
    return {points:history.points+delta,text:[history.text,factor.label].filter(Boolean).join('; '),
      factors:[...history.factors,factor],handlesFinish:history.handlesFinish};
  }

  function hockeyHistory(summary,progress,state) {
    if (state === 'upcoming') return {points:0,text:'',factors:[]};
    const comp=summary?.header?.competitions?.[0] || {};
    const ot=hockeyOvertime(null,comp,summary);
    const current=state === 'completed' ? Math.max(3600,hockeyElapsed(comp.status,ot.postseason) || 0) : hockeyElapsed(comp.status,ot.postseason) ?? progress*3600;
    const plays=(summary?.scoringPlays?.length ? summary.scoringPlays : (summary?.plays || []).filter(p=>p.scoringPlay)) || [];
    const clockMode=hockeyPlayClockMode(summary);
    const moments=plays.filter(p=>p.homeScore != null && p.awayScore != null && !(ot.shootout && Number(p.period?.number || p.period)>4))
      .map(p=>({home:Number(p.homeScore),away:Number(p.awayScore),time:hockeyElapsed({period:p.period?.number || p.period,displayClock:p.clock?.displayValue,clock:p.clock?.value,clockMode},ot.postseason),text:p.text || '',extraAttacker:p.extraAttacker===true || p.goaliePulled===true}))
      // Final summaries often omit period/clock. Their recorded OT winner must
      // still be included; only a live summary is bounded by the current clock.
      .filter(p=>Number.isFinite(p.home) && Number.isFinite(p.away) && p.time !== null && (state === 'completed' || p.time <= current))
      .sort((a,b)=>a.time-b.time);
    if (!moments.length) return {points:0,text:'',factors:[],handlesFinish:true};
    const completeLedger=moments.every((moment,i)=>{
      const prior=moments[i-1] || {home:0,away:0};
      const homeGain=moment.home-prior.home,awayGain=moment.away-prior.away;
      return (homeGain===1 && awayGain===0) || (homeGain===0 && awayGain===1);
    });
    let lastTime=0,margin=0,leader=0,changes=0,tiedTime=0,oneGoalTime=0,homeDeficit=0,awayDeficit=0,comeback=0,lateTie=0,lateAhead=0,pulledComeback=false;
    for (const moment of moments) {
      const duration=Math.max(0,Math.min(3600,moment.time)-Math.min(3600,lastTime));
      if (margin===0) tiedTime+=duration;
      if (Math.abs(margin)<=1) oneGoalTime+=duration;
      const next=moment.home-moment.away;
      homeDeficit=Math.max(homeDeficit,-next); awayDeficit=Math.max(awayDeficit,next);
      if (next>=0) comeback=Math.max(comeback,homeDeficit);
      if (next<=0) comeback=Math.max(comeback,awayDeficit);
      if (next && leader && Math.sign(next)!==leader) changes++;
      if (next) leader=Math.sign(next);
      const recent=state === 'completed' || current-moment.time<=180;
      if (moment.time>=3300 && moment.time<=3600 && recent) {
        if (next===0 && margin!==0) {
          lateTie=moment.time>=3480 ? 9 : 6;
          if (moment.extraAttacker || /extra attacker|goalie pulled|6.on.[45]/i.test(moment.text)) pulledComeback=true;
        }
        if (next!==0 && (margin===0 || Math.sign(next)!==Math.sign(margin))) lateAhead=moment.time>=3480 ? 10 : 7;
      }
      margin=next; lastTime=moment.time;
    }
    const tail=Math.max(0,Math.min(3600,current)-Math.min(3600,lastTime));
    if (margin===0) tiedTime+=tail;
    if (Math.abs(margin)<=1) oneGoalTime+=tail;
    const duration=Math.max(1,Math.min(3600,current));
    const factors=[];
    const add=(label,points)=>{if(points) factors.push({label,points});};
    add('Late tying goal',lateTie);
    add('Late go-ahead goal',lateAhead);
    add('Goalie-pull comeback',pulledComeback ? 3 : 0);
    add('Erased a multi-goal deficit',comeback>=2 ? Math.min(10,4+2*(comeback-1)) : 0);
    add(`${changes} lead change${changes===1 ? '' : 's'}`,Math.min(9,changes*3));
    // Time tied is a subset of within-one time; award the combined path once.
    if (completeLedger && current>=1440) add('Time tied or within one goal',Math.round((state==='completed' ? 8 : 3)*(.7*oneGoalTime/duration+.3*tiedTime/duration)));
    let remaining=state==='completed' ? 32 : 12;
    const capped=factors.map(f=>{const points=Math.min(remaining,f.points);remaining-=points;return {...f,points};}).filter(f=>f.points);
    return {points:capped.reduce((sum,f)=>sum+f.points,0),text:capped.map(f=>f.label).join('; '),factors:capped,
      handlesFinish:true,tiedShare:tiedTime/duration,withinOneShare:oneGoalTime/duration};
  }

  function hockeyEventShock({text,positioned,i,play}) {
    let value = 0;
    let label = '';
    if (/shorthanded goal|short-handed goal/.test(text)) { value=6; label='Shorthanded goal'; }
    return value ? {value,label} : null;
  }

  const nhlModel = {
    unit:'goal',pregame:proPregame,
    gameState:hockeyGameState,
    situation:({game,competition,summary,status,progress,scoreGap}) =>
      hockeySituationImpact(game,competition,summary,status,progress,scoreGap),
    milestone:hockeyGoalMilestone,
    liveMilestone:hockeyLiveMilestone,
    decisiveFloor:true,
    upset:hockeyUpset,
    completedResult:hockeyCompletedResult,
    completedHistory:hockeyCompletedHistory,
    ownsCompletedOvertime:true,
    historyImpact:hockeyHistory,
    eventShock:hockeyEventShock,
    pressure:{maxGap:2,impact:hockeyPressure},
    contextAnchors:() => [[0,.40],[.25,.34],[.5,.27],[.67,.21],[.82,.13],[.93,.08],[1,.06]],
    history:{threshold:2,units:'goals'}
  };

  const api = {nhlLiveMarginCloseness,hockeyOnIceState,hockeyPowerPlay,hockeySituationImpact,hockeyGoalMilestone,hockeyGameState,hockeyEventShock,hockeyOvertime,hockeyHistory,hockeyCompletedHistory,hockeyPressure,hockeyUpset,hockeyElapsed,nhlModel};
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api;
  } else {
    (root.SportsRadarScoring ||= {}).sports_nhl = api;
  }
})(globalThis);

/* Shared scoring module; supports classic browser scripts and Worker/Node bundling. */
(function (root) {
  const {nflModel} = typeof module !== 'undefined' && module.exports
    ? require('./sports/nfl.js')
    : root.SportsRadarScoring.sports_nfl;
  const {mlbModel} = typeof module !== 'undefined' && module.exports
    ? require('./sports/mlb.js')
    : root.SportsRadarScoring.sports_mlb;
  const {nhlModel} = typeof module !== 'undefined' && module.exports
    ? require('./sports/nhl.js')
    : root.SportsRadarScoring.sports_nhl;
  const {nbaModel,ncaabModel} = typeof module !== 'undefined' && module.exports
    ? require('./sports/basketball.js')
    : root.SportsRadarScoring.sports_basketball;
  const {cfbModel} = typeof module !== 'undefined' && module.exports
    ? require('./sports/cfb.js')
    : root.SportsRadarScoring.sports_cfb;
  const {tennisModel} = typeof module !== 'undefined' && module.exports
    ? require('./sports/tennis.js')
    : root.SportsRadarScoring.sports_tennis;
  const {soccerModel} = typeof module !== 'undefined' && module.exports
    ? require('./sports/soccer.js')
    : root.SportsRadarScoring.sports_soccer;

  // Shared helpers never import this registry or the orchestrator.
  const SPORT_MODELS = {
    NFL:nflModel,MLB:mlbModel,NHL:nhlModel,NBA:nbaModel,NCAAB:ncaabModel,
    CFB:cfbModel,Tennis:tennisModel,Soccer:soccerModel
  };

  const api = {SPORT_MODELS};
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api;
  } else {
    (root.SportsRadarScoring ||= {}).models = api;
  }
})(globalThis);

/* Shared scoring module; supports classic browser scripts and Worker/Node bundling. */
(function (root) {
  const {eventPosition} = typeof module !== 'undefined' && module.exports
    ? require('./time.js')
    : root.SportsRadarScoring.shared_time;
  const {winProbabilitySeries} = typeof module !== 'undefined' && module.exports
    ? require('./probability.js')
    : root.SportsRadarScoring.shared_probability;

  function historyImpact(
    sport,
    summary,
    progress,
    state,
    history={}
  ) {
    if (
      state === 'upcoming'
    ) {
      return {
        points:0,
        text:'',
        factors:[]
      };
    }

    const plays =
      summary?.scoringPlays?.length
        ? summary.scoringPlays
        : (summary?.plays || [])
            .filter(
              play =>
                play.scoringPlay === true
            );

    const moments =
      plays
        .map(play => {
          const home =
            Number(play.homeScore);

          const away =
            Number(play.awayScore);

          const period =
            Number(
              play.period?.number ||
              play.period ||
              0
            );

          const position =
            period
              ? eventPosition(
                  sport,
                  {
                    status:{
                      period,
                      displayClock:
                        play.clock?.displayValue ||
                        '',
                      clock:play.clock?.value,
                      type:{
                        detail:
                          play.period?.displayValue ||
                          ''
                      }
                    }
                  }
                )
              : null;

          return (
            Number.isFinite(home) &&
            Number.isFinite(away)
          )
            ? {
                home,
                away,
                position,
                text:
                  String(
                    play.text ||
                    play.shortText ||
                    ''
                  )
              }
            : null;
        })
        .filter(Boolean)
        .sort(
          (a,b) =>
            (a.position ?? 0) -
            (b.position ?? 0)
        );

    const threshold = history.threshold || 7;
    const units = history.units || 'points';

    const competitors =
      summary?.header
        ?.competitions?.[0]
        ?.competitors ||
      [];

    const nameFor =
      side =>
        competitors.find(
          item =>
            item.homeAway === side
        )?.team?.displayName ||
        (
          side === 'home'
            ? 'The home team'
            : 'The away team'
        );

    const possessive =
      name =>
        `${name}${/s$/i.test(name) ? "'" : "'s"}`;

    const currentProgress =
      state === 'completed'
        ? 1
        : Math.max(
            0,
            Math.min(
              1,
              Number(progress) || 0
            )
          );

    let previousLeader = 0;
    let leadChanges = 0;
    let lastFlip = -1;

    const flipPositions = [];
    const tiePositions = [];

    let deepestHomeDeficit = 0;
    let deepestAwayDeficit = 0;
    let comeback = null;

    let previousHome = 0;
    let previousAway = 0;

    let runSide = '';
    let runPoints = 0;
    let runCount = 0;

    for (const moment of moments) {
      const margin =
        moment.home -
        moment.away;

      deepestHomeDeficit =
        Math.max(
          deepestHomeDeficit,
          -margin
        );

      deepestAwayDeficit =
        Math.max(
          deepestAwayDeficit,
          margin
        );

      if (
        margin >= 0 &&
        deepestHomeDeficit >= threshold &&
        (
          !comeback ||
          deepestHomeDeficit >
          comeback.deficit
        )
      ) {
        comeback = {
          side:'home',
          deficit:
            deepestHomeDeficit
        };
      }

      if (
        margin <= 0 &&
        deepestAwayDeficit >= threshold &&
        (
          !comeback ||
          deepestAwayDeficit >
          comeback.deficit
        )
      ) {
        comeback = {
          side:'away',
          deficit:
            deepestAwayDeficit
        };
      }

      const leader =
        Math.sign(margin);

      if (
        margin === 0 &&
        moment.position !== null &&
        Number.isFinite(moment.position)
      ) {
        tiePositions.push(
          moment.position
        );
      }

      if (
        leader &&
        previousLeader &&
        leader !== previousLeader
      ) {
        leadChanges++;

        lastFlip =
          moment.position ?? -1;

        flipPositions.push(
          lastFlip
        );
      }

      if (leader) {
        previousLeader =
          leader;
      }

      const homeGain =
        moment.home -
        previousHome;

      const awayGain =
        moment.away -
        previousAway;

      const scorer =
        homeGain > 0 &&
        awayGain === 0
          ? 'home'
          : awayGain > 0 &&
            homeGain === 0
            ? 'away'
            : '';

      if (scorer) {
        if (
          runSide !== scorer
        ) {
          runSide = scorer;
          runPoints = 0;
          runCount = 0;
        }

        runPoints +=
          scorer === 'home'
            ? homeGain
            : awayGain;

        runCount++;
      } else {
        runSide = '';
        runPoints = 0;
        runCount = 0;
      }

      previousHome =
        moment.home;

      previousAway =
        moment.away;
    }

    const factors = [];
    const details = [];
    const basketball = Boolean(history.dramaBucket);
    const basketballLatePhase = history.latePhase;
    const basketballDramaBucket = history.dramaBucket;

    if (leadChanges) {
      if (basketball) {
        history.leadChanges({sport,state,flipPositions,currentProgress,basketballDramaBucket,basketballLatePhase,factors,details});
      } else {
        const points =
          state === 'live'
            ? Math.min(
                7,
                flipPositions.reduce(
                  (sum,position) =>
                    sum +
                    (
                      position >=
                      currentProgress -
                      .1
                        ? 3
                        : position >=
                          currentProgress -
                          .25
                          ? 2
                          : 1
                    ),
                  0
                )
              )
            : Math.min(
                9,
                leadChanges * 3
              );

        factors.push({
          label:
            `${leadChanges} lead change${leadChanges === 1 ? '' : 's'}`,
          points
        });

        details.push(
          `the lead changed ${leadChanges} time${leadChanges === 1 ? '' : 's'}`
        );
      }
    }

    if (comeback) {
      factors.push({
        label:'Erased a large deficit',
        points:
          Math.min(
            8,
            4 +
            Math.floor(
              comeback.deficit /
              threshold
            ) *
            2
          )
      });

      details.push(
        `${nameFor(comeback.side)} erased a deficit of ${comeback.deficit} ${units}`
      );
    }

    if (
      !basketball &&
      lastFlip >= .65 &&
      currentProgress -
      lastFlip <= .16
    ) {
      factors.push({
        label:'Recent late lead change',
        points:5
      });

      details.push(
        'the lead flipped late'
      );
    }

    history.lateTies?.({basketball,tiePositions,basketballDramaBucket,basketballLatePhase,factors,details});

    const latestPosition =
      moments.at(-1)?.position ??
      null;

    if (
      state === 'live' &&
      runCount >= 2 &&
      runPoints >= threshold &&
      latestPosition !== null &&
      currentProgress -
      latestPosition <= .1
    ) {
      factors.push({
        label:'Recent unanswered scoring run',
        points:4
      });

      details.push(
        `${nameFor(runSide)} scored ${runPoints} unanswered ${units} recently`
      );
    }

    if (
      moments.length >= 3 &&
      currentProgress >= .4
    ) {
      let competitiveTime = 0;
      let priorPosition = 0;
      let priorMargin = 0;

      for (const moment of moments) {
        const position =
          Math.min(
            currentProgress,
            Math.max(
              priorPosition,
              moment.position ??
              priorPosition
            )
          );

        if (
          Math.abs(priorMargin) <=
          threshold
        ) {
          competitiveTime +=
            position -
            priorPosition;
        }

        priorPosition =
          position;

        priorMargin =
          moment.home -
          moment.away;
      }

      if (
        Math.abs(priorMargin) <=
        threshold
      ) {
        competitiveTime +=
          Math.max(
            0,
            currentProgress -
            priorPosition
          );
      }

      const competitiveShare =
        currentProgress
          ? competitiveTime /
            currentProgress
          : 0;

      if (
        competitiveShare >= .55
      ) {
        const points =
          state === 'completed'
            ? (
                competitiveShare >= .75
                  ? 7
                  : 5
              )
            : 3;

        factors.push({
          label:'Sustained competitive game',
          points
        });

        details.push(
          `the score stayed within ${threshold} ${units} for about ${Math.round(competitiveShare * 100)}% of the game`
        );
      }
    }

    const winChances =
      winProbabilitySeries(
        summary
      );

    let controlSwings = 0;
    let controlSide = 0;

    for (const chance of winChances) {
      const side =
        chance >= .65
          ? 1
          : chance <= .35
            ? -1
            : 0;

      if (
        side &&
        controlSide &&
        side !== controlSide
      ) {
        controlSwings++;
      }

      if (side) {
        controlSide = side;
      }
    }

    if (
      controlSwings >= 2 &&
      leadChanges < 2
    ) {
      factors.push({
        label:'Repeated swings in control',
        points:
          Math.min(
            7,
            3 +
            controlSwings
          ),
        bucket:
          basketball
            ? basketballDramaBucket
            : undefined
      });

      details.push(
        `win probability swung decisively between both teams ${controlSwings} times`
      );
    }

    let strongestSwing = {
      size:0,
      end:-1,
      direction:0
    };

    for (
      let end = 1;
      end < winChances.length;
      end++
    ) {
      for (
        let start =
          Math.max(
            0,
            end - 10
          );
        start < end;
        start++
      ) {
        const change =
          winChances[end] -
          winChances[start];

        if (
          Math.abs(change) >
          strongestSwing.size
        ) {
          strongestSwing = {
            size:
              Math.abs(change),
            end,
            direction:
              Math.sign(change)
          };
        }
      }
    }

    if (
      strongestSwing.size >= .2
    ) {
      const points =
        Math.min(
          state === 'completed'
            ? 9
            : 7,
          Math.round(
            strongestSwing.size *
            15
          ) +
          (
            state === 'live' &&
            strongestSwing.end >=
            winChances.length -
            10
              ? 1
              : 0
          )
        );

      factors.push({
        label:'Big win-chance swing',
        points,
        bucket:
          basketball
            ? basketballDramaBucket
            : undefined
      });

      details.push(
        `${possessive(nameFor(strongestSwing.direction > 0 ? 'home' : 'away'))} estimated win chance swung by ${Math.round(strongestSwing.size * 100)} percentage points`
      );
    }

    if (
      state === 'completed' &&
      winChances.length >= 8
    ) {
      const uncertainties =
        winChances.map(
          probability =>
            1 -
            2 *
            Math.abs(
              probability -
              .5
            )
        );

      const averageUncertainty =
        uncertainties.reduce(
          (sum,value) =>
            sum + value,
          0
        ) /
        uncertainties.length;

      const lateSlice =
        uncertainties.slice(
          Math.max(
            0,
            Math.floor(
              uncertainties.length *
              .75
            )
          )
        );

      const lateUncertainty =
        lateSlice.length
          ? lateSlice.reduce(
              (sum,value) =>
                sum + value,
              0
            ) /
            lateSlice.length
          : 0;

      if (
        averageUncertainty >= .58
      ) {
        factors.push({
          label:'Competitive throughout',
          points:6
        });

        details.push(
          'win probability stayed balanced for much of the game'
        );
      } else if (
        averageUncertainty >= .45
      ) {
        factors.push({
          label:'Competitive for much of game',
          points:4
        });
      }

      if (
        lateUncertainty >= .65
      ) {
        factors.push({
          label:'High late uncertainty',
          points:5,
          bucket:
            basketball
              ? basketballDramaBucket
              : undefined
        });

        details.push(
          'the outcome remained highly uncertain late'
        );
      }
    }

    if (
      state === 'completed' &&
      moments.length
    ) {
      const decisive =
        moments.at(-1);

      const prior =
        moments.length > 1
          ? moments.at(-2)
          : {
              home:0,
              away:0
            };

      const finalMargin =
        decisive.home -
        decisive.away;

      const priorMargin =
        prior.home -
        prior.away;

      const finalLeader =
        Math.sign(finalMargin);

      const changedOutcome =
        finalLeader &&
        (
          priorMargin === 0 ||
          Math.sign(priorMargin) !==
            finalLeader
        );

      if (
        decisive.position >= .94 &&
        changedOutcome &&
        Math.abs(finalMargin) <= threshold
      ) {
        factors.push({
          label:'Decisive final score',
          points:8,
          bucket:
            basketball
              ? basketballDramaBucket
              : undefined
        });

        details.push(
          decisive.text
            ? `the decisive score came at the end: ${decisive.text}`
            : 'the decisive score came in the final moments'
        );
      }
    }

    const cap =
      state === 'completed'
        ? 25
        : 15;

    let remaining =
      cap;

    const bucketRemaining =
      new Map();

    if (basketball) {
      bucketRemaining.set(
        basketballDramaBucket,
        history.dramaCap
      );
    }

    const cappedFactors =
      factors
        .map(factor => {
          const bucketLimit =
            factor.bucket &&
            bucketRemaining.has(
              factor.bucket
            )
              ? bucketRemaining.get(
                  factor.bucket
                )
              : remaining;

          const points =
            Math.min(
              Math.max(
                0,
                factor.points
              ),
              remaining,
              bucketLimit
            );

          remaining -=
            points;

          if (
            factor.bucket &&
            bucketRemaining.has(
              factor.bucket
            )
          ) {
            bucketRemaining.set(
              factor.bucket,
              bucketLimit -
              points
            );
          }

          const {
            bucket,
            ...visibleFactor
          } = factor;

          return {
            ...visibleFactor,
            points
          };
        })
        .filter(
          factor =>
            factor.points > 0
        );

    const stagnation =
      history.stagnation?.(
        sport,
        summary,
        currentProgress,
        state
      ) || {points:0,text:''};

    if (
      stagnation.points
    ) {
      cappedFactors.push({
        label:
          'Offensive stagnation',
        points:
          -stagnation.points
      });

      details.push(
        stagnation.text
      );
    }

    return {
      points:
        cap -
        remaining -
        stagnation.points,

      text:
        details
          .join('; ')
          .replace(
            /^[a-z]/,
            character =>
              character.toUpperCase()
          ),

      factors:
        cappedFactors
    };
  }

  const api = {historyImpact};
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api;
  } else {
    (root.SportsRadarScoring ||= {}).shared_history = api;
  }
})(globalThis);

/* Shared scoring module; supports classic browser scripts and Worker/Node bundling. */
(function (root) {
  const {gameProgress,eventPosition} = typeof module !== 'undefined' && module.exports
    ? require('./time.js')
    : root.SportsRadarScoring.shared_time;

  function eventShockFor(sport,summary,status,model={}) {
    const plays = summary?.plays?.length ? summary.plays : summary?.scoringPlays || [];
    const duration = model.duration || 60;
    const currentProgress = gameProgress(sport,{status});
    const positioned = plays.map((play,index) => {
      const period = Number(play.period?.number || play.period || 0);
      const position = period ? eventPosition(sport,{status:{period,displayClock:play.clock?.displayValue || '',clock:play.clock?.value,type:{detail:play.period?.displayValue || ''}}}) : null;
      return {play,index,position};
    }).filter(item => item.position !== null && item.position <= eventPosition(sport,{status}) + .01).sort((a,b) => a.position-b.position || a.index-b.index);
    let points = 0;
    const reasons = [];
    for (let i=0;i<positioned.length;i++) {
      const {play,position} = positioned[i];
      const text = String(play.text || play.shortText || play.type?.text || '').toLowerCase();
      let value = 0;
      let label = '';
      let shock;
      if (/blocked.{0,30}(?:punt|kick|field goal)|(?:punt|kick|field goal).{0,30}blocked/.test(text) && /touchdown|\btd\b/.test(text)) { value=12; label='Blocked kick or punt returned for a touchdown'; }
      else if (/pick[- ]six|intercept(?:ion|ed).{0,80}(?:touchdown|\btd\b)|fumble.{0,40}(?:returned|touchdown)|defensive touchdown/.test(text)) { value=10; label='Defensive touchdown'; }
      else if (/\bsafety\b/.test(text)) { value=6; label='Safety'; }
      else if (/grand slam/.test(text)) { value=8; label='Grand slam'; }
      else if (model.earlyEventShock && (shock = model.earlyEventShock({text,positioned,i,play}))) { ({value,label} = shock); }
      else if (/\bturnover\b|intercepted|fumble recovered by|picked off|caught stealing/.test(text)) { value=4; label='Turnover'; }
      else if (model.eventShock && (shock = model.eventShock({text,positioned,i,play}))) { ({value,label} = shock); }
      if (!value) continue;
      const playsSince = positioned.length - 1 - i;
      const periodGap = Math.abs(Number(status?.period || 0)-Number(play.period?.number || play.period || 0));
      const currentEventPosition = eventPosition(sport,{status});
      const ageMinutes = model.inningEventAge ? periodGap * 20 : Math.max(0,currentEventPosition-position) * duration;
      const decay = Math.min(Math.max(0,1-playsSince/7),Math.max(0,1-ageMinutes/3));
      if (decay <= 0) continue;
      points += value * decay;
      reasons.push(label);
    }
    return {points:Math.min(12,Math.round(points)),reasons:[...new Set(reasons)]};
  }

  const api = {eventShockFor};
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api;
  } else {
    (root.SportsRadarScoring ||= {}).shared_events = api;
  }
})(globalThis);

/* Shared scoring module; supports classic browser scripts and Worker/Node bundling. */
(function (root) {
  function pressureImpact(summary,progress,scoreGap,competition,policy) {
    if (policy?.impact) return policy.impact(summary,progress,scoreGap,competition);
    if (!policy || !summary || scoreGap > policy.maxGap) {
      return {points:0,reasons:[]};
    }

    const recent = (summary.plays || [])
      .slice(-18)
      .filter(play => !play?.scoringPlay)
      .map(play => ({
        text:String(play?.text || play?.shortText || play?.type?.text || '').toLowerCase(),
        teamId:String(play?.team?.id || play?.teamId || play?.team?.team?.id || '')
      }))
      .filter(play => play.text);

    const dangerous = recent.filter(play =>
      /shot on goal|saved by|\bsave\b|breakaway|penalty shot|hit (?:the )?(?:post|crossbar)|off (?:the )?(?:post|crossbar)|big chance|close range|point-blank/.test(play.text)
    );

    const premium = recent.filter(play =>
      /breakaway|penalty shot|hit (?:the )?(?:post|crossbar)|off (?:the )?(?:post|crossbar)|big chance|point-blank/.test(play.text)
    );

    let points = 0;
    const reasons = [];

    if (premium.length) {
      points += Math.min(4,2 + premium.length);
      reasons.push(`${premium.length} premium scoring chance${premium.length === 1 ? '' : 's'} recently`);
    }

    if (dangerous.length >= 4) {
      points += dangerous.length >= 7 ? 3 : 2;
      reasons.push(`${dangerous.length} dangerous attempts or saves in the recent action`);
    }

    if (points && progress >= .78) points++;

    if (policy.weight) points = policy.weight(points,scoreGap,dangerous,competition);

    return {
      points:Math.min(7,points),
      reasons
    };
  }

  const api = {pressureImpact};
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api;
  } else {
    (root.SportsRadarScoring ||= {}).shared_pressure = api;
  }
})(globalThis);

/* Shared browser/Worker scoring orchestrator. Sport rules live in scoring/. */
(function (root) {
  const {SPORT_MODELS} = typeof module !== 'undefined' && module.exports
    ? require('./scoring/models.js')
    : root.SportsRadarScoring.models;
  const {eventSignalText,isPostseasonGame,championshipSeriesFactors,playoffSeriesLeverage,specificStakesFactors,pregameContextFactors,completedStakesImpact,contextWeightFor} = typeof module !== 'undefined' && module.exports
    ? require('./scoring/shared/context.js')
    : root.SportsRadarScoring.shared_context;
  const {SPORT_FLOOR,SCHEDULE_SCARCITY,CLOSE_MARGIN,SPORT_BASE,NFL_DIVISIONS,NHL_DIVISIONS,NBA_DIVISIONS,MLB_DIVISIONS,CONTEXT_WEIGHTS} = typeof module !== 'undefined' && module.exports
    ? require('./scoring/shared/config.js')
    : root.SportsRadarScoring.shared_config;
  const {normalizeWinProbability,winProbabilityImpact,winProbabilitySeries} = typeof module !== 'undefined' && module.exports
    ? require('./scoring/shared/probability.js')
    : root.SportsRadarScoring.shared_probability;
  const {gameProgress,livePhase,normalizedTime,eventPosition,ordinal,clockSeconds} = typeof module !== 'undefined' && module.exports
    ? require('./scoring/shared/time.js')
    : root.SportsRadarScoring.shared_time;
  const {underdogCandidate,parseLine,lineFromSummary,listedSpread,moneylinePrices,pregameMarketFactor} = typeof module !== 'undefined' && module.exports
    ? require('./scoring/shared/market.js')
    : root.SportsRadarScoring.shared_market;
  const {upsetImpact:sharedUpsetImpact} = typeof module !== 'undefined' && module.exports
    ? require('./scoring/shared/upset.js')
    : root.SportsRadarScoring.shared_upset;
  const {historyImpact} = typeof module !== 'undefined' && module.exports
    ? require('./scoring/shared/history.js')
    : root.SportsRadarScoring.shared_history;
  const {eventShockFor} = typeof module !== 'undefined' && module.exports
    ? require('./scoring/shared/events.js')
    : root.SportsRadarScoring.shared_events;
  const {pressureImpact} = typeof module !== 'undefined' && module.exports
    ? require('./scoring/shared/pressure.js')
    : root.SportsRadarScoring.shared_pressure;
  const {recordFor,rankFor,recordStats,divisionFor,winningRecord,proRecordFactors} = typeof module !== 'undefined' && module.exports
    ? require('./scoring/shared/records.js')
    : root.SportsRadarScoring.shared_records;
  const {nflDivisionFor,unbeatenStartImpact} = typeof module !== 'undefined' && module.exports
    ? require('./scoring/sports/nfl.js')
    : root.SportsRadarScoring.sports_nfl;
  const {footballStagnationImpact,defensiveFinishFactor,footballMarginCloseness,footballLiveCloseness:sharedFootballLiveCloseness,footballRunwayPenalty,footballFieldPosition,footballSituationImpact,footballMilestone} = typeof module !== 'undefined' && module.exports
    ? require('./scoring/shared/football.js')
    : root.SportsRadarScoring.shared_football;
  const {nhlLiveMarginCloseness,hockeyOnIceState,hockeyPowerPlay,hockeySituationImpact,hockeyGoalMilestone} = typeof module !== 'undefined' && module.exports
    ? require('./scoring/sports/nhl.js')
    : root.SportsRadarScoring.sports_nhl;
  const {mlbLiveMarginCloseness,runnerOn,baseballSituationImpact,noHitBid,baseballPerformanceMilestone} = typeof module !== 'undefined' && module.exports
    ? require('./scoring/sports/mlb.js')
    : root.SportsRadarScoring.sports_mlb;
  const {basketballSituationImpact,basketballScoringMilestone} = typeof module !== 'undefined' && module.exports
    ? require('./scoring/shared/basketball.js')
    : root.SportsRadarScoring.shared_basketball;
  const {tennisSituationImpact} = typeof module !== 'undefined' && module.exports
    ? require('./scoring/sports/tennis.js')
    : root.SportsRadarScoring.sports_tennis;
  const {soccerSituationImpact,soccerScoringMilestone} = typeof module !== 'undefined' && module.exports
    ? require('./scoring/sports/soccer.js')
    : root.SportsRadarScoring.sports_soccer;

  // Retain opening context across the existing browser and Worker adapters.
  // Weak keys release it when each scoreboard snapshot is discarded.
  const liveRatingContexts = new WeakMap();

  // Keep the public API and generic helpers stable while allowing independent
  // sport calibration. Models without these hooks retain the original path.
  function footballLiveCloseness(sport,gap,progress,context=null) {
    return (SPORT_MODELS[sport]?.liveCloseness || sharedFootballLiveCloseness)(sport,gap,progress,context);
  }

  function upsetImpact(candidate,teams,gameState,progress,sport='',competition=null) {
    return SPORT_MODELS[sport]?.upset?.(candidate,teams,gameState,progress,sport,competition) ??
      sharedUpsetImpact(candidate,teams,gameState,progress,sport,competition);
  }

  const clampScore = value =>
    Math.max(1,Math.min(99,Math.round(value)));

  function factorText(factors,score) {
    const parts = factors.map(
      factor =>
        `${factor.label} ${factor.points > 0 ? '+' : ''}${factor.points}`
    );

    if (
      factors.reduce((sum,item) => sum + item.points,0) > 99 &&
      score === 99
    ) {
      parts.push('capped at 99');
    }

    return parts.join(' · ');
  }

  function pregameRating(sport,event,competition,context) {
    const model = SPORT_MODELS[sport] || {};
    const detail =
      eventSignalText(
        event,
        competition,
        context
      );

    const factors = [{
      label:'Sport baseline',
      points:SPORT_FLOOR
    }];

    const scheduleScarcity = SCHEDULE_SCARCITY[sport] || 0;
    if (scheduleScarcity) {
      factors.push({
        label:'Schedule scarcity',
        points:scheduleScarcity
      });
    }

    const mlbPostseasonScarcity = model.postseasonScarcity || 0;
    const postseason = isPostseasonGame(sport,event,competition,detail);
    const championshipSeries = championshipSeriesFactors(sport,competition,detail);

    const majorTournament = model.majorTournament?.(detail);
    let reason =
      'Regular-season matchup · no extra stakes listed';

    if (championshipSeries) {
      factors.push(...championshipSeries);
      reason = 'Championship series';
    } else if (
      /world series/.test(detail)
    ) {
      factors.push({
        label:'World Series',
        points:42
      });

      if (mlbPostseasonScarcity) {
        factors.push({
          label:'Postseason scarcity',
          points:mlbPostseasonScarcity
        });
      }

      reason =
        'World Series championship';
    } else if (
      /super bowl|stanley cup final|champions league final|national championship|grand slam final/
        .test(detail)
    ) {
      factors.push({
        label:'Championship',
        points:40
      });

      reason =
        'Championship game';
    } else if (
      /conference final|league final|finals|championship|title game/
        .test(detail)
    ) {
      factors.push({
        label:'Final round',
        points:30
      });

      reason =
        'Final-round stakes';
    } else if (
      /playoff|postseason|wild card|divisional round|quarterfinal|semifinal|knockout/
        .test(detail) ||
      Number(
        event?.season?.type?.id ??
        event?.season?.type
      ) === 3
    ) {
      factors.push({
        label:'Postseason',
        points:22
      });

      if (mlbPostseasonScarcity) {
        factors.push({
          label:'Postseason scarcity',
          points:mlbPostseasonScarcity
        });
      }

      reason =
        'Postseason game';
    } else if (majorTournament) {
      factors.push(majorTournament.factor);
      reason = majorTournament.reason;
    }

    if (!championshipSeries) {
      const seriesLeverage = playoffSeriesLeverage(sport,competition,detail);
      if (seriesLeverage) factors.push(seriesLeverage);
    }

    if (
      !championshipSeries &&
      factors.length > 1 &&
      /game\s*1\b|game one\b|g1\b/
        .test(detail)
    ) {
      factors.push({
        label:'Series opener',
        points:5
      });

      reason +=
        ' · Game 1';
    }

    const seriesLeverage = playoffSeriesLeverage(sport,competition,detail);
    const specificStakes = championshipSeries ? [] :
      specificStakesFactors(
        sport,
        detail
      ).filter(item => !seriesLeverage || !['Deciding game','Elimination stakes','Clinching opportunity'].includes(item.label));

    if (specificStakes.length) {
      factors.push(
        ...specificStakes
      );

      reason +=
        ` · ${specificStakes
          .map(item => item.label)
          .join(', ')}`;
    }

    const competitors =
      competition?.competitors || [];

    reason = model.pregame
      ? model.pregame(sport,competition,competitors,postseason,factors,reason,detail)
      : reason;

    if (
      /rivalry|rival\b|derby/
        .test(detail) &&
      !factors.some(
        item =>
          item.label.endsWith('matchup')
      )
    ) {
      factors.push({
        label:'Rivalry',
        points:7
      });

      reason +=
        ' · rivalry';
    }

    const contextFactors =
      pregameContextFactors(
        event,
        competition
      );

    if (contextFactors.length) {
      factors.push(
        ...contextFactors
      );

      reason +=
        ' · verified matchup context';
    }

    const rawPregameScore = factors.reduce((sum,item) => sum + item.points,0);
    return {
      score:Math.min(90,clampScore(rawPregameScore)),
      rawPregameScore,
      factors,
      reason,
      contextFactors
    };
  }

  function stateRating(
    openingScore,
    sport,
    gameState,
    gap,
    progress,
    homeWinProbability=null,
    footballContext=null,
    openingFactors=[]
  ) {
    // Every caller, including restored snapshots, uses the capped opening basis.
    openingScore = Math.min(90,openingScore);
    const closeLimit =
      CLOSE_MARGIN[sport] || 10;

    const modelState = SPORT_MODELS[sport]?.gameState?.({
      sport,gameState,gap,progress,context:footballContext,closeLimit
    }) || {};
    const {footballState=null,basketballState=null} = modelState;
    const completedCloseLimit = modelState.completedCloseLimit ?? closeLimit;
    const marginClose = gap === null ? 0 : modelState.marginClose ??
      Math.max(0,1-gap/completedCloseLimit);

    const probability =
      normalizeWinProbability(
        homeWinProbability
      );

    const uncertainty =
      probability === null
        ? null
        : 1 -
          2 *
          Math.abs(
            probability -
            .5
          );

    const close =
      uncertainty === null ||
      gameState === 'completed'
        ? marginClose
        : .3 *
          marginClose +
          .7 *
          Math.min(uncertainty,modelState.uncertaintyCeiling ?? 1);

    // Keep postseason stakes separate from records, market, matchup quality,
    // and ordinary narrative. Those transient factors continue to use the
    // established context decay curve; stakes get their own live viability.
    const persistentStakeLabels =
      /world series|championship|final round|finals|title game|semifinal|postseason|playoff|elimination|clinching|deciding game|winner[- ]take[- ]all|aggregate tie|second-leg consequences/i;
    const persistentStakes =
      gameState === 'live'
        ? Math.min(openingScore,openingFactors
            .filter(item => persistentStakeLabels.test(item.label))
            .reduce((sum,item) => sum + Math.max(0,Number(item.points) || 0),0))
        : 0;

    const contextWeight =
      contextCarryWeight(
        progress,
        gameState,
        sport,
        false
      );

    const transientOpeningScore = Math.max(0,openingScore-persistentStakes);
    const comebackViability = modelState.comebackViability ?? Math.max(
      Math.sqrt(Math.max(0,Math.min(1,marginClose))),
      modelState.minimumComebackViability || 0
    );
    const retainedStakeWeight = .68 * Math.max(0,Math.min(1,comebackViability));
    const retainedContextWeight = contextWeight * (modelState.contextViability ?? 1);
    const contextPoints =
      Math.round(
        transientOpeningScore *
        retainedContextWeight
      );
    const retainedStakePoints = Math.round(persistentStakes * retainedStakeWeight);

    const stateBase = modelState.stateBase ?? (gameState === 'completed' ? 18 : 12);
    const closeCeiling = modelState.closeCeiling ?? (gameState === 'completed'
      ? 24 : 14 + 16 * Math.max(0,Math.min(1,progress)));

    const closePoints =
      Math.round(
        closeCeiling *
        close
      );

    const phasePoints =
      gameState === 'completed'
        ? 0
        : Math.round(
            (
              2 +
              5 *
              progress
            ) *
            close
          );

    const widePenalty = modelState.widePenalty ?? (
      gap !== null && gap >= closeLimit && progress > .3
        ? Math.min(28,Math.round((gap / closeLimit) * 13 * progress))
        : 0
    );

    const factors = [{
      label:'Game-state baseline',
      points:stateBase
    }];

    if (contextPoints) {
      factors.push({
        label:'Pregame context carried into play',
        points:contextPoints
      });
    }

    if (retainedStakePoints) {
      factors.push({label:'Persistent postseason stakes',points:retainedStakePoints});
    }

    if (closePoints) {
      factors.push({
        label:
          gameState === 'completed'
            ? 'Final margin'
            : uncertainty === null
              ? 'Score closeness and leverage'
              : 'Outcome uncertainty and score closeness',
        points:closePoints
      });
    }

    if (phasePoints) {
      factors.push({
        label:'Late-game leverage',
        points:phasePoints
      });
    }

    if (widePenalty) {
      factors.push({
        label:
          modelState.limitedRunway
            ? 'Limited comeback runway'
            : 'Wide margin',
        points:-widePenalty
      });
    }

    return {
      score:
        clampScore(
          factors.reduce(
            (sum,item) =>
              sum + item.points,
            0
          )
        ),

      factors,
      closePoints,
      widePenalty,
      contextWeight,
      retainedContextWeight,
      persistentStakes,
      retainedStakeWeight,
      comebackViability,
      uncertainty,
      footballState,
      basketballState
    };
  }

  function rateGame(
    sport,
    gameState,
    teams,
    event,
    competition,
    context
  ) {
    competition = SPORT_MODELS[sport]?.prepareCompetition?.(competition,event) ?? competition;
    const opening =
      pregameRating(
        sport,
        event,
        competition,
        context
      );

    const factors =
      opening.factors.map(
        item => ({
          ...item
        })
      );

    if (
      gameState === 'upcoming'
    ) {
      return {
        ...opening,
        openingScore:
          opening.score,
        underdog:null,
        upsetText:'',
        upsetPoints:0
      };
    }

    const values =
      teams
        .map(team =>
          Number(team.score)
        )
        .filter(
          Number.isFinite
        );

    const gap =
      values.length === 2
        ? Math.abs(
            values[0] -
            values[1]
          )
        : null;

    const progress =
      gameState === 'completed'
        ? 1
        : gameProgress(
            sport,
            competition
          );

    const championship = (Boolean(SPORT_MODELS[sport]?.championshipContext) && opening.factors.some(item =>
      /world series|championship|final round|finals|title game/i.test(item.label)
    )) || Boolean(gameState === 'live' && SPORT_MODELS[sport]?.decisiveStakes?.(eventSignalText(event,competition,context)));

    const stateValue =
      stateRating(
        opening.score,
        sport,
        gameState,
        gap,
        progress,
        null,
        {
          competition,
          teams,
          championship
        },
        opening.factors
      );

    factors.length = 0;

    factors.push(
      ...stateValue.factors
    );

    const detail =
      `${competition?.status?.type?.detail || ''} ${competition?.status?.type?.shortDetail || ''}`;

    const completedStakes =
      gameState === 'completed'
        ? completedStakesImpact(
            sport,
            event,
            competition,
            context
          )
        : {
            points:0,
            factors:[]
          };

    if (completedStakes.points) {
      factors.push(
        ...completedStakes.factors
      );
    }

    if (
      gameState === 'completed' &&
      !SPORT_MODELS[sport]?.ownsCompletedOvertime && /overtime|\b\d*ot\b/i
        .test(detail)
    ) {
      factors.push({
        label:'Overtime',
        points:13
      });
    }

    const underdog =
      underdogCandidate(
        sport,
        competition,
        competition?.odds?.[0]
      );

    const upset =
      upsetImpact(
        underdog,
        teams,
        gameState,
        progress,
        sport,
        competition
      );

    if (upset.points) {
      factors.push({
        label:
          gameState === 'completed'
            ? 'Underdog won outright'
            : 'Underdog threatens upset',
        points:upset.points
      });
    }

    const completedResult = SPORT_MODELS[sport]?.completedResult?.(sport,gameState,teams,event,competition,context);
    if (completedResult?.points) {
      factors.push(completedResult);
    }

    const score =
      clampScore(
        factors.reduce(
          (sum,item) =>
            sum + item.points,
          0
        )
      );

    let reason =
      opening.reason;

    const unit = SPORT_MODELS[sport]?.unit || 'point';

    if (
      gameState === 'live'
    ) {
      reason =
        gap === 0
          ? `Tied ${teams[0].score}–${teams[1].score}${progress > .65 ? ' late' : ''}`
          : gap !== null &&
            stateValue.closePoints > 0
            ? `${gap}-${unit} game${progress > .65 ? ' late' : ''}`
            : `Game in progress · ${Math.round(progress * 100)}% elapsed`;
    }

    if (
      gameState === 'completed'
    ) {
      reason =
        /overtime|\b\d*ot\b/i
          .test(detail)
          ? `Overtime finish · ${gap}-${unit} margin`
          : gap !== null
            ? `Decided by ${gap} ${unit}${gap === 1 ? '' : 's'}`
            : 'Final result';
    }

    if (
      gameState === 'live' &&
      competition?.status
    ) {
      liveRatingContexts.set(competition.status,{
        openingScore:opening.score,
        openingFactors:opening.factors,
        championshipStakes:championship,
        underdog,
        competition
      });
    }

    return {
      score,
      factors,
      reason,
      openingScore:
        opening.score,
      rawPregameScore:opening.rawPregameScore,
      openingFactors:opening.factors,
      ...(championship ? {championshipStakes:true} : {}),
      underdog,
      upsetText:
        upset.text,
      upsetPoints:
        upset.points,
      contextFactors:
        opening.contextFactors || []
    };
  }

  function liveMilestone(sport,summary) {
    return SPORT_MODELS[sport]?.milestone?.(summary,sport) ?? null;
  }

  function liveSnapshot(
    game,
    competition,
    summary
  ) {
    const status =
      competition?.status ||
      game.liveRawStatus;

    const situation =
      competition?.situation ||
      game.liveRawSituation ||
      {};

    const snapshot = {
      phase:
        livePhase(
          game.sport,
          status,
          competition?.format || game.sourceCompetition?.format || game.sourceEvent?.competitions?.[0]?.format || game.format
        ),

      note:'',
      reasons:[],
      bonus:0,
      bases:null,
      winProbability:null,

      components:{
        probability:0,
        situation:0,
        pressure:0,
        milestone:0,
        eventShock:0
      }
    };

    const progress =
      gameProgress(
        game.sport,
        {
          ...competition,
          status
        }
      );

    const scoreGap =
      Math.abs(
        Number(
          game.teams?.[0]?.[2]
        ) -
        Number(
          game.teams?.[1]?.[2]
        )
      );

    const probability =
      summary
        ? winProbabilityImpact(
            summary,
            progress,
            'live',
            game.sport
          )
        : {
            points:0,
            text:'',
            probability:null,
            uncertainty:null
          };

    snapshot.winProbability =
      probability.probability;

    snapshot.components.probability =
      probability.points;

    if (
      probability.text
    ) {
      snapshot.reasons.push(
        probability.text
      );
    }

    const sportImpact = SPORT_MODELS[game.sport]?.situation?.({
      game,competition,summary,status,situation,progress,scoreGap
    }) || {points:0,note:'',reasons:[],bases:null};

    if (
      sportImpact.note
    ) {
      snapshot.note =
        sportImpact.note;
    }

    if (
      sportImpact.bases
    ) {
      snapshot.bases =
        sportImpact.bases;
    }

    snapshot.reasons.push(
      ...(
        sportImpact.reasons ||
        []
      )
    );

    snapshot.components.situation =
      Math.min(
        12,
        Math.max(
          0,
          Number(
            sportImpact.points
          ) ||
          0
        )
      );

    const pressure =
      dangerousChanceImpact(
        game.sport,
        summary,
        progress,
        scoreGap,
        competition
      );

    snapshot.components.pressure =
      pressure.points;

    snapshot.reasons.push(
      ...(pressure.reasons || [])
    );

    const milestone =
      summary
        ? (SPORT_MODELS[game.sport]?.liveMilestone?.(summary,{game,competition,status,progress,scoreGap}) ?? liveMilestone(
            game.sport,
            summary
          ))
        : null;

    if (
      milestone
    ) {
      snapshot.reasons.push(
        milestone.text
      );

      snapshot.components.milestone =
        Math.min(
          14,
          Math.max(
            0,
            milestone.points
          )
        );
    }

    const shock = eventShockImpact(game.sport,summary,status);
    snapshot.components.eventShock = Math.max(0,Math.min(12,shock.points));
    if (snapshot.components.eventShock) snapshot.reasons.push(...shock.reasons);

    const probabilityPositive =
      Math.max(
        0,
        snapshot.components.probability
      );

    const probabilityNegative =
      Math.min(
        0,
        snapshot.components.probability
      );

    // An active tying or winning drive has immediate competitive leverage
    // even when the leader's win probability is high. Keep that estimate
    // untouched. NFL decisive states can raise the competitive floor beyond
    // the ordinary cap; overlapping situation/probability points still use max.
    const driveFloor = sportImpact.decisiveDrive
      ? Math.round(
          sportImpact.decisiveDrive.urgency *
          (18 + Math.min(2,sportImpact.decisiveDrive.positionBonus))
        )
      : 0;
    const decisiveFloor = game.sport === 'NFL' || SPORT_MODELS[game.sport]?.decisiveFloor ? Math.max(0,Number(sportImpact.competitiveFloor) || 0) : 0;
    const competitiveSituation =
      SPORT_MODELS[game.sport]?.decisiveFloor && decisiveFloor > 0 ? decisiveFloor : Math.min(
        Math.max(20,decisiveFloor),
        Math.max(
          driveFloor,
          Number(sportImpact.competitiveFloor) || 0,
          probabilityPositive +
          snapshot.components.situation +
          snapshot.components.pressure
        )
      );

    const positiveBonus =
      Math.min(
        Math.max(30,decisiveFloor),
        competitiveSituation +
        snapshot.components.milestone +
        snapshot.components.eventShock
      );

    const negativeBonus =
      Math.max(
        -8,
        probabilityNegative
      );

    snapshot.bonus =
      decisiveFloor > 0
        ? Math.max(decisiveFloor,positiveBonus + negativeBonus)
        : positiveBonus + negativeBonus;

    return snapshot;
  }

  function refreshLiveState(game,competition,summary) {
    const context =
      liveRatingContexts.get(
        game.liveRawStatus
      ) ||
      liveRatingContexts.get(
        competition?.status
      );

    const previous = {
      ...(
        context?.competition ||
        game.sourceCompetition
      ),

      status:
        game.liveRawStatus ||
        context?.competition?.status,

      situation:
        game.liveRawSituation ||
        context?.competition?.situation
    };

    // The scoreboard is the live authority.  A summary may enrich it, but it
    // must never become the source of score, clock, possession, or situation.
    const candidate = competition || previous;
    const summaryCandidate = summary?.header?.competitions?.[0];
    const validationCandidate = summaryCandidate || candidate;

    const type =
      validationCandidate.status?.type;

    const competitors =
      validationCandidate.competitors ||
      [];

    const matched =
      game.teams.map(team => {
        const id =
          String(
            team[8] ||
            team.id ||
            ''
          );

        if (id) {
          return competitors.find(item =>
            String(
              item.team?.id ||
              item.athlete?.id ||
              item.id ||
              ''
            ) === id
          );
        }

        const names =
          competitors.filter(item =>
            (
              item.team?.displayName ||
              item.athlete?.displayName
            ) === team[0]
          );

        return names.length === 1
          ? names[0]
          : undefined;
      });

    const wrongTeams =
      competitors.length > 0 &&
      matched.some(team =>
        !team
      );

    // A summary at the same nominal clock can still be one scoring play
    // behind. Its win probability then describes a different game state.
    const summaryScoreConflict = Boolean(summaryCandidate && candidate.competitors) &&
      game.teams.some(team => {
        const id = String(team[8] || team.id || '');
        const find = items => items.find(item => id
          ? String(item.team?.id || item.athlete?.id || item.id || '') === id
          : (item.team?.displayName || item.athlete?.displayName) === team[0]);
        const fromSummary = find(summaryCandidate.competitors || []);
        const fromScoreboard = find(candidate.competitors || []);
        return Number.isFinite(Number(fromSummary?.score)) &&
          Number.isFinite(Number(fromScoreboard?.score)) &&
          Number(fromSummary.score) !== Number(fromScoreboard.score);
      });

    const older =
      previous.status?.period &&
      validationCandidate.status?.period &&
      gameProgress(
        game.sport,
        validationCandidate
      ) <
      gameProgress(
        game.sport,
        previous
      );

    const lastAccepted = game.summaryState;
    const summaryRegressed = Boolean(summaryCandidate && lastAccepted?.status) &&
      gameProgress(game.sport,summaryCandidate) < gameProgress(game.sport,lastAccepted);

    const rejected =
      wrongTeams ||
      summaryScoreConflict ||
      older ||
      summaryRegressed ||
      type?.completed === true ||
      (
        type?.state &&
        type.state !== 'in'
      );

    game.lastSummaryAccepted = Boolean(summary) && !rejected;

    if (game.lastSummaryAccepted && summaryCandidate) {
      game.summaryState = {
        status:summaryCandidate.status,
        competitors:(summaryCandidate.competitors || []).map(team => ({
          team:{id:team.team?.id || team.athlete?.id || team.id || ''},
          score:team.score
        }))
      };
    }

    const current =
      rejected
        ? previous
        : {
            ...previous,
            ...candidate,

            status:
              candidate.status ||
              previous.status,

            situation:
              candidate.status
                ? candidate.situation ||
                  {}
                : previous.situation
          };

    if (
      !rejected &&
      matched.length === 2 &&
      matched.every(team =>
        team &&
        team.score != null &&
        team.score !== '' &&
        Number.isFinite(
          Number(team.score)
        )
      )
    ) {
      // Scores always come from the scoreboard candidate, never the summary.
      const scoreboardCompetitors = candidate.competitors || [];
      const scoreboardMatched = candidate === validationCandidate
        ? matched
        : game.teams.map(team => {
            const id = String(team[8] || team.id || '');
            if (id) return scoreboardCompetitors.find(item => String(item.team?.id || item.athlete?.id || item.id || '') === id);
            const names = scoreboardCompetitors.filter(item => (item.team?.displayName || item.athlete?.displayName) === team[0]);
            return names.length === 1 ? names[0] : undefined;
          });
      if (scoreboardMatched.some(team => !team)) return {competition:current,summary:rejected ? null : summary};
      scoreboardMatched.forEach(
        (team,index) => {
          game.teams[index][2] =
            String(team.score);

          if (
            'score' in
            game.teams[index]
          ) {
            game.teams[index].score =
              String(team.score);
          }
        }
      );
    }

    const openingScore = Math.min(90,
      game.openingScore ??
      context?.openingScore);

    const openingFactors = game.openingFactors || context?.openingFactors || [];

    if (game.championshipStakes || context?.championshipStakes) game.championshipStakes = true;
    else delete game.championshipStakes;

    if (
      Number.isFinite(
        openingScore
      )
    ) {
      const gap =
        Math.abs(
          Number(
            game.teams[0][2]
          ) -
          Number(
            game.teams[1][2]
          )
        );

      const progress =
        gameProgress(
          game.sport,
          current
        );

      const state =
        stateRating(
          openingScore,
          game.sport,
          'live',
          Number.isFinite(gap)
            ? gap
            : null,
          progress,
          null,
          {
            competition:current,
            teams:game.teams,
            championship:game.championshipStakes,
            situation:current.situation,
            summary:rejected ? null : summary
          },
          openingFactors
        );

      const underdog =
        game.underdog ||
        context?.underdog;

      const upset =
        upsetImpact(
          underdog,
          game.teams,
          'live',
          progress,
          game.sport,
          current
        );

      const factors = [
        ...state.factors
      ];

      if (
        upset.points
      ) {
        factors.push({
          label:
            'Underdog threatens upset',
          points:
            upset.points
        });
      }

      game.baseScore =
        clampScore(
          factors.reduce(
            (sum,item) =>
              sum +
              item.points,
            0
          )
        );

      game.factors =
        factors;

      game.openingScore =
        openingScore;

      game.openingFactors = openingFactors;

      game.underdog =
        underdog;

      game.upsetPoints =
        upset.points;

      game.upsetText =
        upset.text;

      const unit = SPORT_MODELS[game.sport]?.unit || 'point';

      game.why =
        gap === 0
          ? `Tied ${game.teams[0][2]}–${game.teams[1][2]}${progress > .65 ? ' late' : ''}`
          : state.closePoints > 0
            ? `${gap}-${unit} game${progress > .65 ? ' late' : ''}`
            : `Game in progress · ${Math.round(progress * 100)}% elapsed`;

      if (
        current.status
      ) {
        liveRatingContexts.set(
          current.status,
          {
            openingScore,
            underdog,
            competition:current
          }
        );
      }
    }

    game.liveRawStatus =
      current.status;

    game.liveRawSituation =
      current.situation;

    game.status =
      current.status?.type?.shortDetail ||
      current.status?.type?.detail ||
      game.status;

    return {
      competition:current,
      summary:
        rejected
          ? null
          : summary
    };
  }

  function applyLiveSnapshot(
    game,
    competition,
    summary
  ) {
    if (
      game.state !== 'live'
    ) {
      return;
    }

    const current =
      refreshLiveState(
        game,
        competition,
        summary
      );

    game.live =
      liveSnapshot(
        game,
        current.competition,
        current.summary
      );

    game.score =
      clampScore(
        game.baseScore +
        game.live.bonus
      );
  }

  function momentumImpact(sport,summary,progress,state,completedContext=null) {
    const history = SPORT_MODELS[sport]?.historyImpact
      ? SPORT_MODELS[sport].historyImpact(summary,progress,state)
      : historyImpact(sport,summary,progress,state,SPORT_MODELS[sport]?.history);
    // The optional adapter context supplies the actual base and finishing award.
    // Standalone histories, public arity, and every non-completed path stay intact.
    return state === 'completed' && completedContext
      ? SPORT_MODELS[sport]?.completedHistory?.(summary,history,completedContext) ?? history
      : history;
  }

  function contextCarryWeight(progress,gameState,sport='',championship=false) {
    const anchors = SPORT_MODELS[sport]?.contextAnchors?.(championship) || [
            [0,.38],
            [.25,.30],
            [.5,.20],
            [.75,.12],
            [.9,.08],
            [1,.06]
          ];
    return contextWeightFor(progress,gameState,anchors);
  }

  function eventShockImpact(sport,summary,status) {
    return eventShockFor(sport,summary,status,SPORT_MODELS[sport]);
  }

  function dangerousChanceImpact(sport,summary,progress,scoreGap,competition=null) {
    return pressureImpact(summary,progress,scoreGap,competition,SPORT_MODELS[sport]?.pressure);
  }

  const api = {
    SPORT_FLOOR,
    SCHEDULE_SCARCITY,
    SPORT_BASE,
    NFL_DIVISIONS,
    NHL_DIVISIONS,
    NBA_DIVISIONS,
    MLB_DIVISIONS,
    CONTEXT_WEIGHTS,
    CLOSE_MARGIN,
    clampScore,
    factorText,
    recordFor,
    rankFor,
    recordStats,
    parseLine,
    lineFromSummary,
    eventSignalText,
    nflDivisionFor,
    divisionFor,
    winningRecord,
    listedSpread,
    moneylinePrices,
    pregameMarketFactor,
    proRecordFactors,
    pregameContextFactors,
    specificStakesFactors,
    completedStakesImpact,
    pregameRating,
    gameProgress,
    normalizedTime,
    eventPosition,
    normalizeWinProbability,
    winProbabilitySeries,
    winProbabilityImpact,
    footballStagnationImpact,
    momentumImpact,
    defensiveFinishFactor,
    underdogCandidate,
    upsetImpact,
    unbeatenStartImpact,
    contextCarryWeight,
    nhlLiveMarginCloseness,
    mlbLiveMarginCloseness,
    footballMarginCloseness,
    footballLiveCloseness,
    footballRunwayPenalty,
    stateRating,
    rateGame,
    ordinal,
    livePhase,
    runnerOn,
    clockSeconds,
    footballFieldPosition,
    footballSituationImpact,
    baseballSituationImpact,
    hockeyOnIceState,
    hockeyPowerPlay,
    hockeySituationImpact,
    basketballSituationImpact,
    tennisSituationImpact,
    dangerousChanceImpact,
    eventShockImpact,
    soccerSituationImpact,
    noHitBid,
    hockeyGoalMilestone,
    footballMilestone,
    basketballScoringMilestone,
    baseballPerformanceMilestone,
    soccerScoringMilestone,
    liveMilestone,
    liveSnapshot,
    applyLiveSnapshot
  };

  root.SportsRadarScore = api;

  if (
    typeof module !== 'undefined' &&
    module.exports
  ) {
    module.exports = api;
  }
})(globalThis);
