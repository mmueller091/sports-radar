var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  try {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  } catch (e) {
    throw mod = 0, e;
  }
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// scoring/shared/time.js
var require_time = __commonJS({
  "scoring/shared/time.js"(exports2, module2) {
    (function(root) {
      function normalizedTime(sport, competition) {
        const status = competition?.status || {};
        const period = Number(
          status.period || 0
        );
        const total = {
          NFL: 4,
          CFB: 4,
          NHL: 3,
          NBA: 4,
          NCAAB: 2,
          MLB: 9,
          Soccer: 2,
          Tennis: 3
        }[sport] || 4;
        if (!period) return { progress: 0, elapsedSeconds: null, remainingSeconds: null };
        if (sport === "MLB") {
          const detail = String(
            status.type?.detail || status.type?.shortDetail || ""
          ).toLowerCase();
          const half = /bottom|bot\b/.test(detail) ? 0.75 : /top\b/.test(detail) ? 0.25 : 0.5;
          const elapsed = period - 1 + half;
          return { elapsedSeconds: elapsed * 20 * 60, remainingSeconds: null, progress: Math.max(
            0,
            Math.min(
              1,
              elapsed / 9
            )
          ) };
        }
        if (sport === "Tennis") {
          const bestOf = Number(
            competition?.format?.regulation?.periods || competition?.format?.bestOf || total
          ) || total;
          const elapsed = period - 1 + 0.5;
          return { elapsedSeconds: null, remainingSeconds: null, progress: Math.max(
            0,
            Math.min(
              0.98,
              elapsed / Math.max(
                1,
                bestOf
              )
            )
          ) };
        }
        const length = {
          NFL: 15,
          CFB: 15,
          NHL: 20,
          NBA: 12,
          NCAAB: 20,
          Soccer: 45
        }[sport];
        const display = String(status.displayClock || "").trim();
        const colon = display.match(/^(\d+):(\d+(?:\.\d+)?)$/);
        const decimal = display.match(/^(\d+\.\d+)$/);
        const soccer = display.match(/^(\d+)'?(?:\+(\d+)'?)?$/);
        const numeric = Number(status.clock);
        let elapsedSeconds = null;
        let remainingSeconds = null;
        if (sport === "Soccer") {
          const minute = soccer ? Number(soccer[1]) + Number(soccer[2] || 0) : null;
          elapsedSeconds = soccer?.[2] ? minute * 60 : Number.isFinite(numeric) && status.clock != null ? numeric : minute !== null ? minute * 60 : colon ? Number(colon[1]) * 60 + Number(colon[2]) : null;
        } else {
          remainingSeconds = colon ? Number(colon[1]) * 60 + Number(colon[2]) : decimal ? Number(decimal[1]) : Number.isFinite(numeric) && status.clock != null ? numeric : null;
          if (remainingSeconds !== null) {
            if (status.clockMode === "elapsed") {
              elapsedSeconds = (period - 1) * length * 60 + remainingSeconds;
              remainingSeconds = Math.max(0, length * 60 - remainingSeconds);
            } else {
              elapsedSeconds = (period - 1) * length * 60 + Math.max(0, length * 60 - remainingSeconds);
            }
          }
        }
        const elapsedPeriods = elapsedSeconds === null ? period - 0.5 : elapsedSeconds / (length * 60);
        return { elapsedSeconds, remainingSeconds, progress: Math.max(0, Math.min(1, elapsedPeriods / total)) };
      }
      function gameProgress2(sport, competition) {
        return normalizedTime(sport, competition).progress;
      }
      function eventPosition2(sport, competition) {
        const time2 = normalizedTime(sport, competition);
        const regulationMinutes = { NFL: 60, CFB: 60, NHL: 60, NBA: 48, NCAAB: 40, MLB: 180, Soccer: 90 }[sport];
        return time2.elapsedSeconds !== null && regulationMinutes ? time2.elapsedSeconds / (regulationMinutes * 60) : time2.progress;
      }
      function ordinal(value) {
        const n = Number(value);
        return `${n}${n % 100 >= 11 && n % 100 <= 13 ? "th" : {
          1: "st",
          2: "nd",
          3: "rd"
        }[n % 10] || "th"}`;
      }
      function livePhase(sport, status, format = {}, season = {}) {
        const detail = String(
          status?.type?.detail || status?.type?.shortDetail || ""
        ).trim();
        const period = Number(
          status?.period || 0
        );
        const statusText = [status?.type?.name, status?.type?.detail, status?.type?.shortDetail].join(" ");
        if (sport === "NHL" && (/shootout|\bSO\b/i.test(statusText) || period === 5 && Number(season?.type?.id ?? season?.type) === 2)) return "Shootout";
        if (sport === "MLB") {
          const half = detail.match(
            /\b(top|bottom|bot)\b/i
          )?.[1] || status?.inningHalf;
          return half && period ? `${/^bot/i.test(half) ? "Bottom" : "Top"} ${ordinal(period)}` : detail || (period ? `${ordinal(period)} inning` : "Live");
        }
        if (sport === "Tennis") {
          return detail || (period ? `${ordinal(period)} set` : "Live");
        }
        const regulationPeriods = sport === "NCAAB" ? Number(format?.regulation?.periods) || 2 : { NFL: 4, CFB: 4, NBA: 4, NHL: 3 }[sport];
        const overtime = regulationPeriods && period > regulationPeriods ? period - regulationPeriods : 0;
        const overtimeLabel = overtime === 1 ? "OT" : `${overtime}OT`;
        if (/halftime|intermission|end of/i.test(detail)) {
          return overtime ? detail.replace(/\b\d+(?:st|nd|rd|th)?\s+(?:quarter|half|period)\b/gi, overtimeLabel) : detail;
        }
        const clock = String(status?.displayClock || "").trim();
        if (regulationPeriods && period) {
          const unit = sport === "NHL" ? "period" : sport === "NCAAB" && regulationPeriods === 2 ? "half" : "quarter";
          return `${clock && /^\d+:\d+$/.test(clock) ? `${clock} \xB7 ` : ""}${overtime ? overtimeLabel : `${ordinal(period)} ${unit}`}`;
        }
        return detail || (clock && clock !== "0.0" ? clock : "Live");
      }
      function clockSeconds(status) {
        return normalizedTime("NBA", { status: { ...status, period: status?.period || 1 } }).remainingSeconds;
      }
      function isHalftimeStatus(status) {
        const type = status?.type || {};
        if (type.completed || ["post", "pre"].includes(type.state)) return false;
        const text = [type.name, type.description, type.detail, type.shortDetail, status?.displayPeriod].filter(Boolean).join(" ");
        if (/half[ -]?time/i.test(text)) return true;
        return Number(status?.period) === 2 && /^(?:0+:)?0+(?:\.0+)?$/.test(String(status?.displayClock || ""));
      }
      function isLateGameStatus(sport, status, competition = {}) {
        const period = Number(status?.period), seconds = clockSeconds(status);
        if (["NFL", "CFB"].includes(sport)) return period > 4 || period === 4 && seconds !== null;
        if (sport === "NBA") return period > 4 || period === 4 && seconds !== null && seconds <= 360;
        if (sport === "NCAAB") return period > 2 || period === 2 && seconds !== null && seconds <= 300;
        if (sport === "NHL") return period > 3 || period === 3 && seconds !== null && seconds <= 600;
        if (sport === "MLB") return period >= 7;
        if (sport === "Soccer") return (normalizedTime(sport, { status }).elapsedSeconds || 0) >= 4500;
        return sport === "Tennis" && normalizedTime(sport, { ...competition, status }).progress > 0.65;
      }
      const api = { isHalftimeStatus, isLateGameStatus, normalizedTime, gameProgress: gameProgress2, eventPosition: eventPosition2, ordinal, livePhase, clockSeconds };
      if (typeof module2 !== "undefined" && module2.exports) {
        module2.exports = api;
      } else {
        (root.SportsRadarScoring ||= {}).shared_time = api;
      }
    })(globalThis);
  }
});

// scoring/shared/probability.js
var require_probability = __commonJS({
  "scoring/shared/probability.js"(exports2, module2) {
    (function(root) {
      const { gameProgress: gameProgress2, eventPosition: eventPosition2 } = typeof module2 !== "undefined" && module2.exports ? require_time() : root.SportsRadarScoring.shared_time;
      function normalizeWinProbability(value) {
        if (value === null || value === void 0 || value === "") {
          return null;
        }
        let probability = Number(value);
        if (!Number.isFinite(probability)) {
          return null;
        }
        if (probability > 1 && probability <= 100) {
          probability /= 100;
        }
        return probability >= 0 && probability <= 1 ? probability : null;
      }
      const winProbabilityFor = (item) => normalizeWinProbability(
        item?.homeWinPercentage ?? item?.homeWinProbability ?? item?.homeWinPct ?? item?.value
      );
      function winProbabilitySeries(summary) {
        return (summary?.winprobability || []).map(winProbabilityFor).filter(
          (value) => value !== null
        );
      }
      function winProbabilityObservations(sport, summary) {
        const plays = summary?.plays || [];
        const playsById = new Map(plays.filter((play) => play?.id != null).map((play) => [String(play.id), play]));
        return (summary?.winprobability || []).map((item, index) => {
          const probability = winProbabilityFor(item);
          const play = item?.playId == null ? null : playsById.get(String(item.playId));
          const timed = play || item;
          const period = Number(timed?.period?.number || timed?.period || 0);
          const rawPosition = period ? eventPosition2(sport, { status: {
            period,
            displayClock: timed?.clock?.displayValue || timed?.displayClock || "",
            clock: timed?.clock?.value ?? timed?.clockValue,
            ...sport === "NHL" ? { clockMode: "elapsed" } : {},
            type: { detail: timed?.period?.displayValue || timed?.periodText || "" }
          } }) : Number(item?.position ?? item?.gameProgress);
          const position = Number.isFinite(rawPosition) ? Math.max(0, rawPosition) : null;
          return probability === null ? null : { probability, position, index, playId: item?.playId ?? null };
        }).filter(Boolean);
      }
      function winProbabilityImpact(summary, progress, state = "live", sport = "") {
        const competition = summary?.header?.competitions?.[0];
        const summaryStatus = competition?.status?.type;
        const estimate = (summary?.winprobability || []).filter((item) => winProbabilityFor(item) !== null).at(-1);
        const estimatePlay = estimate?.playId == null ? null : (summary?.plays || []).find(
          (play) => String(play.id) === String(estimate.playId)
        );
        const scoreChanged = estimatePlay && (competition?.competitors || []).some((team) => {
          const value = team.homeAway === "home" ? estimatePlay.homeScore : team.homeAway === "away" ? estimatePlay.awayScore : null;
          return value != null && team.score != null && Number.isFinite(Number(value)) && Number.isFinite(Number(team.score)) && Number(value) !== Number(team.score);
        });
        const estimatePeriod = Number(estimatePlay?.period?.number || 0);
        const estimateProgress = sport && estimatePeriod ? gameProgress2(sport, {
          status: {
            period: estimatePeriod,
            displayClock: estimatePlay.clock?.displayValue,
            type: { detail: estimatePlay.period?.displayValue }
          }
        }) : null;
        if (state !== "live" || summaryStatus?.completed === true || summaryStatus?.state === "post" || summaryStatus?.state === "pre" || scoreChanged || /end (?:of )?game/i.test(
          `${estimatePlay?.type?.text || ""} ${estimatePlay?.text || ""}`
        ) || estimateProgress !== null && Math.abs(Number(progress) - estimateProgress) > 0.05) {
          return {
            points: 0,
            text: "",
            probability: null,
            uncertainty: null
          };
        }
        const series = winProbabilitySeries(summary);
        if (!series.length) {
          return {
            points: 0,
            text: "",
            probability: null,
            uncertainty: null
          };
        }
        const probability = series.at(-1);
        const uncertainty = Math.max(
          0,
          1 - 2 * Math.abs(
            probability - 0.5
          )
        );
        const p = Math.max(
          0,
          Math.min(
            1,
            Number(progress) || 0
          )
        );
        const leverageWeight = 0.35 + 0.65 * Math.pow(
          p,
          1.5
        );
        const bonus = Math.round(
          16 * uncertainty * leverageWeight
        );
        let penalty = 0;
        if (p >= 0.55 && uncertainty < 0.35) {
          penalty = Math.round(
            (0.35 - uncertainty) / 0.35 * 12 * (0.4 + 0.6 * p)
          );
        }
        const points = Math.max(
          -8,
          Math.min(
            16,
            bonus - penalty
          )
        );
        const pct = Math.round(
          probability * 100
        );
        let text = "";
        if (uncertainty >= 0.8) {
          text = `Win probability is nearly even (${pct}% / ${100 - pct}%)`;
        } else if (uncertainty >= 0.55 && p >= 0.65) {
          text = `The outcome is still highly uncertain (${pct}% / ${100 - pct}%)`;
        } else if (points < 0) {
          text = `The feed estimates a one-sided outcome (${pct}% / ${100 - pct}%)`;
        }
        return {
          points,
          text,
          probability,
          uncertainty
        };
      }
      const api = { normalizeWinProbability, winProbabilitySeries, winProbabilityObservations, winProbabilityImpact };
      if (typeof module2 !== "undefined" && module2.exports) {
        module2.exports = api;
      } else {
        (root.SportsRadarScoring ||= {}).shared_probability = api;
      }
    })(globalThis);
  }
});

// scoring/shared/trajectory.js
var require_trajectory = __commonJS({
  "scoring/shared/trajectory.js"(exports2, module2) {
    (function(root) {
      const { gameProgress: gameProgress2, eventPosition: eventPosition2 } = typeof module2 !== "undefined" && module2.exports ? require_time() : root.SportsRadarScoring.shared_time;
      const { winProbabilityObservations } = typeof module2 !== "undefined" && module2.exports ? require_probability() : root.SportsRadarScoring.shared_probability;
      const unit = (value) => Math.max(0, Math.min(1, Number(value) || 0));
      const nonnegative = (value) => Math.max(0, Number(value) || 0);
      const uncertainty = (probability) => unit(1 - 2 * Math.abs(probability - 0.5));
      const emptyTelemetry = () => ({
        competitiveShare: null,
        uncertaintyShare: null,
        dominantShare: null,
        marginContinuity: null,
        genuineContinuity: null,
        genuineContinuitySource: null,
        lateMovementShare: null,
        lastCompetitivePosition: null,
        trajectoryEndPosition: null,
        wpCoverageStart: null,
        wpCoverageEnd: null,
        wpCoverageShare: 0,
        wpObservationCount: 0
      });
      function scoringMoments(sport, summary) {
        const plays = summary?.scoringPlays?.length ? summary.scoringPlays : (summary?.plays || []).filter((play) => play?.scoringPlay === true);
        return plays.map((play, index) => {
          const home = Number(play?.homeScore);
          const away = Number(play?.awayScore);
          const period = Number(play?.period?.number || play?.period || 0);
          const rawPosition = period ? eventPosition2(sport, { status: {
            period,
            displayClock: play?.clock?.displayValue || "",
            clock: play?.clock?.value,
            // Provider NHL play clocks count up, as in chronological replay.
            ...sport === "NHL" ? { clockMode: "elapsed" } : {},
            type: { detail: play?.period?.displayValue || "" }
          } }) : null;
          return Number.isFinite(home) && Number.isFinite(away) && Number.isFinite(rawPosition) ? { home, away, position: nonnegative(rawPosition), play, index } : null;
        }).filter(Boolean).sort((a, b) => a.position - b.position || a.index - b.index);
      }
      function trajectoryAnalysis(sport, summary, progress = null, state = "completed", model = {}) {
        if (state === "upcoming") return emptyTelemetry();
        const competition = summary?.header?.competitions?.[0] || {};
        const observedProgress = progress == null ? gameProgress2(sport, competition) : Number(progress);
        const moments = scoringMoments(sport, summary);
        const observations = winProbabilityObservations(sport, summary).filter((item) => item.position !== null).sort((a, b) => a.position - b.position || a.index - b.index);
        const rawGamePosition = eventPosition2(sport, competition);
        const elapsed = Math.max(
          state === "completed" ? 1 : 0,
          Number.isFinite(observedProgress) ? observedProgress : 0,
          Number.isFinite(rawGamePosition) ? rawGamePosition : 0,
          moments.at(-1)?.position || 0,
          observations.at(-1)?.position || 0
        );
        if (!elapsed) return emptyTelemetry();
        const threshold = Math.max(1, Number(model?.history?.threshold) || 1);
        function closeness(gap, position, moment = null) {
          let value = null;
          if (typeof model?.trajectoryCloseness === "function") {
            value = model.trajectoryCloseness({ sport, gap, progress: position, summary, competition, moment });
          } else if (typeof model?.gameState === "function") {
            const historicalCompetition = { ...competition, status: {}, competitors: [
              { homeAway: "home", score: String(moment?.home ?? 0), team: { id: "home" } },
              { homeAway: "away", score: String(moment?.away ?? 0), team: { id: "away" } }
            ] };
            const result = model.gameState({
              sport,
              gameState: "live",
              gap,
              progress: position,
              context: { competition: historicalCompetition, summary }
            }) || {};
            value = result.marginClose ?? result.footballState?.close ?? result.basketballState?.close;
          }
          return Number.isFinite(Number(value)) ? unit(value) : Math.exp(-Math.pow(Math.max(0, gap) / threshold, 2));
        }
        const scoreStates = [{ home: 0, away: 0, position: 0, play: null }, ...moments].filter((moment) => moment.position <= elapsed + 1e-6);
        function scoreStateAt(position) {
          let current = scoreStates[0];
          for (const moment of scoreStates) {
            if (moment.position > position) break;
            current = moment;
          }
          return current;
        }
        function competitiveAt(position) {
          const moment = scoreStateAt(position);
          return closeness(Math.abs(moment.home - moment.away), position, moment);
        }
        const wp = [];
        for (const item of observations.filter((item2) => item2.position <= elapsed + 1e-6)) {
          if (wp.length && Math.abs(wp.at(-1).position - item.position) < 1e-9) wp[wp.length - 1] = item;
          else wp.push(item);
        }
        const wpCoverageStart = wp.length ? wp[0].position : null;
        const wpCoverageEnd = wp.length ? wp.at(-1).position : null;
        const wpCoverageSpan = wp.length > 1 ? wpCoverageEnd - wpCoverageStart : 0;
        const wpCoverageShare = elapsed ? unit(wpCoverageSpan / elapsed) : 0;
        const hasWpCoverage = wpCoverageSpan > 0;
        function probabilityAt(position) {
          if (!hasWpCoverage || position < wpCoverageStart || position > wpCoverageEnd) return null;
          if (position === wpCoverageStart) return wp[0].probability;
          if (position === wpCoverageEnd) return wp.at(-1).probability;
          for (let i = 1; i < wp.length; i++) {
            if (wp[i].position < position) continue;
            const left = wp[i - 1], right = wp[i];
            const span = right.position - left.position;
            const weight = span ? (position - left.position) / span : 1;
            return left.probability + (right.probability - left.probability) * weight;
          }
          return wp.at(-1).probability;
        }
        const bins = 240;
        const competitive = [];
        const uncertainties = [];
        for (let i = 0; i < bins; i++) {
          const position = elapsed * (i + 0.5) / bins;
          competitive.push(competitiveAt(position));
          const probability = probabilityAt(position);
          uncertainties.push(probability === null ? null : uncertainty(probability));
        }
        const mean = (values) => values.length ? values.reduce((sum, value) => sum + value, 0) / values.length : null;
        const supportedUncertainties = uncertainties.filter((value) => value !== null);
        const competitiveShare = mean(competitive);
        const uncertaintyShare = mean(supportedUncertainties);
        const dominantShare = mean(hasWpCoverage ? supportedUncertainties.map((value) => Math.pow(1 - value, 2)) : competitive.map((value) => Math.pow(1 - value, 2)));
        const radius = Math.max(1, Math.round(bins * 0.1));
        function continuityFor(values) {
          const contributions = [];
          for (let index = 0; index < values.length; index++) {
            const value = values[index];
            if (value === null) continue;
            const local = values.slice(Math.max(0, index - radius), Math.min(bins, index + radius + 1)).filter((item) => item !== null);
            if (local.length) contributions.push(Math.sqrt(value * mean(local)));
          }
          return mean(contributions);
        }
        const marginContinuity = continuityFor(competitive);
        const genuineTension = competitive.map((close, index) => uncertainties[index] === null ? null : Math.sqrt(close * uncertainties[index]));
        const genuineContinuity = hasWpCoverage ? continuityFor(genuineTension) : marginContinuity;
        const genuineContinuitySource = hasWpCoverage ? "positioned-win-probability" : "margin-fallback";
        const drama = [];
        for (let i = 1; i < scoreStates.length; i++) {
          const before = scoreStates[i - 1], after = scoreStates[i];
          const beforeClose = closeness(Math.abs(before.home - before.away), after.position, after);
          const afterClose = closeness(Math.abs(after.home - after.away), after.position, after);
          const weight = Math.abs(afterClose - beforeClose);
          if (weight) drama.push({ position: after.position, weight });
        }
        for (let i = 1; i < wp.length; i++) {
          const weight = Math.abs(wp[i].probability - wp[i - 1].probability);
          if (weight) drama.push({ position: wp[i].position, weight });
        }
        const totalDrama = drama.reduce((sum, item) => sum + item.weight, 0);
        const lateMovementShare = totalDrama ? drama.filter((item) => item.position >= elapsed * 0.8).reduce((sum, item) => sum + item.weight, 0) / totalDrama : null;
        function genuinelyCompetitive(position) {
          const close = competitiveAt(position);
          const probability = probabilityAt(position);
          return probability === null ? hasWpCoverage ? null : close : Math.sqrt(close * uncertainty(probability));
        }
        let lastCompetitivePosition = null;
        const searchEnd = hasWpCoverage ? wpCoverageEnd : elapsed;
        if (genuinelyCompetitive(searchEnd) >= 0.5) lastCompetitivePosition = searchEnd;
        else {
          for (let i = bins - 1; i >= 0; i--) {
            const position = elapsed * (i + 0.5) / bins;
            const tension = genuinelyCompetitive(position);
            if (tension !== null && tension >= 0.5) {
              lastCompetitivePosition = position;
              break;
            }
          }
        }
        return {
          competitiveShare,
          uncertaintyShare,
          dominantShare,
          marginContinuity,
          genuineContinuity,
          genuineContinuitySource,
          lateMovementShare,
          lastCompetitivePosition,
          trajectoryEndPosition: elapsed,
          wpCoverageStart,
          wpCoverageEnd,
          wpCoverageShare,
          wpObservationCount: wp.length
        };
      }
      const api = { scoringMoments, trajectoryAnalysis };
      if (typeof module2 !== "undefined" && module2.exports) module2.exports = api;
      else (root.SportsRadarScoring ||= {}).shared_trajectory = api;
    })(globalThis);
  }
});

// scoring/shared/config.js
var require_config = __commonJS({
  "scoring/shared/config.js"(exports2, module2) {
    (function(root) {
      const SPORT_FLOOR = 32;
      const SCHEDULE_SCARCITY = { NFL: 10, MLB: 0, NHL: 5, CFB: 8, NBA: 5, NCAAB: 3, Tennis: 2, Soccer: 4 };
      const SPORT_BASE2 = Object.fromEntries(
        Object.entries(SCHEDULE_SCARCITY).map(([sport, points]) => [sport, SPORT_FLOOR + points])
      );
      const NFL_DIVISIONS = {
        BUF: "AFC East",
        MIA: "AFC East",
        NE: "AFC East",
        NYJ: "AFC East",
        BAL: "AFC North",
        CIN: "AFC North",
        CLE: "AFC North",
        PIT: "AFC North",
        HOU: "AFC South",
        IND: "AFC South",
        JAX: "AFC South",
        TEN: "AFC South",
        DEN: "AFC West",
        KC: "AFC West",
        LAC: "AFC West",
        LV: "AFC West",
        DAL: "NFC East",
        NYG: "NFC East",
        PHI: "NFC East",
        WSH: "NFC East",
        CHI: "NFC North",
        DET: "NFC North",
        GB: "NFC North",
        MIN: "NFC North",
        ATL: "NFC South",
        CAR: "NFC South",
        NO: "NFC South",
        TB: "NFC South",
        ARI: "NFC West",
        LAR: "NFC West",
        SF: "NFC West",
        SEA: "NFC West"
      };
      const NHL_DIVISIONS = {
        BOS: "Atlantic Division",
        BUF: "Atlantic Division",
        DET: "Atlantic Division",
        FLA: "Atlantic Division",
        MTL: "Atlantic Division",
        OTT: "Atlantic Division",
        TB: "Atlantic Division",
        TOR: "Atlantic Division",
        CAR: "Metropolitan Division",
        CBJ: "Metropolitan Division",
        NJ: "Metropolitan Division",
        NYI: "Metropolitan Division",
        NYR: "Metropolitan Division",
        PHI: "Metropolitan Division",
        PIT: "Metropolitan Division",
        WSH: "Metropolitan Division",
        CHI: "Central Division",
        COL: "Central Division",
        DAL: "Central Division",
        MIN: "Central Division",
        NSH: "Central Division",
        STL: "Central Division",
        UTA: "Central Division",
        WPG: "Central Division",
        ANA: "Pacific Division",
        CGY: "Pacific Division",
        EDM: "Pacific Division",
        LA: "Pacific Division",
        LAK: "Pacific Division",
        SJ: "Pacific Division",
        SJS: "Pacific Division",
        SEA: "Pacific Division",
        VAN: "Pacific Division",
        VGK: "Pacific Division"
      };
      const NBA_DIVISIONS = {
        BOS: "Atlantic Division",
        BKN: "Atlantic Division",
        NY: "Atlantic Division",
        NYK: "Atlantic Division",
        PHI: "Atlantic Division",
        TOR: "Atlantic Division",
        CHI: "Central Division",
        CLE: "Central Division",
        DET: "Central Division",
        IND: "Central Division",
        MIL: "Central Division",
        ATL: "Southeast Division",
        CHA: "Southeast Division",
        MIA: "Southeast Division",
        ORL: "Southeast Division",
        WSH: "Southeast Division",
        DEN: "Northwest Division",
        MIN: "Northwest Division",
        OKC: "Northwest Division",
        POR: "Northwest Division",
        UTA: "Northwest Division",
        GS: "Pacific Division",
        GSW: "Pacific Division",
        LAC: "Pacific Division",
        LAL: "Pacific Division",
        PHX: "Pacific Division",
        SAC: "Pacific Division",
        DAL: "Southwest Division",
        HOU: "Southwest Division",
        MEM: "Southwest Division",
        NO: "Southwest Division",
        NOP: "Southwest Division",
        SA: "Southwest Division",
        SAS: "Southwest Division"
      };
      const MLB_DIVISIONS = {
        BAL: "AL East",
        BOS: "AL East",
        NYY: "AL East",
        TB: "AL East",
        TOR: "AL East",
        CWS: "AL Central",
        CHW: "AL Central",
        CLE: "AL Central",
        DET: "AL Central",
        KC: "AL Central",
        KCR: "AL Central",
        MIN: "AL Central",
        ATH: "AL West",
        OAK: "AL West",
        HOU: "AL West",
        LAA: "AL West",
        SEA: "AL West",
        TEX: "AL West",
        ATL: "NL East",
        MIA: "NL East",
        NYM: "NL East",
        PHI: "NL East",
        WSH: "NL East",
        CHC: "NL Central",
        CIN: "NL Central",
        MIL: "NL Central",
        PIT: "NL Central",
        STL: "NL Central",
        ARI: "NL West",
        COL: "NL West",
        LAD: "NL West",
        SD: "NL West",
        SDP: "NL West",
        SF: "NL West",
        SFG: "NL West"
      };
      const LEAGUE_DIVISIONS = {
        NFL: NFL_DIVISIONS,
        NHL: NHL_DIVISIONS,
        NBA: NBA_DIVISIONS,
        MLB: MLB_DIVISIONS
      };
      const CONTEXT_WEIGHTS = {
        former_captain_return: 10,
        first_game_back: 10,
        former_star_return: 8,
        star_injury_return: 8,
        championship_rematch: 8,
        playoff_rematch: 6,
        rivalry: 7,
        meaningful_rematch: 2,
        rivalry_development: 2,
        major_trade_storyline: 6,
        historic_streak: 6,
        season_debut: 5,
        milestone_chase: 5,
        playoff_race: 5,
        coach_return: 4,
        star_hot_streak: 4,
        notable_recent_performance: 2,
        team_win_streak: 3,
        elite_efficiency_profile: 4,
        strength_of_schedule: 3,
        confirmed_key_starters: 4,
        ace_pitching_matchup: 5,
        star_absence: -5,
        multiple_stars_out: -8
      };
      const CONTEXT_LABELS = {
        former_captain_return: "Former captain returns",
        first_game_back: "First game back against former team",
        former_star_return: "Former star returns",
        star_injury_return: "Star player returns from injury",
        championship_rematch: "Championship rematch",
        playoff_rematch: "Playoff rematch",
        rivalry: "Rivalry context",
        meaningful_rematch: "Verified rematch context",
        rivalry_development: "Material rivalry development",
        major_trade_storyline: "Major trade storyline",
        historic_streak: "Historic streak",
        season_debut: "Notable season debut",
        milestone_chase: "Major milestone chase",
        playoff_race: "Playoff race implications",
        coach_return: "Coach returns to former team",
        star_hot_streak: "Star player hot streak",
        notable_recent_performance: "Recent notable performance",
        team_win_streak: "Team winning streak",
        elite_efficiency_profile: "Elite efficiency profile",
        strength_of_schedule: "Battle-tested schedule",
        confirmed_key_starters: "Confirmed key starters",
        ace_pitching_matchup: "Confirmed ace pitching matchup",
        star_absence: "Notable star absence",
        multiple_stars_out: "Multiple major absences"
      };
      const CLOSE_MARGIN2 = {
        NFL: 14,
        MLB: 3,
        NHL: 3,
        CFB: 14,
        NBA: 12,
        NCAAB: 12,
        Tennis: 3,
        Soccer: 3
      };
      const api = { SPORT_FLOOR, SCHEDULE_SCARCITY, SPORT_BASE: SPORT_BASE2, NFL_DIVISIONS, NHL_DIVISIONS, NBA_DIVISIONS, MLB_DIVISIONS, LEAGUE_DIVISIONS, CONTEXT_WEIGHTS, CONTEXT_LABELS, CLOSE_MARGIN: CLOSE_MARGIN2 };
      if (typeof module2 !== "undefined" && module2.exports) {
        module2.exports = api;
      } else {
        (root.SportsRadarScoring ||= {}).shared_config = api;
      }
    })(globalThis);
  }
});

// scoring/shared/records.js
var require_records = __commonJS({
  "scoring/shared/records.js"(exports2, module2) {
    (function(root) {
      const { LEAGUE_DIVISIONS } = typeof module2 !== "undefined" && module2.exports ? require_config() : root.SportsRadarScoring.shared_config;
      function recordFor2(competitor) {
        const records = competitor?.records || competitor?.team?.records || [];
        const overall = records.find(
          (item) => /overall|total/i.test(
            `${item.type || ""} ${item.name || ""} ${item.abbreviation || ""}`
          )
        ) || records[0];
        return overall?.summary || competitor?.record?.summary || (typeof competitor?.record === "string" ? competitor.record : "");
      }
      function rankFor2(competitor, sport) {
        if (!["CFB", "NCAAB"].includes(sport)) {
          return null;
        }
        const rank = Number(
          competitor?.curatedRank?.current ?? competitor?.team?.rank
        );
        return Number.isFinite(rank) && rank >= 1 && rank <= 25 ? rank : null;
      }
      function divisionFor(sport, competitors) {
        const map = LEAGUE_DIVISIONS[sport];
        if (!map || !Array.isArray(competitors) || competitors.length !== 2) {
          return "";
        }
        const divisions = competitors.map(
          (item) => map[String(
            item.team?.abbreviation || item.abbreviation || ""
          ).toUpperCase()]
        );
        return divisions[0] && divisions[0] === divisions[1] ? divisions[0] : "";
      }
      function recordStats(competitor) {
        const match = String(
          recordFor2(competitor)
        ).match(
          /^(\d+)-(\d+)(?:-(\d+))?/
        );
        if (!match) {
          return null;
        }
        const wins = Number(match[1]);
        const losses = Number(match[2]);
        const ties = Number(match[3] || 0);
        const games = wins + losses + ties;
        return games ? {
          wins,
          losses,
          ties,
          games,
          pct: (wins + ties / 2) / games
        } : null;
      }
      function winningRecord(competitor) {
        const record = recordStats(competitor);
        return Boolean(
          record && record.pct > 0.5
        );
      }
      function proRecordFactors(sport, competitors) {
        if (!["MLB", "NHL", "NBA"].includes(sport)) {
          return [];
        }
        const records = competitors.map(
          recordStats
        );
        if (records.length !== 2 || !records.every(Boolean)) {
          return [];
        }
        const minimumGames = {
          MLB: 8,
          NHL: 4,
          NBA: 4
        }[sport] || 4;
        const mature = records.every(
          (record) => record.games >= minimumGames
        );
        const bothWinning = records.every(
          (record) => record.pct > 0.5
        );
        const bothAtLeastEven = records.every(
          (record) => record.pct >= 0.5
        );
        const bothBelow = records.every(
          (record) => record.pct < 0.5
        );
        const factors = [];
        factors.push(
          ...proTeamQualityFactors(
            sport,
            records
          )
        );
        if (bothWinning) {
          factors.push({
            label: "Both winning records",
            points: mature ? 7 : 3
          });
          if (Math.abs(
            records[0].pct - records[1].pct
          ) <= 0.1) {
            factors.push({
              label: "Evenly matched winning records",
              points: mature ? 3 : 2
            });
          }
        } else if (bothAtLeastEven) {
          factors.push({
            label: "Both teams at least .500",
            points: mature ? 4 : 2
          });
        } else if (bothBelow) {
          factors.push({
            label: "Both teams below .500",
            points: mature ? -4 : -2
          });
        }
        if (records.some(
          (record) => record.losses === 0 && record.games >= 3
        )) {
          factors.push({
            label: "Unbeaten team",
            points: 4
          });
        }
        if (records.some(
          (record) => record.wins === 0 && record.games >= 3
        )) {
          factors.push({
            label: "Winless team",
            points: -3
          });
        }
        return factors;
      }
      function proTeamQualityFactors(sport, records) {
        if (!["MLB", "NHL", "NBA"].includes(sport) || !Array.isArray(records) || records.length !== 2 || !records.every(Boolean)) {
          return [];
        }
        const priorGames = 6;
        const adjusted = records.map(
          (record) => (record.pct * record.games + 0.5 * priorGames) / (record.games + priorGames)
        );
        const average = adjusted.reduce((sum, value) => sum + value, 0) / adjusted.length;
        const factors = [];
        let points = 0;
        if (average >= 0.7) points = 10;
        else if (average >= 0.64) points = 7;
        else if (average >= 0.58) points = 4;
        else if (average >= 0.54) points = 2;
        if (points) {
          factors.push({
            label: "Adjusted team quality",
            points
          });
        }
        if (adjusted.every((value) => value >= 0.64)) {
          factors.push({
            label: "Both teams have strong adjusted quality",
            points: 3
          });
        }
        if (adjusted.every((value) => value >= 0.7)) {
          factors.push({
            label: "Both teams have elite adjusted quality",
            points: 2
          });
        }
        return factors;
      }
      const api = { recordFor: recordFor2, rankFor: rankFor2, divisionFor, recordStats, winningRecord, proRecordFactors, proTeamQualityFactors };
      if (typeof module2 !== "undefined" && module2.exports) {
        module2.exports = api;
      } else {
        (root.SportsRadarScoring ||= {}).shared_records = api;
      }
    })(globalThis);
  }
});

// scoring/shared/nfl-pregame.js
var require_nfl_pregame = __commonJS({
  "scoring/shared/nfl-pregame.js"(exports2, module2) {
    (function(root) {
      const unit = (x) => Math.max(0, Math.min(1, x));
      const round = (x) => Number(x.toFixed(2));
      const smooth = (x) => {
        x = unit(x);
        return x * x * (3 - 2 * x);
      };
      const stat = (row, name) => row?.stats?.find((s) => s.name === name)?.value;
      function standing(row) {
        const wins = stat(row, "wins"), losses = stat(row, "losses"), ties = stat(row, "ties") ?? 0;
        if (![wins, losses, ties].every((x) => typeof x === "number" && Number.isFinite(x) && x >= 0)) return null;
        const games = wins + losses + ties;
        return {
          id: String(row.id || row.team?.id || ""),
          wins,
          losses,
          ties,
          games,
          pct: games ? (wins + ties / 2) / games : 0,
          differential: Number.isFinite(stat(row, "pointsFor")) && Number.isFinite(stat(row, "pointsAgainst")) ? stat(row, "pointsFor") - stat(row, "pointsAgainst") : null
        };
      }
      function evidenceFromSummary(event, summary, opposition = []) {
        const competition = event?.competitions?.[0], start = Date.parse(event?.date);
        const ids = (competition?.competitors || []).map((t) => String(t.team?.id || ""));
        const header = summary?.header;
        if (ids.length !== 2 || !ids[0] || !ids[1] || String(header?.id) !== String(event.id) || !Number.isFinite(start) || Number(header?.season?.year) !== Number(event.season?.year)) return null;
        const groups = (summary.standings?.groups || []).map((group) => ({
          name: group.divisionHeader,
          sourceUrl: group.href,
          entries: (group.standings?.entries || []).map(standing).filter(Boolean)
        }));
        const teams = ids.map((id) => groups.flatMap((g) => g.entries).find((r) => r.id === id));
        if (teams.some((row, i) => !row || !(competition.competitors[i].records || []).some((r) => (r.type === "total" || r.name === "overall" || !r.type) && r.summary === `${row.wins}-${row.losses}${row.ties ? "-" + row.ties : ""}`))) return null;
        const recent = ids.map((id) => ({ id, events: [...new Map(((summary.lastFiveGames || []).find((t) => String(t.team?.id) === id)?.events || []).filter((e) => e.id && Date.parse(e.gameDate) < start && Date.parse(e.gameDate) >= Date.parse(`${event.season.year}-08-01`) && ["W", "L", "T"].includes(e.gameResult) && [e.homeTeamScore, e.awayTeamScore].every((x) => x != null && x !== "" && typeof x !== "boolean" && Number.isFinite(Number(x)))).map((e) => [String(e.id), e])).values()].sort((a, b) => Date.parse(b.gameDate) - Date.parse(a.gameDate)).slice(0, 5).map((e) => ({
          id: String(e.id),
          date: e.gameDate,
          opponentId: String(e.opponent?.id || ""),
          opponent: opposition.map(standing).find((t) => t?.id === String(e.opponent?.id)),
          result: e.gameResult,
          margin: (Number(e.homeTeamScore) - Number(e.awayTeamScore)) * (String(e.homeTeamId) === id ? 1 : -1),
          sourceUrl: e.links?.[0]?.href
        })) }));
        return {
          season: Number(event.season.year),
          eventId: String(event.id),
          start: event.date,
          teams,
          recent,
          division: groups.find((g) => ids.every((id) => g.entries.some((r) => r.id === id))) || null,
          sourceUrl: `https://www.espn.com/nfl/preview?gameId=${event.id}`
        };
      }
      function validatedEvidence(competition, records) {
        const e = competition?.sportsRadarNflPregame;
        if (!e || records.length !== 2 || !records.every(Boolean) || e.teams?.length !== 2 || e.teams.some((row, i) => String(row.id) !== String(competition.competitors[i]?.team?.id) || row.wins !== records[i].wins || row.losses !== records[i].losses || row.games !== records[i].games) || Number(competition.season?.year) !== e.season) return null;
        return e;
      }
      function nflRecordAssessment(competition, records) {
        if (records.length !== 2 || !records.every(Boolean)) return { positive: 0, penalty: 0, losingWeight: 0 };
        const pct = records.map((r) => r.pct), deficits = pct.map((p) => unit(1 - 2 * p));
        const losingWeight = smooth(Math.min(...deficits) / 0.2);
        const severity = 7 * losingWeight * (0.65 * Math.max(...deficits) + 0.35 * (deficits[0] + deficits[1]) / 2);
        const e = validatedEvidence(competition, records), maturity = unit((Math.min(...records.map((r) => r.games)) - 2) / 4);
        const recovery = e?.teams.every((t) => Number.isFinite(t.differential)) ? e.teams.reduce((sum, t) => sum + 2 * unit((t.differential / t.games + 3) / 6), 0) * maturity : 0;
        const relief = severity * recovery / 7;
        const single = Math.min(2, Math.max(0, (Math.max(...pct) - 0.5) * 12)) * Math.min(1, Math.max(...records.map((r) => r.games)) / 4);
        const mutual = smooth((Math.min(...pct) - 0.5) / 0.07);
        const positive = single + (14 - single) * mutual * smooth(((pct[0] + pct[1]) / 2 - 0.5) / 0.2);
        const severeTeam = 5 * (1 - smooth(Math.min(...pct) / 0.125));
        const appliedSeverity = Math.max(severity, severeTeam), appliedRelief = appliedSeverity - Math.max(severity - relief, severeTeam);
        return {
          positive: round(positive),
          penalty: round(-appliedSeverity + appliedRelief),
          losingWeight,
          severity: round(appliedSeverity),
          relief: round(appliedRelief)
        };
      }
      function nflMarketInteraction(spread, total) {
        if (typeof spread !== "number" || !Number.isFinite(spread) || typeof total !== "number" || !Number.isFinite(total) || total > 100) return 0;
        return round(3 * smooth((7 - Math.abs(spread)) / 4) * smooth((total - 46) / 8));
      }
      function nflReturnPoints(item, competition) {
        const e = item.injuryEvidence;
        if (!e || !(competition?.competitors || []).some((t) => String(t.team?.id || t.id) === String(e.affectedTeamId))) return 0;
        const proof = e.playerSignificance;
        if (proof?.verified === true && proof.playerId && /^https?:\/\//.test(proof.sourceUrl || "") && proof.fact) {
          if (proof.tier === "major-quarterback") return 5;
          if (proof.tier === "established-star") return 3;
        }
        return e.importance === "starting-quarterback" ? 3 : e.importance === "key-player" ? 2 : 1;
      }
      function nflEvidenceFactors(competition, records, division) {
        const e = validatedEvidence(competition, records);
        if (!e) return [];
        const factors = [], maturity = unit((Math.min(...records.map((r) => r.games)) - 2) / 4);
        const add = (label, points, detail, sourceUrl = e.sourceUrl) => {
          points = round(points);
          if (points) factors.push({ label, points, detail, sourceUrl });
        };
        const group = e.division;
        if (division && group?.name === division && group.entries.length === 4 && maturity) {
          const leader = group.entries.reduce((a, b) => a.pct > b.pct ? a : b);
          const behind = (row) => (leader.wins - row.wins + (row.losses - leader.losses)) / 2;
          const bothNear = e.teams.every((row) => behind(row) <= 1);
          const canLead = e.teams.map((row, i) => {
            const pct = (row.wins + 1 + row.ties / 2) / (row.games + 1);
            return group.entries.every((other) => other.id === row.id || pct >= (other.id === e.teams[1 - i].id ? (other.wins + other.ties / 2) / (other.games + 1) : other.pct));
          });
          const stakes = bothNear ? canLead.every(Boolean) ? 7 : 5 : e.teams.every((row) => row.pct >= 0.5 && behind(row) <= 2) ? 2 : 0;
          add(
            canLead.every(Boolean) && bothNear ? "Division lead at stake" : "Division race positioning",
            stakes * maturity,
            canLead.every(Boolean) && bothNear ? `Either winner can take at least a share of the ${division} lead` : `Both teams are within ${bothNear ? "one game" : "two games"} of the ${division} lead`,
            group.sourceUrl
          );
          const meeting = e.recent.flatMap((t) => t.events).find((g) => e.teams.some((t) => t.id === g.opponentId));
          if (meeting && stakes) add(
            "Season-series tiebreaker",
            Math.min(1, 8 - stakes) * maturity,
            "A verified earlier meeting makes the division season series relevant",
            meeting.sourceUrl
          );
        }
        if (e.teams.every((t) => Number.isFinite(t.differential))) {
          const strength = e.teams.reduce((sum, t) => sum + t.differential / t.games, 0) / 2;
          const { losingWeight } = nflRecordAssessment(competition, records);
          add(
            "Season point differential",
            Math.max(-2, Math.min(2, strength / 4)) * maturity * (1 - losingWeight),
            "Season scoring margins provide a small quality adjustment"
          );
        }
        const form = e.recent.map((t) => t.events.slice(0, 3));
        if (form.every((g) => g.length === 3)) {
          const average = form.flat().reduce((sum, g) => sum + Math.max(-21, Math.min(21, g.margin)), 0) / 6;
          add("Recent performance", Math.max(-1, Math.min(2, average / 6)) * maturity, "Scoring margins over each team\u2019s last three games; individual margins capped at 21");
        }
        const strongWins = e.recent.map((t) => t.events[0]).filter((g) => g?.result === "W" && g.opponent?.games >= 4 && g.opponent.pct >= 0.6);
        if (strongWins.length) add(
          "Recent win over winning opposition",
          strongWins.length * 0.75 * maturity,
          "Latest result includes a win over an opponent currently winning at least 60% of its games",
          strongWins[0].sourceUrl
        );
        const streak = e.recent.reduce((sum, t) => {
          const first = t.events[0]?.result;
          let length = 0;
          for (const g of t.events) {
            if (g.result !== first) break;
            length++;
          }
          return sum + (length >= 3 && first !== "T" ? (first === "W" ? 1 : -1) * Math.min(1, (length - 2) * 0.25) : 0);
        }, 0);
        add("Sustained recent form", streak * maturity, "Verified consecutive wins or losses, limited to the available five-game history");
        return factors;
      }
      const api = { evidenceFromSummary, nflEvidenceFactors, nflRecordAssessment, nflMarketInteraction, nflReturnPoints };
      if (typeof module2 !== "undefined" && module2.exports) module2.exports = api;
      else (root.SportsRadarScoring ||= {}).shared_nfl_pregame = api;
    })(globalThis);
  }
});

// scoring/shared/market.js
var require_market = __commonJS({
  "scoring/shared/market.js"(exports2, module2) {
    (function(root) {
      function parseLine2(raw, competition, sport) {
        if (!raw) return null;
        const listed = raw.close || raw.closing || raw;
        const totalValue = listed.overUnder ?? listed.over_under ?? listed.total?.overUnder ?? listed.total?.value;
        const total = totalValue == null || totalValue === "" ? NaN : Number(totalValue);
        const details = String(
          listed.details || listed.displayValue || ""
        ).trim();
        const isMoneyline = /[+-]\d{3,}\b/.test(details) && !/[+-]\d+\.\d+/.test(details);
        let spread = isMoneyline ? "" : String(
          listed.spread?.displayValue || details
        ).trim();
        if (!spread && listed.spread != null && Number.isFinite(Number(listed.spread)) && (!isMoneyline || Math.abs(Number(listed.spread)) <= 10)) {
          const amount = Math.abs(
            Number(listed.spread)
          );
          const home = (competition?.competitors || []).find(
            (team) => team.homeAway === "home"
          );
          const away = (competition?.competitors || []).find(
            (team) => team.homeAway === "away"
          );
          const favored = listed.homeTeamOdds?.favorite ? home : listed.awayTeamOdds?.favorite ? away : null;
          if (favored) {
            spread = amount === 0 ? "PK" : `${favored.team?.abbreviation || favored.abbreviation || "Favorite"} -${amount}`;
          }
        }
        if (!spread && !details && !Number.isFinite(total)) {
          return null;
        }
        return {
          spread: spread || "",
          moneyline: isMoneyline ? details : "",
          total: Number.isFinite(total) ? total : null,
          provider: listed.provider?.name || raw.provider?.name || "",
          verifiedClose: Boolean(
            raw.close || raw.closing
          )
        };
      }
      function lineFromSummary2(summary, sport) {
        const competition = summary?.header?.competitions?.[0];
        return parseLine2(
          summary?.pickcenter?.[0] || competition?.odds?.[0] || summary?.odds?.[0],
          competition,
          sport
        );
      }
      function listedSpread(competition) {
        const spread = parseLine2(
          competition?.odds?.[0],
          competition,
          "NFL"
        )?.spread || "";
        const match = spread.match(
          /[+-](\d+(?:\.\d+)?)/
        );
        return match ? Number(match[1]) : null;
      }
      function numberFromLine(value) {
        if (value === null || value === void 0 || value === "") {
          return null;
        }
        const n = Number(
          String(value).replace(
            /[^+\-.\d]/g,
            ""
          )
        );
        return Number.isFinite(n) ? n : null;
      }
      function moneylinePrices(raw) {
        if (!raw) {
          return [];
        }
        const odds = raw.close || raw.closing || raw;
        const candidates = [
          odds.homeTeamOdds?.moneyLine,
          odds.awayTeamOdds?.moneyLine,
          odds.homeTeamOdds?.moneyline,
          odds.awayTeamOdds?.moneyline,
          odds.moneyline?.home?.close?.odds,
          odds.moneyline?.away?.close?.odds,
          odds.moneyline?.home?.open?.odds,
          odds.moneyline?.away?.open?.odds,
          odds.moneyLine?.home?.close?.odds,
          odds.moneyLine?.away?.close?.odds,
          odds.moneyLine?.home?.open?.odds,
          odds.moneyLine?.away?.open?.odds
        ];
        const details = String(
          odds.details || odds.displayValue || ""
        ).match(
          /[+-]\d{3,4}\b/g
        ) || [];
        return [
          ...new Set(
            [
              ...candidates,
              ...details
            ].map(numberFromLine).filter(
              (value) => value !== null && Math.abs(value) >= 100
            )
          )
        ];
      }
      function spreadMarketPoints(spread) {
        return Math.round(5 / (1 + (spread / 6) ** 2));
      }
      function footballPregameSpread(competition) {
        const raw = competition?.odds?.[0];
        const odds = raw?.close || raw?.closing || raw;
        if (!odds) return null;
        const number = (value) => {
          if (value == null || typeof value === "boolean" || typeof value === "object" || String(value).trim() === "") return null;
          const text = String(value).trim().replace(/[−–]/g, "-");
          if (/^(?:pk|pick(?:['’]?em)?|even)$/i.test(text)) return 0;
          return /^[+-]?\d+(?:\.\d+)?$/.test(text) && Number.isFinite(Number(text)) ? Math.abs(Number(text)) : null;
        };
        for (const value of [
          odds.spread?.displayValue,
          odds.spread,
          odds.pointSpread?.home?.close?.line,
          odds.pointSpread?.away?.close?.line
        ]) {
          const spread = number(value);
          if (spread !== null) return spread;
        }
        const details = String(odds.details || odds.displayValue || "").trim().replace(/[−–]/g, "-");
        if (/\b(?:pk|pick(?:['’]?em)?|even)\b/i.test(details)) return 0;
        const match = details.match(/(?:^|\s)[+-](\d+(?:\.\d+)?)\s*$/);
        return match && Number(match[1]) < 100 ? Number(match[1]) : null;
      }
      const FOOTBALL_SPREAD_ANCHORS = {
        NFL: [[0, 7], [3, 6], [3.5, 5.625], [6, 2], [7, 0], [8, -2], [10, -4], [14, -6], [17, -8], [21, -10]],
        CFB: [[0, 5], [3, 4], [7, 2], [10, 1], [14, 0], [20, -4], [27, -7], [35, -10]]
      };
      function footballSpreadAdjustment(sport, spread) {
        if (spread == null || typeof spread !== "number" || !Number.isFinite(spread)) return 0;
        const anchors = FOOTBALL_SPREAD_ANCHORS[sport];
        if (!anchors) return 0;
        const value = Math.abs(spread);
        for (let i = 1; i < anchors.length; i++) {
          const [x, y] = anchors[i - 1], [nextX, nextY] = anchors[i];
          if (value <= nextX) {
            if (sport !== "NFL") return y + (nextY - y) * (value - x) / (nextX - x);
            const tangent = (index) => {
              if (index === 0) return (anchors[1][1] - anchors[0][1]) / (anchors[1][0] - anchors[0][0]);
              if (index === anchors.length - 1) return 0;
              const [px, py] = anchors[index - 1], [cx, cy] = anchors[index], [nx, ny] = anchors[index + 1];
              const left = (cy - py) / (cx - px), right = (ny - cy) / (nx - cx);
              if (left * right <= 0) return 0;
              const a = 2 * (nx - cx) + (cx - px), b = nx - cx + 2 * (cx - px);
              return (a + b) / (a / left + b / right);
            };
            const width = nextX - x, t = (value - x) / width;
            return (2 * t ** 3 - 3 * t ** 2 + 1) * y + (t ** 3 - 2 * t ** 2 + t) * width * tangent(i - 1) + (-2 * t ** 3 + 3 * t ** 2) * nextY + (t ** 3 - t ** 2) * width * tangent(i);
          }
        }
        return anchors.at(-1)[1];
      }
      function pregameMarketFactor(sport, competition, options = {}) {
        const raw = competition?.odds?.[0];
        if (!raw) {
          return null;
        }
        if (sport === "CFB" && options.calibratedPregame) {
          const spread = footballPregameSpread(competition);
          const points = footballSpreadAdjustment(sport, spread);
          return points ? { label: points < 0 ? "Projected spread mismatch" : points >= 4 ? "Very close projected spread" : "Competitive projected spread", points: Number(points.toFixed(2)) } : null;
        }
        if (["NBA", "CFB", "NCAAB"].includes(sport)) {
          const spread = listedSpread(competition);
          const points = spread === null ? 0 : spreadMarketPoints(spread);
          return points ? {
            label: points >= 4 ? "Very close projected spread" : "Competitive projected spread",
            points
          } : null;
        }
        if (["NHL", "MLB"].includes(sport)) {
          const prices = moneylinePrices(raw);
          if (!prices.length) {
            return null;
          }
          const shortest = Math.min(
            ...prices.map(
              (value) => Math.abs(value)
            )
          );
          if (shortest <= 125) {
            return {
              label: "Near pick\u2019em market",
              points: 5
            };
          }
          if (shortest <= 150) {
            return {
              label: "Competitive betting market",
              points: 3
            };
          }
        }
        return null;
      }
      function underdogCandidate2(sport, competition, raw) {
        if (!raw || !competition?.competitors || competition.competitors.length !== 2) {
          return null;
        }
        const odds = raw.close || raw.closing || raw;
        const sides = ["home", "away"].map((side) => {
          const competitor = competition.competitors.find(
            (item) => item.homeAway === side
          );
          if (!competitor) {
            return null;
          }
          const spread = numberFromLine(
            odds.pointSpread?.[side]?.close?.line ?? odds.pointSpread?.[side]?.open?.line
          );
          const moneyline = numberFromLine(
            odds.moneyline?.[side]?.close?.odds ?? odds.moneyline?.[side]?.open?.odds
          );
          return {
            side,
            competitor,
            spread,
            moneyline
          };
        }).filter(Boolean);
        if (sides.length !== 2) {
          return null;
        }
        const spreadMinimum = {
          NFL: 7,
          // Ramp CFB impact through ten instead of creating a +9.5/+10 cliff.
          CFB: 7,
          NBA: 8,
          NCAAB: 8
        }[sport];
        const moneylineMinimum = {
          MLB: 180,
          NHL: 180,
          Soccer: 250,
          Tennis: 180
        }[sport];
        let pick = spreadMinimum ? sides.find(
          (item) => item.spread !== null && item.spread >= spreadMinimum
        ) : null;
        let type = pick ? "spread" : "";
        if (!pick && spreadMinimum) {
          const amount = Math.abs(
            numberFromLine(
              odds.spread
            ) ?? numberFromLine(
              odds.details?.match(
                /[+-]\d+(?:\.\d+)?/
              )?.[0]
            ) ?? 0
          );
          if (amount >= spreadMinimum) {
            pick = sides.find(
              (item) => odds[`${item.side}TeamOdds`]?.underdog === true || odds[`${item.side}TeamOdds`]?.favorite === false
            );
            if (pick) {
              pick = {
                ...pick,
                spread: amount
              };
              type = "spread";
            }
          }
        }
        if (!pick && moneylineMinimum) {
          pick = sides.find(
            (item) => item.moneyline !== null && item.moneyline >= moneylineMinimum
          );
          if (pick) {
            type = "moneyline";
          }
        }
        if (!pick) {
          return null;
        }
        const value = type === "spread" ? pick.spread : pick.moneyline;
        const minimum = type === "spread" ? spreadMinimum : moneylineMinimum;
        const teamIndex = competition.competitors.indexOf(
          pick.competitor
        );
        return {
          side: pick.side,
          teamId: String(
            pick.competitor.team?.id || pick.competitor.id || ""
          ),
          teamIndex,
          teamName: pick.competitor.team?.displayName || pick.competitor.team?.name || "The underdog",
          type,
          value,
          strength: Math.min(
            1,
            Math.max(
              0,
              (value - minimum) / (type === "spread" ? minimum : 200)
            )
          ),
          activation: sport === "CFB" && type === "spread" ? Math.min(1, Math.max(0, (value - 7) / 3)) : 1,
          description: type === "spread" ? `${value}-point underdog` : `+${value} moneyline underdog`
        };
      }
      const api = { parseLine: parseLine2, lineFromSummary: lineFromSummary2, listedSpread, numberFromLine, moneylinePrices, spreadMarketPoints, pregameMarketFactor, underdogCandidate: underdogCandidate2, footballPregameSpread, footballSpreadAdjustment, FOOTBALL_SPREAD_ANCHORS };
      if (typeof module2 !== "undefined" && module2.exports) {
        module2.exports = api;
      } else {
        (root.SportsRadarScoring ||= {}).shared_market = api;
      }
    })(globalThis);
  }
});

// scoring/shared/football.js
var require_football = __commonJS({
  "scoring/shared/football.js"(exports2, module2) {
    (function(root) {
      const { lineFromSummary: lineFromSummary2, parseLine: parseLine2 } = typeof module2 !== "undefined" && module2.exports ? require_market() : root.SportsRadarScoring.shared_market;
      const { ordinal, clockSeconds } = typeof module2 !== "undefined" && module2.exports ? require_time() : root.SportsRadarScoring.shared_time;
      function defensiveFinishFactor(sport, summary) {
        if (!["NFL", "CFB"].includes(sport)) return null;
        const competition = summary?.header?.competitions?.[0];
        const teams = competition?.competitors || [];
        const home = teams.find((team) => team.homeAway === "home");
        const away = teams.find((team) => team.homeAway === "away");
        if (!home || !away) return null;
        const drives = [...summary?.drives?.previous || [], ...summary?.drives?.current ? [summary.drives.current] : []];
        const plays = summary?.plays?.length ? summary.plays : drives.flatMap((drive) => (drive.plays || []).map((play) => ({ ...play, driveTeam: drive.team?.id })));
        const textFor = (play) => String(play?.text || play?.shortText || "");
        const administrative = (play) => /kneel|end of (?:game|quarter|period)|timeout|two.minute warning/i.test(textFor(play));
        const offenseFor = (play) => String(play?.start?.team?.id || play?.driveTeam || "");
        const turnover = /intercept(?:ed|ion)|fumble.*(?:lost|recover)|turnover on downs|defensive stop/i;
        const scoring = summary?.scoringPlays?.length ? summary.scoringPlays : plays.filter((play) => play.scoringPlay === true);
        const lastScore = scoring.at(-1);
        const scoringText = `${lastScore?.clock?.displayValue || ""} ${textFor(lastScore)}`;
        if (/(0:00|last second|game[- ]winning)/i.test(scoringText) && /field goal|goal|home run|touchdown/i.test(scoringText)) return null;
        for (let index = plays.length - 1; index >= 0; index--) {
          const play = plays[index];
          const text = textFor(play);
          if (administrative(play) || play.scoringPlay) continue;
          const fourthDown = Number(play.start?.down) === 4 || /\b4th\b|fourth.down/i.test(text);
          if (!turnover.test(text) && !(fourthDown && /incomplete|stopped|no gain|sack/i.test(text))) continue;
          if (/nullified|no play|overturned/i.test(text)) continue;
          const offense = offenseFor(play);
          const offenseHome = offense === String(home.team?.id);
          if (!offense || !offenseHome && offense !== String(away.team?.id)) continue;
          const finalMargin = Number(home.score) - Number(away.score);
          if (!Number.isFinite(finalMargin) || (offenseHome ? finalMargin >= 0 : finalMargin <= 0)) continue;
          const previous = plays[index - 1];
          const homeScore = Number(play.homeScore ?? previous?.homeScore);
          const awayScore = Number(play.awayScore ?? previous?.awayScore);
          const deficit = offenseHome ? awayScore - homeScore : homeScore - awayScore;
          if (!Number.isFinite(deficit) || deficit < 0 || deficit > 8) continue;
          const later = plays.slice(index + 1).filter((item) => !administrative(item));
          if (later.some((item) => !offenseFor(item) || offenseFor(item) === offense || item.scoringPlay || turnover.test(textFor(item)))) continue;
          const changedPossession = play.end?.team?.id && String(play.end.team.id) !== offense;
          const lostBall = /intercept(?:ed|ion)|turnover on downs|fumble.*lost/i.test(text) || changedPossession || fourthDown;
          if (!lostBall && !/defensive stop.*(?:seal|end.*game)|(?:seal|end.*game).*defensive stop/i.test(text)) continue;
          const period = Number(play.period?.number || play.period || 0);
          const clock = String(play.clock?.displayValue || "").match(/^(\d+):(\d{2})$/);
          const seconds = clock ? Number(clock[1]) * 60 + Number(clock[2]) : Infinity;
          const late = period > 4 || period === 4 && seconds <= 120;
          const explicitFinal = period >= 4 && /final (?:meaningful )?possession|seals? (?:the )?(?:game|win)|game[- ]sealing/i.test(text);
          if (!late && !explicitFinal) continue;
          const endZone = /intercept(?:ed|ion)/i.test(text) && /end zone|endzone/i.test(text);
          const yards = Number(play.start?.yardsToEndzone);
          const redZone = Number.isFinite(yards) && yards >= 0 && yards <= 20 || /goal.to.go|\band goal\b|red zone/i.test(text);
          return { label: "Decisive defensive finish", points: endZone ? 14 : redZone ? 12 : 9 };
        }
        return null;
      }
      function footballStagnationImpact(sport, summary, progress, state = "live") {
        if (!["NFL", "CFB"].includes(sport) || !summary || state !== "completed" && !(sport === "NFL" && state === "live" && progress >= 0.65)) {
          return {
            points: 0,
            text: ""
          };
        }
        const p = state === "completed" ? 1 : Math.max(
          0,
          Math.min(
            1,
            Number(progress) || 0
          )
        );
        const competition = summary?.header?.competitions?.[0];
        const scores = (competition?.competitors || []).map(
          (team) => Number(team?.score)
        ).filter(Number.isFinite);
        const combinedScore = scores.length === 2 ? scores[0] + scores[1] : null;
        const normalize = (value) => String(value || "").toLowerCase().replace(
          /[^a-z0-9]/g,
          ""
        );
        const statMaps = (summary?.boxscore?.teams || []).map(
          (team) => new Map(
            (team.statistics || []).map((stat) => [
              normalize(
                stat.name || stat.abbreviation || stat.label || stat.displayName
              ),
              stat
            ]).filter(
              ([name]) => Boolean(name)
            )
          )
        );
        const findStat = (map, names) => {
          for (const name of names) {
            const stat = map.get(
              normalize(name)
            );
            if (stat) {
              return stat;
            }
          }
          return null;
        };
        const numberValue = (stat) => {
          if (!stat) {
            return null;
          }
          const direct = Number(stat.value);
          if (Number.isFinite(direct)) {
            return direct;
          }
          const match = String(
            stat.displayValue ?? ""
          ).match(
            /-?\d+(?:\.\d+)?/
          );
          return match ? Number(match[0]) : null;
        };
        const efficiency = (stat) => {
          if (!stat) {
            return null;
          }
          const text = String(
            stat.displayValue ?? ""
          );
          const match = text.match(
            /(\d+)\s*[-/]\s*(\d+)/
          );
          if (match) {
            const made = Number(match[1]);
            const attempts = Number(match[2]);
            return {
              rate: attempts ? made / attempts : 0,
              attempts
            };
          }
          const value = numberValue(stat);
          if (value === null) {
            return null;
          }
          return {
            rate: Math.max(
              0,
              Math.min(
                1,
                value > 1 ? value / 100 : value
              )
            ),
            attempts: null
          };
        };
        const average = (values) => {
          const usable = values.filter(
            Number.isFinite
          );
          return usable.length ? usable.reduce(
            (sum, value) => sum + value,
            0
          ) / usable.length : null;
        };
        const yardsPerPlay = average(
          statMaps.map(
            (map) => numberValue(
              findStat(
                map,
                [
                  "yardsPerPlay",
                  "yardsPerPlayAverage"
                ]
              )
            )
          )
        );
        const thirdDowns = statMaps.map(
          (map) => efficiency(
            findStat(
              map,
              [
                "thirdDownEff",
                "thirdDownEfficiency"
              ]
            )
          )
        ).filter(Boolean);
        const thirdDownRate = thirdDowns.length ? average(
          thirdDowns.map(
            (item) => item.rate
          )
        ) : null;
        const redZones = statMaps.map(
          (map) => efficiency(
            findStat(
              map,
              [
                "redZoneAttempts",
                "redZoneEfficiency",
                "redZoneEff"
              ]
            )
          )
        ).filter(Boolean);
        const redZoneAttempts = redZones.length && redZones.every(
          (item) => Number.isFinite(
            item.attempts
          )
        ) ? redZones.reduce(
          (sum, item) => sum + item.attempts,
          0
        ) : null;
        const redZoneTouchdowns = redZoneAttempts !== null ? redZones.reduce(
          (sum, item) => sum + item.rate * item.attempts,
          0
        ) : null;
        const drives = [
          ...summary?.drives?.previous || [],
          ...state === "completed" && summary?.drives?.current ? [summary.drives.current] : []
        ].filter(
          (drive) => drive && drive.isCurrent !== true && !/end of (?:half|game)|kneel/i.test(
            String(
              drive.result || drive.description || ""
            )
          )
        );
        const puntRate = drives.length >= 4 ? drives.filter(
          (drive) => /punt/i.test(
            String(
              drive.result || drive.description || ""
            )
          )
        ).length / drives.length : null;
        const puntTotal = (summary?.boxscore?.players || []).flatMap(
          (block) => (block.statistics || []).filter(
            (group) => group.name === "punting"
          ).flatMap(
            (group) => (group.athletes || []).map(
              (athlete) => Number(
                athlete.stats?.[0]
              ) || 0
            )
          )
        ).reduce(
          (sum, value) => sum + value,
          0
        );
        const clamp01 = (value) => Math.max(
          0,
          Math.min(
            1,
            value
          )
        );
        const signals = [];
        if (combinedScore !== null) {
          const total = [
            lineFromSummary2(
              summary,
              sport
            )?.total,
            parseLine2(
              competition?.odds?.[0],
              competition,
              sport
            )?.total,
            parseLine2(
              summary?.odds?.[0],
              competition,
              sport
            )?.total
          ].find(
            (value) => Number.isFinite(value) && value > 0
          );
          const expectedLowEnd = (total !== void 0 ? total : sport === "CFB" ? 28 : 22) * p;
          signals.push({
            label: "very little scoring",
            weight: 0.3,
            value: expectedLowEnd ? clamp01(
              (expectedLowEnd - combinedScore) / expectedLowEnd
            ) : 0
          });
        }
        if (yardsPerPlay !== null) {
          signals.push({
            label: "low yards per play",
            weight: 0.25,
            value: clamp01(
              (4.9 - yardsPerPlay) / 1.4
            )
          });
        }
        if (puntRate !== null) {
          signals.push({
            label: "repeated empty possessions",
            weight: 0.2,
            value: clamp01(
              (puntRate - 0.35) / 0.4
            )
          });
        } else if (puntTotal) {
          signals.push({
            label: "repeated punts",
            weight: 0.15,
            value: clamp01(
              (puntTotal - 6) / 6
            )
          });
        }
        if (redZoneAttempts !== null) {
          const expected = (sport === "CFB" ? 5 : 4) * p;
          const fewOpportunities = expected ? clamp01(
            (expected - redZoneAttempts) / expected
          ) : 0;
          const failedConversions = redZoneAttempts ? clamp01(
            (0.5 - redZoneTouchdowns / redZoneAttempts) / 0.5
          ) * clamp01(
            redZoneAttempts / 3
          ) : 0;
          signals.push({
            label: failedConversions > fewOpportunities ? "poor red-zone touchdown conversion" : "few scoring opportunities",
            weight: 0.15,
            value: Math.max(
              fewOpportunities,
              failedConversions
            )
          });
        }
        if (thirdDownRate !== null) {
          signals.push({
            label: "poor third-down offense",
            weight: 0.1,
            value: clamp01(
              (0.34 - thirdDownRate) / 0.22
            )
          });
        }
        const scoringPlays = summary?.scoringPlays || [];
        if (scoringPlays.length >= 4) {
          signals.push({
            label: "no touchdowns",
            weight: 0.1,
            value: scoringPlays.some(
              (play) => /touchdown/i.test(
                `${play.text || ""} ${play.type?.text || ""}`
              )
            ) ? 0 : 1
          });
        }
        const meaningful = signals.filter(
          (signal) => signal.value >= 0.35
        );
        if ((state === "live" ? meaningful.filter((signal) => signal.label !== "no touchdowns").length : meaningful.length) < 3) {
          return {
            points: 0,
            text: ""
          };
        }
        const totalWeight = signals.reduce(
          (sum, signal) => sum + signal.weight,
          0
        );
        let index = totalWeight ? signals.reduce(
          (sum, signal) => sum + signal.value * signal.weight,
          0
        ) / totalWeight : 0;
        let action = 0;
        const defensivePlays = summary?.plays?.length ? summary.plays : (summary?.drives?.previous || []).flatMap(
          (drive) => drive.plays || []
        );
        for (const play of defensivePlays) {
          const text = String(
            play.text || play.shortText || play.type?.text || ""
          ).toLowerCase();
          if (state === "live" && /no play|nullified|overturned/i.test(text)) continue;
          if (/intercept(?:ed|ion)|fumble.*(?:lost|recover)/.test(text)) {
            action += 0.75;
            const returnYards = Number(
              text.match(
                /return(?:ed)?(?: for)?\s+(\d+)\s+yards/
              )?.[1] || 0
            );
            if (returnYards >= 20) {
              action += 3;
            }
            if (Number(
              play.period?.number || play.period
            ) >= 4 && Number.isFinite(
              Number(play.homeScore)
            ) && Number.isFinite(
              Number(play.awayScore)
            ) && Math.abs(
              Number(play.homeScore) - Number(play.awayScore)
            ) <= 8) {
              action += 2;
            }
          }
          if (/\bsack(?:ed)?\b/.test(text)) {
            action += 0.5;
          }
          if (state === "live" ? /turnover on downs|stopped on fourth|fourth.down stop/.test(text) || Number(play.start?.down) === 4 && /incomplete|no gain|sack/.test(text) : /turnover on downs|4th down|fourth down|stopped on fourth/.test(text)) {
            action += 2;
          }
          if (/blocked (?:punt|field goal|kick)|\bsafety\b/.test(text)) {
            action += 5;
          }
          if (/defensive touchdown|interception return.*touchdown|fumble return.*touchdown/.test(text)) {
            action += 8;
          }
          const yards = Number(
            play.statYardage ?? play.yards ?? play.statYards
          );
          if (Number.isFinite(yards) && Math.abs(yards) >= 20) {
            action += 1;
          }
        }
        const severeCompleted = meaningful.length >= 5;
        if (state === "live") {
          const statAction = statMaps.reduce((sum, map) => sum + [
            [["turnovers"], 0.75],
            [["sacks"], 0.5],
            [["fourthDownStops"], 2],
            [["blockedKicks", "kicksBlocked"], 5],
            [["safeties"], 5],
            [["defensiveTouchdowns"], 8],
            [["explosivePlays"], 1]
          ].reduce((value, [names, weight]) => value + Math.max(0, numberValue(findStat(map, names)) || 0) * weight, 0), 0);
          action = Math.max(action, statAction);
        }
        index *= 1 - Math.min(
          state === "live" ? 1 : severeCompleted ? 0.9 : 0.25,
          state === "live" ? action / 12 : severeCompleted ? action / 24 : action / 40
        );
        if (index < 0.45) {
          return {
            points: 0,
            text: ""
          };
        }
        const progressMultiplier = state === "completed" ? 1 : clamp01((p - 0.65) / 0.2);
        const cap = state === "live" ? 10 : severeCompleted ? 36 : 20;
        const points = Math.max(
          state === "live" ? 0 : 1,
          Math.round(
            cap * progressMultiplier * index
          )
        );
        const strongest = [...signals].sort(
          (a, b) => b.value - a.value
        ).filter(
          (signal) => signal.value >= 0.35
        ).slice(0, 3).map(
          (signal) => signal.label
        );
        return {
          points,
          text: `Offensive stagnation: ${strongest.join(", ")}`
        };
      }
      function footballMarginCloseness(gap) {
        if (gap === null || !Number.isFinite(Number(gap))) {
          return 0;
        }
        const points = Math.max(
          0,
          Number(gap)
        );
        const anchors = [
          [0, 1],
          [3, 0.98],
          [8, 0.9],
          [9, 0.82],
          [11, 0.72],
          [14, 0.58],
          [16, 0.52],
          [24, 0.28],
          [32, 0]
        ];
        if (points <= anchors[0][0]) {
          return anchors[0][1];
        }
        for (let i = 1; i < anchors.length; i++) {
          if (points <= anchors[i][0]) {
            const [x0, y0] = anchors[i - 1];
            const [x1, y1] = anchors[i];
            const t = (points - x0) / (x1 - x0);
            return y0 + (y1 - y0) * t;
          }
        }
        return 0;
      }
      function footballCompetitorId(item) {
        return String(
          item?.team?.id || item?.id || ""
        );
      }
      function footballCompetitorAbbreviation(item) {
        return String(
          item?.team?.abbreviation || item?.abbreviation || ""
        ).toUpperCase();
      }
      function footballSituationFieldPosition(situation, holderAbbr) {
        const text = `${situation?.possessionText || ""} ${situation?.downDistanceText || ""} ${situation?.shortDownDistanceText || ""}`.toUpperCase();
        const match = text.match(
          /\b([A-Z]{2,4})\s+(\d{1,2})\b/
        );
        if (!match) {
          return /\b50\b/.test(text) ? 50 : null;
        }
        const code = match[1];
        const yard = Number(match[2]);
        if (!Number.isFinite(yard) || yard < 0 || yard > 50) {
          return null;
        }
        return code === holderAbbr ? yard : 100 - yard;
      }
      function footballLiveCloseness(sport, gap, progress, context = null) {
        const points = Number(gap);
        if (!["NFL", "CFB"].includes(sport) || !Number.isFinite(points)) {
          return null;
        }
        const p = Math.max(
          0,
          Math.min(
            1,
            Number(progress) || 0
          )
        );
        const requiredPossessions = points <= 0 ? 0 : Math.ceil(
          points / 8
        );
        const fullGamePossessions = sport === "CFB" ? 12.5 : 10.5;
        let possessionAdjustment = 0;
        let possessionState = "";
        let fieldPosition = null;
        const competition = context?.competition || context || null;
        const situation = context?.situation || competition?.situation || {};
        const competitors = competition?.competitors || [];
        if (points > 0 && competitors.length === 2) {
          const scored = competitors.map((item) => ({
            item,
            score: Number(item?.score)
          })).filter(
            (item) => Number.isFinite(item.score)
          );
          if (scored.length === 2) {
            const trailing = scored[0].score < scored[1].score ? scored[0].item : scored[1].score < scored[0].score ? scored[1].item : null;
            const holderId = String(
              situation?.possession?.id || situation?.possession || ""
            );
            const trailingId = footballCompetitorId(
              trailing
            );
            if (trailing && holderId && trailingId) {
              if (holderId === trailingId) {
                possessionAdjustment += 0.45;
                possessionState = "trailing";
                const holderAbbr = footballCompetitorAbbreviation(
                  trailing
                );
                fieldPosition = footballSituationFieldPosition(
                  situation,
                  holderAbbr
                );
                if (fieldPosition !== null && fieldPosition >= 70) {
                  possessionAdjustment += 0.25;
                }
              } else if (p >= 0.9 && (sport !== "NFL" || competitors.some((item) => footballCompetitorId(item) === holderId))) {
                possessionAdjustment -= 0.35;
                possessionState = "leading";
              }
            }
          }
        }
        let expectedPossessions = Math.max(
          0,
          fullGamePossessions * (1 - p) + 0.5 + possessionAdjustment
        );
        const runway = sport === "NFL" ? footballClockRunway(competition, situation) : null;
        if (runway) expectedPossessions = runway.expectedPossessions;
        const possessionSlack = expectedPossessions - requiredPossessions;
        const comebackFeasibility = requiredPossessions === 0 ? 1 : 1 / (1 + Math.exp(
          -2 * (possessionSlack + 0.8)
        ));
        const marginClose = footballMarginCloseness(
          points
        );
        const close = marginClose * (0.45 + 0.55 * comebackFeasibility);
        return {
          close,
          marginClose,
          comebackFeasibility,
          requiredPossessions,
          expectedPossessions,
          possessionSlack,
          possessionAdjustment,
          possessionState,
          fieldPosition
        };
      }
      function footballTimeouts(competition, situation, team) {
        const value = situation?.[`${team?.homeAway}Timeouts`] ?? team?.timeouts;
        if (value === null || value === void 0 || value === "" || typeof value === "boolean") return null;
        const count = Number(value);
        return Number.isInteger(count) && count >= 0 && count <= 3 ? count : null;
      }
      function footballClockRunway(competition, situation = competition?.situation) {
        const status = competition?.status;
        const seconds = clockSeconds(status);
        if (Number(status?.period) !== 4 || seconds === null || seconds > 180) return null;
        const teams = competition?.competitors || [];
        if (teams.length !== 2 || teams.some((t) => t.score == null || !Number.isFinite(Number(t.score)))) return null;
        const trailing = teams.find((t) => Number(t.score) < Number(teams.find((other) => other !== t).score));
        const holder = teams.find((t) => footballCompetitorId(t) === String(situation?.possession?.id || situation?.possession || ""));
        if (!trailing || !holder || holder === trailing) return null;
        const timeouts = footballTimeouts(competition, situation, trailing);
        const down = Number(situation?.down);
        if (timeouts === null || down < 1 || down > 4 || !Number.isInteger(down)) return null;
        const snaps = 4 - down;
        const stops = timeouts + (seconds > 120 ? 1 : 0);
        const drain = 6 * snaps + 40 * Math.max(0, snaps - stops);
        const remaining = Math.max(0, seconds - drain - 8);
        return { timeouts, remaining, expectedPossessions: remaining === 0 ? 0 : Math.min(1.4, 0.25 + remaining / 100) };
      }
      function footballRunwayPenalty(gap, progress, footballState) {
        if (!footballState || gap === null || !Number.isFinite(Number(gap))) {
          return 0;
        }
        const points = Number(gap);
        const p = Math.max(
          0,
          Math.min(
            1,
            Number(progress) || 0
          )
        );
        const possessionMismatch = Math.max(
          0,
          footballState.requiredPossessions - footballState.expectedPossessions
        );
        const lowFeasibility = Math.max(
          0,
          0.55 - footballState.comebackFeasibility
        ) / 0.55;
        const runwayPenalty = points >= 9 ? lowFeasibility * 16 * (0.5 + 0.5 * p) + Math.min(
          8,
          possessionMismatch * 4
        ) : 0;
        const marginPenalty = points >= 17 ? Math.min(
          14,
          (points - 16) / 16 * 10 * (0.5 + 0.5 * p)
        ) : 0;
        return Math.min(
          28,
          Math.round(
            runwayPenalty + marginPenalty
          )
        );
      }
      function footballFieldPosition(game, holder, spot, downText) {
        const text = `${spot || ""} ${downText || ""}`.toUpperCase();
        const match = text.match(
          /\b([A-Z]{2,4})\s+(\d{1,2})\b/
        );
        if (!match) {
          return /\b50\b/.test(text) ? 50 : null;
        }
        const code = match[1];
        const yard = Number(match[2]);
        if (!Number.isFinite(yard) || yard < 0 || yard > 50) {
          return null;
        }
        const holderAbbr = String(
          holder?.[1] || ""
        ).toUpperCase();
        return code === holderAbbr ? yard : 100 - yard;
      }
      function nflOvertimeRules(competition, summary) {
        const season = { ...summary?.header?.season, ...competition?.season };
        const year = Number(season.year), seasonType = Number(season.type?.id ?? season.type);
        const postseason = seasonType === 3, regularSeason = seasonType === 2;
        const period = Number(competition?.status?.period);
        return {
          postseason,
          regularSeason,
          openingTouchdownWins: year > 0 && (regularSeason || postseason) && year < (postseason ? 2022 : 2025),
          clockExpired: regularSeason && period > 4 && (period > 5 || clockSeconds(competition?.status) === 0)
        };
      }
      function footballOvertimeResponse(sport, competition, summary) {
        const period = Number(competition?.status?.period);
        const situation = competition?.situation || {}, last = situation.lastPlay;
        if (!["CFB", "NFL"].includes(sport) || period <= 4 || competition?.status?.type?.completed || competition?.status?.type?.state === "post" || !last?.id || !(Number(last.scoreValue) > 0)) return null;
        const teams = competition?.competitors || [];
        if (teams.length !== 2 || teams.some((t) => t.score == null || t.score === "" || !Number.isFinite(Number(t.score)))) return null;
        const seen = /* @__PURE__ */ new Set();
        const completed = [...summary?.drives?.previous || [], ...summary?.drives?.current ? [summary.drives.current] : []].filter((d) => {
          const start = Number(d.start?.period?.number ?? d.plays?.[0]?.period?.number);
          if (d.isCurrent === true || !d.result || /end of|kickoff/i.test(d.result) || !(sport === "CFB" ? start === period : start > 4 && start <= period)) return false;
          const key = String(d.id || d.plays?.[0]?.id || "");
          if (!key || seen.has(key)) return false;
          seen.add(key);
          return d.plays?.some((p) => String(p.start?.team?.id || "") === String(d.team?.id || "") && p.start?.team?.id);
        });
        if (completed.length !== 1) return null;
        const drive = completed[0], first = drive.plays[0], end = drive.plays.at(-1);
        if (String(end?.id) !== String(last.id) || Number(end.period?.number) !== period || !/^(?:FG|TD|field goal|touchdown)$/i.test(drive.result) || first.homeScore == null || first.awayScore == null || Number(first.homeScore) !== Number(first.awayScore) || teams.some((t) => end[`${t.homeAway}Score`] == null || Number(end[`${t.homeAway}Score`]) !== Number(t.score))) return null;
        const scorer = teams.find((t) => footballCompetitorId(t) === String(drive.team?.id));
        const responder = teams.find((t) => t !== scorer);
        if (!scorer || !responder || String(last.team?.id || "") !== footballCompetitorId(scorer)) return null;
        const deficit = Number(scorer.score) - Number(responder.score);
        if (deficit <= 0 || deficit > 8) return null;
        const rules = nflOvertimeRules(competition, summary);
        if (sport === "NFL" && (rules.clockExpired || deficit >= 6 && rules.openingTouchdownWins)) return null;
        return { teamId: footballCompetitorId(responder), abbreviation: responder.team?.abbreviation || "", deficit };
      }
      function footballPendingTryImpact({ game, competition, status, situation, summary }) {
        const seconds = clockSeconds(status);
        const period = Number(status?.period);
        if (game.sport === "NFL" && period > 5 && nflOvertimeRules(competition, summary).regularSeason) return null;
        if (!["NFL", "CFB"].includes(game.sport) || game.state !== "live" || status?.type?.completed || status?.type?.state === "post" || !Number.isInteger(period) || period < 4 || period === 4 && (seconds === null || seconds < 0 || seconds > (game.sport === "CFB" ? 150 : 120))) return null;
        const play = situation?.lastPlay;
        if (Number(situation?.down) !== -1 || situation?.yardLine == null || Number(situation.yardLine) !== 0 || Number(play?.scoreValue) !== 6 || !/touchdown|\btd\b/i.test(`${play?.text || ""} ${play?.scoringType?.name || ""}`)) return null;
        const resolved = (p) => {
          const pat = p?.pointAfterAttempt;
          const text = `${p?.text || ""} ${p?.type?.text || ""}`;
          return pat?.id != null && Number(pat.id) !== 0 || /overturned|nullified|no play|no touchdown/i.test(text) || /\([^)]*\bkick\b[^)]*\)|\b(?:kick|pat|extra.point|two.point|2.pt|conversion)\b.*\b(?:good|failed|missed|blocked|successful|unsuccessful)\b/i.test(text);
        };
        if (resolved(play)) return null;
        const teams = competition?.competitors || [];
        const scorerId = String(play.team?.id || "");
        const offense = teams.find((t) => footballCompetitorId(t) === scorerId);
        const defense = teams.find((t) => t !== offense);
        const possession = String(situation.possession?.id || situation.possession || "");
        if (teams.length !== 2 || !scorerId || !offense || !defense || possession && possession !== scorerId || teams.some((t) => t.score == null || t.score === "" || !Number.isFinite(Number(t.score))) || Number(offense.score) < 6) return null;
        const deficit = Number(defense.score) - Number(offense.score);
        if (![0, 1, 2].includes(deficit)) return null;
        if (teams.some((t) => play[`${t.homeAway}Score`] != null && Number(play[`${t.homeAway}Score`]) !== Number(t.score))) return null;
        const drives = [...summary?.drives?.previous || [], ...summary?.drives?.current ? [summary.drives.current] : []];
        const allPlays = summary?.plays?.length ? summary.plays : drives.flatMap((d) => d.plays || []);
        const seen = /* @__PURE__ */ new Set();
        const plays = allPlays.filter((p) => {
          if (!p.id) return true;
          if (seen.has(String(p.id))) return false;
          seen.add(String(p.id));
          return true;
        });
        const index = play.id ? plays.findIndex((p) => String(p.id) === String(play.id)) : -1;
        const scoring = play.id ? (summary?.scoringPlays || []).find((p) => String(p.id) === String(play.id)) : null;
        if (resolved(scoring) || allPlays.some((p) => play.id && String(p.id) === String(play.id) && resolved(p)) || index >= 0 && plays.slice(index + 1).some((p) => !/timeout|review|end of (?:\d+(?:st|nd|rd|th)?\s+)?(?:quarter|period|game)/i.test(`${p.type?.text || ""} ${p.text || ""}`))) return null;
        const base = Number(game.baseScore);
        const consequence = game.sport === "CFB" ? deficit <= 1 ? 0.95 : 0.92 : deficit <= 1 ? 0.9 : 0.86;
        return {
          points: 12,
          competitiveFloor: Number.isFinite(base) ? Math.round(Math.max(0, 99 - base) * consequence) : 0,
          note: `${offense.team?.abbreviation || offense.team?.displayName || "Scoring team"} \xB7 Conversion try pending`,
          reasons: [deficit === 0 ? "Touchdown scored; the conversion try can win the game" : deficit === 1 ? "Touchdown scored; extra point can tie or two-point try can take the lead" : "Touchdown scored; a two-point try can tie the game"]
        };
      }
      function footballSituationImpact(game, competition, status, situation, progress, scoreGap, options = null) {
        const possessionId = String(
          situation.possession?.id || situation.possession || ""
        );
        const holder = game.teams.find(
          (team) => String(
            team[8] || ""
          ) === possessionId
        );
        const down = Number(
          situation.down
        );
        const distance = Number(
          situation.distance
        );
        const downText = String(
          situation.downDistanceText || situation.shortDownDistanceText || (down >= 1 && down <= 4 ? `${ordinal(down)} & ${Number.isFinite(distance) ? distance : "goal"}` : "")
        ).trim();
        const spot = String(
          situation.possessionText || ""
        ).trim();
        const redZone = situation.isRedZone === true || /\b(?:[A-Z]{2,4}\s)?(?:[1-9]|1\d|20)\b/.test(spot) && /red zone/i.test(
          String(
            situation.shortText || situation.text || ""
          )
        );
        const goalToGo = situation.isGoalToGo === true || /&\s*goal/i.test(downText);
        const fieldPosition = footballFieldPosition(
          game,
          holder,
          spot,
          downText
        );
        const lateOneScore = progress >= 0.72 && scoreGap <= 8;
        const competitive = scoreGap <= 14;
        const holderIndex = holder ? game.teams.indexOf(holder) : -1;
        const holderScore = Number(game.teams?.[holderIndex]?.[2]);
        const opponentScore = Number(game.teams?.[1 - holderIndex]?.[2]);
        const offenseTrailingOrTied = holderIndex >= 0 && Number.isFinite(holderScore) && Number.isFinite(opponentScore) && holderScore <= opponentScore;
        const offenseCanTieOrLead = offenseTrailingOrTied && holderScore + 7 >= opponentScore;
        const nfl = game.sport === "NFL";
        const seconds = clockSeconds(status);
        const period = Number(status?.period);
        const runway = nfl ? footballClockRunway({ ...competition, status }, situation) : null;
        let points = 0;
        let fourthPoints = 0;
        const reasons = [];
        if (redZone) {
          const goalLine = goalToGo && fieldPosition !== null && fieldPosition >= 95;
          const redZonePoints = offenseCanTieOrLead ? goalLine ? 5 : lateOneScore ? 4 : 3 : offenseTrailingOrTied ? goalLine ? 3 : 2 : 0;
          points += redZonePoints;
          if (redZonePoints) reasons.push(
            goalLine ? `${holder?.[0] || "The offense"} is goal-to-go at the doorstep` : `${holder?.[0] || "The offense"} is in the red zone`
          );
        }
        if (down === 4 && downText) {
          let fourth = 1;
          if (competitive && (redZone || fieldPosition > 50)) {
            fourth++;
          }
          if (competitive && Number.isFinite(distance) && distance <= 2) {
            fourth += 2;
          }
          if (lateOneScore) {
            fourth += 3;
          }
          if (competitive && redZone) {
            fourth += 1;
          } else if (competitive && fieldPosition !== null && fieldPosition >= 70) {
            fourth += 1;
          }
          if (competitive && goalToGo) {
            fourth += 2;
          }
          if (progress >= 0.9 && lateOneScore) {
            fourth += 2;
          }
          fourth = Math.min(
            10,
            fourth
          );
          if (nfl) {
            const urgent = period >= 4 && (period > 4 || seconds !== null && seconds <= 240);
            const liveDrive = offenseTrailingOrTied && scoreGap <= 8;
            fourth = urgent && liveDrive ? (seconds !== null && seconds <= 120 ? 10 : 7) + (fieldPosition >= 65 ? 1 : 0) : urgent && scoreGap <= 8 && holderIndex >= 0 ? runway?.remaining === 0 ? 2 : 6 : competitive ? Math.min(3, 1 + (distance > 0 && distance <= 2 ? 1 : 0) + (fieldPosition >= 70 ? 1 : 0)) : 1;
          }
          fourthPoints = fourth;
          points += fourth;
          reasons.push(
            fourth > 1 ? `${downText} is a pivotal down` : downText
          );
        }
        if (!redZone && fieldPosition !== null && fieldPosition >= 80 && scoreGap <= 8 && offenseTrailingOrTied) {
          points += 2;
          reasons.push(
            `${holder?.[0] || "The offense"} is deep in opponent territory`
          );
        }
        if (lateOneScore && !nfl) {
          points += progress >= 0.9 ? 4 : 2;
          reasons.push(
            `It is a one-possession game late in the ${Number(status?.period) >= 4 ? "fourth quarter" : "game"}`
          );
        }
        if (seconds !== null && Number(status?.period) >= 4 && seconds <= 120 && scoreGap <= 8 && !nfl) {
          points += 2;
          reasons.push(
            "The game is in a two-minute decision window"
          );
        }
        if (nfl && lateOneScore) {
          const direction = holderIndex < 0 ? 1 : offenseTrailingOrTied ? 4 : runway?.remaining === 0 ? 0 : 2;
          points = Math.max(points, direction);
          if (direction) reasons.push(offenseTrailingOrTied ? "A tying or winning possession is available late" : "A late one-possession game");
        }
        const decisiveDrive = Number(status?.period) >= 4 && holderIndex >= 0 && (nfl ? holderScore <= opponentScore : holderScore < opponentScore) && scoreGap <= 8;
        const clockUrgency = seconds === null || nfl && seconds <= 0 ? 0 : Math.max(0, Math.min(1, (240 - seconds) / 120));
        const driveUrgency = Number(status?.period) > 4 ? nfl ? options?.overtime?.canWin ? 1 : 0.35 : Math.max(0.6, seconds === null ? 1 : clockUrgency) : clockUrgency;
        let driveLeverage = null;
        if (decisiveDrive && driveUrgency > 0) {
          const positionBonus = goalToGo && fieldPosition >= 95 ? 3 : redZone ? 2 : fieldPosition >= (nfl && scoreGap <= 3 && (!options?.overtime?.active || options.overtime.fieldGoalWins) ? 58 : 70) ? 2 : fieldPosition > 50 ? 1 : 0;
          const drivePoints = Math.round(
            driveUrgency * ((nfl && scoreGap === 0 ? 10 : scoreGap >= 4 ? 9 : 8) + positionBonus)
          );
          driveLeverage = { urgency: driveUrgency, positionBonus };
          points = Math.max(points, drivePoints + Math.min(2, fourthPoints));
          reasons.push(
            `${holder?.[0] || "The trailing team"} has a ${scoreGap >= 4 ? "tying or winning TD" : !nfl ? "tying or winning score" : scoreGap === 0 ? "go-ahead scoring" : scoreGap === 3 ? "tying FG or winning TD" : "winning FG or TD"} drive in progress`
          );
        }
        if (nfl && situation.isTwoPointAttempt === true && holderIndex >= 0 && period >= 4 && (period > 4 || seconds !== null && seconds <= 180)) {
          const deficit = opponentScore - holderScore;
          if ([1, 2, 9, 10].includes(deficit)) {
            points = 12;
            driveLeverage = { urgency: 1, positionBonus: 2 };
            reasons.push(deficit === 1 ? "Two-point try to take the lead" : deficit === 2 ? "Two-point try to tie" : "Two-point try needed to stay within one possession");
          }
        }
        return {
          points: Math.min(
            12,
            points
          ),
          note: [
            holder ? `${holder[1] || holder[0]} ball` : "",
            downText,
            spot && !downText.includes(spot) ? spot : ""
          ].filter(Boolean).join(" \xB7 "),
          reasons,
          decisiveDrive: driveLeverage
        };
      }
      function footballMilestone(summary) {
        for (const block of summary?.boxscore?.players || []) {
          for (const group of block.statistics || []) {
            if (!/pass/i.test(
              group.name || group.displayName || ""
            )) {
              continue;
            }
            const touchdowns = (group.labels || []).findIndex(
              (label) => /^TD$|^PASS TD$/i.test(label)
            );
            if (touchdowns < 0) {
              continue;
            }
            const passer = (group.athletes || []).filter(
              (entry) => Number(
                entry.stats?.[touchdowns]
              ) >= 3
            ).sort(
              (a, b) => Number(b.stats?.[touchdowns]) - Number(a.stats?.[touchdowns])
            )[0];
            if (passer) {
              const count = Number(
                passer.stats[touchdowns]
              );
              return {
                text: `${passer.athlete?.displayName || "A quarterback"} has thrown ${count} touchdown passes`,
                points: count >= 5 ? 12 : count >= 4 ? 8 : 5
              };
            }
          }
        }
        return null;
      }
      function footballGameState({ sport, gameState, gap, progress, context: footballContext }) {
        const footballState = ["NFL", "CFB"].includes(sport) && gameState === "live" ? footballLiveCloseness(
          sport,
          gap,
          progress,
          footballContext
        ) : null;
        return {
          footballState,
          marginClose: footballState?.close,
          comebackViability: footballState?.comebackFeasibility,
          widePenalty: footballState ? footballRunwayPenalty(gap, progress, footballState) : void 0,
          limitedRunway: Boolean(footballState)
        };
      }
      function footballEventShock({ text, positioned, i, play }) {
        let value = 0;
        let label = "";
        if (/touchdown|\btd\b/.test(text) && /\b(?:[4-9]\d|1\d\d)[ -]?(?:yard|yd)s?\b/.test(text)) {
          value = 5;
          label = "40-plus-yard touchdown";
        }
        return value ? { value, label } : null;
      }
      function footballSituation2({ game, competition, status, situation, progress, scoreGap }) {
        return footballSituationImpact(game, competition, status, situation, progress, scoreGap);
      }
      const api = { defensiveFinishFactor, footballStagnationImpact, footballMarginCloseness, footballCompetitorId, footballCompetitorAbbreviation, footballSituationFieldPosition, footballLiveCloseness, footballRunwayPenalty, footballFieldPosition, footballSituationImpact, nflOvertimeRules, footballOvertimeResponse, footballPendingTryImpact, footballMilestone, footballGameState, footballEventShock, footballSituation: footballSituation2, footballTimeouts, footballClockRunway };
      if (typeof module2 !== "undefined" && module2.exports) {
        module2.exports = api;
      } else {
        (root.SportsRadarScoring ||= {}).shared_football = api;
      }
    })(globalThis);
  }
});

// scoring/sports/nfl.js
var require_nfl = __commonJS({
  "scoring/sports/nfl.js"(exports2, module2) {
    (function(root) {
      const { NFL_DIVISIONS } = typeof module2 !== "undefined" && module2.exports ? require_config() : root.SportsRadarScoring.shared_config;
      const { recordStats } = typeof module2 !== "undefined" && module2.exports ? require_records() : root.SportsRadarScoring.shared_records;
      const { nflEvidenceFactors, nflRecordAssessment, nflMarketInteraction } = typeof module2 !== "undefined" && module2.exports ? require_nfl_pregame() : root.SportsRadarScoring.shared_nfl_pregame;
      const { parseLine: parseLine2 } = typeof module2 !== "undefined" && module2.exports ? require_market() : root.SportsRadarScoring.shared_market;
      const { listedSpread, footballPregameSpread, footballSpreadAdjustment } = typeof module2 !== "undefined" && module2.exports ? require_market() : root.SportsRadarScoring.shared_market;
      const { footballGameState, footballSituationImpact, nflOvertimeRules, footballOvertimeResponse, footballPendingTryImpact, footballMilestone, footballEventShock, footballStagnationImpact, footballFieldPosition, footballClockRunway } = typeof module2 !== "undefined" && module2.exports ? require_football() : root.SportsRadarScoring.shared_football;
      const { clockSeconds } = typeof module2 !== "undefined" && module2.exports ? require_time() : root.SportsRadarScoring.shared_time;
      function nflOvertime(competition, summary) {
        const period = Number(competition?.status?.period);
        const rules = nflOvertimeRules(competition, summary);
        const ordinary = { active: period > 4, suddenDeath: false, canWin: false, canTie: false, fieldGoalWins: false, clockExpired: rules.clockExpired };
        if (!ordinary.active) return ordinary;
        const explicitTry = competition?.situation?.isTwoPointAttempt === true;
        if (competition?.status?.type?.completed || competition?.status?.type?.state === "post" || rules.clockExpired && !explicitTry) return ordinary;
        const holder = String(competition?.situation?.possession?.id || competition?.situation?.possession || "");
        const teams = competition?.competitors || [];
        const offense = teams.find((t) => String(t.team?.id || t.id || "") === holder);
        const defense = teams.find((t) => t !== offense);
        if (!holder || teams.length !== 2 || !offense || !defense || teams.some((t) => t.score == null || t.score === "" || typeof t.score === "boolean" || !Number.isFinite(Number(t.score)))) return ordinary;
        const deficit = Number(defense.score) - Number(offense.score);
        if (!Number.isFinite(deficit)) return ordinary;
        const seen = /* @__PURE__ */ new Set();
        const completed = [...summary?.drives?.previous || [], ...summary?.drives?.current ? [summary.drives.current] : []].filter((d) => {
          const plays2 = d.plays || [];
          const startPeriod = Number(d.start?.period?.number ?? plays2[0]?.period?.number);
          return startPeriod > 4 && startPeriod <= period && d.isCurrent !== true && d.result && !/end of|kickoff/i.test(d.result) && plays2.some((p) => String(p.start?.team?.id || "") === String(d.team?.id || "") && p.start?.team?.id && !/kickoff|timeout|end of/i.test(p.type?.text || p.text || ""));
        }).filter((d) => {
          if (!d.id) return true;
          if (seen.has(String(d.id))) return false;
          seen.add(String(d.id));
          return true;
        });
        const possessed = new Set(completed.map((d) => String(d.team?.id || "")));
        const plays = summary?.plays?.length ? summary.plays : [...summary?.drives?.previous || [], ...summary?.drives?.current ? [summary.drives.current] : []].flatMap((d) => d.plays || []);
        const recoveredKicks = /* @__PURE__ */ new Set();
        for (const play of plays) {
          if (!(Number(play.period?.number) > 4 && Number(play.period?.number) <= period) || /overturned|nullified|no play/i.test(play.text || "")) continue;
          const startId = String(play.start?.team?.id || ""), endId = String(play.end?.team?.id || "");
          if (!teams.some((t) => String(t.team?.id || t.id || "") === startId) || !teams.some((t) => String(t.team?.id || t.id || "") === endId)) continue;
          if (play.isTurnover === true && startId !== endId) possessed.add(endId);
          if (/kickoff/i.test(play.type?.text || "") && /recover/i.test(play.text || "") && startId === endId) {
            teams.filter((t) => String(t.team?.id || t.id || "") !== startId).forEach((t) => possessed.add(String(t.team?.id || t.id)));
            if (play.id) recoveredKicks.add(String(play.id));
          }
        }
        const last = competition?.situation?.lastPlay;
        const terminal = last?.id ? plays.find((p) => String(p.id) === String(last.id)) : null;
        const matches = terminal && teams.every((t) => terminal[`${t.homeAway}Score`] != null && Number(terminal[`${t.homeAway}Score`]) === Number(t.score));
        const closed = last?.id && completed.some((d) => String(d.plays?.at(-1)?.id) === String(last.id));
        const pendingTry = explicitTry || closed && footballPendingTryImpact({
          game: { sport: "NFL", state: "live", baseScore: 0 },
          competition,
          status: competition.status,
          situation: competition.situation,
          summary
        });
        const safety = matches && terminal.scoringPlay === true && /\bsafety\b/i.test(`${terminal.type?.text || ""} ${terminal.text || ""}`);
        if (deficit !== 0 && matches && !pendingTry && (safety || possessed.size === 2 && (closed || recoveredKicks.has(String(last?.id))))) return { ...ordinary, resolved: true };
        const otherHadBall = possessed.has(String(defense.team?.id || defense.id || ""));
        const suddenDeath = deficit === 0 && otherHadBall;
        const canWin = explicitTry ? deficit >= 0 && deficit <= 1 : deficit >= 0 && deficit <= 7 && (otherHadBall || rules.openingTouchdownWins);
        return {
          ...ordinary,
          suddenDeath,
          canWin,
          canTie: explicitTry ? deficit === 2 : deficit > 0 && deficit <= 8 && otherHadBall,
          fieldGoalWins: !explicitTry && deficit >= 0 && deficit < 3 && otherHadBall
        };
      }
      function nflSituation(args) {
        args = { ...args, competition: { ...args.competition, season: { ...args.game.sourceEvent?.season, ...args.competition?.season } } };
        const pendingTry = footballPendingTryImpact(args);
        if (pendingTry) return pendingTry;
        const response = footballOvertimeResponse("NFL", { ...args.competition, status: args.status, situation: args.situation }, args.summary);
        if (response) return {
          points: 12,
          competitiveFloor: Math.round(Math.max(0, 99 - Number(args.game.baseScore || 0)) * 0.86),
          note: `${response.abbreviation || "Opponent"} overtime response pending`,
          reasons: ["The opening overtime score does not end the game; the opponent still has a response possession"]
        };
        const overtime = nflOvertime(args.competition, args.summary);
        if (overtime.resolved) return { points: 0, competitiveFloor: 0, note: "Overtime result awaiting confirmation", reasons: [] };
        if (overtime.clockExpired && args.situation.isTwoPointAttempt !== true)
          return { points: 0, competitiveFloor: 0, note: "Overtime clock expired", reasons: [] };
        const result = footballSituationImpact(args.game, args.competition, args.status, args.situation, args.progress, args.scoreGap, { overtime });
        const { game, competition, status, situation, scoreGap } = args;
        const holderId = String(situation.possession?.id || situation.possession || "");
        const holder = game.teams.find((team) => String(team[8] || "") === holderId);
        const opponent = game.teams.find((team) => team !== holder);
        const deficit = holder && opponent ? Number(opponent[2]) - Number(holder[2]) : NaN;
        const seconds = clockSeconds(status);
        const regulation = Number(status?.period) === 4;
        const criticalTry = situation.isTwoPointAttempt === true && [1, 2].includes(deficit) && regulation && seconds !== null && seconds >= 0 && seconds <= 120;
        const base = Number(game.baseScore);
        const overtimeOpportunity = overtime.active && (overtime.canWin || overtime.canTie);
        if (Number.isFinite(base) && (criticalTry || overtimeOpportunity || regulation && seconds > 0 && seconds <= 180 && result.decisiveDrive && deficit >= 0 && deficit <= 8)) {
          const position = footballFieldPosition(
            game,
            holder,
            situation.possessionText,
            situation.downDistanceText || situation.shortDownDistanceText
          );
          const goal = (situation.isGoalToGo === true || /&\s*goal/i.test(situation.downDistanceText || situation.shortDownDistanceText || "")) && position !== null && position >= 90;
          const territory = position === null ? 0 : Math.max(0, Math.min(1, (position - 25) / 55));
          const winningRange = deficit < 3 && position !== null && position >= 58;
          let consequence = winningRange ? 0.8 : 0.7 + 0.06 * territory;
          const afterFailure = footballClockRunway(
            { ...competition, status },
            { ...situation, possession: opponent?.[8], down: 1 }
          );
          const finalFourth = Number(situation.down) === 4 && deficit > 0 && (afterFailure ? afterFailure.remaining <= 15 : seconds <= 60);
          if (finalFourth) {
            const distance = Number(situation.distance);
            const shortness = Number.isFinite(distance) && distance > 0 ? Math.max(0, Math.min(1, (10 - distance) / 9)) : 0;
            consequence = Math.max(consequence, 0.82 + 0.04 * shortness);
          }
          if (goal) consequence = Math.max(consequence, 0.86);
          if (criticalTry) consequence = deficit === 1 ? 0.9 : 0.86;
          if (overtimeOpportunity) consequence = Math.max(consequence, situation.isTwoPointAttempt === true ? deficit <= 1 ? 0.9 : 0.86 : 0.86);
          const yardsNeeded = position === null ? 75 : Math.max(0, (scoreGap <= 3 ? 65 : 100) - position);
          const viability = criticalTry || goal || overtimeOpportunity && (nflOvertimeRules(competition, args.summary).postseason || situation.isTwoPointAttempt === true) ? 1 : Math.min(1, Math.max(0, seconds || 0) / (8 + 0.65 * yardsNeeded));
          const urgency = criticalTry || overtimeOpportunity ? 1 : result.decisiveDrive.urgency;
          result.competitiveFloor = Math.round(Math.max(0, 99 - base) * consequence * urgency * viability);
        }
        if (overtime.canWin) result.reasons.push(overtime.suddenDeath ? "Sudden-death overtime: next score wins" : "This overtime possession can win the game");
        else if (overtime.canTie) result.reasons.push("This overtime possession can tie the game");
        return result;
      }
      function nflGameState(args) {
        const result = footballGameState(args);
        if (args.gameState !== "live" || !result.footballState || args.gap == null || !Number.isFinite(args.gap) || args.gap < 0 || args.gap > 8 || args.progress < 0.75) return result;
        const competition = args.context?.competition || args.context;
        const status = competition?.status;
        const seconds = clockSeconds(status);
        const overtime = nflOvertime(competition, args.context?.summary);
        const state = result.footballState;
        const urgency = Number(status?.period) === 4 && seconds !== null ? seconds > 0 ? Math.max(0, Math.min(1, (600 - seconds) / 480)) : 0 : overtime.canWin ? 1 : 0;
        const directional = args.gap === 0 || state.possessionState === "trailing" ? 1 : state.possessionState === "leading" ? state.comebackFeasibility * 0.4 : 0.2;
        result.closeCeiling = 14 + 16 * Math.max(0, Math.min(1, args.progress)) + 12 * urgency * directional;
        return result;
      }
      function nflDivisionFor(competitors) {
        const divisions = competitors.map(
          (item) => NFL_DIVISIONS[String(
            item.team?.abbreviation || ""
          ).toUpperCase()]
        );
        return divisions.length === 2 && divisions[0] && divisions[0] === divisions[1] ? divisions[0] : "";
      }
      function nflSpreadPoints(spread) {
        return footballSpreadAdjustment("NFL", spread);
      }
      function unbeatenStartImpact2(sport, gameState, teams) {
        if (sport !== "NFL" || gameState !== "completed" || teams.length !== 2) return 0;
        const scores = teams.map((team) => Number(team.score ?? team[2]));
        if (!scores.every(Number.isFinite) || scores[0] === scores[1]) return 0;
        const loser = teams[scores[0] < scores[1] ? 0 : 1];
        const record = String(loser.pregameRecord || "").match(/^(\d+)-(\d+)(?:-(\d+))?$/);
        if (!record || Number(record[1]) < 4 || Number(record[2]) !== 0) return 0;
        return Math.round(Math.min(10, 4 + 0.75 * (Number(record[1]) - 4)));
      }
      function nflPregame(sport, competition, competitors, postseason, factors, reason, detail, options = {}) {
        if (sport === "NFL") {
          const factorStart = factors.length;
          const spread = options.calibratedPregame ? footballPregameSpread(competition) : listedSpread(competition);
          const marketKnown = options.calibratedPregame && spread !== null;
          const division = nflDivisionFor(
            competitors
          );
          const records = competitors.map(
            recordStats
          );
          const knownRecords = !postseason && records.length === 2 && records.every(Boolean);
          const bothWinning = knownRecords && records.every(
            (record) => record.pct > 0.5
          );
          const recordAssessment = options.calibratedPregame && knownRecords ? nflRecordAssessment(competition, records) : null;
          if (division) {
            factors.push({
              label: `${division} matchup`,
              points: 4
            });
            if (bothWinning && !marketKnown && !options.calibratedPregame) {
              factors.push({
                label: "Division race between winning teams",
                points: 3
              });
            }
            reason += ` \xB7 ${division} rivals`;
          }
          if (recordAssessment) {
            if (recordAssessment.positive) factors.push({
              label: bothWinning ? "Both winning records" : "Winning team quality",
              points: recordAssessment.positive,
              ...!bothWinning ? { detail: "Single winning-team interest; capped at two before market scaling" } : {}
            });
            if (recordAssessment.penalty) factors.push({
              label: "Graduated losing-record penalty",
              points: recordAssessment.penalty,
              recordSeverity: recordAssessment.severity,
              performanceRelief: recordAssessment.relief,
              detail: `Records ${records.map((r) => `${r.wins}-${r.losses} (${Math.round(r.pct * 100)}%)`).join(" and ")} set the deduction${recordAssessment.relief > 0 ? "; season scoring margins soften it" : ""}`
            });
          } else if (bothWinning) {
            factors.push({
              label: "Both winning records",
              points: 14
            });
            if (!marketKnown && Math.abs(
              records[0].pct - records[1].pct
            ) <= 0.1) {
              factors.push({
                label: "Evenly matched winning records",
                points: 4
              });
            }
            reason += " \xB7 both teams winning";
          } else if (knownRecords && records.every(
            (record) => record.pct >= 0.5
          )) {
            factors.push({
              label: "Both teams at least .500",
              points: 5
            });
          } else if (knownRecords && records.every(
            (record) => record.pct < 0.5
          )) {
            factors.push({
              label: "Both teams below .500",
              points: -7
            });
          }
          if (knownRecords && records.some(
            (record) => record.wins === 0 && record.games >= 3
          ) && !recordAssessment) {
            factors.push({
              label: "Winless team",
              points: -5
            });
          }
          if (knownRecords && records.some(
            (record) => record.losses === 0 && record.games >= 3
          )) {
            factors.push({
              label: "Unbeaten team",
              points: 7
            });
          }
          const spreadPoints = spread === null ? 0 : options.calibratedPregame ? nflSpreadPoints(spread) : Math.round(7 * Math.exp(-((spread / 7.5) ** 2)));
          if (marketKnown) {
            const retention = 0.5 + 0.5 * Math.max(0, Math.min(1, (21 - spread) / 14));
            for (const factor of factors.slice(factorStart)) {
              if (["Both winning records", "Both teams at least .500", "Unbeaten team", "Winning team quality"].includes(factor.label)) factor.points = Number((factor.points * retention).toFixed(2));
            }
            if (factors.slice(factorStart).some((factor) => factor.label === "Both teams below .500")) {
              const index = factors.findIndex((factor, i) => i >= factorStart && factor.label === "Winless team");
              if (index >= 0) factors.splice(index, 1);
            }
          }
          if (spreadPoints) {
            const tight = options.calibratedPregame ? spread <= 3.5 : spreadPoints >= 5;
            factors.push({
              label: spreadPoints < 0 ? "Projected spread mismatch" : tight ? "Tight projected spread" : options.calibratedPregame ? spread > 7 ? "Substantial projected favorite" : "Moderate projected favorite" : "Competitive projected spread",
              points: Number(spreadPoints.toFixed(2)),
              ...options.calibratedPregame ? { detail: `Listed ${spread}-point spread; ${spreadPoints < 0 ? "projected mismatch lowers" : "projected competitiveness raises"} excitement` } : {}
            });
            reason += spreadPoints < 0 ? " \xB7 projected mismatch" : tight ? " \xB7 close line" : options.calibratedPregame ? spread > 7 ? " \xB7 substantial favorite" : " \xB7 moderate favorite" : " \xB7 competitive line";
          }
          if (options.calibratedPregame && !postseason) {
            const evidence = nflEvidenceFactors(competition, records, division);
            factors.push(...evidence);
            if (evidence.some((f) => /Division lead|Division race/.test(f.label))) reason += " \xB7 verified division positioning";
            const total = parseLine2(competition?.odds?.[0], competition, "NFL")?.total;
            if (total > 46 && total <= 100) factors.push({
              label: "Expected scoring potential",
              points: Number(Math.min(5, (total - 46) / 2).toFixed(2)),
              detail: `Listed total ${total}; capped at five points`
            });
            const interaction = nflMarketInteraction(spread, total);
            if (interaction) factors.push({
              label: "Close-game scoring upside",
              points: interaction,
              detail: `A ${spread}-point spread and ${total} total jointly add entertainment upside; capped at three points`
            });
          }
        }
        return reason;
      }
      const nflModel = {
        prepareCompetition: (competition, event) => ({ ...competition, season: { ...event?.season, ...competition?.season } }),
        pregame: nflPregame,
        gameState: nflGameState,
        situation: nflSituation,
        milestone: footballMilestone,
        completedResult: (sport, gameState, teams) => ({
          label: "Ended unbeaten start",
          points: unbeatenStartImpact2(sport, gameState, teams)
        }),
        eventShock: footballEventShock,
        history: { threshold: 7, units: "points", stagnation: footballStagnationImpact }
      };
      const api = { nflDivisionFor, nflSpreadPoints, unbeatenStartImpact: unbeatenStartImpact2, nflPregame, nflModel, nflOvertime };
      if (typeof module2 !== "undefined" && module2.exports) {
        module2.exports = api;
      } else {
        (root.SportsRadarScoring ||= {}).sports_nfl = api;
      }
    })(globalThis);
  }
});

// scoring/shared/pregame.js
var require_pregame = __commonJS({
  "scoring/shared/pregame.js"(exports2, module2) {
    (function(root) {
      const { pregameMarketFactor } = typeof module2 !== "undefined" && module2.exports ? require_market() : root.SportsRadarScoring.shared_market;
      const { proRecordFactors, divisionFor } = typeof module2 !== "undefined" && module2.exports ? require_records() : root.SportsRadarScoring.shared_records;
      function marketPregame(sport, competition, factors, reason, options = {}) {
        if (["MLB", "NHL", "NBA", "CFB", "NCAAB"].includes(sport)) {
          const market = pregameMarketFactor(
            sport,
            competition,
            options
          );
          if (market) {
            factors.push(market);
            reason += market.points < 0 ? " \xB7 projected mismatch" : market.points >= 5 ? " \xB7 near pick\u2019em" : " \xB7 competitive market";
          }
        }
        return reason;
      }
      function proPregame(sport, competition, competitors, postseason, factors, reason, detail) {
        if (["MLB", "NHL", "NBA"].includes(sport)) {
          const recordFactors = postseason ? [] : proRecordFactors(
            sport,
            competitors
          );
          factors.push(
            ...recordFactors
          );
          const division = divisionFor(
            sport,
            competitors
          );
          const bothWinning = recordFactors.some(
            (item) => item.label === "Both winning records"
          );
          if (division) {
            factors.push({
              label: `${division} matchup`,
              points: 3
            });
            const meaningfulDivisionRace = bothWinning && /playoff|postseason|wild card|race|elimination|clinching/.test(detail);
            if (meaningfulDivisionRace) {
              factors.push({
                label: "Division matchup between winning teams",
                points: 2
              });
            }
            reason += ` \xB7 ${division} matchup`;
          }
          if (bothWinning) {
            reason += " \xB7 both teams winning";
          }
        }
        return marketPregame(sport, competition, factors, reason);
      }
      const api = { marketPregame, proPregame };
      if (typeof module2 !== "undefined" && module2.exports) {
        module2.exports = api;
      } else {
        (root.SportsRadarScoring ||= {}).shared_pregame = api;
      }
    })(globalThis);
  }
});

// scoring/sports/mlb.js
var require_mlb = __commonJS({
  "scoring/sports/mlb.js"(exports2, module2) {
    (function(root) {
      const { proPregame } = typeof module2 !== "undefined" && module2.exports ? require_pregame() : root.SportsRadarScoring.shared_pregame;
      function mlbLiveMarginCloseness(gap, progress) {
        if (gap === null || !Number.isFinite(Number(gap))) return 0;
        const p = Math.max(0, Math.min(1, Number(progress) || 0));
        const tolerance = 6.5 - 3.6 * p;
        return Math.max(0, 1 - Number(gap) / tolerance);
      }
      function runnerOn(situation, base) {
        const value = situation?.[`on${base}`] ?? situation?.runners?.[base.toLowerCase()];
        return value === void 0 || value === null ? null : Boolean(value);
      }
      function sideScores(game, competition) {
        const byId = new Map(
          game.teams.map(
            (team) => [
              String(
                team[8] || ""
              ),
              Number(team[2])
            ]
          )
        );
        const result = {};
        for (const item of competition?.competitors || []) {
          const side = item.homeAway;
          const id = String(
            item.team?.id || item.id || ""
          );
          const direct = Number(
            item.score
          );
          const fallback = byId.get(id);
          if (side) {
            result[side] = Number.isFinite(direct) ? direct : fallback;
          }
        }
        return result;
      }
      function baseballSituationImpact(game, competition, status, situation, progress, scoreGap) {
        const bases = {
          first: runnerOn(
            situation,
            "First"
          ),
          second: runnerOn(
            situation,
            "Second"
          ),
          third: runnerOn(
            situation,
            "Third"
          )
        };
        const occupied = Object.entries(bases).filter(
          ([, value]) => value
        ).map(
          ([base]) => base
        );
        const outs = Number(
          situation.outs
        );
        const hasOuts = situation.outs !== void 0 && situation.outs !== null && Number.isInteger(outs) && outs >= 0 && outs <= 2;
        const inning = Number(
          status?.period || 0
        );
        const detail = String(
          status?.type?.detail || status?.type?.shortDetail || ""
        ).toLowerCase();
        const half = /bottom|bot\b/.test(detail) ? "bottom" : /top\b/.test(detail) ? "top" : "";
        const battingSide = half === "bottom" ? "home" : half === "top" ? "away" : "";
        const scores = sideScores(
          game,
          competition
        );
        const battingScore = battingSide ? Number(
          scores[battingSide]
        ) : NaN;
        const fieldingScore = battingSide ? Number(
          scores[battingSide === "home" ? "away" : "home"]
        ) : NaN;
        const differential = Number.isFinite(battingScore) && Number.isFinite(fieldingScore) ? battingScore - fieldingScore : null;
        const countText = String(situation.count || `${situation.balls ?? ""}-${situation.strikes ?? ""}`);
        const fullCount = /^3-2$/.test(countText.trim());
        if (Number.isFinite(outs) && outs >= 3) {
          return { points: 0, note: "3 outs", reasons: [], bases, competitiveFloor: 0 };
        }
        let points = 0;
        const reasons = [];
        if (occupied.length) {
          const occupiedText = occupied.length === 3 ? `${occupied[0]}, ${occupied[1]}, and ${occupied[2]}` : occupied.join(" and ");
          reasons.push(
            `Runners on ${occupiedText}`
          );
        }
        if (occupied.length === 3) {
          points += scoreGap <= 2 ? inning >= 7 ? 4 : 2 : scoreGap <= 4 ? 1 : 0;
          if (scoreGap <= 4) reasons.push("The bases are loaded");
        }
        if ((bases.second || bases.third) && inning >= 7 && scoreGap <= 2 && differential !== null && differential <= 0) {
          points += inning >= 9 ? 6 : 4;
          reasons.push(
            "The tying or go-ahead run is in scoring position late"
          );
        }
        if (bases.third && inning >= 9 && scoreGap <= 1) {
          points += 2;
          reasons.push(
            "A critical run is 90 feet away"
          );
        }
        if (half === "bottom" && inning >= 9 && differential === 0) {
          points += 7;
          reasons.push(
            "The home team has a walk-off opportunity"
          );
        } else if (half === "bottom" && inning >= 9 && differential === -1 && occupied.length) {
          points += 5;
          reasons.push(
            "The tying run is on base in the bottom of the ninth or later"
          );
        }
        if (hasOuts && outs === 2 && occupied.length && inning >= 7 && scoreGap <= 2) {
          points += 2;
          reasons.push(
            "The inning has reached a two-out pressure spot"
          );
        }
        if (inning >= 7 && scoreGap <= 2 && hasOuts && outs === 2 && fullCount) {
          points += 3;
          reasons.push("A full count with two outs raises the plate appearance leverage");
        }
        if (inning >= 7 && scoreGap <= 2 && differential !== null && differential <= 0) {
          if (differential === 0) {
            points += occupied.length ? 3 : 4;
            reasons.push(occupied.length ? "The go-ahead run is on base" : "The go-ahead run is at the plate");
          } else {
            const runsToTie = Math.abs(differential);
            if (occupied.length >= runsToTie) {
              points += 3;
              reasons.push("The tying run is on base");
            } else if (occupied.length + 1 === runsToTie) {
              points += 4;
              reasons.push("The tying run is at the plate");
            } else if (occupied.length + 2 === runsToTie && (situation.onDeck || situation.onDeckBatter || situation.nextBatter)) {
              points += 2;
              reasons.push("The tying run is on deck");
            }
          }
        }
        const decisivePlateAppearance = inning >= 9 && (half === "bottom" || half === "top" && differential < 0) && differential !== null && differential <= 0 && -differential <= occupied.length + 1 && scoreGap <= 3;
        const competitiveFloor = decisivePlateAppearance ? Math.min(20, 15 + (hasOuts && outs === 2 ? 2 : 0) + (fullCount ? 2 : 0) + (occupied.length ? 1 : 0) + (bases.second || bases.third ? 1 : 0)) : 0;
        return {
          points: Math.min(
            12,
            points
          ),
          note: hasOuts ? `${outs} ${outs === 1 ? "out" : "outs"}` : "",
          reasons,
          bases,
          competitiveFloor
        };
      }
      function noHitBid(summary) {
        const competitors = summary?.header?.competitions?.[0]?.competitors || [];
        for (const block of summary?.boxscore?.players || []) {
          const opponent = competitors.find(
            (item) => String(
              item.team?.id || ""
            ) !== String(
              block.team?.id || ""
            )
          );
          if (!opponent || Number(opponent.hits) !== 0 || opponent.hits == null) {
            continue;
          }
          for (const group of block.statistics || []) {
            const labels = group.labels || [];
            const innings = labels.indexOf("IP");
            const hits = labels.indexOf("H");
            if (innings < 0 || hits < 0) {
              continue;
            }
            const pitcher = (group.athletes || []).find(
              (entry) => Number.parseFloat(
                entry.stats?.[innings]
              ) >= 6 && Number(
                entry.stats?.[hits]
              ) === 0
            );
            if (pitcher) {
              return {
                text: `${pitcher.athlete?.displayName || "A pitcher"} has thrown ${Math.floor(Number.parseFloat(pitcher.stats[innings]))} hitless innings in a no-hit bid`,
                points: 14
              };
            }
          }
        }
        return null;
      }
      function baseballPerformanceMilestone(summary) {
        const candidates = [];
        const noHit = noHitBid(summary);
        if (noHit) {
          candidates.push(noHit);
        }
        for (const block of summary?.boxscore?.players || []) {
          for (const group of block.statistics || []) {
            const labels = group.labels || [];
            const homeRuns = labels.findIndex(
              (label) => /^HR$|^HOME RUNS$/i.test(label)
            );
            const strikeouts = labels.findIndex(
              (label) => /^K$|^SO$|^STRIKEOUTS$/i.test(label)
            );
            for (const entry of group.athletes || []) {
              const name = entry.athlete?.displayName || "A player";
              if (homeRuns >= 0) {
                const count = Number(
                  entry.stats?.[homeRuns]
                );
                if (count >= 2) {
                  candidates.push({
                    text: count >= 3 ? `${name} has hit ${count} home runs` : `${name} has hit 2 home runs and is one away from a rare three-homer game`,
                    points: count >= 4 ? 14 : count >= 3 ? 12 : 6
                  });
                }
              }
              if (strikeouts >= 0 && /pitch/i.test(
                `${group.name || ""} ${group.displayName || ""}`
              )) {
                const count = Number(
                  entry.stats?.[strikeouts]
                );
                if (count >= 10) {
                  candidates.push({
                    text: `${name} has struck out ${count} batters`,
                    points: count >= 15 ? 12 : 7
                  });
                }
              }
            }
          }
        }
        return candidates.sort(
          (a, b) => b.points - a.points
        )[0] || null;
      }
      function baseballGameState({ sport, gameState, gap, progress, context: footballContext }) {
        const liveSituation = footballContext?.situation || footballContext?.competition?.situation || {};
        const liveStatus = footballContext?.competition?.status || {};
        const inning = Number(liveStatus.period || liveStatus.inning || 0);
        const inningHalf = String(liveSituation.halfInning || liveSituation.inningHalf || liveSituation.lastPlay?.type?.text || `${liveStatus.type?.detail || ""} ${liveStatus.type?.shortDetail || ""}`).toLowerCase();
        const homeTrailing = Array.isArray(footballContext?.teams) && footballContext.teams.length === 2 && Number(footballContext.teams[0][2]) < Number(footballContext.teams[1][2]);
        const guaranteedMlbAtBat = sport === "MLB" && inning >= 8 && (homeTrailing && /bottom|middle|home/.test(inningHalf) || !homeTrailing && /top|away/.test(inningHalf));
        return {
          marginClose: gameState === "live" ? mlbLiveMarginCloseness(gap, progress) : void 0,
          minimumComebackViability: guaranteedMlbAtBat ? 0.9 : 0
        };
      }
      function baseballEventShock({ text, positioned, i, play }) {
        let value = 0;
        let label = "";
        if (/\bhome run\b/.test(text) && (/\b(?:tying|go[- ]ahead|game[- ]tying|takes the lead|puts .* ahead)\b.{0,45}\bhome run\b|\bhome run\b.{0,45}\b(?:ties|takes the lead|goes ahead|go[- ]ahead)\b/.test(text) || (() => {
          const before = positioned.slice(0, i).reverse().find((item) => Number.isFinite(Number(item.play.homeScore)) && Number.isFinite(Number(item.play.awayScore)));
          const afterHome = Number(play.homeScore);
          const afterAway = Number(play.awayScore);
          if (!before || !Number.isFinite(afterHome) || !Number.isFinite(afterAway)) return false;
          const beforeMargin = Number(before.play.homeScore) - Number(before.play.awayScore);
          const afterMargin = afterHome - afterAway;
          return afterMargin === 0 || beforeMargin === 0 || beforeMargin * afterMargin < 0;
        })())) {
          value = 6;
          label = "Tying or go-ahead home run";
        }
        return value ? { value, label } : null;
      }
      const mlbModel = {
        unit: "run",
        duration: 180,
        inningEventAge: true,
        postseasonScarcity: 6,
        championshipContext: true,
        pregame: proPregame,
        gameState: baseballGameState,
        situation: ({ game, competition, status, situation, progress, scoreGap }) => baseballSituationImpact(game, competition, status, situation, progress, scoreGap),
        milestone: baseballPerformanceMilestone,
        earlyEventShock: baseballEventShock,
        contextAnchors: (championship) => championship ? [[0, 0.58], [0.25, 0.5], [0.5, 0.4], [0.75, 0.3], [0.9, 0.24], [1, 0.22]] : null,
        history: { threshold: 3, units: "runs" }
      };
      const api = { mlbLiveMarginCloseness, runnerOn, sideScores, baseballSituationImpact, noHitBid, baseballPerformanceMilestone, baseballGameState, baseballEventShock, mlbModel };
      if (typeof module2 !== "undefined" && module2.exports) {
        module2.exports = api;
      } else {
        (root.SportsRadarScoring ||= {}).sports_mlb = api;
      }
    })(globalThis);
  }
});

// scoring/shared/context.js
var require_context = __commonJS({
  "scoring/shared/context.js"(exports2, module2) {
    (function(root) {
      const { CONTEXT_WEIGHTS, CONTEXT_LABELS } = typeof module2 !== "undefined" && module2.exports ? require_config() : root.SportsRadarScoring.shared_config;
      const { footballPregameSpread } = typeof module2 !== "undefined" && module2.exports ? require_market() : root.SportsRadarScoring.shared_market;
      const { nflReturnPoints } = typeof module2 !== "undefined" && module2.exports ? require_nfl_pregame() : root.SportsRadarScoring.shared_nfl_pregame;
      function footballAbsencePoints(item, competition) {
        const evidence = item.injuryEvidence;
        const competitors = competition?.competitors || [];
        const affected = competitors.find((team) => String(team.team?.id || team.id || "") === String(evidence?.affectedTeamId || ""));
        if (!evidence || !["star", "starting-quarterback"].includes(evidence.importance) || !evidence.affectedTeamId || !affected) return 0;
        const spread = footballPregameSpread(competition);
        if (spread === null) return evidence.importance === "starting-quarterback" ? -5 : -3;
        const raw = competition?.odds?.[0];
        const odds = raw?.close || raw?.closing || raw;
        const marketAt = Date.parse(odds?.lastUpdated || odds?.lastModified || "");
        const reportedAt = Date.parse(evidence.reportedAt || "");
        const side = affected.homeAway;
        return ["home", "away"].includes(side) && odds?.[`${side}TeamOdds`]?.underdog === true && Number.isFinite(marketAt) && Number.isFinite(reportedAt) && reportedAt > marketAt ? -2 : 0;
      }
      function eventSignalText(event, competition, context) {
        return [
          event?.name,
          event?.shortName,
          (competition?.notes || []).map((note) => note.headline).join(" "),
          competition?.series?.summary,
          competition?.series?.title,
          competition?.series?.type,
          event?.season?.type?.name,
          event?.season?.type?.slug,
          event?.season?.slug,
          context
        ].filter(Boolean).join(" ").toLowerCase();
      }
      function normalizeContextType(value) {
        return String(value || "").trim().toLowerCase().replace(
          /[\s-]+/g,
          "_"
        );
      }
      function pregameContextFactors(event, competition, options = {}) {
        const sources = [
          event?.sportsRadarContextFactors,
          competition?.sportsRadarContextFactors,
          event?.sportsRadarContext,
          competition?.sportsRadarContext,
          event?.contextFactors,
          competition?.contextFactors
        ];
        const items = sources.flatMap(
          (source) => Array.isArray(source) ? source : Array.isArray(source?.factors) ? source.factors : []
        ).filter(Boolean);
        const candidates = [];
        for (const item of items) {
          if (item?.verified === false) {
            continue;
          }
          const confidence = Number(
            item?.confidence
          );
          if (Number.isFinite(confidence) && confidence < 0.7) {
            continue;
          }
          const type = normalizeContextType(
            item?.type
          );
          let points = options.calibratedPregame && type === "star_absence" ? footballAbsencePoints(item, competition) : CONTEXT_WEIGHTS[type];
          if (options.calibratedPregame && options.sport === "NFL" && points > 0) points = Math.min(type === "rivalry" ? 2 : 4, points);
          if (options.calibratedPregame && options.sport === "NFL" && type === "star_injury_return") points = nflReturnPoints(item, competition);
          if (!Number.isFinite(points)) {
            continue;
          }
          candidates.push({
            type,
            label: String(
              (options.calibratedPregame && options.sport === "NFL" && type === "star_injury_return" ? points === 5 ? "Decorated starting quarterback returns" : points === 3 ? item.injuryEvidence?.importance === "starting-quarterback" ? "Starting quarterback returns" : "Established star returns" : points === 2 ? "Regular player returns" : "Confirmed player return" : "") || item?.label || CONTEXT_LABELS[type] || type
            ).trim(),
            text: String(
              item?.text || item?.description || item?.label || CONTEXT_LABELS[type] || ""
            ).trim(),
            points,
            sourceUrl: item.sourceUrl,
            returnSignificance: type === "star_injury_return" ? item.injuryEvidence?.playerSignificance : void 0,
            dedupeKey: options.calibratedPregame && options.sport === "NFL" && ["former_captain_return", "first_game_back", "former_star_return", "star_injury_return", "season_debut"].includes(type) ? "player-return" : String(
              item?.dedupeKey || ([
                "former_captain_return",
                "first_game_back",
                "former_star_return"
              ].includes(type) ? "former-team-return" : [
                "championship_rematch",
                "playoff_rematch"
              ].includes(type) ? "rematch" : type)
            )
          });
        }
        candidates.sort(
          (a, b) => Math.abs(b.points) - Math.abs(a.points)
        );
        const factors = [];
        const seen = /* @__PURE__ */ new Set();
        let positiveRemaining = options.calibratedPregame && options.sport === "NFL" ? 6 : 22;
        let negativeRemaining = 10;
        for (const item of candidates) {
          if (!item.label || seen.has(item.dedupeKey)) {
            continue;
          }
          seen.add(item.dedupeKey);
          let points = item.points;
          if (points > 0) {
            points = Math.min(
              points,
              positiveRemaining
            );
            positiveRemaining -= points;
          } else if (points < 0) {
            points = -Math.min(
              Math.abs(points),
              negativeRemaining
            );
            negativeRemaining -= Math.abs(points);
          }
          if (!points) {
            continue;
          }
          factors.push({
            label: item.label,
            points,
            contextType: item.type,
            contextText: item.text,
            ...item.sourceUrl ? { sourceUrl: item.sourceUrl } : {},
            ...item.returnSignificance ? { returnSignificance: item.returnSignificance } : {}
          });
        }
        return factors;
      }
      function aggregateScoreFromText(value) {
        const text = String(value || "").toLowerCase();
        const match = text.match(
          /(?:aggregate(?: score)?|on aggregate)[^0-9]{0,12}(\d+)\D{1,5}(\d+)/
        ) || text.match(
          /(\d+)\s*[-–:]\s*(\d+)[^.;]{0,24}(?:on aggregate|aggregate score)/
        );
        return match ? [
          Number(match[1]),
          Number(match[2])
        ] : null;
      }
      function specificStakesFactors(sport, detail) {
        const text = String(detail || "").toLowerCase();
        const factors = [];
        if (/\bgame\s*(?:7|seven)\b|\bdeciding game\b/.test(text)) {
          factors.push({
            label: "Deciding game",
            points: 12
          });
        } else if (/\belimination game\b|\bwin or go home\b|\bwinner advances\b|\bmust[- ]win\b/.test(text)) {
          factors.push({
            label: "Elimination stakes",
            points: 9
          });
        }
        if (/\bclinches?\b|\bclinching (?:game|opportunity|scenario)\b|\bcan clinch\b/.test(text)) {
          factors.push({
            label: "Clinching opportunity",
            points: 6
          });
        }
        if (sport === "Soccer" && /\bsecond leg\b|\b2nd leg\b|\bon aggregate\b|\baggregate score\b/.test(text)) {
          const aggregate = aggregateScoreFromText(text);
          const closeAggregate = aggregate && Math.abs(
            aggregate[0] - aggregate[1]
          ) <= 1;
          factors.push({
            label: closeAggregate ? "Close aggregate tie" : "Second-leg consequences",
            points: closeAggregate ? 7 : 4
          });
        }
        return factors;
      }
      function singleEliminationRound(sport, detail) {
        if (sport === "NFL") {
          return /\bwild[- ]card\b(?!\s+(?:race|berth|spot|picture|contention|hunt))|\bdivisional (?:round|playoff)\b|\b(?:afc|nfc|conference) championship\b|\bsuper bowl\b(?!\s+rematch)/.test(detail);
        }
        if (sport === "CFB") {
          return /\b(?:college football playoff|cfp)\b(?!\s+(?:race|berth|spot|picture|contention|hunt))|\bnational championship\b(?!\s+rematch)/.test(detail);
        }
        return sport === "NCAAB" && /\bncaa (?:tournament|championship)\b|\bmarch madness\b|\bfirst four\b|\bsweet (?:16|sixteen)\b|\belite (?:8|eight)\b|\bfinal four\b|\bnational championship\b/.test(detail);
      }
      function isPostseasonGame(sport, event, competition, detail) {
        return Number(event?.season?.type?.id ?? event?.season?.type) === 3 || singleEliminationRound(sport, detail) || /\bworld series\b|\bsuper bowl\b|\bstanley cup final\b|\b(?:nba|wnba) finals\b|\bnational championship\b|\bconference (?:finals?|championship)\b|\b(?:quarterfinal|semifinal|knockout)\b|\b(?:wild[- ]card|divisional) (?:round|game|playoff)\b|\b(?:playoffs?|postseason) (?:game|round|series)\b/.test(detail) || sport === "CFB" && /\bbowl\b/.test(detail) || /^(?:postseason|playoffs?)$/.test(String(event?.season?.type?.name || "").toLowerCase());
      }
      function playoffSeriesLeverage(sport, competition, detail) {
        if (!["MLB", "NHL", "NBA"].includes(sport)) return null;
        const seriesData = competition?.series || {};
        const series = String([seriesData.summary, seriesData.title, seriesData.type].filter(Boolean).join(" ")).toLowerCase();
        if (!isPostseasonGame(sport, {}, competition, detail) && !series) return null;
        const game = Number(detail.match(/\bgame\s*([1-7])\b/)?.[1] || series.match(/\bgame\s*([1-7])\b/)?.[1] || seriesData.gameNumber || 0);
        const winsMatch = series.match(/\b([0-3])\s*[-–]\s*([0-3])\b/);
        const structuredWins = [seriesData.homeWins ?? seriesData.homeTeamWins, seriesData.awayWins ?? seriesData.awayTeamWins].map((value) => value == null ? NaN : Number(value));
        const wins = winsMatch ? [Number(winsMatch[1]), Number(winsMatch[2])] : structuredWins.every(Number.isFinite) ? structuredWins : [];
        const bestOf = Number(seriesData.bestOf || series.match(/best[- ]of[- ]([357])/i)?.[1] || 7);
        const clinchWins = Number(seriesData.winsRequired || Math.ceil(bestOf / 2));
        const winsNeeded = seriesData.winsNeeded;
        const clinchOpportunity = (Array.isArray(winsNeeded) ? winsNeeded : Object.values(winsNeeded && typeof winsNeeded === "object" ? winsNeeded : { value: winsNeeded })).some((value) => value !== null && value !== void 0 && Number.isFinite(Number(value)) && Number(value) <= 1);
        const deciding = seriesData.winnerTakeAll === true || game === bestOf || /\bdeciding game\b|\bwinner[- ]take[- ]all\b/.test(detail) || wins.length === 2 && wins[0] === wins[1] && wins[0] === clinchWins - 1;
        const clinchChance = Number(seriesData.clinchChance);
        const elimination = seriesData.eliminationRisk === true || seriesData.clinchChance === true || Number.isFinite(clinchChance) && clinchChance >= 0.5 || clinchOpportunity || /\belimination game\b|\bwin or go home\b|\bmust[- ]win\b|\bcan clinch\b|\bclinching (?:game|opportunity|scenario)\b|\bclinches?\b/.test(detail) || wins.length === 2 && Math.max(...wins) >= clinchWins - 1;
        const tiedGameFive = game === 5 && wins.length === 2 && wins[0] === 2 && wins[1] === 2;
        const points = deciding ? 16 : elimination ? 10 : tiedGameFive ? 5 : { 2: 2, 3: 3, 4: 4, 5: 4, 6: 4 }[game] || 0;
        return points ? { label: deciding ? "Playoff winner-take-all" : elimination ? "Playoff elimination / clinch" : "Playoff series leverage", points } : null;
      }
      function championshipSeriesFactors(sport, competition, detail) {
        const championship = sport === "MLB" && /\bworld series\b/.test(detail) || sport === "NBA" && /\bnba finals\b/.test(detail) || sport === "NHL" && /\bstanley cup finals?\b/.test(detail);
        if (!championship) return null;
        const seriesLeverage = playoffSeriesLeverage(sport, competition, detail);
        const game = Number(detail.match(/\bgame\s*([1-7])\b/)?.[1] || 0);
        const series = String(competition?.series?.summary || "").toLowerCase();
        const record = series.match(/\b([0-3])\s*[-–]\s*([0-3])\b/);
        const wins = record ? [Number(record[1]), Number(record[2])] : [];
        const deciding = game === 7 || /\bgame seven\b|\bdeciding game\b|\bwinner[- ]take[- ]all\b/.test(detail) || wins.length === 2 && wins.every((value) => value === 3);
        const elimination = /\belimination game\b|\bwin or go home\b|\bmust[- ]win\b|\bcan clinch\b|\bclinching (?:game|opportunity|scenario)\b|\bclinches?\b/.test(detail) || wins.some((value) => value === 3);
        const leverage = seriesLeverage?.points ?? (deciding ? 16 : elimination ? 10 : { 2: 1, 3: 3, 4: 5, 5: 6, 6: 7 }[game] || 0);
        return [
          { label: sport === "MLB" ? "World Series" : sport === "NHL" ? "Championship" : "Final round", points: sport === "MLB" ? 50 : 45 },
          ...leverage ? [{
            label: deciding ? "Championship winner-take-all" : elimination ? "Championship elimination / clinch" : "Championship series leverage",
            points: leverage
          }] : []
        ];
      }
      function completedStakesImpact(sport, event, competition, context) {
        const detail = eventSignalText(
          event,
          competition,
          context
        );
        let stage = null;
        let consequence = null;
        if (/world series|super bowl|stanley cup final|champions league final|national championship|grand slam final/.test(detail)) {
          stage = {
            label: "Championship stakes",
            points: 18
          };
        } else if (/\bnba finals\b|\bwnba finals\b|\bleague final\b|\bchampionship series\b|\btitle series\b|\bfinals\b/.test(detail)) {
          stage = {
            label: "Final-round stakes",
            points: 15
          };
        } else if (/conference final|conference championship|\bsemifinal\b|\bsemi-final\b/.test(detail)) {
          stage = {
            label: "Semifinal stakes",
            points: 13
          };
        } else if (/playoff|postseason|wild card|divisional round|quarterfinal|knockout/.test(detail) || singleEliminationRound(sport, detail) || Number(
          event?.season?.type?.id ?? event?.season?.type
        ) === 3) {
          stage = {
            label: "Postseason stakes",
            points: 10
          };
        }
        if (/\bgame\s*(?:7|seven)\b|\bdeciding game\b|\bwinner[- ]take[- ]all\b/.test(detail) || /super bowl|national championship|champions league final|grand slam final/.test(detail)) {
          consequence = {
            label: "Winner-take-all consequence",
            points: 10
          };
        } else if (/\bwinner advances\b|\badvances? to\b|\badvanced to\b|\beliminates?\b|\beliminated\b|\bloser (?:is )?eliminated\b/.test(detail)) {
          consequence = {
            label: "Advancement or elimination decided",
            points: 8
          };
        } else if (/\bwinner (?:wins|takes) (?:the )?(?:division|league|conference)\b/.test(detail) || /\b(?:wins|won|clinches|clinched|secures|secured|captures|captured|takes|took)\b[^.;]{0,50}\b(?:division|league|conference) (?:title|championship)\b/.test(detail) || /\b(?:division|league|conference) (?:title|championship) (?:decided|clinched|secured|won)\b/.test(detail)) {
          consequence = {
            label: "Division or conference title decided",
            points: 8
          };
        } else if (/\b(?:clinches|clinched|secures|secured|earns|earned)\b[^.;]{0,40}\bplayoff berth\b/.test(detail) || /\bplayoff berth\b[^.;]{0,30}\b(?:clinched|secured|earned|decided)\b/.test(detail)) {
          consequence = {
            label: "Playoff berth decided",
            points: 7
          };
        } else if (/\bwinner (?:takes|gets) (?:the )?(?:first place|top seed|no\.?\s*1 seed|number one seed)\b/.test(detail) || /\b(?:clinches|clinched|secures|secured|takes|took|wins|won)\b[^.;]{0,45}\b(?:first place|top seed|no\.?\s*1 seed|number one seed)\b/.test(detail) || /\b(?:first place|top seed|no\.?\s*1 seed|number one seed)\b[^.;]{0,30}\b(?:decided|clinched|secured|won)\b/.test(detail)) {
          consequence = {
            label: "First place or major seeding decided",
            points: 6
          };
        } else if (/\b(?:clinched|secured|captured|earned)\b/.test(detail) && !/\b(?:can|could|may|might) clinch\b|\bclinching (?:opportunity|scenario)\b/.test(detail)) {
          consequence = {
            label: "Competitive consequence clinched",
            points: 5
          };
        } else if (/\bavoids? elimination\b|\bstays? alive\b|\bsurvives? elimination\b/.test(detail)) {
          consequence = {
            label: "Elimination survival",
            points: 5
          };
        }
        if (!consequence && singleEliminationRound(sport, detail)) {
          consequence = { label: "Advancement or elimination decided", points: 8 };
        }
        const factors = [];
        let remaining = 24;
        for (const factor of [stage, consequence]) {
          if (!factor || remaining <= 0) {
            continue;
          }
          const points = Math.min(
            factor.points,
            remaining
          );
          if (points) {
            factors.push({
              ...factor,
              points
            });
            remaining -= points;
          }
        }
        return {
          points: 24 - remaining,
          factors
        };
      }
      function contextWeightFor(progress, gameState, anchors) {
        if (gameState === "completed") {
          return 0.05;
        }
        const p = Math.max(
          0,
          Math.min(
            1,
            Number(progress) || 0
          )
        );
        for (let i = 1; i < anchors.length; i++) {
          if (p <= anchors[i][0]) {
            const [
              x0,
              y0
            ] = anchors[i - 1];
            const [
              x1,
              y1
            ] = anchors[i];
            const t = (p - x0) / (x1 - x0);
            return y0 + (y1 - y0) * t;
          }
        }
        return 0.06;
      }
      const api = { eventSignalText, normalizeContextType, pregameContextFactors, aggregateScoreFromText, specificStakesFactors, singleEliminationRound, isPostseasonGame, playoffSeriesLeverage, championshipSeriesFactors, completedStakesImpact, contextWeightFor };
      if (typeof module2 !== "undefined" && module2.exports) {
        module2.exports = api;
      } else {
        (root.SportsRadarScoring ||= {}).shared_context = api;
      }
    })(globalThis);
  }
});

// scoring/shared/upset.js
var require_upset = __commonJS({
  "scoring/shared/upset.js"(exports2, module2) {
    (function(root) {
      const { footballLiveCloseness } = typeof module2 !== "undefined" && module2.exports ? require_football() : root.SportsRadarScoring.shared_football;
      function upsetImpact2(candidate, teams, gameState, progress, sport = "", competition = null) {
        if (!candidate || gameState === "upcoming") {
          return {
            points: 0,
            text: ""
          };
        }
        const index = teams.findIndex(
          (team) => candidate.teamId && String(
            team.id || team[8] || ""
          ) === candidate.teamId
        );
        const teamIndex = index >= 0 ? index : candidate.teamIndex;
        if (teamIndex < 0 || teamIndex > 1 || teams.length !== 2) {
          return {
            points: 0,
            text: ""
          };
        }
        const score = Number(
          teams[teamIndex].score ?? teams[teamIndex][2]
        );
        const other = Number(
          teams[1 - teamIndex].score ?? teams[1 - teamIndex][2]
        );
        if (!Number.isFinite(score) || !Number.isFinite(other)) {
          return {
            points: 0,
            text: ""
          };
        }
        const margin = score - other;
        const activation = Number.isFinite(candidate.activation) ? candidate.activation : 1;
        const scaled = (points) => Math.round(points * activation);
        if (gameState === "completed") {
          return margin > 0 ? {
            points: scaled(Math.min(
              22,
              18 + Math.round(
                4 * candidate.strength
              )
            )),
            text: `${candidate.teamName} won outright after entering as a ${candidate.description}`
          } : {
            points: 0,
            text: ""
          };
        }
        if (margin > 0 && progress >= 0.35) {
          return {
            points: scaled(Math.min(
              18,
              7 + Math.round(
                7 * progress
              ) + Math.round(
                4 * candidate.strength
              )
            )),
            text: `${candidate.teamName}, a ${candidate.description}, leads ${score}\u2013${other}`
          };
        }
        if (margin === 0 && progress >= 0.7) {
          return {
            points: scaled(Math.min(
              12,
              4 + Math.round(
                5 * progress
              ) + Math.round(
                2 * candidate.strength
              )
            )),
            text: `${candidate.teamName}, a ${candidate.description}, is tied ${score}\u2013${other} late`
          };
        }
        if (margin < 0 && progress >= 0.7 && ["NFL", "CFB"].includes(sport)) {
          const footballState = footballLiveCloseness(
            sport,
            -margin,
            progress,
            competition
          );
          const tiedPoints = Math.min(
            12,
            4 + Math.round(5 * progress) + Math.round(2 * candidate.strength)
          );
          const possessionWeight = footballState.possessionState === "trailing" ? 1 : footballState.possessionState === "leading" ? 0.68 : 0.8;
          const fieldWeight = footballState.possessionState === "trailing" && footballState.fieldPosition !== null ? 1 + 0.08 * Math.max(0, (footballState.fieldPosition - 50) / 50) : 1;
          const marginWeight = Math.exp(-Math.pow(-margin / 10, 1.6));
          const points = scaled(Math.round(
            tiedPoints * marginWeight * footballState.comebackFeasibility * possessionWeight * fieldWeight
          ));
          return {
            points,
            text: points ? `${candidate.teamName}, a ${candidate.description}, trails ${score}\u2013${other} but remains an upset threat` : ""
          };
        }
        return {
          points: 0,
          text: ""
        };
      }
      const api = { upsetImpact: upsetImpact2 };
      if (typeof module2 !== "undefined" && module2.exports) {
        module2.exports = api;
      } else {
        (root.SportsRadarScoring ||= {}).shared_upset = api;
      }
    })(globalThis);
  }
});

// scoring/sports/nhl.js
var require_nhl = __commonJS({
  "scoring/sports/nhl.js"(exports2, module2) {
    (function(root) {
      const { proPregame } = typeof module2 !== "undefined" && module2.exports ? require_pregame() : root.SportsRadarScoring.shared_pregame;
      const { clockSeconds, normalizedTime } = typeof module2 !== "undefined" && module2.exports ? require_time() : root.SportsRadarScoring.shared_time;
      const { eventSignalText, isPostseasonGame, playoffSeriesLeverage } = typeof module2 !== "undefined" && module2.exports ? require_context() : root.SportsRadarScoring.shared_context;
      const { upsetImpact: upsetImpact2 } = typeof module2 !== "undefined" && module2.exports ? require_upset() : root.SportsRadarScoring.shared_upset;
      function nhlLiveMarginCloseness(gap, progress = 0, situation = {}) {
        if (gap === null || !Number.isFinite(Number(gap))) {
          return 0;
        }
        const goals = Math.max(
          0,
          Number(gap)
        );
        if (goals <= 1) return 1 - 0.1 * goals;
        const p = Math.max(0, Math.min(1, Number(progress) || 0));
        const extra = Math.min(0.45, (situation.trailingGoaliePulled ? 0.22 : 0) + (situation.trailingPowerPlay ? 0.23 : 0));
        const third = Math.max(0, Math.min(1, (p - 0.67) / 0.1));
        const thirdRamp = third * third * (3 - 2 * third);
        const secondsRemaining = Math.max(0, (1 - p) * 3600);
        const twoGoalRunway = 1.6 * (1 - Math.exp(-Math.pow(secondsRemaining / 500, 1.8))) * Math.exp(-Math.pow(Math.max(0, goals - 2) / 0.32, 2)) * thirdRamp;
        const runway = 2.1 - 1.85 * p + extra + twoGoalRunway;
        return 0.9 * Math.exp(-Math.pow(goals - 1, 1.35) / runway);
      }
      function smoothNhlTarget(seconds, anchors) {
        const s = Math.max(0, Math.min(1200, Number(seconds) || 0));
        for (let i = 1; i < anchors.length; i++) {
          const high = anchors[i - 1], low = anchors[i];
          if (s <= high[0] && s >= low[0]) {
            const x = (high[0] - s) / (high[0] - low[0]);
            const eased = x * x * (3 - 2 * x);
            return high[1] + (low[1] - high[1]) * eased;
          }
        }
        return s > anchors[0][0] ? anchors[0][1] : anchors.at(-1)[1];
      }
      function hockeyOnIceState(summary, teams) {
        const onIce = summary?.onIce || [];
        const blocks = summary?.boxscore?.players || [];
        if (onIce.length !== 2) {
          return null;
        }
        const goalieIds = new Map(
          blocks.map((block) => [
            String(
              block.team?.id || ""
            ),
            new Set(
              (block.statistics || []).filter(
                (group) => /goalie/i.test(
                  group.name || group.displayName || ""
                )
              ).flatMap(
                (group) => (group.athletes || []).map(
                  (entry) => String(
                    entry.athleteid || entry.athleteId || entry.athlete?.id || ""
                  )
                )
              )
            )
          ])
        );
        const sides = onIce.map((side) => {
          const id = String(
            side.teamId || side.team?.id || ""
          );
          const entries = side.entries || [];
          const goalies = goalieIds.get(id) || /* @__PURE__ */ new Set();
          const hasGoalie = entries.some(
            (entry) => goalies.has(
              String(
                entry.athleteid || entry.athleteId || entry.athlete?.id || ""
              )
            )
          );
          return {
            id,
            count: entries.length,
            hasGoalie,
            goalieKnown: goalies.size > 0,
            skaters: entries.length - (hasGoalie ? 1 : 0),
            name: teams.find(
              (team) => String(
                team[8] || ""
              ) === id
            )?.[0] || "A team"
          };
        });
        let powerPlayTeam = null;
        let powerPlayTeamId = null;
        let powerPlayAdvantage = 0;
        let pulledGoalieTeam = null;
        let pulledGoalieTeamId = null;
        if (sides.every((side) => side.goalieKnown && side.count >= 4)) {
          const high = sides[0].skaters > sides[1].skaters ? sides[0] : sides[1];
          const low = high === sides[0] ? sides[1] : sides[0];
          powerPlayAdvantage = Math.max(0, high.skaters - low.skaters - (high.hasGoalie ? 0 : 1));
          if (powerPlayAdvantage) {
            powerPlayTeam = high.name;
            powerPlayTeamId = high.id;
          }
        }
        const noGoalie = sides.find(
          (side) => side.goalieKnown && !side.hasGoalie && side.count >= 5
        );
        const withGoalie = sides.find(
          (side) => side.hasGoalie
        );
        if (noGoalie && withGoalie) {
          pulledGoalieTeam = noGoalie.name;
          pulledGoalieTeamId = noGoalie.id;
        }
        return {
          sides,
          powerPlayTeam,
          powerPlayTeamId,
          powerPlayAdvantage,
          pulledGoalieTeam,
          pulledGoalieTeamId
        };
      }
      function hockeyPowerPlay(summary, teams) {
        const state = hockeyOnIceState(
          summary,
          teams
        );
        return state?.powerPlayTeam || null;
      }
      function hockeyOvertime(event, competition, summary, context = "", normalized = false) {
        const status = competition?.status || summary?.header?.competitions?.[0]?.status || {};
        const summaryStatus = summary?.header?.competitions?.[0]?.status;
        const completedSummary = status.type?.completed && summaryStatus?.type?.completed ? summaryStatus : null;
        const detail = `${status.type?.detail || ""} ${status.type?.shortDetail || ""} ${completedSummary?.type?.detail || ""} ${completedSummary?.type?.shortDetail || ""}`;
        const signal = eventSignalText(event, competition, context) + " " + eventSignalText(summary?.header, competition, "");
        const postseason = isPostseasonGame("NHL", event, competition, signal) || Number(summary?.header?.season?.type?.id ?? summary?.header?.season?.type) === 3;
        let shootout = /shootout|\bSO\b/i.test(detail) || !postseason && Number(status.period) >= 5;
        let depth = shootout ? 0 : Math.max(
          0,
          Number(status.period || 0) - 3,
          Number(detail.match(/(\d+)\s*OT\b/i)?.[1] || (/overtime|\bOT\b/i.test(detail) ? 1 : 0))
        );
        const leverage = playoffSeriesLeverage("NHL", competition, signal);
        const deciding = /game\s*7|deciding|winner.take.all/i.test(signal) || /deciding/i.test(leverage?.label || "");
        const result = { shootout, depth, postseason, deciding, final: /stanley cup final/i.test(signal) };
        if (!normalized) return result;
        const seasonTypes = [event?.season, competition?.season, summary?.header?.season].map((season) => Number(season?.type?.id ?? season?.type)).filter((type) => [2, 3].includes(type));
        const conflict = new Set(seasonTypes).size > 1;
        const resolvedPostseason = !conflict && (seasonTypes.length ? seasonTypes[0] === 3 : postseason);
        const formatKnown = !conflict && (resolvedPostseason || seasonTypes.length > 0);
        const regulation = Number(competition?.format?.regulation?.periods) || 3;
        const period = Number(status.period?.number ?? status.period);
        const structured = Number.isInteger(period) && period > 0;
        const tokens = detail.replace(/\b\d+:\d+(?:\.\d+)?\b/g, " ");
        const counts = [...tokens.matchAll(/\b(\d+)\s*OT\b/gi)].map((m) => Number(m[1]));
        const labelShootout = /shootout|\bSO\b/i.test(tokens);
        const labelDepth = counts.length ? new Set(counts).size === 1 ? counts[0] : null : /\bovertime\b|\bOT\b/i.test(tokens) ? 1 : null;
        const issues = conflict ? ["Conflicting season metadata; overtime format unknown"] : [];
        shootout = false;
        depth = null;
        let source = "unknown";
        if (structured) {
          source = "structured-period";
          if (period <= regulation) depth = 0;
          else if (resolvedPostseason || period === regulation + 1) depth = period - regulation;
          else if (formatKnown && !resolvedPostseason && period === regulation + 2) {
            shootout = true;
            depth = 0;
          } else issues.push("Overtime format/depth unresolved");
          if (labelDepth !== null && labelDepth !== depth || labelShootout && !shootout)
            issues.push("Label conflicts with structured period/format");
        } else if (labelShootout && !resolvedPostseason) {
          shootout = true;
          depth = 0;
          source = "label";
        } else if (labelDepth > 0 && !(formatKnown && !resolvedPostseason && labelDepth > 1)) {
          depth = labelDepth;
          source = "label";
        } else if (/\b[123](?:st|nd|rd)\b|\bregulation\b/i.test(tokens)) {
          depth = 0;
          source = "label";
        }
        if (depth === null) issues.push("No reliable overtime count");
        return { ...result, postseason: resolvedPostseason, shootout, depth, source, formatKnown, regulation, period: structured ? period : null, issues };
      }
      function hockeyLiveTiming(event, competition, summary) {
        const ot = hockeyOvertime(event, competition, summary, "", true), status = competition?.status || {};
        const raw = normalizedTime("NHL", { status: { ...status, period: 1, clockMode: "remaining" } }).remainingSeconds;
        const length = ot.shootout ? null : ot.depth > 0 ? ot.formatKnown ? ot.postseason ? 1200 : 300 : null : ot.period && ot.period <= ot.regulation ? 1200 : null;
        const valid = raw !== null && length !== null && raw >= 0 && raw <= length;
        const seconds = valid ? status.clockMode === "elapsed" ? length - raw : raw : null;
        const elapsed = seconds === null ? null : ot.depth > 0 ? ot.regulation * 1200 + (ot.depth - 1) * length + length - seconds : (ot.period - 1) * 1200 + length - seconds;
        return {
          ...ot,
          seconds,
          elapsed,
          periodLength: length,
          clockMode: status.clockMode || "remaining",
          issues: [...ot.issues, ...raw !== null && !valid && !ot.shootout ? ["Clock/period length unresolved or out of range"] : []]
        };
      }
      function hockeySituationImpact(game, competition, summary, status, progress, scoreGap, allocation = null) {
        const state = summary ? hockeyOnIceState(summary, game.teams) : null;
        const scores = game.teams.map((team) => Number(team[2]));
        const trailing = scores.length === 2 && scores.every(Number.isFinite) && scores[0] !== scores[1] ? String(game.teams[scores[0] < scores[1] ? 0 : 1][8] || "") : "";
        const pulled = Boolean(trailing && state?.pulledGoalieTeamId === trailing);
        const powerPlay = Boolean(trailing && state?.powerPlayTeamId === trailing);
        const advantage = powerPlay || scoreGap === 0 ? state?.powerPlayAdvantage || 0 : 0;
        const timing = allocation ? hockeyLiveTiming(game.sourceEvent, { ...competition, status }, summary) : null;
        const seconds = timing ? timing.seconds : clockSeconds(status);
        const late = (timing ? timing.period : Number(status?.period)) === 3 && seconds !== null;
        const ot = timing || hockeyOvertime(game.sourceEvent, { ...competition, status }, summary);
        let target = 0;
        let note = "";
        if (ot.shootout) {
          target = 90;
          note = "Shootout";
        } else if (ot.depth && scoreGap === 0) {
          target = ot.postseason ? Math.min(98, 95 + 2 * (ot.depth - 1)) : Math.round(smoothNhlTarget(seconds ?? 300, allocation ? [[300, 88], [0, 90]] : [[300, 92], [0, 94]]));
          if (ot.postseason && ot.deciding) target = Math.max(target, 96);
          if (ot.postseason && ot.final) target = Math.max(target, 95);
          if (ot.postseason && ot.final && ot.deciding) target = 99;
          note = ot.postseason ? `Playoff sudden-death ${ot.depth > 1 ? ot.depth : ""}OT` : "3-on-3 overtime";
        } else if (late && scoreGap <= 1) {
          if (scoreGap === 0) target = smoothNhlTarget(seconds, allocation ? [
            [1200, 52],
            [720, 62],
            [600, 68],
            [300, 78],
            [120, 83],
            [60, 85],
            [0, 87]
          ] : [[1200, 52], [720, 58], [600, 65], [300, 77], [120, 84], [60, 88], [0, 90]]);
          else if (allocation) target = smoothNhlTarget(seconds, [
            [1200, 52],
            [720, 60],
            [600, 64],
            [300, 72],
            [120, 78],
            [60, 80],
            [0, 82]
          ]);
          else if (seconds <= 60) target = 78;
          else if (seconds <= 120) target = 74;
          else if (seconds <= 300) target = 69;
          if (!allocation) target = Math.round(target);
          const reach = (limit, value) => allocation ? target + (Math.max(target, value) - target) * smoothNhlTarget(seconds, [[1200, 0], [limit, 1], [0, 1]]) : seconds <= limit ? Math.max(target, value) : target;
          if (powerPlay) target = reach(300, scoreGap === 0 ? 84 : 82);
          if (advantage >= 2) target = reach(180, 89);
          if (pulled) target = reach(180, powerPlay ? 91 : 85);
          note = pulled ? powerPlay ? "Pulled the goalie with a power play" : "Pulled the goalie" : advantage >= 2 ? "Two-skater advantage" : powerPlay ? "Trailing-team power play" : "";
        } else if (late && scoreGap === 2 && (allocation || seconds <= 180) && (pulled || powerPlay)) {
          target = (pulled && powerPlay ? 55 : 46) * (allocation ? smoothNhlTarget(seconds, [[1200, 0], [180, 1], [0, 1]]) : 1);
          note = "Two-goal comeback with extra manpower";
        }
        if (target && !ot.depth && !ot.shootout) {
          if (ot.postseason) target = Math.min(96, target + (ot.final ? 5 : 2));
          target = Math.min(96, target + Math.round(hockeyPressure(summary, progress, scoreGap, competition, allocation).points / 2));
        }
        if (!note && state?.powerPlayTeam) note = `${state.powerPlayTeam} power play`;
        if (!note && state?.pulledGoalieTeam) note = `${state.pulledGoalieTeam} pulled the goalie`;
        const viability = nhlLiveMarginCloseness(scoreGap, progress, { trailingGoaliePulled: pulled, trailingPowerPlay: powerPlay });
        const points = Math.round((powerPlay ? 5 : pulled ? 3 : state?.powerPlayTeam ? scoreGap === 0 ? 4 : 1 : 0) * viability);
        const base = Number(game.baseScore);
        const floorBase = base - (allocation?.context || 0);
        return {
          points,
          note,
          reasons: note ? [note] : [],
          competitiveFloor: Number.isFinite(base) && target ? Math.max(0, target - floorBase) : 0,
          competitiveTarget: target,
          manpower: { pulled, powerPlay, advantage },
          overtime: ot,
          ...allocation ? { allocation: { context: allocation.context || 0, floorBase, timing } } : {}
        };
      }
      function hockeyGoalMilestone(summary) {
        for (const block of summary?.boxscore?.players || []) {
          for (const group of block.statistics || []) {
            if (/goalie/i.test(
              group.name || group.displayName || ""
            )) {
              continue;
            }
            const goals = (group.labels || []).indexOf("G");
            if (goals < 0) {
              continue;
            }
            const scorer = (group.athletes || []).filter(
              (entry) => Number(
                entry.stats?.[goals]
              ) >= 2
            ).sort(
              (a, b) => Number(
                b.stats[goals]
              ) - Number(
                a.stats[goals]
              )
            )[0];
            if (scorer) {
              const count = Number(
                scorer.stats[goals]
              );
              const name = scorer.athlete?.displayName || "A player";
              return {
                scorerName: name,
                text: count >= 3 ? `${name} has a hat trick (${count} goals)` : `${name} has 2 goals and is one away from a hat trick`,
                points: count >= 3 ? 6 : 3
              };
            }
          }
        }
        return null;
      }
      function hockeyGameState({ gameState, gap, progress, context }) {
        const teams = context?.teams?.[0]?.[0] ? context.teams : (context?.competition?.competitors || []).map((item) => [item.team?.displayName || "", "", item.score, "", "", "", null, "", String(item.team?.id || "")]);
        const state = context?.summary ? hockeyOnIceState(context.summary, teams) : null;
        const scores = teams.map((team) => Number(team[2]));
        const trailing = scores.length === 2 && scores[0] !== scores[1] ? String(teams[scores[0] < scores[1] ? 0 : 1][8] || "") : "";
        const marginClose = nhlLiveMarginCloseness(gap, progress, {
          trailingGoaliePulled: Boolean(trailing && state?.pulledGoalieTeamId === trailing),
          trailingPowerPlay: Boolean(trailing && state?.powerPlayTeamId === trailing)
        });
        const seconds = context?.nhlAllocation ? hockeyLiveTiming(null, context.competition, context.summary).seconds : clockSeconds(context?.competition?.status);
        const finalMinute = Number(context?.competition?.status?.period) === 3 && seconds !== null ? Math.max(0, Math.min(1, (120 - seconds) / 60)) : 0;
        const twoGoalWeight = Math.exp(-Math.pow((Number(gap) - 2) / 0.32, 2));
        const lateTwoGoalPenalty = Math.round(3 * finalMinute * finalMinute * (3 - 2 * finalMinute) * twoGoalWeight);
        return gameState === "live" ? {
          marginClose,
          minimumComebackViability: gap === 1 ? 0.82 : 0,
          // Avoid the generic integer-margin penalty reintroducing a cliff at 3.
          widePenalty: gap == null || !Number.isFinite(gap) ? 0 : Math.round(20 * progress * (1 - marginClose) * Math.min(1, Math.max(0, gap - 1) / 4)) + lateTwoGoalPenalty
        } : {};
      }
      function hockeyLiveMilestone(summary, { scoreGap, progress, status }) {
        const milestone = hockeyGoalMilestone(summary);
        if (!milestone) return { points: 0, text: "" };
        let points = milestone.points * nhlLiveMarginCloseness(scoreGap, progress);
        if (milestone.points === 6) {
          const goals = (summary.scoringPlays?.length ? summary.scoringPlays : (summary.plays || []).filter((p) => p.scoringPlay)).filter((p) => String(p.text || "").toLowerCase().includes(milestone.scorerName.toLowerCase()));
          const latest = goals.at(-1);
          const postseason = hockeyOvertime(null, { status }, summary).postseason;
          const now = hockeyElapsed(status, postseason);
          const then = hockeyElapsed({ period: latest?.period?.number, displayClock: latest?.clock?.displayValue, clockMode: hockeyPlayClockMode(summary) }, postseason);
          const age = now !== null && then !== null ? now - then : NaN;
          points *= Number.isFinite(age) ? Math.max(0, 1 - age / 180) : 0.5;
        }
        return { ...milestone, points: Math.round(points) };
      }
      function hockeyUpset(candidate, teams, state, progress, sport, competition) {
        const impact = upsetImpact2(candidate, teams, state, progress, sport, competition);
        if (!impact.points) return impact;
        const value = Number(candidate.value) || 180;
        const magnitude = Math.min(22, 4 + 18 * (1 - Math.exp(-Math.max(0, value - 180) / 210)));
        const oldMaximum = Math.min(22, 18 + Math.round(4 * candidate.strength));
        return { ...impact, points: Math.round(impact.points * magnitude / oldMaximum) };
      }
      function hockeyElapsed(status, postseason = true) {
        const period = Number(status?.period?.number ?? status?.period);
        const seconds = clockSeconds({ ...status, clockMode: void 0 });
        if (!(period > 0) || seconds === null) return null;
        const length = period <= 3 || postseason ? 1200 : 300;
        const elapsed = status.clockMode === "elapsed" ? seconds : length - seconds;
        return (period <= 3 ? (period - 1) * 1200 : 3600 + (period - 4) * length) + elapsed;
      }
      function hockeyPlayClockMode(summary) {
        const plays = summary?.plays || [];
        const sequenced = plays.length > 1 && plays.every((p) => p.sequenceNumber != null && Number.isFinite(Number(p.sequenceNumber)));
        const ordered = sequenced ? [...plays].sort((a, b) => Number(a.sequenceNumber) - Number(b.sequenceNumber)) : summary?.scoringPlays?.length ? summary.scoringPlays : plays.filter((p) => p.scoringPlay);
        let up = 0, down = 0;
        for (let i = 1; i < ordered.length; i++) {
          const a = ordered[i - 1], b = ordered[i];
          if (Number(a.period?.number || a.period) !== Number(b.period?.number || b.period)) continue;
          if (!sequenced && !(Number(b.homeScore) >= Number(a.homeScore) && Number(b.awayScore) >= Number(a.awayScore))) continue;
          const first = clockSeconds({ displayClock: a.clock?.displayValue, clock: a.clock?.value });
          const second = clockSeconds({ displayClock: b.clock?.displayValue, clock: b.clock?.value });
          if (first === null || second === null) continue;
          if (second > first) up++;
          else if (second < first) down++;
        }
        return up > down ? "elapsed" : "remaining";
      }
      function hockeyPressure(summary, progress, gap, competition, allocation = null) {
        if (!summary || gap > 2) return { points: 0, reasons: [] };
        const timing = allocation ? hockeyLiveTiming(null, competition, summary) : null;
        const postseason = timing ? timing.postseason : hockeyOvertime(null, competition, summary).postseason;
        const now = timing ? timing.elapsed : hockeyElapsed(competition?.status || summary.header?.competitions?.[0]?.status, postseason);
        const plays = summary.plays || [];
        const clockMode = hockeyPlayClockMode(summary);
        const timed = plays.map((play) => ({ play, time: hockeyElapsed({ period: play.period?.number || play.period, displayClock: play.clock?.displayValue, clock: play.clock?.value, clockMode }, postseason) }));
        const hasTime = now !== null && timed.some((item) => item.time !== null);
        const recent = hasTime ? timed.filter((item) => item.time !== null && now - item.time >= 0 && now - item.time <= 90).map((item) => item.play) : plays.slice(-18);
        const dangerous = recent.filter((play) => !play.scoringPlay && /shot on goal|saved by|\bsave\b|breakaway|penalty shot|hit (?:the )?(?:post|crossbar)|off (?:the )?(?:post|crossbar)|big chance|close range|point-blank/i.test(play.text || play.shortText || play.type?.text || ""));
        const competitors = competition?.competitors || summary.header?.competitions?.[0]?.competitors || [];
        const trailing = competitors.length === 2 && Number(competitors[0].score) !== Number(competitors[1].score) ? String(competitors[Number(competitors[0].score) < Number(competitors[1].score) ? 0 : 1].team?.id || "") : "";
        let trailingCount = 0, leadingCount = 0, premium = 0;
        for (const play of dangerous) {
          const text = play.text || play.shortText || play.type?.text || "";
          let id = String(play.team?.id || play.teamId || "");
          if (/^(?:save\b|.* makes (?:a )?save)/i.test(text) && !/shot|breakaway|saved by/i.test(text)) {
            id = String(competitors.find((c) => String(c.team?.id) !== id)?.team?.id || "");
          }
          if (trailing && id) {
            if (id === trailing) trailingCount++;
            else leadingCount++;
          }
          if (/breakaway|penalty shot|post|crossbar|point-blank|big chance/i.test(text)) premium++;
        }
        const known = trailingCount + leadingCount;
        const direction = known ? 0.45 + 1.1 * trailingCount / known : 1;
        const activity = Math.min(7, dangerous.length * 0.8 + Math.min(3, premium * 1.2));
        const leverage = (0.3 + 0.7 * progress) * nhlLiveMarginCloseness(gap, progress);
        const points = Math.min(7, Math.round(activity * direction * leverage));
        return { points, reasons: points ? [`${dangerous.length} dangerous chances ${hasTime ? "in the last 90 seconds" : "in recent records"}${trailingCount > leadingCount ? ", led by the trailing team" : ""}`] : [] };
      }
      function hockeyCompletedResult(sport, state, teams, event, competition, context) {
        if (state !== "completed") return null;
        const ot = hockeyOvertime(event, competition, null, context);
        const points = ot.shootout ? 9 : ot.depth ? ot.postseason ? Math.min(28, 18 + 4 * (ot.depth - 1)) : 13 : 0;
        return points ? { label: ot.shootout ? "Shootout finish" : `${ot.postseason ? "Playoff sudden-death" : "Overtime"} winner${ot.depth > 1 ? ` (${ot.depth}OT)` : ""}`, points } : null;
      }
      function hockeyCompletedHistory(summary, history, { game, finishPoints = 0 } = {}) {
        const ot = hockeyOvertime(game?.sourceEvent, game?.sourceCompetition, summary);
        const finish2 = hockeyCompletedResult(
          "NHL",
          "completed",
          game?.teams,
          game?.sourceEvent,
          { ...game?.sourceCompetition, status: summary?.header?.competitions?.[0]?.status || game?.sourceCompetition?.status },
          ""
        );
        const awarded = (game?.factors || []).filter((f) => /^(Shootout finish|Overtime winner|Playoff sudden-death winner)/.test(f.label)).reduce((sum, f) => sum + f.points, 0);
        if (finish2 && !awarded) history = { ...history, points: history.points + finish2.points, factors: [...history.factors, finish2], text: [history.text, finish2.label].filter(Boolean).join("; ") };
        const floor = Math.max(history.completedContestTarget || 0, ot.shootout ? 61 : ot.postseason && ot.depth ? [0, 78, 85, 90, 93][Math.min(4, ot.depth)] : ot.depth ? 63 : 0);
        const existing = Number(game?.score) + history.points + (history.handlesFinish ? 0 : Number(finishPoints || 0));
        const delta = Number.isFinite(existing) ? Math.max(0, Math.round(floor - existing)) : 0;
        if (!delta) return history;
        const factor = { label: `Completed ${ot.shootout ? "shootout" : ot.postseason && ot.depth ? `${ot.depth}OT playoff` : ot.depth ? "overtime" : "late competitive path"} floor`, points: delta };
        return {
          points: history.points + delta,
          text: [history.text, factor.label].filter(Boolean).join("; "),
          factors: [...history.factors, factor],
          handlesFinish: history.handlesFinish
        };
      }
      function hockeyHistory(summary, progress, state, options = {}) {
        if (state === "upcoming") return { points: 0, text: "", factors: [] };
        const comp = summary?.header?.competitions?.[0] || {};
        const allocation = state === "live" ? options.nhlAllocation : null;
        const ot = allocation?.timing || (allocation ? hockeyLiveTiming(null, comp, summary) : hockeyOvertime(null, comp, summary));
        const current = state === "completed" ? Math.max(3600, hockeyElapsed(comp.status, ot.postseason) || 0) : (allocation ? ot.elapsed : hockeyElapsed(comp.status, ot.postseason)) ?? progress * 3600;
        const plays = (summary?.scoringPlays?.length ? summary.scoringPlays : (summary?.plays || []).filter((p) => p.scoringPlay)) || [];
        const clockMode = hockeyPlayClockMode(summary);
        const moments = plays.filter((p) => p.homeScore != null && p.awayScore != null && !(ot.shootout && Number(p.period?.number || p.period) > 4)).map((p) => ({ home: Number(p.homeScore), away: Number(p.awayScore), time: hockeyElapsed({ period: p.period?.number || p.period, displayClock: p.clock?.displayValue, clock: p.clock?.value, clockMode }, ot.postseason), text: p.text || "", extraAttacker: p.extraAttacker === true || p.goaliePulled === true })).filter((p) => Number.isFinite(p.home) && Number.isFinite(p.away) && p.time !== null && (state === "completed" || p.time <= current)).sort((a, b) => a.time - b.time);
        if (!moments.length) return { points: 0, text: "", factors: [], handlesFinish: true };
        const completeLedger = moments.every((moment, i) => {
          const prior = moments[i - 1] || { home: 0, away: 0 };
          const homeGain = moment.home - prior.home, awayGain = moment.away - prior.away;
          return homeGain === 1 && awayGain === 0 || homeGain === 0 && awayGain === 1;
        });
        let lastTime = 0, margin = 0, leader = 0, changes = 0, lateChanges = 0, tiedTime = 0, oneGoalTime = 0, lateCloseTime = 0, lateTiedTime = 0, homeDeficit = 0, awayDeficit = 0, comeback = 0, lateTie = 0, lateAhead = 0, pulledComeback = false, dramaticTime = null, majorDrama = false;
        for (const moment of moments) {
          const duration2 = Math.max(0, Math.min(3600, moment.time) - Math.min(3600, lastTime));
          if (margin === 0) tiedTime += duration2;
          if (Math.abs(margin) <= 1) oneGoalTime += duration2;
          const lateDuration = Math.max(0, Math.min(3600, moment.time) - Math.max(3e3, lastTime));
          if (Math.abs(margin) <= 1) lateCloseTime += lateDuration;
          if (margin === 0) lateTiedTime += lateDuration;
          const next = moment.home - moment.away;
          homeDeficit = Math.max(homeDeficit, -next);
          awayDeficit = Math.max(awayDeficit, next);
          if (next >= 0) comeback = Math.max(comeback, homeDeficit);
          if (next <= 0) comeback = Math.max(comeback, awayDeficit);
          const leadChange = next && leader && Math.sign(next) !== leader;
          const tyingGoal = next === 0 && margin !== 0;
          const goAheadGoal = next !== 0 && (margin === 0 || Math.sign(next) !== Math.sign(margin));
          const multiGoalComeback = tyingGoal && (margin < 0 ? homeDeficit : awayDeficit) >= 2;
          if (leadChange) {
            changes++;
            if (moment.time >= 3300 && moment.time <= 3600) lateChanges++;
          }
          if (tyingGoal || goAheadGoal || leadChange || multiGoalComeback) dramaticTime = moment.time;
          if (multiGoalComeback) majorDrama = true;
          if (next) leader = Math.sign(next);
          const recent = state === "completed" || current - moment.time <= 180;
          if (moment.time >= 3300 && moment.time <= 3600 && recent) {
            if (next === 0 && margin !== 0) {
              lateTie = moment.time >= 3480 ? 9 : 6;
              if (moment.extraAttacker || /extra attacker|goalie pulled|6.on.[45]/i.test(moment.text)) pulledComeback = true;
            }
            if (next !== 0 && (margin === 0 || Math.sign(next) !== Math.sign(margin))) lateAhead = moment.time >= 3480 ? 10 : 7;
          }
          margin = next;
          lastTime = moment.time;
        }
        const tail = Math.max(0, Math.min(3600, current) - Math.min(3600, lastTime));
        if (margin === 0) tiedTime += tail;
        if (Math.abs(margin) <= 1) oneGoalTime += tail;
        const lateTail = Math.max(0, Math.min(3600, current) - Math.max(3e3, lastTime));
        if (Math.abs(margin) <= 1) lateCloseTime += lateTail;
        if (margin === 0) lateTiedTime += lateTail;
        const duration = Math.max(1, Math.min(3600, current));
        const factors = [];
        const add = (label, points) => {
          if (points) factors.push({ label, points });
        };
        add("Late tying goal", lateTie);
        add("Late go-ahead goal", lateAhead);
        add("Goalie-pull comeback", pulledComeback ? 3 : 0);
        add("Erased a multi-goal deficit", comeback >= 2 ? Math.min(10, 4 + 2 * (comeback - 1)) : 0);
        add(`${changes} lead change${changes === 1 ? "" : "s"}`, Math.min(9, changes * 3));
        if (!(state === "live" && options.replaceSustained) && completeLedger && current >= 1440) add("Time tied or within one goal", Math.round((state === "completed" ? 8 : 3) * (0.7 * oneGoalTime / duration + 0.3 * tiedTime / duration)));
        if (state === "live" && options.replaceSustained) add("Trajectory sustained history", Math.max(0, Number(options.trajectoryPositive) || 0));
        const relevance = state === "live" && Number.isFinite(options.liveRelevance) ? Math.max(0, Math.min(1, options.liveRelevance)) : null;
        let remaining = state === "completed" ? 32 : 12;
        const capped = factors.map((f) => {
          const points = Math.min(remaining, f.points * (relevance ?? 1));
          remaining -= points;
          return { ...f, points };
        }).filter((f) => f.points);
        let finalFactors = capped;
        let liveHeadroom = null;
        if (state === "live") {
          const status = comp.status || {};
          const period = Number(status.period || 0);
          const seconds = allocation ? ot.seconds : clockSeconds(status);
          const scores = (comp.competitors || []).map((team) => Number(team.score));
          const tied = scores.length === 2 && scores.every(Number.isFinite) && scores[0] === scores[1];
          let headroom = null;
          if (allocation) {
            const events = factors.filter((f) => f.label !== "Trajectory sustained history").reduce((sum, f) => sum + Math.max(0, f.points) * (relevance ?? 1), 0);
            const endBudget = 2 + Math.min(4, events);
            if (!ot.postseason && (ot.depth || ot.shootout)) headroom = endBudget;
            else if (!ot.postseason && period === 3 && seconds !== null)
              headroom = smoothNhlTarget(seconds, [1200, 720, 600, 300, 120, 60, 0].map((s) => [s, endBudget + (12 - endBudget) * Math.min(1, s / 600)]));
          } else if (tied && !ot.postseason && period === 3 && seconds !== null && seconds <= 15) {
            const age = dramaticTime === null ? Infinity : Math.max(0, current - dramaticTime);
            const recency = smoothNhlTarget(age, [[300, 0], [240, 2], [120, 3], [60, 4], [0, 4]]);
            const significant = majorDrama || pulledComeback || lateChanges >= 2;
            const significance = significant ? smoothNhlTarget(age, [[90, 0], [60, 1], [0, 1]]) : 0;
            headroom = Math.max(0, Math.min(5, Math.round(recency + significance)));
          } else if (tied && !ot.postseason && ot.shootout) {
            headroom = 2;
          } else if (tied && !ot.postseason && ot.depth) {
            const target = Math.round(smoothNhlTarget(seconds ?? 300, [[300, 92], [0, 94]]));
            headroom = Math.max(0, 94 - target);
          }
          if (headroom !== null) {
            liveHeadroom = headroom;
            let available = headroom;
            finalFactors = capped.map((f) => {
              const points = Math.min(available, f.points);
              available -= points;
              return { ...f, points };
            }).filter((f) => f.points);
          }
        }
        const finalScores = (comp.competitors || []).map((c) => [c.homeAway, Number(c.score)]);
        const last = moments.at(-1);
        const reconciled = finalScores.length === 2 && finalScores.every(([side, score]) => Number.isFinite(score) && (score === last[side] || ot.shootout && last.home === last.away && score === last[side] + 1));
        const trailing = (comp.competitors || []).find((c) => Number(c.score) < Math.max(...finalScores.map(([, score]) => score)));
        const trailingPressure = state === "completed" ? (summary?.plays || []).filter((p) => {
          const time2 = hockeyElapsed({ period: p.period?.number || p.period, displayClock: p.clock?.displayValue, clockMode }, ot.postseason);
          return time2 !== null && time2 >= 3300 && time2 <= 3600 && !p.scoringPlay && String(p.team?.id || p.teamId || "") === String(trailing?.team?.id || "unresolved") && /shot on goal|saved by|breakaway|hit (?:the )?(?:post|crossbar)|point-blank/i.test(p.text || p.type?.text || "");
        }).length : 0;
        const meaningful = comeback >= 2 || changes > 0 || lateTie > 0 || lateAhead > 0 || lateTiedTime >= 300 || trailingPressure >= 3;
        const completedContestTarget = state === "completed" && completeLedger && reconciled && Math.abs(margin) <= 1 && meaningful && lateCloseTime >= 300 ? Math.round(44 + 14 * lateCloseTime / 600 + 6 * lateTiedTime / 600 + Math.min(8, 2 * comeback + changes) + Math.min(4, trailingPressure / 2)) : 0;
        return {
          points: finalFactors.reduce((sum, f) => sum + f.points, 0),
          text: finalFactors.map((f) => f.label).join("; "),
          factors: finalFactors,
          ...state === "completed" ? { completedContestTarget } : {},
          ...relevance === null ? {} : { relevance: {
            retention: relevance,
            cap: 12,
            headroom: liveHeadroom,
            factors: factors.map((f) => {
              const retainedPoints = finalFactors.find((a) => a.label === f.label)?.points || 0;
              return {
                label: f.label,
                rawPoints: f.points,
                relevantPoints: f.points * relevance,
                retainedPoints,
                relevanceReduction: f.points * (1 - relevance),
                capReduction: f.points * relevance - retainedPoints
              };
            })
          } },
          handlesFinish: true,
          tiedShare: tiedTime / duration,
          withinOneShare: oneGoalTime / duration
        };
      }
      function hockeyEventShock({ text, positioned, i, play }) {
        let value = 0;
        let label = "";
        if (/shorthanded goal|short-handed goal/.test(text)) {
          value = 6;
          label = "Shorthanded goal";
        }
        return value ? { value, label } : null;
      }
      const nhlModel = {
        unit: "goal",
        pregame: proPregame,
        gameState: hockeyGameState,
        liveFloor: ({ game, progress, scoreGap }) => {
          if (!Number.isFinite(scoreGap) || progress >= 2 / 3) return 0;
          const elapsed = Math.max(0, progress * 60);
          const anchors = [[0, 1], [10, 1], [20, 0.88], [30, 0.55], [40, 0]];
          let retention = 0;
          for (let i = 1; i < anchors.length; i++) if (elapsed <= anchors[i][0]) {
            const [a, y] = anchors[i - 1], [b, z] = anchors[i], x = (elapsed - a) / (b - a);
            retention = y + (z - y) * x * x * (3 - 2 * x);
            break;
          }
          const oneGoal = 0.98 - 0.04 * Math.max(0, Math.min(1, (elapsed - 10) / 10));
          const margin = scoreGap <= 1 ? 1 - (1 - oneGoal) * scoreGap : oneGoal * Math.exp(-3 * Math.pow(scoreGap - 1, 2));
          return Math.min(90, Math.max(0, Number(game.openingScore) || 0)) * retention * margin;
        },
        situation: ({ game, competition, summary, status, progress, scoreGap, nhlAllocation }) => hockeySituationImpact(game, competition, summary, status, progress, scoreGap, nhlAllocation),
        milestone: hockeyGoalMilestone,
        liveMilestone: hockeyLiveMilestone,
        decisiveFloor: true,
        upset: hockeyUpset,
        completedResult: hockeyCompletedResult,
        completedHistory: hockeyCompletedHistory,
        ownsCompletedOvertime: true,
        historyImpact: hockeyHistory,
        eventShock: hockeyEventShock,
        pressure: { maxGap: 2, impact: hockeyPressure },
        contextAnchors: () => [[0, 0.4], [0.25, 0.34], [0.5, 0.27], [0.67, 0.21], [0.82, 0.13], [0.93, 0.08], [1, 0.06]],
        history: { threshold: 2, units: "goals" }
      };
      const api = { nhlLiveMarginCloseness, hockeyOnIceState, hockeyPowerPlay, hockeySituationImpact, hockeyGoalMilestone, hockeyGameState, hockeyEventShock, hockeyOvertime, hockeyLiveTiming, hockeyPlayClockMode, hockeyHistory, hockeyCompletedHistory, hockeyPressure, hockeyUpset, hockeyElapsed, nhlModel };
      if (typeof module2 !== "undefined" && module2.exports) {
        module2.exports = api;
      } else {
        (root.SportsRadarScoring ||= {}).sports_nhl = api;
      }
    })(globalThis);
  }
});

// scoring/shared/college.js
var require_college = __commonJS({
  "scoring/shared/college.js"(exports2, module2) {
    (function(root) {
      const { listedSpread, footballPregameSpread } = typeof module2 !== "undefined" && module2.exports ? require_market() : root.SportsRadarScoring.shared_market;
      function collegePregame(sport, competition, competitors, postseason, factors, reason, rankingRules, options = {}) {
        const ranks = ["CFB", "NCAAB"].includes(sport) ? competitors.map(
          (item) => Number(
            item.curatedRank?.current || item.team?.rank
          )
        ).filter(
          (rank) => rank > 0 && rank <= 25
        ) : [];
        const rankingFactors = [];
        const rankingSpread = sport === "CFB" && options.calibratedPregame ? footballPregameSpread(competition) : listedSpread(competition);
        const competitiveness = rankingSpread === null ? null : 1 / (1 + (rankingSpread / 10) ** 2);
        if (ranks.length === 2) {
          rankingFactors.push({
            label: "Two ranked teams",
            points: rankingRules.twoRankedPoints
          });
          rankingRules.matchup({ ranks, competitors, postseason, factors, rankingFactors });
          reason += " \xB7 two ranked teams";
        } else if (ranks.length === 1) {
          rankingFactors.push({
            label: "Ranked team",
            points: rankingRules.rankedPoints
          });
          if (ranks[0] <= 10) {
            rankingFactors.push({ label: "Top 10 team", points: rankingRules.topTenPoints });
          }
          reason += " \xB7 ranked team";
        }
        if (rankingFactors.length) {
          const multiplier = ranks.length === 2 ? 0.15 + 0.85 * (competitiveness ?? 0.7) : competitiveness ?? 0.35;
          let rawPoints = 0;
          let scaledPoints = 0;
          for (const factor of rankingFactors) {
            rawPoints += factor.points;
            const next = Math.round(rawPoints * multiplier);
            if (next > scaledPoints) {
              factors.push({ ...factor, points: next - scaledPoints });
            }
            scaledPoints = next;
          }
        }
        return reason;
      }
      const api = { collegePregame };
      if (typeof module2 !== "undefined" && module2.exports) {
        module2.exports = api;
      } else {
        (root.SportsRadarScoring ||= {}).shared_college = api;
      }
    })(globalThis);
  }
});

// scoring/shared/basketball.js
var require_basketball = __commonJS({
  "scoring/shared/basketball.js"(exports2, module2) {
    (function(root) {
      const { clockSeconds } = typeof module2 !== "undefined" && module2.exports ? require_time() : root.SportsRadarScoring.shared_time;
      function basketballLiveCloseness(sport, gap, progress, context = {}) {
        if (!["NBA", "NCAAB"].includes(sport) || !Number.isFinite(Number(gap))) return null;
        const points = Math.max(0, Number(gap));
        const marginClose = Math.max(0, 1 - points / 24);
        const status = context.competition?.status || context.status || {};
        const seconds = clockSeconds(status);
        if (seconds === null) return { close: marginClose, marginClose, comebackFeasibility: 1, expectedPossessions: null, requiredPossessions: Math.ceil(points / 3) };
        const regulationPeriods = sport === "NCAAB" ? 2 : 4;
        const periodLength = sport === "NCAAB" ? 20 : 12;
        const period = Number(status.period || 0);
        const remaining = period > regulationPeriods ? seconds : seconds + Math.max(0, regulationPeriods - period) * periodLength * 60;
        const situation = context.situation || context.competition?.situation || {};
        const teams = context.teams || [];
        const scores = teams.map((team) => Number(Array.isArray(team) ? team[2] : team.score));
        const trailingIndex = scores.length === 2 && scores[0] !== scores[1] ? scores[0] < scores[1] ? 0 : 1 : -1;
        const trailingId = trailingIndex >= 0 ? String(Array.isArray(teams[trailingIndex]) ? teams[trailingIndex][8] || "" : teams[trailingIndex].team?.id || teams[trailingIndex].id || "") : "";
        const possessionId = String(situation.possession?.id || situation.possession || "");
        let expectedPossessions = remaining / 24 + 0.5;
        if (possessionId && trailingId) expectedPossessions += possessionId === trailingId ? 0.65 : -0.65;
        const timeoutSource = situation.timeoutsRemaining || situation.timeouts || {};
        const rawCompetitor = (context.competition?.competitors || []).find((item) => String(item.team?.id || item.id || "") === trailingId);
        const trailingSide = rawCompetitor?.homeAway || (Array.isArray(teams[trailingIndex]) ? teams[trailingIndex]?.[7] : teams[trailingIndex]?.homeAway) || "";
        const rawTimeouts = rawCompetitor?.timeoutsRemaining ?? rawCompetitor?.timeouts?.remaining ?? rawCompetitor?.timeouts;
        const trailingTimeouts = Number(timeoutSource[trailingId] ?? timeoutSource[trailingSide] ?? situation[`${trailingSide}TimeoutsRemaining`] ?? rawTimeouts);
        if (Number.isFinite(trailingTimeouts)) expectedPossessions += Math.min(2, Math.max(0, trailingTimeouts)) * 0.4;
        expectedPossessions = Math.max(0, expectedPossessions);
        const requiredPossessions = Math.ceil(points / 3);
        const slack = expectedPossessions - requiredPossessions;
        const comebackFeasibility = requiredPossessions === 0 ? 1 : 1 / (1 + Math.exp(-2 * (slack + 0.4)));
        const close = marginClose * (0.25 + 0.75 * comebackFeasibility);
        return { close, marginClose, comebackFeasibility, expectedPossessions, requiredPossessions, slack };
      }
      function basketballSituationImpact(game, status, progress, scoreGap, situation = {}) {
        let points = 0;
        let genericTimePoints = 0;
        const reasons = [];
        const genericTimeReasons = [];
        const seconds = clockSeconds(status);
        const regulationPeriods = game.sport === "NCAAB" ? 2 : 4;
        const possessionId = String(situation.possession?.id || situation.possession || "");
        const holderIndex = possessionId ? game.teams.findIndex((team) => String(team[8] || "") === possessionId) : -1;
        const holder = holderIndex >= 0 ? game.teams[holderIndex] : null;
        const other = holderIndex >= 0 ? game.teams[1 - holderIndex] : null;
        const holderScore = holder ? Number(holder[2]) : NaN;
        const otherScore = other ? Number(other[2]) : NaN;
        const finalPossession = seconds !== null && Number(status?.period) >= regulationPeriods && scoreGap <= 3 && holder && Number.isFinite(holderScore) && Number.isFinite(otherScore) && holderScore <= otherScore && seconds < 40 ? { urgency: Math.max(0, Math.min(1, (40 - seconds) / 28)) } : null;
        if (progress >= 0.78 && scoreGap <= 6) {
          genericTimePoints = scoreGap === 0 ? progress >= 0.9 ? 9 : 6 : scoreGap <= 3 ? progress >= 0.9 ? 7 : 5 : 3;
          points += genericTimePoints;
          const reason = scoreGap === 0 ? "The game is tied late" : `It is a ${scoreGap}-point game late`;
          reasons.push(reason);
          genericTimeReasons.push(reason);
        }
        if (seconds !== null && Number(status?.period) >= regulationPeriods && seconds <= 24 && scoreGap <= 3) {
          if (holder && Number.isFinite(holderScore) && Number.isFinite(otherScore) && holderScore <= otherScore) {
            points += 5;
            reasons.push(`${holder[0]} has a potential tying or go-ahead final possession`);
          } else {
            points += 3;
            reasons.push("The game may come down to the final possession");
          }
        }
        if (Number(status?.period) > regulationPeriods) {
          points += 6;
          reasons.push("The game is in overtime");
        }
        return {
          points: Math.min(12, points),
          note: holder ? `${holder[1] || holder[0]} possession` : "",
          reasons,
          candidatePoints: Math.min(12, Math.max(0, points - genericTimePoints)),
          genericTimePoints,
          genericTimeReasons,
          competitiveFloor: finalPossession ? Math.round(20 * finalPossession.urgency) : 0,
          finalPossession
        };
      }
      function basketballScoringMilestone(summary, sport) {
        const threshold = sport === "NCAAB" ? 30 : 40;
        let leader = null;
        for (const block of summary?.boxscore?.players || []) {
          for (const group of block.statistics || []) {
            const points = (group.labels || []).findIndex(
              (label) => /^PTS$|^POINTS$/i.test(label)
            );
            if (points < 0) {
              continue;
            }
            for (const entry of group.athletes || []) {
              const count = Number(
                entry.stats?.[points]
              );
              if (count >= threshold && (!leader || count > leader.count)) {
                leader = {
                  count,
                  name: entry.athlete?.displayName || "A player"
                };
              }
            }
          }
        }
        if (!leader) {
          return null;
        }
        const rare = leader.count >= (sport === "NCAAB" ? 40 : 50);
        return {
          text: `${leader.name} has scored ${leader.count} points`,
          points: rare ? 12 : 7
        };
      }
      const api = { basketballLiveCloseness, basketballSituationImpact, basketballScoringMilestone };
      if (typeof module2 !== "undefined" && module2.exports) {
        module2.exports = api;
      } else {
        (root.SportsRadarScoring ||= {}).shared_basketball = api;
      }
    })(globalThis);
  }
});

// scoring/sports/basketball.js
var require_basketball2 = __commonJS({
  "scoring/sports/basketball.js"(exports2, module2) {
    (function(root) {
      const { proPregame, marketPregame } = typeof module2 !== "undefined" && module2.exports ? require_pregame() : root.SportsRadarScoring.shared_pregame;
      const { collegePregame } = typeof module2 !== "undefined" && module2.exports ? require_college() : root.SportsRadarScoring.shared_college;
      const { basketballLiveCloseness, basketballSituationImpact, basketballScoringMilestone } = typeof module2 !== "undefined" && module2.exports ? require_basketball() : root.SportsRadarScoring.shared_basketball;
      function basketballLeadChanges({ sport, state, flipPositions, currentProgress, basketballDramaBucket, basketballLatePhase, factors, details }) {
        const weightedLeadChanges = flipPositions.reduce(
          (sum, position) => {
            if (position === null || !Number.isFinite(position) || position < 0.5) {
              return sum;
            }
            if (position < 0.75) {
              return sum + 0.5;
            }
            if (position < 0.875) {
              return sum + 1.5;
            }
            if (position < 0.95) {
              return sum + 3;
            }
            return sum + 4;
          },
          0
        );
        const leadChangePoints = Math.min(
          state === "completed" ? 12 : 10,
          Math.round(
            weightedLeadChanges
          )
        );
        if (leadChangePoints) {
          const lateLeadChanges = flipPositions.filter(
            (position) => Number.isFinite(position) && position >= 0.75
          ).length;
          factors.push({
            label: lateLeadChanges ? `${lateLeadChanges} late lead change${lateLeadChanges === 1 ? "" : "s"}` : "Second-half lead changes",
            points: leadChangePoints,
            bucket: basketballDramaBucket
          });
          details.push(
            lateLeadChanges ? `the lead changed ${lateLeadChanges} time${lateLeadChanges === 1 ? "" : "s"} in the ${basketballLatePhase}` : "the lead changed after halftime"
          );
        }
        const clusterStart = state === "completed" ? 0.875 : Math.max(
          0.75,
          currentProgress - 0.125
        );
        const clusteredLateFlips = flipPositions.filter(
          (position) => Number.isFinite(position) && position >= clusterStart
        ).length;
        if (clusteredLateFlips >= 2) {
          const clusterPoints = clusteredLateFlips >= 5 ? 7 : clusteredLateFlips === 4 ? 6 : clusteredLateFlips === 3 ? 4 : 2;
          factors.push({
            label: "Late back-and-forth lead changes",
            points: clusterPoints,
            bucket: basketballDramaBucket
          });
          details.push(
            `${clusteredLateFlips} lead changes came in a compressed late-game window`
          );
        }
      }
      function basketballLateTies({ basketball, tiePositions, basketballDramaBucket, basketballLatePhase, factors, details }) {
        if (basketball) {
          const lateTies = tiePositions.filter(
            (position) => position >= 0.75
          );
          if (lateTies.length) {
            const lastLateTie = lateTies.at(-1);
            const tiePoints = lastLateTie >= 0.95 ? Math.min(
              4,
              2 + lateTies.length
            ) : Math.min(
              3,
              lateTies.length
            );
            factors.push({
              label: lateTies.length === 1 ? "Late tie" : `${lateTies.length} late ties`,
              points: tiePoints,
              bucket: basketballDramaBucket
            });
            details.push(
              lastLateTie >= 0.95 ? "the game was tied in the final 5% of regulation" : `the game was tied ${lateTies.length} time${lateTies.length === 1 ? "" : "s"} in the ${basketballLatePhase}`
            );
          }
        }
      }
      function basketballRankedMatchup({ ranks, rankingFactors }) {
        if (ranks.every((rank) => rank <= 10)) {
          rankingFactors.push({ label: "Both top 10", points: 6 });
        } else if (ranks.every((rank) => rank <= 20)) {
          rankingFactors.push({ label: "Both top 20", points: 3 });
        }
        if (ranks.some((rank) => rank <= 10)) {
          rankingFactors.push({ label: "Top 10 team", points: 3 });
        }
      }
      function basketballPregame(sport, competition, competitors, postseason, factors, reason, detail) {
        if (sport === "NBA") return proPregame(sport, competition, competitors, postseason, factors, reason, detail);
        reason = marketPregame(sport, competition, factors, reason);
        return collegePregame(sport, competition, competitors, postseason, factors, reason, {
          twoRankedPoints: 9,
          rankedPoints: 4,
          topTenPoints: 3,
          matchup: basketballRankedMatchup
        });
      }
      function basketballGameState({ sport, gameState, gap, progress, context: footballContext, closeLimit }) {
        const basketballState = ["NBA", "NCAAB"].includes(sport) && gameState === "live" ? basketballLiveCloseness(sport, gap, progress, footballContext || {}) : null;
        const completedNba = sport === "NBA" && gameState === "completed";
        return {
          basketballState,
          completedCloseLimit: completedNba ? 24 : closeLimit,
          marginClose: basketballState?.close,
          comebackViability: basketballState?.comebackFeasibility,
          stateBase: completedNba ? 23 : void 0,
          closeCeiling: completedNba ? 35 : void 0,
          widePenalty: completedNba ? gap !== null && gap >= 20 ? Math.min(28, Math.round(2 + (gap - 20) * 1.1)) : 0 : basketballState ? gap !== null && gap >= 4 && basketballState.comebackFeasibility < 0.45 ? Math.min(14, Math.round((0.45 - basketballState.comebackFeasibility) / 0.45 * 14 * (0.5 + 0.5 * progress))) : 0 : void 0,
          limitedRunway: Boolean(basketballState && basketballState.comebackFeasibility < 0.45)
        };
      }
      function basketballEventShock({ text, positioned, i, play }) {
        let value = 0;
        let label = "";
        if (/buzzer[- ]beater|at the buzzer|game[- ]tying three|ties the game with (?:a )?three|three.{0,30}(?:ties|tie) the game/.test(text)) {
          value = 10;
          label = "Buzzer-beater or tying three";
        }
        return value ? { value, label } : null;
      }
      const nbaModel = {
        duration: 48,
        pregame: basketballPregame,
        gameState: basketballGameState,
        situation: ({ game, status, progress, scoreGap, situation }) => basketballSituationImpact(game, status, progress, scoreGap, situation),
        milestone: basketballScoringMilestone,
        eventShock: basketballEventShock,
        history: {
          threshold: 10,
          units: "points",
          dramaBucket: "basketball-late-drama",
          dramaCap: 15,
          latePhase: "fourth quarter",
          leadChanges: basketballLeadChanges,
          lateTies: basketballLateTies
        }
      };
      const ncaabModel = {
        ...nbaModel,
        duration: 40,
        history: { ...nbaModel.history, latePhase: "final 10 minutes" }
      };
      const api = { basketballLeadChanges, basketballLateTies, basketballRankedMatchup, basketballPregame, basketballGameState, basketballEventShock, nbaModel, ncaabModel };
      if (typeof module2 !== "undefined" && module2.exports) {
        module2.exports = api;
      } else {
        (root.SportsRadarScoring ||= {}).sports_basketball = api;
      }
    })(globalThis);
  }
});

// scoring/sports/cfb.js
var require_cfb = __commonJS({
  "scoring/sports/cfb.js"(exports2, module2) {
    (function(root) {
      const { marketPregame } = typeof module2 !== "undefined" && module2.exports ? require_pregame() : root.SportsRadarScoring.shared_pregame;
      const { collegePregame } = typeof module2 !== "undefined" && module2.exports ? require_college() : root.SportsRadarScoring.shared_college;
      const { recordFor: recordFor2, rankFor: rankFor2 } = typeof module2 !== "undefined" && module2.exports ? require_records() : root.SportsRadarScoring.shared_records;
      const { footballGameState, footballLiveCloseness, footballTimeouts, footballCompetitorId, footballSituationFieldPosition, footballOvertimeResponse, footballPendingTryImpact, footballMilestone, footballEventShock, footballStagnationImpact } = typeof module2 !== "undefined" && module2.exports ? require_football() : root.SportsRadarScoring.shared_football;
      const { clockSeconds } = typeof module2 !== "undefined" && module2.exports ? require_time() : root.SportsRadarScoring.shared_time;
      const unit = (value) => Math.max(0, Math.min(1, value));
      const smooth = (value) => {
        const x = unit(value);
        return x * x * (3 - 2 * x);
      };
      function cfbMidgameFloor({ progress, scoreGap }) {
        if (!Number.isFinite(scoreGap) || progress <= 23 / 60 || progress >= 11 / 12) return 0;
        const ramp = smooth((progress - 23 / 60) / (5 / 60));
        const boundaryLift = smooth((progress - 43 / 60) / (2 / 60));
        const target = 60 + 44 * Math.max(0, Math.min(0.75, progress) - 0.5) + boundaryLift + 6 * Math.max(0, progress - 0.75);
        const anchors = [[0, 1], [3, 0.955], [7, 0.85], [10, 0.72], [14, 0.62], [21, 0.3], [28, 0]];
        let viability = 0;
        for (let i = 1; i < anchors.length; i++) if (scoreGap <= anchors[i][0]) {
          const [x, y] = anchors[i - 1], [xx, yy] = anchors[i];
          viability = y + (yy - y) * smooth((scoreGap - x) / (xx - x));
          break;
        }
        const carryMargin = progress <= 43 / 60 ? 1 : smooth((14 - scoreGap) / 4);
        return target * ramp * viability * carryMargin;
      }
      function cfbEventShockWeight({ text, positioned, i, play }) {
        if (!/touchdown|\btd\b|\bsafety\b/.test(text)) return 1;
        const previous = positioned[i - 1]?.play;
        const scores = (p) => p && [p.homeScore, p.awayScore].every((v) => v !== null && v !== "" && Number.isFinite(Number(v))) ? [Number(p.homeScore), Number(p.awayScore)] : null;
        const before = scores(previous), after = scores(play);
        if (!before || !after) return 0;
        const delta = after.map((v, j) => v - before[j]);
        if (!(delta[0] > 0 && delta[1] === 0 || delta[1] > 0 && delta[0] === 0)) return 0;
        const oldGap = Math.abs(before[0] - before[1]), gap = Math.abs(after[0] - after[1]);
        if (gap < oldGap) return 1 - smooth((gap - 8) / 13);
        return oldGap === 0 && gap <= 8 ? 0.6 : 0;
      }
      function cfbPossession(competition, situation = competition?.situation) {
        const teams = competition?.competitors || [];
        const id = String(situation?.possession?.id || situation?.possession || "");
        const offense = id && teams.find((t) => footballCompetitorId(t) === id);
        const defense = teams.find((t) => t !== offense);
        if (teams.length !== 2 || !offense || !defense || teams.some((t) => t.score == null || t.score === "" || !Number.isFinite(Number(t.score)))) return null;
        const abbr = String(offense.team?.abbreviation || offense.abbreviation || "").toUpperCase();
        const otherAbbr = String(defense.team?.abbreviation || defense.abbreviation || "").toUpperCase();
        const text = `${situation?.possessionText || ""} ${situation?.downDistanceText || situation?.shortDownDistanceText || ""}`.toUpperCase();
        const spot = text.match(/\b([A-Z][A-Z0-9]{1,6})\s+(\d{1,2})\b/);
        let position = footballSituationFieldPosition(situation, abbr);
        if (spot) position = [abbr, otherAbbr].includes(spot[1]) && Number(spot[2]) <= 50 ? spot[1] === abbr ? Number(spot[2]) : 100 - Number(spot[2]) : null;
        return { offense, defense, deficit: Number(defense.score) - Number(offense.score), position };
      }
      function cfbClockRunway(competition, situation = competition?.situation) {
        const seconds = clockSeconds(competition?.status);
        const possession = cfbPossession(competition, situation);
        if (Number(competition?.status?.period) !== 4 || seconds === null || seconds < 0 || seconds > 900 || !possession) return null;
        const { offense, defense, deficit, position } = possession;
        const trailing = deficit >= 0 ? offense : defense;
        const timeouts = footballTimeouts(competition, situation, trailing);
        const down = Number(situation?.down);
        let remaining = seconds;
        let offensiveTimeouts = timeouts ?? 0;
        if (deficit < 0) {
          if (timeouts === null || !Number.isInteger(down) || down < 1 || down > 4) return null;
          const year = Number(competition?.season?.year);
          const warning = year >= 2024 && seconds > 120 ? 1 : 0;
          const stops = timeouts + warning;
          const snaps = 4 - down;
          remaining = Math.max(0, seconds - 6 * snaps - 40 * Math.max(0, snaps - stops) - 8);
          offensiveTimeouts = Math.max(0, timeouts - Math.max(0, snaps - warning));
        }
        const yards = deficit >= 0 ? Math.max(0, 100 - (position ?? 25)) : 75;
        const driveSeconds = 12 + (remaining <= 120 ? 0.42 : 0.6) * yards;
        const usable = remaining + offensiveTimeouts * 5;
        const paceBudget = 14 * remaining / 3600 + 1.5;
        const expectedPossessions = remaining <= 0 ? 0 : Math.min(
          paceBudget,
          Math.min(1, usable / driveSeconds) + Math.max(0, usable - driveSeconds) / 145
        );
        return { remaining, timeouts, offensiveTimeouts, expectedPossessions: expectedPossessions * (deficit < 0 ? 0.78 : 1), driveSeconds };
      }
      function cfbDriveFeasibility(competition, situation = competition?.situation) {
        const possession = cfbPossession(competition, situation), seconds = clockSeconds(competition?.status);
        if (!possession || possession.deficit < 0 || possession.deficit > 8 || Number(competition?.status?.period) !== 4 || seconds === null) return 1;
        const late = smooth((240 - seconds) / 120), down = Number(situation?.down), distance = Number(situation?.distance);
        const long = Number.isFinite(distance) && distance > 0 ? smooth((distance - 9) / 11) : 0;
        const conversion = Number.isFinite(distance) && distance > 0 ? 1 - (down === 4 ? 0.65 : down === 3 ? 0.48 : down === 2 ? 0.12 : 0) * long : 1;
        const yards = Math.max(0, (possession.deficit < 3 ? 65 : 100) - (possession.position ?? 25));
        const timeouts = footballTimeouts(competition, situation, possession.offense) ?? 0;
        const clock = unit((Math.max(0, seconds) + 5 * timeouts) / (12 + 0.55 * yards));
        const field = 1 - 0.16 * unit((yards - 25) / 65) * Math.max(long, smooth(possession.deficit - 7));
        const requiredConversion = 1 - 0.15 * smooth(possession.deficit - 7);
        return 1 - late * (1 - conversion * clock * field * requiredConversion);
      }
      function cfbImmediateTension(gap, runwayCloseness) {
        return runwayCloseness * (1 - 0.18 * smooth((gap - 3) / 11));
      }
      function cfbMarginCloseness(gap) {
        const anchors = [[0, 1], [3, 0.99], [7, 0.95], [10, 0.87], [14, 0.76], [17, 0.64], [21, 0.49], [28, 0.28], [35, 0.1], [42, 0]];
        for (let i = 1; i < anchors.length; i++) {
          if (gap <= anchors[i][0]) {
            const [x, y] = anchors[i - 1], [nextX, nextY] = anchors[i];
            return y + (nextY - y) * unit((gap - x) / (nextX - x));
          }
        }
        return 0;
      }
      function cfbLiveCloseness(sport, gap, progress, context = null) {
        if (gap == null || !Number.isFinite(Number(gap)) || Number(gap) < 0) return null;
        gap = Number(gap);
        const state = footballLiveCloseness("CFB", gap, progress, context);
        const competition = context?.competition || context;
        const situation = context?.situation || competition?.situation;
        const possession = cfbPossession(competition, situation);
        const p = unit(Number(progress) || 0);
        const runway = cfbClockRunway(competition, situation);
        const broad = Math.max(0, 14 * (1 - p) + 0.5 + state.possessionAdjustment);
        const q3Weight = smooth((p - 0.5) / (43 / 60 - 0.5)) * smooth((0.75 - p) / (2 / 60));
        const q3Opportunities = Math.max(0, 2.1 + 6 * Math.max(0, 43 / 60 - p) + 0.15 * state.possessionAdjustment);
        const expectedPossessions = runway?.expectedPossessions ?? broad + (q3Opportunities - broad) * q3Weight;
        const requiredPossessions = gap > 0 ? Math.max(1, gap / 7) : 0;
        const possessionSlack = expectedPossessions - requiredPossessions;
        const driveFeasibility = cfbDriveFeasibility(competition, situation);
        const comebackFeasibility = gap === 0 ? 1 : expectedPossessions === 0 ? 0 : driveFeasibility / (1 + Math.exp(-2.8 * (possessionSlack + 0.45)));
        const marginClose = cfbMarginCloseness(gap);
        return {
          ...state,
          requiredPossessions,
          expectedPossessions,
          possessionSlack,
          comebackFeasibility,
          marginClose,
          possessionState: gap > 0 && possession ? possession.deficit > 0 ? "trailing" : "leading" : "",
          fieldPosition: possession?.deficit > 0 ? possession.position : null,
          close: marginClose * (0.2 + 0.8 * comebackFeasibility),
          runway
        };
      }
      function cfbGameState(args) {
        if (args.gameState !== "live") return footballGameState(args);
        const state = cfbLiveCloseness("CFB", args.gap, args.progress, args.context);
        if (!state) return {};
        const competition = args.context?.competition || args.context;
        const possession = cfbPossession(competition, args.context?.situation || competition?.situation);
        const seconds = clockSeconds(competition?.status);
        const urgency = Number(competition?.status?.period) === 4 && seconds > 0 ? unit((660 - seconds) / 540) : 0;
        const direction = possession?.deficit >= 0 ? 1 : possession ? state.comebackFeasibility * 0.45 : 0.2;
        const mismatch = Math.max(0, state.requiredPossessions - state.expectedPossessions);
        return {
          footballState: state,
          marginClose: state.close,
          comebackViability: state.comebackFeasibility,
          contextViability: 0.15 + 0.85 * state.comebackFeasibility,
          uncertaintyCeiling: state.comebackFeasibility,
          closeCeiling: 14 + 16 * unit(args.progress) + 10 * urgency * direction,
          widePenalty: args.gap >= 9 ? Math.round(Math.min(30, 20 * (1 - state.comebackFeasibility) * unit(args.progress) + 4 * mismatch)) : 0,
          limitedRunway: true
        };
      }
      function cfbOvertime(competition, summary) {
        const period = Number(competition?.status?.period);
        const basic = { active: period > 4, response: false, decisive: false, shootout: false };
        const pending = footballOvertimeResponse("CFB", competition, summary);
        if (pending) return { ...basic, response: true, decisive: true, pendingResponse: pending };
        if (!basic.active) return basic;
        const seen = /* @__PURE__ */ new Set();
        const completed = [...summary?.drives?.previous || [], ...summary?.drives?.current ? [summary.drives.current] : []].filter((d) => d.isCurrent !== true && d.result && !/end of|kickoff/i.test(d.result) && Number(d.start?.period?.number ?? d.plays?.[0]?.period?.number) === period && d.plays?.some((p) => String(p.start?.team?.id || "") === String(d.team?.id || "") && p.start?.team?.id && !/kickoff|timeout|end of/i.test(p.type?.text || p.text || ""))).filter((d) => {
          if (!d.id) return true;
          if (seen.has(String(d.id))) return false;
          seen.add(String(d.id));
          return true;
        });
        const teams = competition?.competitors || [];
        const last = completed.at(-1)?.plays?.at(-1);
        const responseFinished = completed.length === 2 && new Set(completed.map((d) => String(d.team?.id))).size === 2 && competition?.situation?.isTwoPointAttempt !== true && last?.id && String(last.id) === String(competition?.situation?.lastPlay?.id) && teams.length === 2 && Number(teams[0].score) !== Number(teams[1].score) && teams.every((t) => t.score != null && last[`${t.homeAway}Score`] != null && Number(t.score) === Number(last[`${t.homeAway}Score`]));
        const possession = cfbPossession(competition);
        if (!possession) return { ...basic, responseFinished: Boolean(responseFinished) };
        const { offense, defense, deficit } = possession;
        const year = Number(summary?.header?.season?.year || competition?.season?.year);
        const explicitTry = competition?.situation?.isTwoPointAttempt === true;
        const shootout = explicitTry && (year >= 2021 && period >= 7 || year >= 2019 && year < 2021 && period >= 9);
        const own = completed.filter((d) => String(d.team?.id) === footballCompetitorId(offense));
        const other = completed.filter((d) => String(d.team?.id) === footballCompetitorId(defense));
        const pendingResponseTry = explicitTry && !shootout && own.length === 1 && other.length === 1 && completed.indexOf(own[0]) > completed.indexOf(other[0]) && /touchdown/i.test(own[0].result);
        const response = other.length === 1 && (own.length === 0 || pendingResponseTry);
        return { ...basic, response, shootout, responseFinished: Boolean(responseFinished), decisive: response && deficit >= 0 && deficit <= (shootout ? 2 : 8) };
      }
      function cfbSituation({ game, competition, status, situation, summary, scoreGap }) {
        const pendingTry = footballPendingTryImpact({ game, competition, status, situation, summary });
        if (pendingTry) return pendingTry;
        const current = { ...competition, status, situation };
        const possession = cfbPossession(current);
        const result = { points: 0, note: "", reasons: [], competitiveFloor: 0 };
        const overtime = cfbOvertime(current, summary);
        const awaitingUpdate = overtime.active && !overtime.responseFinished && Number.isFinite(scoreGap) && scoreGap <= 8 && (!possession || Number(situation.down) === -1 && Number(situation.lastPlay?.scoreValue) > 0);
        if (overtime.pendingResponse || awaitingUpdate) {
          const pending = overtime.pendingResponse;
          return {
            points: 12,
            competitiveFloor: Math.round(Math.max(0, 99 - Number(game.baseScore || 0)) * (pending ? 0.94 : 0.82)),
            note: pending ? `${pending.abbreviation || "Opponent"} overtime response pending` : "College overtime \xB7 Possession update pending",
            reasons: [pending ? "The opening overtime score does not end the game; the opponent still has a response possession" : "College overtime is untimed; missing possession data does not mean the opportunity has expired"]
          };
        }
        if (!possession) return result;
        const { offense, defense, deficit, position } = possession;
        const down = Number(situation.down), distance = Number(situation.distance);
        const seconds = clockSeconds(status), period = Number(status.period);
        const tryState = situation.isTwoPointAttempt === true;
        const goal = (situation.isGoalToGo === true || /&\s*goal/i.test(situation.downDistanceText || situation.shortDownDistanceText || "")) && position !== null && position >= 90;
        result.note = [offense.team?.abbreviation ? `${offense.team.abbreviation} ball` : "", situation.downDistanceText || situation.shortDownDistanceText, situation.possessionText].filter(Boolean).join(" \xB7 ");
        result.points = tryState ? 2 : down === 4 ? Math.min(3, 1 + (distance > 0 && distance <= 2 ? 1 : 0) + (position >= 70 ? 1 : 0)) : 0;
        let consequence = 0, viability = 1, urgency = 0;
        const criticalTry = tryState && [1, 2].includes(deficit) && period === 4 && seconds !== null && seconds >= 0 && seconds <= 150;
        if (period === 4 && deficit >= 0 && deficit <= 8 && (seconds > 0 || criticalTry)) {
          urgency = criticalTry ? 1 : unit((600 - seconds) / 480);
          const winningRange = deficit < 3 && position !== null && position >= 60;
          consequence = winningRange ? 0.84 : 0.73 + 0.06 * unit(((position ?? 25) - 25) / 55);
          const afterFailure = cfbClockRunway(current, { ...situation, possession: footballCompetitorId(defense), down: 1 });
          const finalFourth = down === 4 && deficit > 0 && (afterFailure ? afterFailure.remaining <= 15 : seconds <= 45);
          if (finalFourth) consequence = Math.max(consequence, 0.87 + 0.03 * (Number.isFinite(distance) && distance > 0 ? unit((10 - distance) / 9) : 0));
          if (goal) consequence = Math.max(consequence, 0.91);
          if (criticalTry) consequence = deficit === 1 ? 0.95 : 0.92;
          if (game.championshipStakes && (criticalTry || finalFourth || goal)) consequence = Math.min(0.98, consequence + 0.04);
          const ranks = [rankFor2(offense, "CFB"), rankFor2(defense, "CFB")];
          if (ranks.every(Boolean)) consequence = Math.min(0.98, consequence + 0.04 * Math.pow((26 - Math.max(...ranks)) / 25, 2));
          const yards = Math.max(0, (deficit < 3 ? 65 : 100) - (position ?? 25));
          viability = criticalTry || goal ? 1 : Math.min(1, seconds / (10 + 0.42 * yards)) * cfbDriveFeasibility(current, situation);
          if (urgency > 0) result.reasons.push(criticalTry ? "Critical two-point try to tie or win" : finalFourth ? "Final meaningful fourth down" : goal ? "Decisive goal-to-go snap" : viability < 0.65 ? "Tying drive limited by distance, field position and required conversions" : "A viable tying or winning possession");
        }
        if (overtime.active && !overtime.responseFinished && Math.abs(deficit) <= 8 && (deficit >= 0 || tryState)) {
          urgency = 1;
          consequence = overtime.decisive ? overtime.shootout || tryState ? 0.97 : 0.94 : 0.82;
          const championship = game.championshipStakes;
          if (overtime.decisive && championship && (tryState || goal || down === 4)) consequence = 1;
          result.reasons.push(overtime.decisive ? "Overtime response: this possession can decide the game" : "College overtime possession; response rights unconfirmed");
        }
        if (urgency > 0) {
          result.points = Math.max(result.points, Math.round(12 * urgency * viability));
          if (Number.isFinite(Number(game.baseScore))) result.competitiveFloor = Math.round(Math.max(0, 99 - Number(game.baseScore)) * consequence * urgency * viability);
        }
        return result;
      }
      function cfbUpsetImpact(candidate, teams, gameState, progress, sport, competition) {
        if (gameState !== "live" || !candidate) return null;
        if (candidate.type !== "spread" || !Number.isFinite(Number(candidate.value))) return null;
        const index = teams.findIndex((t) => String(t.id || t[8] || t.team?.id || "") === candidate.teamId);
        const i = index >= 0 ? index : candidate.teamIndex;
        if (teams.length !== 2 || ![0, 1].includes(i)) return { points: 0, text: "" };
        const margin = Number(teams[i].score ?? teams[i][2]) - Number(teams[1 - i].score ?? teams[1 - i][2]);
        if (!Number.isFinite(margin) || progress < (margin > 0 ? 0.35 : 0.7)) return { points: 0, text: "" };
        const state = cfbLiveCloseness("CFB", Math.abs(margin), progress, competition);
        const x = unit((Number(candidate.value) - 7) / 23);
        const magnitude = x * x * (3 - 2 * x);
        const competitors = competition?.competitors || [];
        const dog = competitors.find((t) => footballCompetitorId(t) === candidate.teamId);
        const favorite = competitors.find((t) => t !== dog);
        const favoriteRank = rankFor2(favorite, "CFB"), dogRank = rankFor2(dog, "CFB");
        const rankThreat = favoriteRank && dog ? (26 - favoriteRank) / 25 * unit(((dogRank || 35) - favoriteRank) / 20) : 0;
        const possessionWeight = margin < 0 ? state.possessionState === "trailing" ? 1 : state.possessionState === "leading" ? 0.65 : 0.8 : 1;
        const fieldWeight = margin < 0 && state.possessionState === "trailing" && state.fieldPosition !== null ? 1 + 0.08 * unit((state.fieldPosition - 50) / 50) : 1;
        const viability = state.comebackFeasibility * Math.exp(-Math.pow(Math.abs(margin) / (margin < 0 ? 8 : 22), 1.6)) * possessionWeight * fieldWeight * (margin > 0 ? 1.25 : 1);
        const activation = 0.5 + 0.5 * unit(candidate.activation ?? 1);
        const points = Math.min(36, Math.round((12 + 16 * magnitude + 6 * rankThreat * unit((progress - 0.5) / 0.4)) * (0.35 + 0.65 * unit(progress)) * viability * activation));
        return { points, text: points ? `${candidate.teamName}, a ${candidate.description}, ${margin > 0 ? "leads" : margin === 0 ? "is tied" : "remains within reach"} in a viable upset` : "" };
      }
      function cfbPregame(sport, competition, competitors, postseason, factors, reason, detail, options = {}) {
        reason = marketPregame(sport, competition, factors, reason, options);
        return collegePregame(sport, competition, competitors, postseason, factors, reason, {
          twoRankedPoints: 28,
          rankedPoints: 11,
          topTenPoints: 5,
          matchup: cfbRankedMatchup
        }, options);
      }
      function cfbRankedMatchup({ ranks, competitors, postseason, factors, rankingFactors }) {
        if (ranks.every(
          (rank) => rank <= 20
        )) {
          rankingFactors.push({
            label: "Both top 20",
            points: 4
          });
        }
        if (ranks.some(
          (rank) => rank <= 10
        )) {
          rankingFactors.push({
            label: "Top 10 team",
            points: 5
          });
        }
        const records = competitors.map(recordFor2).map(
          (value) => String(value).match(
            /^(\d+)-(\d+)/
          )
        );
        if (!postseason && records.every(
          (match) => match && Number(match[1]) > Number(match[2])
        )) {
          factors.push({
            label: "Both winning records",
            points: 3
          });
        }
        if (!postseason && records.some(
          (match) => match && Number(match[1]) >= 4 && Number(match[2]) === 0
        )) {
          factors.push({
            label: "Unbeaten team",
            points: 4
          });
        }
      }
      function cfbCompletedUpset(candidate, teams, gameState, progress, sport, competition) {
        if (!candidate || candidate.type !== "spread" || !Number.isFinite(Number(candidate.value))) return null;
        const competitors = competition?.competitors || [];
        const index = teams.findIndex((t) => String(t.id || t[8] || t.team?.id || "") === candidate.teamId);
        const i = index >= 0 ? index : candidate.teamIndex;
        if (teams.length !== 2 || ![0, 1].includes(i)) return { points: 0, text: "" };
        const margin = Number(teams[i].score ?? teams[i][2]) - Number(teams[1 - i].score ?? teams[1 - i][2]);
        if (!Number.isFinite(margin) || margin <= 0) return { points: 0, text: "" };
        const magnitude = unit((Number(candidate.value) - 7) / 23);
        const dog = competitors.find((t) => footballCompetitorId(t) === candidate.teamId);
        const favorite = dog && competitors.find((t) => t !== dog);
        const favoriteRank = rankFor2(favorite, "CFB"), dogRank = rankFor2(dog, "CFB");
        const rank = favoriteRank ? (26 - favoriteRank) / 25 * unit(((dogRank || 35) - favoriteRank) / 20) : 0;
        const significance = 6 + 16 * magnitude + 6 * rank * (0.35 + 0.65 * magnitude);
        const quality = unit((28 - margin) / 25);
        const extraordinary = quality * quality * (20 * Math.pow(magnitude, 1.5) + 3 * rank * (0.35 + 0.65 * magnitude));
        const points = Math.round(significance * (0.25 + 0.75 * quality) + extraordinary);
        return { points, text: `${candidate.teamName} won outright as a ${candidate.description}; result significance is scaled by competitiveness` };
      }
      function cfbCompletedPath(summary, competition) {
        const plays = summary?.scoringPlays?.length ? summary.scoringPlays : (summary?.plays || []).filter((p) => p.scoringPlay === true);
        const moments = [];
        let valid = plays.length >= 3;
        let previous = { home: 0, away: 0, position: 0 };
        let lastCompetitivePosition = 0, competitiveShare = 0, comeback = 0, changes = 0, leader = 0;
        let homeDeficit = 0, awayDeficit = 0;
        for (const play of plays) {
          const period = Number(play.period?.number ?? play.period);
          const seconds = clockSeconds({ displayClock: play.clock?.displayValue, clock: play.clock?.value });
          const home2 = Number(play.homeScore), away2 = Number(play.awayScore);
          if (play.homeScore == null || play.awayScore == null || play.homeScore === "" || play.awayScore === "" || !Number.isFinite(home2) || !Number.isFinite(away2) || !Number.isInteger(period) || period < 1 || seconds === null || seconds < 0 || seconds > 900) {
            valid = false;
            continue;
          }
          const position = Math.min(1, ((period - 1) * 900 + 900 - seconds) / 3600);
          const homeGain = home2 - previous.home, awayGain = away2 - previous.away;
          if (position < previous.position || homeGain < 0 || awayGain < 0 || homeGain > 8 || awayGain > 8 || homeGain > 0 && awayGain > 0) valid = false;
          if (Math.abs(previous.home - previous.away) <= 8) {
            competitiveShare += Math.max(0, position - previous.position);
            lastCompetitivePosition = position;
          }
          const margin = home2 - away2;
          if (margin && leader && Math.sign(margin) !== leader) changes++;
          if (margin) leader = Math.sign(margin);
          homeDeficit = Math.max(homeDeficit, -margin);
          awayDeficit = Math.max(awayDeficit, margin);
          if (margin >= 0) comeback = Math.max(comeback, homeDeficit);
          if (margin <= 0) comeback = Math.max(comeback, awayDeficit);
          previous = { home: home2, away: away2, position };
          moments.push(previous);
        }
        const home = competition?.competitors?.find((t) => t.homeAway === "home");
        const away = competition?.competitors?.find((t) => t.homeAway === "away");
        if (!home || !away || home.score == null || away.score == null || Number(home.score) !== previous.home || Number(away.score) !== previous.away) valid = false;
        if (Math.abs(previous.home - previous.away) <= 8) {
          competitiveShare += 1 - previous.position;
          lastCompetitivePosition = 1;
        }
        return { valid, lastCompetitivePosition, competitiveShare: unit(competitiveShare), comeback, changes, moments };
      }
      function cfbCompletedHistory(summary, history, { game, finishPoints = 0 }) {
        if (!game || game.sport !== "CFB" || game.state !== "completed") return history;
        const competition = game.sourceCompetition || summary?.header?.competitions?.[0];
        const scores = (competition?.competitors || []).map((t) => t.score == null || t.score === "" ? NaN : Number(t.score));
        if (scores.length !== 2 || !scores.every(Number.isFinite)) return history;
        const gap = Math.abs(scores[0] - scores[1]);
        const path = cfbCompletedPath(summary, competition);
        const status = competition?.status || {};
        const detail = `${status.type?.detail || ""} ${status.type?.shortDetail || ""}`;
        const depthText = detail.match(/\b(\d+)\s*OT\b/i);
        const period = Number(status.period);
        const depth = Number.isInteger(period) && period > 4 ? period - 4 : depthText ? Number(depthText[1]) : /\bot\b|overtime/i.test(detail) ? 1 : 0;
        const year = Number(game.sourceEvent?.season?.year || summary?.header?.season?.year);
        const shootoutStart = year >= 2021 ? 7 : year >= 2019 ? 9 : Infinity;
        const tries = new Set((summary?.plays || []).filter((p) => Number(p.period?.number ?? p.period) >= shootoutStart && /two[ -]point|2[ -]point/i.test(`${p.type?.text || ""} ${p.text || ""}`)).map((p) => p.id || JSON.stringify(p)));
        const shootout = depth >= shootoutStart - 4 && tries.size >= 2;
        const stagnation = history.factors.filter((f) => f.label === "Offensive stagnation").reduce((sum, f) => sum + f.points, 0);
        const positiveHistory = history.points - stagnation;
        const existing = Number(game.score) + history.points + finishPoints;
        if (!Number.isFinite(existing)) return history;
        const adjustments = [];
        let total = existing;
        if (depth > 0 && gap <= 8) {
          const stakes = game.factors.filter((f) => /stakes|consequence|advancement|elimination/i.test(f.label)).reduce((sum, f) => sum + Math.max(0, f.points), 0);
          const overlap = Math.max(0, stakes - 8);
          if (overlap) {
            adjustments.push({ label: "Completed OT correlated stakes cap", points: -overlap });
            total -= overlap;
          }
          const target = Math.min(99, 78 + 18 * (1 - Math.exp(-0.85 * (depth - 1))) + (shootout ? 2 : 0) + Math.min(8, stakes * 0.5)) + stagnation;
          const delta = Math.max(0, Math.round(target - total));
          if (delta) {
            adjustments.push({ label: `Completed ${depth}OT${shootout ? " conversion shootout" : ""} depth retention`, points: delta });
            total += delta;
          }
        }
        if (path.valid && path.lastCompetitivePosition >= 0.75) {
          const late = unit((path.lastCompetitivePosition - 0.75) / 0.2);
          const evidence = unit(positiveHistory / 25);
          const magnitude = unit(path.comeback / 21);
          const marginWeight = Math.exp(-Math.pow(Math.max(0, gap - 8) / 16, 1.35));
          const drama = Math.max(unit(path.changes / 3), smooth((path.comeback - 7) / 7));
          let target = path.competitiveShare >= 0.35 ? (35 + 18 * late + 5 * evidence + 5 * path.competitiveShare + (16 * magnitude + 12 * unit(path.changes / 3)) * drama) * marginWeight : 0;
          target += stagnation;
          const delta = Math.max(0, Math.round(target - total));
          if (delta) {
            adjustments.push({ label: "Completed competitive path retention", points: delta });
            total += delta;
          }
        }
        if (gap >= 21 && path.valid && path.lastCompetitivePosition < 0.75) {
          const stakes = game.factors.filter((f) => /stakes|consequence|advancement|elimination/i.test(f.label)).reduce((sum, f) => sum + Math.max(0, f.points), 0);
          const reduction = Math.min(Math.max(0, stakes - 5), Math.max(0, total - 1));
          if (reduction) {
            adjustments.push({ label: "Completed stakes limited by noncompetitive path", points: -reduction });
            total -= reduction;
          }
        }
        const resultFloor = 1 + (Number(game.upsetPoints) || 0) + stagnation;
        if (resultFloor > total) adjustments.push({ label: "Completed upset result retention", points: Math.round(resultFloor - total) });
        return adjustments.length ? {
          points: history.points + adjustments.reduce((sum, f) => sum + f.points, 0),
          text: [history.text, ...adjustments.map((f) => f.label)].filter(Boolean).join("; "),
          factors: [...history.factors, ...adjustments]
        } : history;
      }
      const cfbModel = {
        pregame: cfbPregame,
        // Scoreboards usually put season metadata on the event, not competition.
        // Preserve it through the core's existing live context without mutating feeds.
        prepareCompetition: (competition, event) => ({ ...competition, season: competition?.season || event?.season }),
        gameState: cfbGameState,
        liveFloor: cfbMidgameFloor,
        liveCloseness: cfbLiveCloseness,
        upset: (...args) => args[2] === "completed" ? cfbCompletedUpset(...args) : cfbUpsetImpact(...args),
        completedHistory: cfbCompletedHistory,
        decisiveStakes: (detail) => /\b(?:college football playoff|cfp)\b(?!\s+(?:race|berth|spot|picture|contention|hunt|rematch))|\b(?:national|conference) championship\b(?!\s+rematch)/i.test(detail),
        decisiveFloor: true,
        situation: cfbSituation,
        milestone: footballMilestone,
        eventShock: footballEventShock,
        eventShockWeight: cfbEventShockWeight,
        history: { threshold: 10, units: "points", stagnation: footballStagnationImpact }
      };
      const api = { cfbImmediateTension, cfbPregame, cfbRankedMatchup, cfbModel, cfbClockRunway, cfbOvertime, cfbLiveCloseness, cfbMarginCloseness };
      if (typeof module2 !== "undefined" && module2.exports) {
        module2.exports = api;
      } else {
        (root.SportsRadarScoring ||= {}).sports_cfb = api;
      }
    })(globalThis);
  }
});

// scoring/sports/tennis.js
var require_tennis = __commonJS({
  "scoring/sports/tennis.js"(exports2, module2) {
    (function(root) {
      function tennisSituationImpact(game, competition, summary, status, progress) {
        const situation = competition?.situation || summary?.header?.competitions?.[0]?.situation || summary?.situation || {};
        const text = [status?.type?.detail, status?.type?.shortDetail, situation?.displayValue, situation?.description, situation?.pointScore, situation?.score].filter(Boolean).join(" ");
        const period = Number(status?.period || 0);
        const bestOf = Number(competition?.format?.regulation?.periods || competition?.format?.bestOf || (period >= 5 ? 5 : 3));
        const sets = game.teams.map((team) => Number(team[2]));
        const deciding = /deciding|final set|fifth set|third set/i.test(text) && period >= bestOf || period >= bestOf && sets.length === 2 && sets.every(Number.isFinite) && Math.abs(sets[0] - sets[1]) <= 1;
        const late = Math.max(0, Math.min(1, (progress - 0.45) / 0.5));
        const tiebreak = situation.tiebreak === true || situation.isTiebreak === true || /tie.?break/i.test(text);
        const matchPoint = situation.matchPoint === true || situation.isMatchPoint === true || /match point/i.test(text);
        let points = 0;
        const reasons = [];
        if (matchPoint) {
          points = Math.max(points, Math.round((deciding ? 10 : 6) + 2 * late + (tiebreak ? 1 : 0)));
          reasons.push("The match is at match point");
        } else if (situation.setPoint === true || situation.isSetPoint === true || /set point/i.test(text)) {
          points = Math.max(points, Math.round(4 + 2 * late + (deciding ? 2 : 0)));
          reasons.push("The current set is at set point");
        }
        if (situation.breakPoint === true || situation.isBreakPoint === true || /break point/i.test(text)) {
          points = Math.max(points, Math.round(2 + 2 * late + (deciding ? 1 : 0)));
          reasons.push("A break point is in progress");
        }
        if (tiebreak) {
          points = Math.max(points, Math.round(4 + 2 * late + (deciding ? 2 : 0)));
          reasons.push("The match is in a tiebreak");
        }
        if (/\bdeuce\b/i.test(text)) {
          points = Math.max(points, Math.round(1 + late + (deciding ? 1 : 0)));
          reasons.push("The current game is at deuce");
        }
        if (deciding && progress >= 0.75) {
          points = Math.max(points, 5);
          reasons.push("The match is deep in a deciding set");
        }
        return {
          points: Math.min(12, points),
          note: text.slice(0, 80),
          reasons,
          competitiveFloor: matchPoint && deciding ? tiebreak ? 20 : 19 : 0
        };
      }
      function tennisMajor(detail) {
        return /wimbledon|australian open|french open|roland garros|us open/.test(detail) ? { factor: { label: "Major tournament", points: 18 }, reason: "Tennis major" } : null;
      }
      const tennisModel = {
        unit: "set",
        majorTournament: tennisMajor,
        situation: ({ game, competition, summary, status, progress }) => tennisSituationImpact(game, competition, summary, status, progress),
        history: { threshold: 2, units: "sets" }
      };
      const api = { tennisSituationImpact, tennisMajor, tennisModel };
      if (typeof module2 !== "undefined" && module2.exports) {
        module2.exports = api;
      } else {
        (root.SportsRadarScoring ||= {}).sports_tennis = api;
      }
    })(globalThis);
  }
});

// scoring/sports/soccer.js
var require_soccer = __commonJS({
  "scoring/sports/soccer.js"(exports2, module2) {
    (function(root) {
      const { aggregateScoreFromText } = typeof module2 !== "undefined" && module2.exports ? require_context() : root.SportsRadarScoring.shared_context;
      const { normalizedTime } = typeof module2 !== "undefined" && module2.exports ? require_time() : root.SportsRadarScoring.shared_time;
      function soccerSituationImpact(competition, summary, status, progress, scoreGap) {
        const situation = competition?.situation || summary?.situation || {};
        const text = [
          status?.type?.detail,
          status?.type?.shortDetail,
          status?.displayClock,
          situation?.description,
          situation?.displayValue,
          ...(competition?.notes || []).map((note) => note.headline),
          competition?.series?.summary,
          competition?.series?.title
        ].filter(Boolean).join(" ").toLowerCase();
        const cardCounts = (summary?.boxscore?.teams || []).map((team) => ({
          id: String(team.team?.id || team.id || ""),
          count: (team.statistics || []).filter((stat) => /redcards|red cards|\brc\b/i.test(
            `${stat.name || ""} ${stat.displayName || ""} ${stat.abbreviation || ""}`
          )).reduce((sum, stat) => sum + (Number(stat.value ?? stat.displayValue) || 0), 0)
        }));
        const cardsById = new Map(cardCounts.filter((team) => team.id).map((team) => [team.id, team.count]));
        const teamRedCards = cardCounts.reduce((sum, team) => sum + team.count, 0);
        const scoredTeams = (competition?.competitors || []).map((item) => ({ id: String(item.team?.id || item.id || ""), score: Number(item.score) }));
        const haveCardDirection = scoredTeams.length === 2 && scoredTeams.every((team) => team.id && Number.isFinite(team.score)) && scoredTeams[0].score !== scoredTeams[1].score && scoredTeams.some((team) => cardsById.has(team.id));
        let points = 0;
        const reasons = [];
        if (teamRedCards > 0 || /\bred card\b|\bsent off\b|\bdown to (?:ten|10)\b/.test(text)) {
          const generic = progress >= 0.55 && scoreGap <= 1 ? 5 : 3;
          const leader = haveCardDirection ? scoredTeams[scoredTeams[0].score > scoredTeams[1].score ? 0 : 1] : null;
          const trailer = haveCardDirection ? scoredTeams[scoredTeams[0].score < scoredTeams[1].score ? 0 : 1] : null;
          const cardDifference = leader ? (cardsById.get(leader.id) || 0) - (cardsById.get(trailer.id) || 0) : 0;
          points += scoreGap <= 1 && progress >= 0.55 && cardDifference !== 0 ? cardDifference > 0 ? 7 : 2 : generic;
          reasons.push(
            "A red card has changed the match conditions"
          );
        }
        const aggregate = aggregateScoreFromText(text);
        if (aggregate) {
          const aggregateGap = Math.abs(
            aggregate[0] - aggregate[1]
          );
          if (aggregateGap <= 1) {
            points += progress >= 0.7 ? 6 : 4;
            reasons.push(
              aggregateGap === 0 ? "The knockout tie is level on aggregate" : "The knockout tie is separated by one goal on aggregate"
            );
          }
        }
        if (/penalty shootout|penalties|shootout/.test(text)) {
          points += 10;
          reasons.push(
            "The match is being decided by penalties"
          );
        } else if ((/stoppage time|added time|90'?\+\d+/.test(text) || Number(status?.period) === 2 && normalizedTime("Soccer", { status }).elapsedSeconds > 90 * 60) && scoreGap <= 1) {
          points += 3;
          reasons.push(
            "A close match is in stoppage time"
          );
        }
        return {
          points: Math.min(12, points),
          note: "",
          reasons
        };
      }
      function soccerScoringMilestone(summary) {
        for (const block of summary?.boxscore?.players || []) {
          for (const group of block.statistics || []) {
            const goals = (group.labels || []).findIndex(
              (label) => /^G$|^GOALS$/i.test(label)
            );
            if (goals < 0) {
              continue;
            }
            const scorer = (group.athletes || []).filter(
              (entry) => Number(
                entry.stats?.[goals]
              ) >= 2
            ).sort(
              (a, b) => Number(
                b.stats?.[goals]
              ) - Number(
                a.stats?.[goals]
              )
            )[0];
            if (scorer) {
              const count = Number(
                scorer.stats[goals]
              );
              return {
                text: count >= 3 ? `${scorer.athlete?.displayName || "A player"} has a hat trick` : `${scorer.athlete?.displayName || "A player"} has scored twice`,
                points: count >= 3 ? 12 : 6
              };
            }
          }
        }
        return null;
      }
      function soccerPressureWeight(points, scoreGap, dangerous, competition) {
        if (scoreGap === 1 && dangerous.length) {
          const teams = (competition?.competitors || []).map((item) => ({ id: String(item.team?.id || item.id || ""), score: Number(item.score) }));
          if (teams.length === 2 && teams.every((team) => team.id && Number.isFinite(team.score))) {
            const trailingId = teams[teams[0].score < teams[1].score ? 0 : 1].id;
            const leadingId = teams[teams[0].score > teams[1].score ? 0 : 1].id;
            const trailing = dangerous.filter((play) => play.teamId === trailingId).length;
            const leading = dangerous.filter((play) => play.teamId === leadingId).length;
            points = Math.round(points * (1 + 0.4 * trailing / dangerous.length - 0.6 * leading / dangerous.length));
          }
        }
        return points;
      }
      const soccerModel = {
        unit: "goal",
        duration: 90,
        situation: ({ competition, summary, status, progress, scoreGap }) => soccerSituationImpact(competition, summary, status, progress, scoreGap),
        milestone: soccerScoringMilestone,
        pressure: { maxGap: 1, weight: soccerPressureWeight },
        history: { threshold: 2, units: "goals" }
      };
      const api = { soccerSituationImpact, soccerScoringMilestone, soccerPressureWeight, soccerModel };
      if (typeof module2 !== "undefined" && module2.exports) {
        module2.exports = api;
      } else {
        (root.SportsRadarScoring ||= {}).sports_soccer = api;
      }
    })(globalThis);
  }
});

// scoring/models.js
var require_models = __commonJS({
  "scoring/models.js"(exports2, module2) {
    (function(root) {
      const { trajectoryAnalysis } = typeof module2 !== "undefined" && module2.exports ? require_trajectory() : root.SportsRadarScoring.shared_trajectory;
      const { nflModel } = typeof module2 !== "undefined" && module2.exports ? require_nfl() : root.SportsRadarScoring.sports_nfl;
      const { mlbModel } = typeof module2 !== "undefined" && module2.exports ? require_mlb() : root.SportsRadarScoring.sports_mlb;
      const { nhlModel } = typeof module2 !== "undefined" && module2.exports ? require_nhl() : root.SportsRadarScoring.sports_nhl;
      const { nbaModel, ncaabModel } = typeof module2 !== "undefined" && module2.exports ? require_basketball2() : root.SportsRadarScoring.sports_basketball;
      const { cfbModel } = typeof module2 !== "undefined" && module2.exports ? require_cfb() : root.SportsRadarScoring.sports_cfb;
      const { tennisModel } = typeof module2 !== "undefined" && module2.exports ? require_tennis() : root.SportsRadarScoring.sports_tennis;
      const { soccerModel } = typeof module2 !== "undefined" && module2.exports ? require_soccer() : root.SportsRadarScoring.sports_soccer;
      const SPORT_MODELS = {
        NFL: nflModel,
        MLB: mlbModel,
        NHL: nhlModel,
        NBA: nbaModel,
        NCAAB: ncaabModel,
        CFB: cfbModel,
        Tennis: tennisModel,
        Soccer: soccerModel
      };
      const analyzeTrajectory = (sport, summary, progress = null, state = "completed") => trajectoryAnalysis(sport, summary, progress, state, SPORT_MODELS[sport] || {});
      const api = { SPORT_MODELS, analyzeTrajectory };
      if (typeof module2 !== "undefined" && module2.exports) {
        module2.exports = api;
      } else {
        (root.SportsRadarScoring ||= {}).models = api;
      }
    })(globalThis);
  }
});

// scoring/shared/history.js
var require_history = __commonJS({
  "scoring/shared/history.js"(exports2, module2) {
    (function(root) {
      const { eventPosition: eventPosition2 } = typeof module2 !== "undefined" && module2.exports ? require_time() : root.SportsRadarScoring.shared_time;
      const { winProbabilitySeries } = typeof module2 !== "undefined" && module2.exports ? require_probability() : root.SportsRadarScoring.shared_probability;
      function historyImpact(sport, summary, progress, state, history = {}, options = {}) {
        if (state === "upcoming") {
          return {
            points: 0,
            text: "",
            factors: []
          };
        }
        const plays = summary?.scoringPlays?.length ? summary.scoringPlays : (summary?.plays || []).filter(
          (play) => play.scoringPlay === true
        );
        const moments = plays.map((play) => {
          const home = Number(play.homeScore);
          const away = Number(play.awayScore);
          const period = Number(
            play.period?.number || play.period || 0
          );
          const position = period ? eventPosition2(
            sport,
            {
              status: {
                period,
                displayClock: play.clock?.displayValue || "",
                clock: play.clock?.value,
                type: {
                  detail: play.period?.displayValue || ""
                }
              }
            }
          ) : null;
          return Number.isFinite(home) && Number.isFinite(away) ? {
            home,
            away,
            position,
            text: String(
              play.text || play.shortText || ""
            )
          } : null;
        }).filter(Boolean).sort(
          (a, b) => (a.position ?? 0) - (b.position ?? 0)
        );
        const threshold = history.threshold || 7;
        const units = history.units || "points";
        const competitors = summary?.header?.competitions?.[0]?.competitors || [];
        const nameFor = (side) => competitors.find(
          (item) => item.homeAway === side
        )?.team?.displayName || (side === "home" ? "The home team" : "The away team");
        const possessive = (name) => `${name}${/s$/i.test(name) ? "'" : "'s"}`;
        const currentProgress = state === "completed" ? 1 : Math.max(
          0,
          Math.min(
            1,
            Number(progress) || 0
          )
        );
        let previousLeader = 0;
        let leadChanges = 0;
        let lastFlip = -1;
        const flipPositions = [];
        const tiePositions = [];
        let deepestHomeDeficit = 0;
        let deepestAwayDeficit = 0;
        let comeback = null;
        let previousHome = 0;
        let previousAway = 0;
        let runSide = "";
        let runPoints = 0;
        let runCount = 0;
        let runUsefulPoints = 0;
        let cfbRun = null;
        for (const moment of moments) {
          const margin = moment.home - moment.away;
          deepestHomeDeficit = Math.max(
            deepestHomeDeficit,
            -margin
          );
          deepestAwayDeficit = Math.max(
            deepestAwayDeficit,
            margin
          );
          if (margin >= 0 && deepestHomeDeficit >= threshold && (!comeback || deepestHomeDeficit > comeback.deficit)) {
            comeback = {
              side: "home",
              deficit: deepestHomeDeficit
            };
          }
          if (margin <= 0 && deepestAwayDeficit >= threshold && (!comeback || deepestAwayDeficit > comeback.deficit)) {
            comeback = {
              side: "away",
              deficit: deepestAwayDeficit
            };
          }
          const leader = Math.sign(margin);
          if (margin === 0 && moment.position !== null && Number.isFinite(moment.position)) {
            tiePositions.push(
              moment.position
            );
          }
          if (leader && previousLeader && leader !== previousLeader) {
            leadChanges++;
            lastFlip = moment.position ?? -1;
            flipPositions.push(
              lastFlip
            );
          }
          if (leader) {
            previousLeader = leader;
          }
          const homeGain = moment.home - previousHome;
          const awayGain = moment.away - previousAway;
          const scorer = homeGain > 0 && awayGain === 0 ? "home" : awayGain > 0 && homeGain === 0 ? "away" : "";
          if (scorer) {
            if (runSide !== scorer) {
              runSide = scorer;
              runPoints = 0;
              runCount = 0;
              runUsefulPoints = 0;
            }
            const before = scorer === "home" ? previousHome - previousAway : previousAway - previousHome;
            const gain = scorer === "home" ? homeGain : awayGain;
            if (before <= 0) runUsefulPoints += Math.min(gain, -before + 8);
            runPoints += scorer === "home" ? homeGain : awayGain;
            runCount++;
          } else {
            runSide = "";
            runPoints = 0;
            runCount = 0;
            runUsefulPoints = 0;
          }
          previousHome = moment.home;
          previousAway = moment.away;
        }
        const factors = [];
        const details = [];
        const basketball = Boolean(history.dramaBucket);
        const basketballLatePhase = history.latePhase;
        const basketballDramaBucket = history.dramaBucket;
        if (leadChanges) {
          if (basketball) {
            history.leadChanges({ sport, state, flipPositions, currentProgress, basketballDramaBucket, basketballLatePhase, factors, details });
          } else {
            const points = state === "live" ? Math.min(
              7,
              flipPositions.reduce(
                (sum, position) => sum + (position >= currentProgress - 0.1 ? 3 : position >= currentProgress - 0.25 ? 2 : 1),
                0
              )
            ) : Math.min(
              9,
              leadChanges * 3
            );
            factors.push({
              label: `${leadChanges} lead change${leadChanges === 1 ? "" : "s"}`,
              points
            });
            details.push(
              `the lead changed ${leadChanges} time${leadChanges === 1 ? "" : "s"}`
            );
          }
        }
        if (comeback) {
          factors.push({
            label: "Erased a large deficit",
            points: Math.min(
              8,
              4 + Math.floor(
                comeback.deficit / threshold
              ) * 2
            )
          });
          details.push(
            `${nameFor(comeback.side)} erased a deficit of ${comeback.deficit} ${units}`
          );
        }
        if (!basketball && lastFlip >= 0.65 && currentProgress - lastFlip <= 0.16) {
          factors.push({
            label: "Recent late lead change",
            points: 5
          });
          details.push(
            "the lead flipped late"
          );
        }
        history.lateTies?.({ basketball, tiePositions, basketballDramaBucket, basketballLatePhase, factors, details });
        const latestPosition = moments.at(-1)?.position ?? null;
        if (state === "live" && runCount >= 2 && runPoints >= threshold && latestPosition !== null && currentProgress - latestPosition <= 0.1) {
          const points = sport === "CFB" && options.cfbCompetitionHistory ? Math.round(4 * Math.min(1, runUsefulPoints / runPoints)) : 4;
          if (sport === "CFB" && options.cfbCompetitionHistory) cfbRun = {
            side: runSide,
            runPoints,
            usefulPoints: runUsefulPoints,
            rawPoints: 4,
            points,
            overlapDiscount: 4 - points
          };
          if (points) factors.push({ label: "Recent unanswered scoring run", points });
          details.push(
            `${nameFor(runSide)} scored ${runPoints} unanswered ${units} recently`
          );
        }
        if (!(state === "live" && options.replaceSustained) && moments.length >= 3 && currentProgress >= 0.4) {
          let competitiveTime = 0;
          let priorPosition = 0;
          let priorMargin = 0;
          for (const moment of moments) {
            const position = Math.min(
              currentProgress,
              Math.max(
                priorPosition,
                moment.position ?? priorPosition
              )
            );
            if (Math.abs(priorMargin) <= threshold) {
              competitiveTime += position - priorPosition;
            }
            priorPosition = position;
            priorMargin = moment.home - moment.away;
          }
          if (Math.abs(priorMargin) <= threshold) {
            competitiveTime += Math.max(
              0,
              currentProgress - priorPosition
            );
          }
          const competitiveShare = currentProgress ? competitiveTime / currentProgress : 0;
          if (competitiveShare >= 0.55) {
            const points = state === "completed" ? competitiveShare >= 0.75 ? 7 : 5 : 3;
            factors.push({
              label: "Sustained competitive game",
              points
            });
            details.push(
              `the score stayed within ${threshold} ${units} for about ${Math.round(competitiveShare * 100)}% of the game`
            );
          }
        }
        const winChances = winProbabilitySeries(
          summary
        );
        let controlSwings = 0;
        let controlSide = 0;
        for (const chance of winChances) {
          const side = chance >= 0.65 ? 1 : chance <= 0.35 ? -1 : 0;
          if (side && controlSide && side !== controlSide) {
            controlSwings++;
          }
          if (side) {
            controlSide = side;
          }
        }
        if (controlSwings >= 2 && leadChanges < 2) {
          factors.push({
            label: "Repeated swings in control",
            points: Math.min(
              7,
              3 + controlSwings
            ),
            bucket: basketball ? basketballDramaBucket : void 0
          });
          details.push(
            `win probability swung decisively between both teams ${controlSwings} times`
          );
        }
        let strongestSwing = {
          size: 0,
          end: -1,
          direction: 0
        };
        for (let end = 1; end < winChances.length; end++) {
          for (let start = Math.max(
            0,
            end - 10
          ); start < end; start++) {
            const change = winChances[end] - winChances[start];
            if (Math.abs(change) > strongestSwing.size) {
              strongestSwing = {
                size: Math.abs(change),
                end,
                direction: Math.sign(change)
              };
            }
          }
        }
        if (strongestSwing.size >= 0.2) {
          const points = Math.min(
            state === "completed" ? 9 : 7,
            Math.round(
              strongestSwing.size * 15
            ) + (state === "live" && strongestSwing.end >= winChances.length - 10 ? 1 : 0)
          );
          factors.push({
            label: "Big win-chance swing",
            points,
            bucket: basketball ? basketballDramaBucket : void 0
          });
          details.push(
            `${possessive(nameFor(strongestSwing.direction > 0 ? "home" : "away"))} estimated win chance swung by ${Math.round(strongestSwing.size * 100)} percentage points`
          );
        }
        if (state === "completed" && winChances.length >= 8) {
          const uncertainties = winChances.map(
            (probability) => 1 - 2 * Math.abs(
              probability - 0.5
            )
          );
          const averageUncertainty = uncertainties.reduce(
            (sum, value) => sum + value,
            0
          ) / uncertainties.length;
          const lateSlice = uncertainties.slice(
            Math.max(
              0,
              Math.floor(
                uncertainties.length * 0.75
              )
            )
          );
          const lateUncertainty = lateSlice.length ? lateSlice.reduce(
            (sum, value) => sum + value,
            0
          ) / lateSlice.length : 0;
          if (averageUncertainty >= 0.58) {
            factors.push({
              label: "Competitive throughout",
              points: 6
            });
            details.push(
              "win probability stayed balanced for much of the game"
            );
          } else if (averageUncertainty >= 0.45) {
            factors.push({
              label: "Competitive for much of game",
              points: 4
            });
          }
          if (lateUncertainty >= 0.65) {
            factors.push({
              label: "High late uncertainty",
              points: 5,
              bucket: basketball ? basketballDramaBucket : void 0
            });
            details.push(
              "the outcome remained highly uncertain late"
            );
          }
        }
        if (state === "completed" && moments.length) {
          const decisive = moments.at(-1);
          const prior = moments.length > 1 ? moments.at(-2) : {
            home: 0,
            away: 0
          };
          const finalMargin = decisive.home - decisive.away;
          const priorMargin = prior.home - prior.away;
          const finalLeader = Math.sign(finalMargin);
          const changedOutcome = finalLeader && (priorMargin === 0 || Math.sign(priorMargin) !== finalLeader);
          if (decisive.position >= 0.94 && changedOutcome && Math.abs(finalMargin) <= threshold) {
            factors.push({
              label: "Decisive final score",
              points: 8,
              bucket: basketball ? basketballDramaBucket : void 0
            });
            details.push(
              decisive.text ? `the decisive score came at the end: ${decisive.text}` : "the decisive score came in the final moments"
            );
          }
        }
        if (state === "live" && options.replaceSustained && options.trajectoryPositive > 0) {
          factors.push({ label: "Trajectory sustained history", points: options.trajectoryPositive });
        }
        const relevance = state === "live" && Number.isFinite(options.liveRelevance) ? Math.max(0, Math.min(1, options.liveRelevance)) : null;
        const allocations = [];
        const cap = state === "completed" ? 25 : 15 - (cfbRun?.overlapDiscount || 0) * (relevance ?? 1);
        let remaining = cap;
        const bucketRemaining = /* @__PURE__ */ new Map();
        if (basketball) {
          bucketRemaining.set(
            basketballDramaBucket,
            history.dramaCap
          );
        }
        const cappedFactors = factors.map((factor) => {
          const bucketLimit = factor.bucket && bucketRemaining.has(
            factor.bucket
          ) ? bucketRemaining.get(
            factor.bucket
          ) : remaining;
          const points = Math.min(
            Math.max(
              0,
              factor.points * (relevance ?? 1)
            ),
            remaining,
            bucketLimit
          );
          remaining -= points;
          if (relevance !== null) allocations.push({
            label: factor.label,
            rawPoints: factor.points,
            relevantPoints: factor.points * relevance,
            retainedPoints: points,
            relevanceReduction: factor.points * (1 - relevance),
            capReduction: factor.points * relevance - points
          });
          if (factor.bucket && bucketRemaining.has(
            factor.bucket
          )) {
            bucketRemaining.set(
              factor.bucket,
              bucketLimit - points
            );
          }
          const {
            bucket,
            ...visibleFactor
          } = factor;
          return {
            ...visibleFactor,
            points
          };
        }).filter(
          (factor) => factor.points > 0
        );
        const stagnation = history.stagnation?.(
          sport,
          summary,
          currentProgress,
          state
        ) || { points: 0, text: "" };
        if (stagnation.points) {
          cappedFactors.push({
            label: "Offensive stagnation",
            points: -stagnation.points
          });
          details.push(
            stagnation.text
          );
        }
        return {
          ...cfbRun ? { cfbRun } : {},
          ...relevance === null ? {} : { relevance: {
            retention: relevance,
            cap,
            bucketCap: basketball ? history.dramaCap : null,
            factors: allocations
          } },
          points: cap - remaining - stagnation.points,
          text: details.join("; ").replace(
            /^[a-z]/,
            (character) => character.toUpperCase()
          ),
          factors: cappedFactors
        };
      }
      const api = { historyImpact };
      if (typeof module2 !== "undefined" && module2.exports) {
        module2.exports = api;
      } else {
        (root.SportsRadarScoring ||= {}).shared_history = api;
      }
    })(globalThis);
  }
});

// scoring/shared/events.js
var require_events = __commonJS({
  "scoring/shared/events.js"(exports2, module2) {
    (function(root) {
      const { gameProgress: gameProgress2, eventPosition: eventPosition2 } = typeof module2 !== "undefined" && module2.exports ? require_time() : root.SportsRadarScoring.shared_time;
      function eventShockFor(sport, summary, status, model = {}, positionOverride = null) {
        const positionFor = (value) => positionOverride ? positionOverride(value) : eventPosition2(sport, { status: value });
        const plays = summary?.plays?.length ? summary.plays : summary?.scoringPlays || [];
        const duration = model.duration || 60;
        const currentProgress = gameProgress2(sport, { status });
        const positioned = plays.map((play, index) => {
          const period = Number(play.period?.number || play.period || 0);
          const position = period ? positionFor({ period, displayClock: play.clock?.displayValue || "", clock: play.clock?.value, type: { detail: play.period?.displayValue || "" } }) : null;
          return { play, index, position };
        }).filter((item) => item.position !== null && positionFor(status) !== null && item.position <= positionFor(status) + 0.01).sort((a, b) => a.position - b.position || a.index - b.index);
        let points = 0;
        const reasons = [];
        for (let i = 0; i < positioned.length; i++) {
          const { play, position } = positioned[i];
          const text = String(play.text || play.shortText || play.type?.text || "").toLowerCase();
          let value = 0;
          let label = "";
          let shock;
          if (/blocked.{0,30}(?:punt|kick|field goal)|(?:punt|kick|field goal).{0,30}blocked/.test(text) && /touchdown|\btd\b/.test(text)) {
            value = 12;
            label = "Blocked kick or punt returned for a touchdown";
          } else if (/pick[- ]six|intercept(?:ion|ed).{0,80}(?:touchdown|\btd\b)|fumble.{0,40}(?:returned|touchdown)|defensive touchdown/.test(text)) {
            value = 10;
            label = "Defensive touchdown";
          } else if (/\bsafety\b/.test(text)) {
            value = 6;
            label = "Safety";
          } else if (/grand slam/.test(text)) {
            value = 8;
            label = "Grand slam";
          } else if (model.earlyEventShock && (shock = model.earlyEventShock({ text, positioned, i, play }))) {
            ({ value, label } = shock);
          } else if (/\bturnover\b|intercepted|fumble recovered by|picked off|caught stealing/.test(text)) {
            value = 4;
            label = "Turnover";
          } else if (model.eventShock && (shock = model.eventShock({ text, positioned, i, play }))) {
            ({ value, label } = shock);
          }
          if (model.eventShockWeight) value *= model.eventShockWeight({ text, positioned, i, play });
          if (!value) continue;
          const playsSince = positioned.length - 1 - i;
          const periodGap = Math.abs(Number(status?.period || 0) - Number(play.period?.number || play.period || 0));
          const currentEventPosition = positionFor(status);
          const ageMinutes = model.inningEventAge ? periodGap * 20 : Math.max(0, currentEventPosition - position) * duration;
          const decay = Math.min(Math.max(0, 1 - playsSince / 7), Math.max(0, 1 - ageMinutes / 3));
          if (decay <= 0) continue;
          points += value * decay;
          reasons.push(label);
        }
        return { points: Math.min(12, Math.round(points)), reasons: [...new Set(reasons)] };
      }
      const api = { eventShockFor };
      if (typeof module2 !== "undefined" && module2.exports) {
        module2.exports = api;
      } else {
        (root.SportsRadarScoring ||= {}).shared_events = api;
      }
    })(globalThis);
  }
});

// scoring/shared/pressure.js
var require_pressure = __commonJS({
  "scoring/shared/pressure.js"(exports2, module2) {
    (function(root) {
      function aggregateLiveBonus({
        probabilityPoints = 0,
        situationPoints = 0,
        pressurePoints = 0,
        milestonePoints = 0,
        eventShockPoints = 0,
        sportImpact = {},
        decisiveFloorEnabled = false,
        preserveCompetitiveSupport = false,
        nfl = false
      } = {}) {
        const probabilityPositive = Math.max(0, Number(probabilityPoints) || 0);
        const probabilityNegative = Math.min(0, Number(probabilityPoints) || 0);
        const driveFloor = sportImpact.decisiveDrive ? Math.round(sportImpact.decisiveDrive.urgency * (18 + Math.min(2, sportImpact.decisiveDrive.positionBonus))) : 0;
        const decisiveFloor = nfl || decisiveFloorEnabled ? Math.max(0, Number(sportImpact.competitiveFloor) || 0) : 0;
        const competitiveSituation = decisiveFloorEnabled && decisiveFloor > 0 && !preserveCompetitiveSupport ? decisiveFloor : Math.min(Math.max(20, decisiveFloor), Math.max(
          driveFloor,
          Number(sportImpact.competitiveFloor) || 0,
          probabilityPositive + situationPoints + pressurePoints
        ));
        const positiveBonus = Math.min(
          Math.max(30, decisiveFloor),
          competitiveSituation + milestonePoints + eventShockPoints
        );
        const negativeBonus = Math.max(-8, probabilityNegative);
        const bonus = decisiveFloor > 0 ? Math.max(decisiveFloor, positiveBonus + negativeBonus) : positiveBonus + negativeBonus;
        return {
          bonus,
          probabilityPositive,
          probabilityNegative,
          driveFloor,
          decisiveFloor,
          competitiveSituation,
          positiveBonus,
          negativeBonus
        };
      }
      function pressureImpact(summary, progress, scoreGap, competition, policy) {
        if (policy?.impact) return policy.impact(summary, progress, scoreGap, competition);
        if (!policy || !summary || scoreGap > policy.maxGap) {
          return { points: 0, reasons: [] };
        }
        const recent = (summary.plays || []).slice(-18).filter((play) => !play?.scoringPlay).map((play) => ({
          text: String(play?.text || play?.shortText || play?.type?.text || "").toLowerCase(),
          teamId: String(play?.team?.id || play?.teamId || play?.team?.team?.id || "")
        })).filter((play) => play.text);
        const dangerous = recent.filter(
          (play) => /shot on goal|saved by|\bsave\b|breakaway|penalty shot|hit (?:the )?(?:post|crossbar)|off (?:the )?(?:post|crossbar)|big chance|close range|point-blank/.test(play.text)
        );
        const premium = recent.filter(
          (play) => /breakaway|penalty shot|hit (?:the )?(?:post|crossbar)|off (?:the )?(?:post|crossbar)|big chance|point-blank/.test(play.text)
        );
        let points = 0;
        const reasons = [];
        if (premium.length) {
          points += Math.min(4, 2 + premium.length);
          reasons.push(`${premium.length} premium scoring chance${premium.length === 1 ? "" : "s"} recently`);
        }
        if (dangerous.length >= 4) {
          points += dangerous.length >= 7 ? 3 : 2;
          reasons.push(`${dangerous.length} dangerous attempts or saves in the recent action`);
        }
        if (points && progress >= 0.78) points++;
        if (policy.weight) points = policy.weight(points, scoreGap, dangerous, competition);
        return {
          points: Math.min(7, points),
          reasons
        };
      }
      const api = { pressureImpact, aggregateLiveBonus };
      if (typeof module2 !== "undefined" && module2.exports) {
        module2.exports = api;
      } else {
        (root.SportsRadarScoring ||= {}).shared_pressure = api;
      }
    })(globalThis);
  }
});

// rating-core.js
var require_rating_core = __commonJS({
  "rating-core.js"(exports2, module2) {
    (function(root) {
      const { SPORT_MODELS } = typeof module2 !== "undefined" && module2.exports ? require_models() : root.SportsRadarScoring.models;
      const { eventSignalText, isPostseasonGame, championshipSeriesFactors, playoffSeriesLeverage, specificStakesFactors, pregameContextFactors, completedStakesImpact, contextWeightFor } = typeof module2 !== "undefined" && module2.exports ? require_context() : root.SportsRadarScoring.shared_context;
      const { SPORT_FLOOR, SCHEDULE_SCARCITY, CLOSE_MARGIN: CLOSE_MARGIN2, SPORT_BASE: SPORT_BASE2, NFL_DIVISIONS, NHL_DIVISIONS, NBA_DIVISIONS, MLB_DIVISIONS, CONTEXT_WEIGHTS } = typeof module2 !== "undefined" && module2.exports ? require_config() : root.SportsRadarScoring.shared_config;
      const { normalizeWinProbability, winProbabilityImpact, winProbabilitySeries } = typeof module2 !== "undefined" && module2.exports ? require_probability() : root.SportsRadarScoring.shared_probability;
      const { gameProgress: gameProgress2, livePhase, normalizedTime, eventPosition: eventPosition2, ordinal, clockSeconds, isLateGameStatus } = typeof module2 !== "undefined" && module2.exports ? require_time() : root.SportsRadarScoring.shared_time;
      const { underdogCandidate: underdogCandidate2, parseLine: parseLine2, lineFromSummary: lineFromSummary2, listedSpread, moneylinePrices, pregameMarketFactor } = typeof module2 !== "undefined" && module2.exports ? require_market() : root.SportsRadarScoring.shared_market;
      const { upsetImpact: sharedUpsetImpact } = typeof module2 !== "undefined" && module2.exports ? require_upset() : root.SportsRadarScoring.shared_upset;
      const { historyImpact } = typeof module2 !== "undefined" && module2.exports ? require_history() : root.SportsRadarScoring.shared_history;
      const { eventShockFor } = typeof module2 !== "undefined" && module2.exports ? require_events() : root.SportsRadarScoring.shared_events;
      const { pressureImpact, aggregateLiveBonus } = typeof module2 !== "undefined" && module2.exports ? require_pressure() : root.SportsRadarScoring.shared_pressure;
      const { recordFor: recordFor2, rankFor: rankFor2, recordStats, divisionFor, winningRecord, proRecordFactors } = typeof module2 !== "undefined" && module2.exports ? require_records() : root.SportsRadarScoring.shared_records;
      const { nflDivisionFor, unbeatenStartImpact: unbeatenStartImpact2 } = typeof module2 !== "undefined" && module2.exports ? require_nfl() : root.SportsRadarScoring.sports_nfl;
      const { footballStagnationImpact, defensiveFinishFactor, footballMarginCloseness, footballLiveCloseness: sharedFootballLiveCloseness, footballRunwayPenalty, footballFieldPosition, footballSituationImpact, footballMilestone } = typeof module2 !== "undefined" && module2.exports ? require_football() : root.SportsRadarScoring.shared_football;
      const { nhlLiveMarginCloseness, hockeyOnIceState, hockeyPowerPlay, hockeySituationImpact, hockeyGoalMilestone } = typeof module2 !== "undefined" && module2.exports ? require_nhl() : root.SportsRadarScoring.sports_nhl;
      const { mlbLiveMarginCloseness, runnerOn, baseballSituationImpact, noHitBid, baseballPerformanceMilestone } = typeof module2 !== "undefined" && module2.exports ? require_mlb() : root.SportsRadarScoring.sports_mlb;
      const { basketballSituationImpact, basketballScoringMilestone } = typeof module2 !== "undefined" && module2.exports ? require_basketball() : root.SportsRadarScoring.shared_basketball;
      const { tennisSituationImpact } = typeof module2 !== "undefined" && module2.exports ? require_tennis() : root.SportsRadarScoring.sports_tennis;
      const { soccerSituationImpact, soccerScoringMilestone } = typeof module2 !== "undefined" && module2.exports ? require_soccer() : root.SportsRadarScoring.sports_soccer;
      const liveRatingContexts = /* @__PURE__ */ new WeakMap();
      function footballLiveCloseness(sport, gap, progress, context = null) {
        return (SPORT_MODELS[sport]?.liveCloseness || sharedFootballLiveCloseness)(sport, gap, progress, context);
      }
      function upsetImpact2(candidate, teams, gameState, progress, sport = "", competition = null) {
        return SPORT_MODELS[sport]?.upset?.(candidate, teams, gameState, progress, sport, competition) ?? sharedUpsetImpact(candidate, teams, gameState, progress, sport, competition);
      }
      const clampScore2 = (value) => Math.max(1, Math.min(99, Math.round(value)));
      function factorText2(factors, score) {
        const parts = factors.map(
          (factor) => `${factor.label} ${factor.points > 0 ? "+" : ""}${factor.points}`
        );
        if (factors.reduce((sum, item) => sum + item.points, 0) > 99 && score === 99) {
          parts.push("capped at 99");
        }
        return parts.join(" \xB7 ");
      }
      function pregameRating(sport, event, competition, context, gameState = "upcoming") {
        const options = { calibratedPregame: gameState === "upcoming" && ["NFL", "CFB"].includes(sport), sport };
        const model = SPORT_MODELS[sport] || {};
        const detail = eventSignalText(
          event,
          competition,
          context
        );
        const factors = [{
          label: "Sport baseline",
          points: SPORT_FLOOR
        }];
        const scheduleScarcity = SCHEDULE_SCARCITY[sport] || 0;
        if (scheduleScarcity) {
          factors.push({
            label: "Schedule scarcity",
            points: scheduleScarcity
          });
        }
        const mlbPostseasonScarcity = model.postseasonScarcity || 0;
        const postseason = isPostseasonGame(sport, event, competition, detail);
        const championshipSeries = championshipSeriesFactors(sport, competition, detail);
        const majorTournament = model.majorTournament?.(detail);
        let reason = "Regular-season matchup \xB7 no extra stakes listed";
        if (championshipSeries) {
          factors.push(...championshipSeries);
          reason = "Championship series";
        } else if (/world series/.test(detail)) {
          factors.push({
            label: "World Series",
            points: 42
          });
          if (mlbPostseasonScarcity) {
            factors.push({
              label: "Postseason scarcity",
              points: mlbPostseasonScarcity
            });
          }
          reason = "World Series championship";
        } else if (/super bowl|stanley cup final|champions league final|national championship|grand slam final/.test(detail)) {
          factors.push({
            label: "Championship",
            points: 40
          });
          reason = "Championship game";
        } else if (/conference final|league final|finals|championship|title game/.test(detail)) {
          factors.push({
            label: "Final round",
            points: 30
          });
          reason = "Final-round stakes";
        } else if (/playoff|postseason|wild card|divisional round|quarterfinal|semifinal|knockout/.test(detail) || Number(
          event?.season?.type?.id ?? event?.season?.type
        ) === 3) {
          factors.push({
            label: "Postseason",
            points: 22
          });
          if (mlbPostseasonScarcity) {
            factors.push({
              label: "Postseason scarcity",
              points: mlbPostseasonScarcity
            });
          }
          reason = "Postseason game";
        } else if (majorTournament) {
          factors.push(majorTournament.factor);
          reason = majorTournament.reason;
        }
        if (!championshipSeries) {
          const seriesLeverage2 = playoffSeriesLeverage(sport, competition, detail);
          if (seriesLeverage2) factors.push(seriesLeverage2);
        }
        if (!championshipSeries && factors.length > 1 && /game\s*1\b|game one\b|g1\b/.test(detail)) {
          factors.push({
            label: "Series opener",
            points: 5
          });
          reason += " \xB7 Game 1";
        }
        const seriesLeverage = playoffSeriesLeverage(sport, competition, detail);
        const specificStakes = championshipSeries ? [] : specificStakesFactors(
          sport,
          detail
        ).filter((item) => !seriesLeverage || !["Deciding game", "Elimination stakes", "Clinching opportunity"].includes(item.label));
        if (specificStakes.length) {
          factors.push(
            ...specificStakes
          );
          reason += ` \xB7 ${specificStakes.map((item) => item.label).join(", ")}`;
        }
        const competitors = competition?.competitors || [];
        reason = model.pregame ? model.pregame(sport, competition, competitors, postseason, factors, reason, detail, options) : reason;
        if (/rivalry|rival\b|derby/.test(detail) && !factors.some(
          (item) => item.label.endsWith("matchup")
        )) {
          factors.push({
            label: "Rivalry",
            points: 7
          });
          reason += " \xB7 rivalry";
        }
        const contextFactors = pregameContextFactors(
          event,
          competition,
          options
        ).filter((factor) => !options.calibratedPregame || !(factor.contextType === "rivalry" && factors.some((existing) => existing.label === "Rivalry" || sport === "NFL" && existing.label.endsWith("matchup")) || factor.contextType === "playoff_race" && postseason || sport === "NFL" && factor.contextType === "team_win_streak" && factors.some((f) => ["Sustained recent form", "Unbeaten team"].includes(f.label))));
        if (contextFactors.length) {
          factors.push(
            ...contextFactors
          );
          reason += " \xB7 verified matchup context";
        }
        if (options.calibratedPregame && sport === "NFL") {
          let remaining = 12;
          for (const factor of factors) {
            if (factor.points > 0 && (/^(?:AFC|NFC) .* matchup$|^Division (?:lead|race)|^Season-series|^Rivalry$/.test(factor.label) || ["rivalry", "meaningful_rematch", "rivalry_development", "championship_rematch", "playoff_rematch", "playoff_race"].includes(factor.contextType))) {
              factor.points = Number(Math.min(factor.points, remaining).toFixed(2));
              remaining -= factor.points;
            }
          }
          for (let i = factors.length - 1; i >= 0; i--) if (!factors[i].points) factors.splice(i, 1);
          reason = factors.filter((f) => !["Sport baseline", "Schedule scarcity"].includes(f.label)).map((f) => f.detail || f.contextText || f.label).join(" \xB7 ") || "Regular-season matchup";
        }
        const rawPregameScore = factors.reduce((sum, item) => sum + item.points, 0);
        return {
          score: Math.min(90, clampScore2(rawPregameScore)),
          rawPregameScore,
          factors,
          reason,
          contextFactors
        };
      }
      function stateRating2(openingScore, sport, gameState, gap, progress, homeWinProbability = null, footballContext = null, openingFactors = []) {
        openingScore = Math.min(90, openingScore);
        const closeLimit = CLOSE_MARGIN2[sport] || 10;
        const modelState = SPORT_MODELS[sport]?.gameState?.({
          sport,
          gameState,
          gap,
          progress,
          context: footballContext,
          closeLimit
        }) || {};
        const { footballState = null, basketballState = null } = modelState;
        const completedCloseLimit = modelState.completedCloseLimit ?? closeLimit;
        const marginClose = gap === null ? 0 : modelState.marginClose ?? Math.max(0, 1 - gap / completedCloseLimit);
        const probability = normalizeWinProbability(
          homeWinProbability
        );
        const uncertainty = probability === null ? null : 1 - 2 * Math.abs(
          probability - 0.5
        );
        const close = uncertainty === null || gameState === "completed" ? marginClose : 0.3 * marginClose + 0.7 * Math.min(uncertainty, modelState.uncertaintyCeiling ?? 1);
        const persistentStakeLabels = /world series|championship|final round|finals|title game|semifinal|postseason|playoff|elimination|clinching|deciding game|winner[- ]take[- ]all|aggregate tie|second-leg consequences/i;
        const persistentStakes = gameState === "live" ? Math.min(openingScore, openingFactors.filter((item) => persistentStakeLabels.test(item.label)).reduce((sum, item) => sum + Math.max(0, Number(item.points) || 0), 0)) : 0;
        const contextWeight = contextCarryWeight(
          progress,
          gameState,
          sport,
          false
        );
        const transientOpeningScore = Math.max(0, openingScore - persistentStakes);
        const comebackViability = modelState.comebackViability ?? Math.max(
          Math.sqrt(Math.max(0, Math.min(1, marginClose))),
          modelState.minimumComebackViability || 0
        );
        const retainedStakeWeight = 0.68 * Math.max(0, Math.min(1, comebackViability));
        const retainedContextWeight = contextWeight * (modelState.contextViability ?? 1);
        const contextPoints = Math.round(
          transientOpeningScore * retainedContextWeight
        );
        const retainedStakePoints = Math.round(persistentStakes * retainedStakeWeight);
        const stateBase = modelState.stateBase ?? (gameState === "completed" ? 18 : 12);
        const closeCeiling = modelState.closeCeiling ?? (gameState === "completed" ? 24 : 14 + 16 * Math.max(0, Math.min(1, progress)));
        const closePoints = Math.round(
          closeCeiling * close
        );
        const phasePoints = gameState === "completed" ? 0 : Math.round(
          (2 + 5 * progress) * close
        );
        const widePenalty = modelState.widePenalty ?? (gap !== null && gap >= closeLimit && progress > 0.3 ? Math.min(28, Math.round(gap / closeLimit * 13 * progress)) : 0);
        const factors = [{
          label: "Game-state baseline",
          points: stateBase
        }];
        if (contextPoints) {
          factors.push({
            label: "Pregame context carried into play",
            points: contextPoints
          });
        }
        if (retainedStakePoints) {
          factors.push({ label: "Persistent postseason stakes", points: retainedStakePoints });
        }
        if (closePoints) {
          factors.push({
            label: gameState === "completed" ? "Final margin" : uncertainty === null ? "Score closeness and leverage" : "Outcome uncertainty and score closeness",
            points: closePoints
          });
        }
        if (phasePoints) {
          factors.push({
            label: "Late-game leverage",
            points: phasePoints
          });
        }
        if (widePenalty) {
          factors.push({
            label: modelState.limitedRunway ? "Limited comeback runway" : "Wide margin",
            points: -widePenalty
          });
        }
        return {
          score: clampScore2(
            factors.reduce(
              (sum, item) => sum + item.points,
              0
            )
          ),
          factors,
          closePoints,
          widePenalty,
          contextWeight,
          retainedContextWeight,
          persistentStakes,
          retainedStakeWeight,
          comebackViability,
          uncertainty,
          footballState,
          basketballState
        };
      }
      function rateGame2(sport, gameState, teams, event, competition, context) {
        competition = SPORT_MODELS[sport]?.prepareCompetition?.(competition, event) ?? competition;
        const opening = pregameRating(
          sport,
          event,
          competition,
          context,
          gameState
        );
        const factors = opening.factors.map(
          (item) => ({
            ...item
          })
        );
        if (gameState === "upcoming") {
          return {
            ...opening,
            openingScore: opening.score,
            underdog: null,
            upsetText: "",
            upsetPoints: 0
          };
        }
        const values = teams.map(
          (team) => Number(team.score)
        ).filter(
          Number.isFinite
        );
        const gap = values.length === 2 ? Math.abs(
          values[0] - values[1]
        ) : null;
        const progress = gameState === "completed" ? 1 : gameProgress2(
          sport,
          competition
        );
        const championship = Boolean(SPORT_MODELS[sport]?.championshipContext) && opening.factors.some(
          (item) => /world series|championship|final round|finals|title game/i.test(item.label)
        ) || Boolean(gameState === "live" && SPORT_MODELS[sport]?.decisiveStakes?.(eventSignalText(event, competition, context)));
        const stateValue = stateRating2(
          opening.score,
          sport,
          gameState,
          gap,
          progress,
          null,
          {
            competition,
            teams,
            championship
          },
          opening.factors
        );
        factors.length = 0;
        factors.push(
          ...stateValue.factors
        );
        const detail = `${competition?.status?.type?.detail || ""} ${competition?.status?.type?.shortDetail || ""}`;
        const completedStakes = gameState === "completed" ? completedStakesImpact(
          sport,
          event,
          competition,
          context
        ) : {
          points: 0,
          factors: []
        };
        if (completedStakes.points) {
          factors.push(
            ...completedStakes.factors
          );
        }
        if (gameState === "completed" && !SPORT_MODELS[sport]?.ownsCompletedOvertime && /overtime|\b\d*ot\b/i.test(detail)) {
          factors.push({
            label: "Overtime",
            points: 13
          });
        }
        const underdog = underdogCandidate2(
          sport,
          competition,
          competition?.odds?.[0]
        );
        const upset = upsetImpact2(
          underdog,
          teams,
          gameState,
          progress,
          sport,
          competition
        );
        if (upset.points) {
          factors.push({
            label: gameState === "completed" ? "Underdog won outright" : "Underdog threatens upset",
            points: upset.points
          });
        }
        const completedResult = SPORT_MODELS[sport]?.completedResult?.(sport, gameState, teams, event, competition, context);
        if (completedResult?.points) {
          factors.push(completedResult);
        }
        const score = clampScore2(
          factors.reduce(
            (sum, item) => sum + item.points,
            0
          )
        );
        let reason = opening.reason;
        const unit = SPORT_MODELS[sport]?.unit || "point";
        if (gameState === "live") {
          reason = gap === 0 ? `Tied ${teams[0].score}\u2013${teams[1].score}${isLateGameStatus(sport, competition?.status, competition) ? " late" : ""}` : gap !== null && stateValue.closePoints > 0 ? `${gap}-${unit} game${isLateGameStatus(sport, competition?.status, competition) ? " late" : ""}` : `Game in progress \xB7 ${Math.round(progress * 100)}% elapsed`;
        }
        if (gameState === "completed") {
          reason = /overtime|\b\d*ot\b/i.test(detail) ? `Overtime finish \xB7 ${gap}-${unit} margin` : gap !== null ? `Decided by ${gap} ${unit}${gap === 1 ? "" : "s"}` : "Final result";
        }
        if (gameState === "live" && competition?.status) {
          liveRatingContexts.set(competition.status, {
            openingScore: opening.score,
            openingFactors: opening.factors,
            championshipStakes: championship,
            underdog,
            competition
          });
        }
        return {
          score,
          factors,
          reason,
          openingScore: opening.score,
          rawPregameScore: opening.rawPregameScore,
          openingFactors: opening.factors,
          ...championship ? { championshipStakes: true } : {},
          underdog,
          upsetText: upset.text,
          upsetPoints: upset.points,
          contextFactors: opening.contextFactors || []
        };
      }
      function liveMilestone(sport, summary) {
        return SPORT_MODELS[sport]?.milestone?.(summary, sport) ?? null;
      }
      function liveSnapshot(game, competition, summary) {
        const status = competition?.status || game.liveRawStatus;
        const situation = competition?.situation || game.liveRawSituation || {};
        const snapshot = {
          phase: livePhase(
            game.sport,
            status,
            competition?.format || game.sourceCompetition?.format || game.sourceEvent?.competitions?.[0]?.format || game.format,
            game.sourceEvent?.season || competition?.season || game.sourceCompetition?.season
          ),
          note: "",
          reasons: [],
          bonus: 0,
          bases: null,
          winProbability: null,
          components: {
            probability: 0,
            situation: 0,
            pressure: 0,
            milestone: 0,
            eventShock: 0
          }
        };
        const progress = gameProgress2(
          game.sport,
          {
            ...competition,
            status
          }
        );
        const scoreGap = Math.abs(
          Number(
            game.teams?.[0]?.[2]
          ) - Number(
            game.teams?.[1]?.[2]
          )
        );
        const probability = summary ? winProbabilityImpact(
          summary,
          progress,
          "live",
          game.sport
        ) : {
          points: 0,
          text: "",
          probability: null,
          uncertainty: null
        };
        snapshot.winProbability = probability.probability;
        snapshot.components.probability = probability.points;
        if (probability.text) {
          snapshot.reasons.push(
            probability.text
          );
        }
        const sportImpact = SPORT_MODELS[game.sport]?.situation?.({
          game,
          competition,
          summary,
          status,
          situation,
          progress,
          scoreGap
        }) || { points: 0, note: "", reasons: [], bases: null };
        if (sportImpact.note) {
          snapshot.note = sportImpact.note;
        }
        if (sportImpact.bases) {
          snapshot.bases = sportImpact.bases;
        }
        snapshot.reasons.push(
          ...sportImpact.reasons || []
        );
        snapshot.components.situation = Math.min(
          12,
          Math.max(
            0,
            Number(
              sportImpact.points
            ) || 0
          )
        );
        const pressure = dangerousChanceImpact(
          game.sport,
          summary,
          progress,
          scoreGap,
          competition
        );
        snapshot.components.pressure = pressure.points;
        snapshot.reasons.push(
          ...pressure.reasons || []
        );
        const milestone = summary ? SPORT_MODELS[game.sport]?.liveMilestone?.(summary, { game, competition, status, progress, scoreGap }) ?? liveMilestone(
          game.sport,
          summary
        ) : null;
        if (milestone) {
          snapshot.reasons.push(
            milestone.text
          );
          snapshot.components.milestone = Math.min(
            14,
            Math.max(
              0,
              milestone.points
            )
          );
        }
        const shock = eventShockImpact(game.sport, summary, status);
        snapshot.components.eventShock = Math.max(0, Math.min(12, shock.points));
        if (snapshot.components.eventShock) snapshot.reasons.push(...shock.reasons);
        snapshot.bonus = aggregateLiveBonus({
          probabilityPoints: snapshot.components.probability,
          situationPoints: snapshot.components.situation,
          pressurePoints: snapshot.components.pressure,
          milestonePoints: snapshot.components.milestone,
          eventShockPoints: snapshot.components.eventShock,
          sportImpact,
          decisiveFloorEnabled: Boolean(SPORT_MODELS[game.sport]?.decisiveFloor),
          nfl: game.sport === "NFL"
        }).bonus;
        const liveFloor = SPORT_MODELS[game.sport]?.liveFloor?.({ game, competition, progress, scoreGap });
        if (Number.isFinite(liveFloor) && liveFloor > 0) snapshot.bonus = Math.max(snapshot.bonus, Math.round(liveFloor) - game.baseScore);
        return snapshot;
      }
      function refreshLiveState(game, competition, summary, validateOnly = false) {
        const context = liveRatingContexts.get(
          game.liveRawStatus
        ) || liveRatingContexts.get(
          competition?.status
        );
        const previous = {
          ...context?.competition || game.sourceCompetition,
          status: game.liveRawStatus || context?.competition?.status,
          situation: game.liveRawSituation || context?.competition?.situation
        };
        const candidate = competition || previous;
        const summaryCandidate = summary?.header?.competitions?.[0];
        const validationCandidate = summaryCandidate || candidate;
        const type = validationCandidate.status?.type;
        const competitors = validationCandidate.competitors || [];
        const matched = game.teams.map((team) => {
          const id = String(
            team[8] || team.id || ""
          );
          if (id) {
            return competitors.find(
              (item) => String(
                item.team?.id || item.athlete?.id || item.id || ""
              ) === id
            );
          }
          const names = competitors.filter(
            (item) => (item.team?.displayName || item.athlete?.displayName) === team[0]
          );
          return names.length === 1 ? names[0] : void 0;
        });
        const wrongTeams = competitors.length > 0 && matched.some(
          (team) => !team
        );
        const summaryScoreConflict = Boolean(summaryCandidate && candidate.competitors) && game.teams.some((team) => {
          const id = String(team[8] || team.id || "");
          const find = (items) => items.find((item) => id ? String(item.team?.id || item.athlete?.id || item.id || "") === id : (item.team?.displayName || item.athlete?.displayName) === team[0]);
          const fromSummary = find(summaryCandidate.competitors || []);
          const fromScoreboard = find(candidate.competitors || []);
          return Number.isFinite(Number(fromSummary?.score)) && Number.isFinite(Number(fromScoreboard?.score)) && Number(fromSummary.score) !== Number(fromScoreboard.score);
        });
        const older = previous.status?.period && validationCandidate.status?.period && eventPosition2(
          game.sport,
          validationCandidate
        ) < eventPosition2(
          game.sport,
          previous
        );
        const lastAccepted = game.summaryState;
        const summaryRegressed = Boolean(summaryCandidate && lastAccepted?.status) && eventPosition2(game.sport, summaryCandidate) < eventPosition2(game.sport, lastAccepted);
        const rejected = wrongTeams || summaryScoreConflict || older || summaryRegressed || type?.completed === true || type?.state && type.state !== "in";
        if (validateOnly) return Boolean(summaryCandidate?.status) && !rejected;
        game.lastSummaryAccepted = Boolean(summary) && !rejected;
        if (game.lastSummaryAccepted && summaryCandidate) {
          game.summaryState = {
            status: summaryCandidate.status,
            competitors: (summaryCandidate.competitors || []).map((team) => ({
              team: { id: team.team?.id || team.athlete?.id || team.id || "" },
              score: team.score
            }))
          };
        }
        const scoreboardCompetitors = candidate.competitors || [];
        const scoreboardMatched = game.teams.map((team) => {
          const id = String(team[8] || team.id || "");
          if (id) return scoreboardCompetitors.find((item) => String(item.team?.id || item.athlete?.id || item.id || "") === id);
          const names = scoreboardCompetitors.filter((item) => (item.team?.displayName || item.athlete?.displayName) === team[0]);
          return names.length === 1 ? names[0] : void 0;
        });
        const scoreboardValid = !candidate.status?.type?.completed && !["post", "pre"].includes(candidate.status?.type?.state) && (!scoreboardCompetitors.length || scoreboardMatched.every((t) => t && t.score != null && t.score !== "" && Number.isFinite(Number(t.score))));
        const scoreboardOlder = previous.status?.period && candidate.status?.period && eventPosition2(game.sport, candidate) < eventPosition2(game.sport, previous);
        const current = !scoreboardValid || scoreboardOlder ? previous : {
          ...previous,
          ...candidate,
          status: candidate.status || previous.status,
          situation: candidate.status ? candidate.situation || {} : previous.situation
        };
        if (scoreboardValid && !scoreboardOlder && scoreboardMatched.length === 2 && scoreboardMatched.every(
          (team) => team && team.score != null && team.score !== "" && Number.isFinite(
            Number(team.score)
          )
        )) {
          if (scoreboardMatched.some((team) => !team)) return { competition: current, summary: rejected ? null : summary };
          scoreboardMatched.forEach(
            (team, index) => {
              game.teams[index][2] = String(team.score);
              if ("score" in game.teams[index]) {
                game.teams[index].score = String(team.score);
              }
            }
          );
        }
        const openingScore = Math.min(
          90,
          game.openingScore ?? context?.openingScore
        );
        const openingFactors = game.openingFactors || context?.openingFactors || [];
        if (game.championshipStakes || context?.championshipStakes) game.championshipStakes = true;
        else delete game.championshipStakes;
        if (Number.isFinite(
          openingScore
        )) {
          const gap = Math.abs(
            Number(
              game.teams[0][2]
            ) - Number(
              game.teams[1][2]
            )
          );
          const progress = gameProgress2(
            game.sport,
            current
          );
          const state = stateRating2(
            openingScore,
            game.sport,
            "live",
            Number.isFinite(gap) ? gap : null,
            progress,
            null,
            {
              competition: current,
              teams: game.teams,
              championship: game.championshipStakes,
              situation: current.situation,
              summary: rejected ? null : summary
            },
            openingFactors
          );
          const underdog = game.underdog || context?.underdog;
          const upset = upsetImpact2(
            underdog,
            game.teams,
            "live",
            progress,
            game.sport,
            current
          );
          const factors = [
            ...state.factors
          ];
          if (upset.points) {
            factors.push({
              label: "Underdog threatens upset",
              points: upset.points
            });
          }
          game.baseScore = clampScore2(
            factors.reduce(
              (sum, item) => sum + item.points,
              0
            )
          );
          game.factors = factors;
          game.openingScore = openingScore;
          game.openingFactors = openingFactors;
          game.underdog = underdog;
          game.upsetPoints = upset.points;
          game.upsetText = upset.text;
          const unit = SPORT_MODELS[game.sport]?.unit || "point";
          game.why = gap === 0 ? `Tied ${game.teams[0][2]}\u2013${game.teams[1][2]}${isLateGameStatus(game.sport, current.status, current) ? " late" : ""}` : state.closePoints > 0 ? `${gap}-${unit} game${isLateGameStatus(game.sport, current.status, current) ? " late" : ""}` : `Game in progress \xB7 ${Math.round(progress * 100)}% elapsed`;
          if (current.status) {
            liveRatingContexts.set(
              current.status,
              {
                openingScore,
                underdog,
                competition: current
              }
            );
          }
        }
        game.liveRawStatus = current.status;
        game.liveRawSituation = current.situation;
        game.status = current.status?.type?.shortDetail || current.status?.type?.detail || game.status;
        return {
          competition: current,
          summary: rejected ? null : summary
        };
      }
      function applyLiveSnapshot2(game, competition, summary) {
        if (game.state !== "live") {
          return;
        }
        const current = refreshLiveState(
          game,
          competition,
          summary
        );
        game.live = liveSnapshot(
          game,
          current.competition,
          current.summary
        );
        game.score = clampScore2(
          game.baseScore + game.live.bonus
        );
      }
      function momentumImpact2(sport, summary, progress, state, completedContext = null) {
        const history = SPORT_MODELS[sport]?.historyImpact ? SPORT_MODELS[sport].historyImpact(summary, progress, state) : historyImpact(sport, summary, progress, state, SPORT_MODELS[sport]?.history);
        return state === "completed" && completedContext ? SPORT_MODELS[sport]?.completedHistory?.(summary, history, completedContext) ?? history : history;
      }
      function contextCarryWeight(progress, gameState, sport = "", championship = false) {
        const anchors = SPORT_MODELS[sport]?.contextAnchors?.(championship) || [
          [0, 0.38],
          [0.25, 0.3],
          [0.5, 0.2],
          [0.75, 0.12],
          [0.9, 0.08],
          [1, 0.06]
        ];
        return contextWeightFor(progress, gameState, anchors);
      }
      function eventShockImpact(sport, summary, status) {
        return eventShockFor(sport, summary, status, SPORT_MODELS[sport]);
      }
      function dangerousChanceImpact(sport, summary, progress, scoreGap, competition = null) {
        return pressureImpact(summary, progress, scoreGap, competition, SPORT_MODELS[sport]?.pressure);
      }
      const api = {
        SPORT_FLOOR,
        SCHEDULE_SCARCITY,
        SPORT_BASE: SPORT_BASE2,
        NFL_DIVISIONS,
        NHL_DIVISIONS,
        NBA_DIVISIONS,
        MLB_DIVISIONS,
        CONTEXT_WEIGHTS,
        CLOSE_MARGIN: CLOSE_MARGIN2,
        clampScore: clampScore2,
        factorText: factorText2,
        recordFor: recordFor2,
        rankFor: rankFor2,
        recordStats,
        parseLine: parseLine2,
        lineFromSummary: lineFromSummary2,
        eventSignalText,
        nflDivisionFor,
        divisionFor,
        winningRecord,
        listedSpread,
        moneylinePrices,
        pregameMarketFactor,
        proRecordFactors,
        pregameContextFactors,
        specificStakesFactors,
        completedStakesImpact,
        pregameRating,
        gameProgress: gameProgress2,
        normalizedTime,
        eventPosition: eventPosition2,
        normalizeWinProbability,
        winProbabilitySeries,
        winProbabilityImpact,
        footballStagnationImpact,
        momentumImpact: momentumImpact2,
        defensiveFinishFactor,
        underdogCandidate: underdogCandidate2,
        upsetImpact: upsetImpact2,
        unbeatenStartImpact: unbeatenStartImpact2,
        contextCarryWeight,
        nhlLiveMarginCloseness,
        mlbLiveMarginCloseness,
        footballMarginCloseness,
        footballLiveCloseness,
        footballRunwayPenalty,
        stateRating: stateRating2,
        rateGame: rateGame2,
        ordinal,
        livePhase,
        runnerOn,
        clockSeconds,
        footballFieldPosition,
        footballSituationImpact,
        baseballSituationImpact,
        hockeyOnIceState,
        hockeyPowerPlay,
        hockeySituationImpact,
        basketballSituationImpact,
        tennisSituationImpact,
        dangerousChanceImpact,
        eventShockImpact,
        soccerSituationImpact,
        noHitBid,
        hockeyGoalMilestone,
        footballMilestone,
        basketballScoringMilestone,
        baseballPerformanceMilestone,
        soccerScoringMilestone,
        liveMilestone,
        liveSnapshot,
        applyLiveSnapshot: applyLiveSnapshot2
      };
      root.SportsRadarDetail = {
        validateLiveSummary: (game, competition, summary) => refreshLiveState(game, competition, summary, true)
      };
      root.SportsRadarScore = api;
      if (typeof module2 !== "undefined" && module2.exports) {
        module2.exports = api;
      }
    })(globalThis);
  }
});

// watch-links.js
var require_watch_links = __commonJS({
  "watch-links.js"(exports2, module2) {
    (function(root) {
      "use strict";
      const providers = [
        {
          id: "peacock",
          name: "Peacock",
          aliases: /^peacock(?:\s+(?:premium|tv))?$/i,
          sports: "https://www.peacocktv.com/watch/sports",
          hosts: ["www.peacocktv.com", "peacocktv.com"],
          gamePath: /^\/watch\/(?:asset|playback)\/.+/
        },
        {
          id: "espn",
          name: "ESPN",
          aliases: /^(?:espn(?:\s*\+|\s*plus|[23u]|news|\s+deportes|\s+select|\s+unl(?:imited|mtd))?|accn(?:x)?|acc network(?: extra)?|secn(?:\s*\+)?|sec network(?:\s*\+)?)$/i,
          sports: "https://www.espn.com/watch/",
          hosts: ["www.espn.com", "espn.com"],
          gamePath: /^\/watch\/(?:player(?:\/|$)|.*\/player\/)/
        },
        {
          id: "paramount",
          name: "Paramount+",
          aliases: /^paramount\s*(?:\+|plus)$/i,
          sports: "https://www.paramountplus.com/browse/sports/",
          hosts: ["www.paramountplus.com", "paramountplus.com"],
          gamePath: /^\/(?:shows\/(?:[^/]+\/)?video|sports\/[^/]+\/(?:video|matches))\/.+/
        },
        {
          id: "prime",
          name: "Prime Video",
          aliases: /^(?:amazon(?: prime(?: video)?)?|prime(?: video)?)(?:\s*\(local\))?$/i,
          sports: "https://www.primevideo.com/sports",
          hosts: ["www.primevideo.com", "primevideo.com", "www.amazon.com", "amazon.com"],
          gamePath: /^\/(?:detail|dp|gp\/video\/(?:detail|dp))\/.+/
        },
        {
          id: "apple",
          name: "Apple TV",
          aliases: /^(?:apple\s*tv\s*\+?|mls season pass)$/i,
          sports: "https://tv.apple.com/sports",
          hosts: ["tv.apple.com"],
          gamePath: /^\/(?:[a-z]{2}\/)?(?:sporting-event|episode)\/.+/
        },
        {
          id: "disney",
          name: "Disney+",
          aliases: /^(?:espn\s+on\s+)?disney\s*(?:\+|plus)$/i,
          sports: "https://www.disneyplus.com/explore/sports",
          hosts: ["www.disneyplus.com", "disneyplus.com"],
          gamePath: /^\/play\/[a-f0-9-]{36}\/?$/i
        },
        {
          id: "max",
          name: "HBO Max",
          aliases: /^(?:hbo\s*max|max)$/i,
          sports: "https://www.hbomax.com/sports",
          hosts: ["www.hbomax.com", "hbomax.com", "play.hbomax.com"],
          gamePath: /^\/video\/watch\/[a-f0-9-]{36}\/[a-f0-9-]{36}\/?$/i
        },
        {
          id: "netflix",
          name: "Netflix",
          aliases: /^netflix$/i,
          sports: "https://www.netflix.com/tudum/topics/sports",
          hosts: ["www.netflix.com", "netflix.com"],
          gamePath: /^\/(?:watch|title)\/\d+\/?$/
        },
        {
          id: "youtube-tv",
          name: "YouTube TV",
          aliases: /^(?:you\s*tube\s*tv|yt\s*tv)$/i,
          sports: "https://tv.youtube.com/directory/sports",
          hosts: ["tv.youtube.com"],
          gamePath: /^\/watch\/[a-zA-Z0-9_-]+$/
        },
        {
          id: "hulu",
          name: "Hulu",
          aliases: /^hulu(?:\s*(?:\+|plus)?\s*live\s*tv)?$/i,
          sports: "https://www.hulu.com/live-sports",
          hosts: ["www.hulu.com", "hulu.com"],
          gamePath: /^\/watch\/[a-f0-9-]{36}\/?$/i
        },
        // These services are only offered when explicitly named, never inferred from a network.
        { id: "flo", name: "FloSports", aliases: /^flo\s*sports$/i, sports: "https://www.flosports.tv/" },
        { id: "dazn", name: "DAZN", aliases: /^dazn(?:\s*(?:\(YES\)|CLE|IND|MEM|MIN|SAS))?$/i, sports: "https://www.dazn.com/" },
        { id: "nba", name: "NBA League Pass", aliases: /^nba\s+league\s+pass$/i, sports: "https://www.nba.com/league-pass/" },
        { id: "mw", name: "MW+", aliases: /^(?:mw\s*\+|mountain west\s*(?:\+|plus))$/i, sports: "https://watch.themw.com/" },
        { id: "midco", name: "Midco Sports Plus", aliases: /^midco sports\s*(?:\+|plus)$/i, sports: "https://midcosportsplus.com/" },
        { id: "swac", name: "SWAC TV", aliases: /^swac\s*tv$/i, sports: "https://tv.swac.org/" },
        {
          id: "youtube",
          name: "YouTube",
          aliases: /^you\s*tube$/i,
          sports: "https://www.youtube.com/sports",
          hosts: ["www.youtube.com", "youtube.com"],
          gamePath: /^\/(?:watch|live\/[a-zA-Z0-9_-]{11})$/
        }
      ];
      const list = (value) => Array.isArray(value) ? value : [];
      function labels(value) {
        return typeof value === "string" ? value.split(/\s*[·,;/|&]\s*/).map((name) => name.trim()).filter(Boolean) : [];
      }
      function officialGameUrl(provider, value) {
        if (!provider?.gamePath || typeof value !== "string" || value.length > 2048 || /[\s\\\u0000-\u001f\u007f]/.test(value)) return "";
        if (!/^https:\/\/[^/]/i.test(value) || /%(?:2f|5c|2e|25)/i.test(value) || /\/(?:\.|\.\.)(?:\/|[?#]|$)/.test(value)) return "";
        try {
          const url = new URL(value);
          if (url.protocol !== "https:" || url.username || url.password || url.port || !provider.hosts.includes(url.hostname)) return "";
          if (url.hash || /%(?:2f|5c|2e|25)/i.test(url.pathname) || !provider.gamePath.test(url.pathname)) return "";
          const queryKeys = provider.id === "espn" ? ["id", "ex_cid"] : provider.id === "youtube" ? ["v"] : [];
          for (const [key, content] of url.searchParams) {
            if (!queryKeys.includes(key) || !/^[a-zA-Z0-9_-]+$/.test(content) || url.searchParams.getAll(key).length !== 1) return "";
          }
          if (provider.id === "espn" && !url.searchParams.get("id") && !/\/(?:id|event)\/[^/]+/.test(url.pathname)) return "";
          if (provider.id === "youtube" && url.pathname === "/watch" && !/^[a-zA-Z0-9_-]{11}$/.test(url.searchParams.get("v") || "")) return "";
          return url.href;
        } catch {
          return "";
        }
      }
      function resolve(game, ...sources) {
        const names = labels(game?.channel);
        const candidates = [];
        const addLink = (link) => {
          if (typeof link === "string") candidates.push(link);
          else if (link && typeof link === "object" && !list(link.rel).some((value) => /highlight|recap|preview/i.test(value))) candidates.push(link.href || link.url);
        };
        const visit = (source) => {
          if (!source || typeof source !== "object") return;
          list(source.links).filter((link) => {
            const rel = list(link?.rel);
            return rel.some((value) => /^(?:watch|stream|live|video)$/i.test(value)) && !rel.some((value) => /highlight|recap|preview/i.test(value));
          }).forEach(addLink);
          for (const broadcast of [...list(source.broadcasts), ...list(source.geoBroadcasts)].filter((item) => item && typeof item === "object")) {
            for (const value of [broadcast.name, broadcast.shortName, broadcast.media?.name, broadcast.media?.shortName, ...list(broadcast.names)]) {
              names.push(...labels(typeof value === "object" ? value?.name : value));
            }
            [broadcast.href, broadcast.url, broadcast.link, broadcast.media?.href, broadcast.media?.url, broadcast.media?.link].forEach(addLink);
            list(broadcast.links).forEach(addLink);
            list(broadcast.media?.links).forEach(addLink);
          }
        };
        visit(game?.sourceEvent);
        visit(game?.sourceCompetition);
        for (const source of sources) {
          visit(source);
          visit(source?.header);
          list(source?.competitions).forEach(visit);
          list(source?.header?.competitions).forEach(visit);
        }
        for (const link of list(game?.watchLinks)) {
          const provider = providers.find((item) => item.id === link?.provider);
          if (provider) {
            if (officialGameUrl(provider, link.url)) names.push(provider.name);
            addLink(link);
          }
        }
        return providers.flatMap((provider) => {
          const matchingNames = names.filter((name2) => provider.aliases.test(name2));
          if (!matchingNames.length) return [];
          const direct = candidates.map((value) => officialGameUrl(provider, value)).find(Boolean);
          const name = provider.id === "espn" && matchingNames.some((value) => /^espn(?:\+|\s*plus)$/i.test(value)) ? "ESPN+" : provider.name;
          return [{ provider: provider.id, name, url: direct || provider.sports, direct: !!direct }];
        });
      }
      const api = { resolve, officialGameUrl, providers };
      if (typeof module2 === "object" && module2.exports) module2.exports = api;
      root.SportsRadarWatch = api;
    })(globalThis);
  }
});

// calibration/trajectory-policy.cjs
var require_trajectory_policy = __commonJS({
  "calibration/trajectory-policy.cjs"(exports2, module2) {
    var unit = (value) => Math.max(0, Math.min(1, Number(value) || 0));
    var smoothstep = (start, end, value) => {
      const x = unit((value - start) / (end - start));
      return x * x * (3 - 2 * x);
    };
    var reference = {
      positiveCap: 10,
      negativeCap: 8,
      genuineWeight: 0.75,
      falseCloseWeight: 0.75,
      dominanceWeight: 0.8,
      revivalPoints: 3,
      evidenceStart: 0.25,
      evidenceEnd: 0.75,
      gateStart: 0.1,
      gateEnd: 0.65,
      fallbackPositiveConfidence: 1,
      wpCountStart: 1,
      wpCountEnd: 6
    };
    var policy = (id, description, changes = {}) => Object.freeze({ id, description, ...reference, ...changes });
    var CURRENT_GATE_POLICIES = Object.freeze([[0.1, 0.65], [0.2, 0.7], [0.25, 0.75], [0.3, 0.8], [0.35, 0.85], [0.45, 0.95]].map(([start, end]) => Object.freeze({ start, end })));
    var POSITIVE_CONFIDENCE_LEVELS = Object.freeze([0.5, 0.65, 0.8, 1]);
    var TRAJECTORY_POLICIES = Object.freeze(CURRENT_GATE_POLICIES.flatMap(({ start, end }) => POSITIVE_CONFIDENCE_LEVELS.map((confidence) => policy(
      `gate-${Math.round(start * 100)}-${Math.round(end * 100)}-wp-${Math.round(confidence * 100)}`,
      `Positive gate ${start} to ${end}; margin fallback sustained reward at ${confidence * 100}% confidence.`,
      { gateStart: start, gateEnd: end, fallbackPositiveConfidence: confidence }
    ))));
    function validatePolicy(p) {
      for (const key of Object.keys(reference)) {
        if (!Number.isFinite(p[key]) || p[key] < 0) throw new Error(`Invalid trajectory policy ${key}`);
      }
      if (p.evidenceEnd <= p.evidenceStart || p.gateEnd <= p.gateStart || p.genuineWeight > 1 || p.gateEnd > 1 || p.fallbackPositiveConfidence > 1 || p.wpCountEnd <= p.wpCountStart) throw new Error("Invalid trajectory policy ramp/weight");
    }
    function trajectoryAdjustment(telemetry, currentCloseness, policy2 = null) {
      if (policy2) validatePolicy(policy2);
      const t = telemetry || {};
      const hasHistory = Number.isFinite(t.trajectoryEndPosition) && t.trajectoryEndPosition > 0 && [t.genuineContinuity, t.marginContinuity, t.competitiveShare, t.dominantShare].every(Number.isFinite);
      const source = t.genuineContinuitySource || "unavailable";
      const diagnostic = {
        enabled: Boolean(policy2),
        policyId: policy2?.id ?? null,
        adjustment: 0,
        evidenceWeight: 0,
        sustainedQuality: 0,
        falseClose: 0,
        dominance: 0,
        lateRevival: 0,
        sustainedQualityContribution: 0,
        adjustedSustainedQualityContribution: 0,
        positiveWpConfidence: 0,
        positiveWpSupport: 0,
        wpConfidence: 0,
        falseCloseContribution: 0,
        dominanceContribution: 0,
        lateRevivalContribution: 0,
        positiveCurrentStateGate: 0,
        rawTrajectory: 0,
        boundedTrajectory: 0,
        telemetrySource: source,
        fallback: source === "margin-fallback",
        wpCoverageShare: unit(t.wpCoverageShare),
        wpObservationCount: t.wpObservationCount || 0,
        wpCoverageStart: t.wpCoverageStart ?? null,
        wpCoverageEnd: t.wpCoverageEnd ?? null,
        trajectoryEndPosition: t.trajectoryEndPosition ?? null,
        hasHistory
      };
      if (!policy2 || !hasHistory) return diagnostic;
      const p = policy2;
      const wpConfidence = source === "positioned-win-probability" ? unit(t.wpCoverageShare) : 0;
      const genuine = source === "positioned-win-probability" ? unit(t.marginContinuity) * (1 - wpConfidence) + unit(t.genuineContinuity) * wpConfidence : unit(t.genuineContinuity);
      const sustainedQuality = p.genuineWeight * genuine + (1 - p.genuineWeight) * unit(t.competitiveShare);
      const falseClose = Math.max(0, unit(t.marginContinuity) - unit(t.genuineContinuity)) * wpConfidence;
      const dominance = unit(t.dominantShare) * (source === "positioned-win-probability" ? wpConfidence : 1);
      const recentCompetition = Number.isFinite(t.lastCompetitivePosition) ? smoothstep(0.8, 1, t.lastCompetitivePosition / t.trajectoryEndPosition) : 0;
      const lateRevival = unit(t.lateMovementShare) * recentCompetition * (1 - sustainedQuality);
      const sustainedQualityContribution = p.positiveCap * smoothstep(0.35, 0.95, sustainedQuality);
      const positiveWpSupport = source === "positioned-win-probability" ? smoothstep(0, 1, unit(t.wpCoverageShare)) * smoothstep(p.wpCountStart, p.wpCountEnd, t.wpObservationCount || 0) : 0;
      const positiveWpConfidence = p.fallbackPositiveConfidence + (1 - p.fallbackPositiveConfidence) * positiveWpSupport;
      const adjustedSustainedQualityContribution = sustainedQualityContribution * positiveWpConfidence;
      const falseCloseContribution = -p.negativeCap * p.falseCloseWeight * falseClose || 0;
      const dominanceContribution = -p.negativeCap * p.dominanceWeight * dominance || 0;
      const lateRevivalContribution = p.revivalPoints * lateRevival;
      const rawTrajectory = adjustedSustainedQualityContribution + falseCloseContribution + dominanceContribution + lateRevivalContribution;
      const boundedTrajectory = Math.max(-p.negativeCap, Math.min(p.positiveCap, rawTrajectory));
      const evidenceWeight = smoothstep(p.evidenceStart, p.evidenceEnd, t.trajectoryEndPosition);
      const positiveCurrentStateGate = smoothstep(p.gateStart, p.gateEnd, unit(currentCloseness));
      const adjustment = boundedTrajectory * evidenceWeight * (boundedTrajectory > 0 ? positiveCurrentStateGate : 1);
      return {
        ...diagnostic,
        adjustment,
        evidenceWeight,
        sustainedQuality,
        falseClose,
        dominance,
        lateRevival,
        sustainedQualityContribution,
        adjustedSustainedQualityContribution,
        positiveWpConfidence,
        positiveWpSupport,
        falseCloseContribution,
        dominanceContribution,
        lateRevivalContribution,
        rawTrajectory,
        boundedTrajectory,
        positiveCurrentStateGate,
        wpConfidence
      };
    }
    module2.exports = { TRAJECTORY_POLICIES, CURRENT_GATE_POLICIES, POSITIVE_CONFIDENCE_LEVELS, trajectoryAdjustment };
  }
});

// calibration/trajectory-live-policy.cjs
var require_trajectory_live_policy = __commonJS({
  "calibration/trajectory-live-policy.cjs"(exports2, module2) {
    var { TRAJECTORY_POLICIES, trajectoryAdjustment } = require_trajectory_policy();
    var { SPORT_MODELS } = require_models();
    var { historyImpact } = require_history();
    var { scoringMoments } = require_trajectory();
    var { eventPosition: eventPosition2 } = require_time();
    var unit = (value) => Math.max(0, Math.min(1, Number(value) || 0));
    var baseline = TRAJECTORY_POLICIES.find((p) => p.id === "gate-45-95-wp-65");
    var LIVE_TRAJECTORY_POLICIES = Object.freeze([
      [0.35, 0.85],
      [0.45, 0.95]
    ].map(([gateStart, gateEnd]) => Object.freeze({
      ...baseline,
      id: `live-owned-${gateStart * 100}-${gateEnd * 100}`,
      description: "Replace sustained history before caps; no revival; protect sport-owned current floors.",
      liveOwnership: true,
      gateStart,
      gateEnd,
      revivalPoints: 0,
      negativeRetention: 0.25
    })));
    var LIVE_HISTORY_RELEVANCE_POLICY = Object.freeze({
      ...LIVE_TRAJECTORY_POLICIES[1],
      id: "live-owned-45-95-relevant-history",
      liveHistoryRelevance: true,
      description: "Current relevance before history caps; supported recovery shares the decisive-state discount taper."
    });
    var LIVE_ENDGAME_ALLOCATION_POLICY = Object.freeze({
      ...LIVE_HISTORY_RELEVANCE_POLICY,
      id: "live-owned-45-95-relevant-history-endgame-allocation",
      endgameAllocation: true,
      description: "NFL floors consume earned positive history; retain existing context outside floor headroom. NHL unchanged."
    });
    var LIVE_NHL_ALLOCATION_POLICY = Object.freeze({
      ...LIVE_ENDGAME_ALLOCATION_POLICY,
      id: "live-owned-45-95-relevant-history-nhl-allocation",
      nhlAllocation: true,
      description: "NHL normalized clocks, context-preserving targets and independent bounded history; NFL allocation unchanged."
    });
    var LIVE_CFB_CONTEXT_POLICY = Object.freeze({
      ...LIVE_NHL_ALLOCATION_POLICY,
      id: "live-owned-45-95-relevant-history-cfb-context",
      cfbContextRetention: true,
      description: "CFB supported matchup context retains its opening-live weight with existing viability; NFL/NHL unchanged."
    });
    var LIVE_CFB_WATCHABILITY_POLICY = Object.freeze({
      ...LIVE_CFB_CONTEXT_POLICY,
      id: "live-owned-45-95-relevant-history-cfb-watchability",
      cfbCurrentState: Object.freeze({ openingCeiling: 34, matureCeiling: 48, matureProgress: 0.5, contextScale: 0.4 }),
      description: "CFB current competition owns more of the watch scale by halftime; discretionary context is supplementary. Other sports and history rules unchanged."
    });
    var LIVE_CFB_COMPETITION_POLICY = Object.freeze({
      ...LIVE_CFB_WATCHABILITY_POLICY,
      id: "live-owned-45-95-relevant-history-cfb-competition",
      cfbImmediateTension: true,
      cfbCompetitionHistory: true,
      description: "CFB immediate tension separates score margin from comeback runway; lead-extending run credit cannot refill through correlated history."
    });
    function cfbContextRetention(core, game, state, matchupScale = 1) {
      const transient = Math.max(0, game.openingScore - state.persistentStakes);
      const ordinary = Math.min(transient, game.openingFactors?.length ? game.openingFactors.filter((f) => ["Sport baseline", "Schedule scarcity"].includes(f.label)).reduce((sum, f) => sum + Math.max(0, Number(f.points) || 0), 0) : transient);
      const matchup = Math.max(0, transient - ordinary);
      const viability = state.contextWeight > 0 ? state.retainedContextWeight / state.contextWeight : 0;
      const matchupWeight = core.contextCarryWeight(0, "live", "CFB") * viability * matchupScale;
      const points = Math.round(ordinary * state.retainedContextWeight + matchup * matchupWeight);
      return { ordinary, matchup, ordinaryWeight: state.retainedContextWeight, matchupWeight, viability, points };
    }
    function endgameFloorBudget(game, base, live, owned) {
      if (game.sport !== "NFL" || !(live.sportImpact?.competitiveFloor > 0)) return null;
      const points = (label) => base.state.factors.find((f) => f.label === label)?.points || 0;
      const ordinaryOpening = (game.openingFactors || []).filter((f) => ["Sport baseline", "Schedule scarcity"].includes(f.label)).reduce((sum, f) => sum + Math.max(0, Number(f.points) || 0), 0);
      const ordinaryContext = Math.round(Math.min(
        ordinaryOpening,
        Math.max(0, game.openingScore - base.state.persistentStakes)
      ) * base.state.retainedContextWeight);
      const matchupContext = Math.max(0, points("Pregame context carried into play") - ordinaryContext);
      const stakes = Math.max(0, points("Persistent postseason stakes"));
      const retainedContext = matchupContext + stakes;
      const positiveHistory = owned.historyOwnership.combinedFactors.reduce((sum, f) => sum + Math.max(0, f.points), 0);
      return {
        positiveHistory,
        matchupContext,
        stakes,
        retainedContext,
        floorBaseScore: base.baseScore + positiveHistory - retainedContext,
        originalFloor: live.sportImpact.competitiveFloor
      };
    }
    function ownedHistory(sport, summary, progress, trajectoryPositive = 0, liveRelevance = null, nhlAllocation = null, cfbCompetitionHistory = false) {
      const model = SPORT_MODELS[sport] || {};
      const options = {
        replaceSustained: true,
        trajectoryPositive,
        cfbCompetitionHistory,
        ...liveRelevance === null ? {} : { liveRelevance },
        ...sport === "NHL" && nhlAllocation ? { nhlAllocation } : {}
      };
      return model.historyImpact ? model.historyImpact(summary, progress, "live", options) : historyImpact(sport, summary, progress, "live", model.history, options);
    }
    function historyRelevance(game, prepared, base, decisiveStrength) {
      const state = base.state, margin = state.marginCloseness;
      const viability = state.comebackViability;
      const hasRunway = Number.isFinite(state.footballState?.comebackFeasibility) || Number.isFinite(state.basketballState?.comebackFeasibility);
      const ramp = (value) => unit((value - 0.15) / 0.3);
      const canReduce = state.widePenalty > 0 && Number.isFinite(margin) && (hasRunway || prepared.progress >= 0.75);
      const eventRetention = canReduce ? Math.max(ramp(margin), hasRunway ? ramp(viability) : 0, decisiveStrength) : 1;
      const currentPosition = eventPosition2(game.sport, prepared.context.competition);
      const end = Number.isFinite(currentPosition) ? currentPosition : prepared.progress;
      const moments = scoringMoments(game.sport, prepared.historySummary || prepared.context.summary).filter((m) => m.position <= end + 1e-9 && m.play.homeScore != null && m.play.awayScore != null);
      const scores = Object.fromEntries((prepared.context.competition?.competitors || []).map((t) => [t.homeAway, t.score == null ? NaN : Number(t.score)]));
      const latest = moments.at(-1);
      const ledgerMatches = Boolean(latest && latest.home === scores.home && latest.away === scores.away);
      const threshold = SPORT_MODELS[game.sport]?.history?.threshold;
      const viable = Number.isFinite(prepared.gap) && prepared.gap <= threshold && margin >= 0.5 && (!hasRunway || viability >= 0.45);
      let recovery = null;
      if (ledgerMatches && viable) for (const side of ["home", "away"]) {
        const opponent = side === "home" ? "away" : "home";
        let deepest = 0, start = -1;
        for (const [i, m] of moments.entries()) if (m[opponent] - m[side] > deepest) {
          deepest = m[opponent] - m[side];
          start = i;
        }
        const recovered = deepest - Math.max(0, scores[opponent] - scores[side]);
        let scoringEvents2 = 0, lastGain = null, valid = true;
        for (let i = start + 1; i < moments.length; i++) {
          const prior = moments[i - 1];
          if (!prior) continue;
          const own = moments[i][side] - prior[side], other = moments[i][opponent] - prior[opponent];
          if (own < 0 || other < 0 || own > 0 && other > 0) valid = false;
          if (own > 0 && other === 0) {
            scoringEvents2++;
            lastGain = moments[i].position;
          }
        }
        if (valid && deepest >= threshold && recovered >= threshold && scoringEvents2 >= 2 && lastGain !== null && end - lastGain <= 0.16 && (!recovery || recovered > recovery.recovered)) {
          recovery = { side, deepestDeficit: deepest, recovered, scoringEvents: scoringEvents2, lastGain, age: end - lastGain };
        }
      }
      return {
        eventRetention,
        marginCloseness: margin,
        comebackViability: viability,
        ledgerMatches,
        recovery,
        recoveryStrength: recovery ? 0.75 : 0,
        eventReason: eventRetention < 1 ? "Current sport margin/runway limits historical competition relevance" : "Current competition history retained",
        recoveryReason: recovery ? "Material score recovery with recent scoring and viable current runway" : "No supported recent material recovery with viable current runway"
      };
    }
    function liveTrajectory(core, game, prepared, base, live, policy) {
      const raw = trajectoryAdjustment(prepared.trajectory, base.state.currentCloseness, policy);
      const impact = live.sportImpact || {}, aggregation = live.aggregation || {};
      const floorBonus = Math.max(0, aggregation.driveFloor || 0, impact.competitiveFloor || 0);
      const decisiveStrength = Math.max(unit(impact.decisiveDrive?.urgency), unit(impact.finalPossession?.urgency), unit(floorBonus / 20));
      const relevance = policy.liveHistoryRelevance ? historyRelevance(game, prepared, base, decisiveStrength) : null;
      const effectivePositiveGate = Math.max(raw.positiveCurrentStateGate, 0.5 * decisiveStrength);
      const requestedPositive = Math.max(0, raw.boundedTrajectory) * raw.evidenceWeight * effectivePositiveGate;
      const nhlAllocation = policy.nhlAllocation && game.sport === "NHL" ? impact.allocation : null;
      const eventHistory = ownedHistory(game.sport, prepared.historySummary || prepared.context.summary, prepared.progress, 0, relevance?.eventRetention ?? null, nhlAllocation, game.sport === "CFB" && policy.cfbCompetitionHistory);
      const combinedHistory = requestedPositive > 0 ? ownedHistory(game.sport, prepared.historySummary || prepared.context.summary, prepared.progress, requestedPositive, relevance?.eventRetention ?? null, nhlAllocation, game.sport === "CFB" && policy.cfbCompetitionHistory) : eventHistory;
      const positiveAfterHistoryCaps = combinedHistory.points - eventHistory.points;
      const protectionStrength = Math.max(decisiveStrength, relevance?.recoveryStrength || 0);
      const negativeMultiplier = 1 - (1 - policy.negativeRetention) * protectionStrength;
      const negativeAfterTaper = Math.min(0, raw.boundedTrajectory) * raw.evidenceWeight * negativeMultiplier;
      const beforeNegative = base.baseScore + live.bonus + combinedHistory.points;
      const protectedRating = floorBonus > 0 ? base.baseScore + floorBonus : null;
      const negativeAfterFloor = protectedRating === null ? negativeAfterTaper : Math.max(negativeAfterTaper, Math.min(0, protectedRating - beforeNegative));
      return {
        momentumPoints: eventHistory.points,
        trajectoryScoring: {
          ...raw,
          unprotectedAdjustment: raw.adjustment,
          adjustment: positiveAfterHistoryCaps + negativeAfterFloor,
          effectivePositiveGate,
          decisiveStrength,
          requestedPositive,
          positiveAfterHistoryCaps,
          ...relevance ? { protectionStrength, positiveReducedByRelevance: requestedPositive * (1 - relevance.eventRetention) } : {},
          negativeMultiplier,
          negativeAfterTaper,
          negativeAfterFloor,
          protectedRating,
          floorBonus
        },
        historyOwnership: {
          originalPoints: Number(game.momentumPoints) || 0,
          eventPoints: eventHistory.points,
          ...eventHistory.cfbRun ? { cfbRun: eventHistory.cfbRun } : {},
          ...relevance ? { relevance, allocation: combinedHistory.relevance } : {},
          replacedPoints: (Number(game.momentumPoints) || 0) - eventHistory.points,
          originalSustainedFactors: (game.factors || []).filter((f) => ["Sustained competitive game", "Time tied or within one goal"].includes(f.label)),
          eventFactors: eventHistory.factors,
          combinedFactors: combinedHistory.factors,
          combinedPoints: combinedHistory.points,
          positiveLimitedByCaps: requestedPositive * (relevance?.eventRetention ?? 1) - positiveAfterHistoryCaps
        }
      };
    }
    module2.exports = {
      LIVE_CFB_COMPETITION_POLICY,
      LIVE_TRAJECTORY_POLICIES,
      LIVE_HISTORY_RELEVANCE_POLICY,
      LIVE_ENDGAME_ALLOCATION_POLICY,
      LIVE_NHL_ALLOCATION_POLICY,
      LIVE_CFB_CONTEXT_POLICY,
      LIVE_CFB_WATCHABILITY_POLICY,
      cfbContextRetention,
      endgameFloorBudget,
      ownedHistory,
      liveTrajectory
    };
  }
});

// scoring/football-transition.cjs
var require_football_transition = __commonJS({
  "scoring/football-transition.cjs"(exports2, module2) {
    var { footballPregameSpread, underdogCandidate: underdogCandidate2 } = require_market();
    var CALIBRATION = "2026-10-31.football-pregame.1";
    var unit = (x) => Math.max(0, Math.min(1, x));
    var smooth = (x) => {
      x = unit(x);
      return x * x * (3 - 2 * x);
    };
    var football2 = (game) => ["NFL", "CFB"].includes(game.sport);
    function recoveredMarket(game, competition, summary) {
      if (!summary) return null;
      const source = summary.header?.competitions?.[0] || competition;
      const markets = [...summary.pickcenter || [], ...source?.odds || []];
      for (const raw of markets) {
        if (raw.isLive || /live|in[ -]?play/i.test([raw.type?.name || raw.type, raw.description, raw.marketType, raw.name].filter(Boolean).join(" "))) continue;
        let market = raw.close || raw.closing;
        const home = Number(raw.pointSpread?.home?.close?.line), away = Number(raw.pointSpread?.away?.close?.line);
        if (!market && Number.isFinite(home) && Number.isFinite(away) && home === -away && home !== 0 && ["home", "away"].every((side) => raw.pointSpread?.[side]?.close?.line != null))
          market = { pointSpread: Object.fromEntries(["home", "away"].map((side) => [side, { close: raw.pointSpread[side].close }])) };
        if (!market) continue;
        const candidate = underdogCandidate2(game.sport, source, market);
        if (candidate && game.teams.some((t) => String(t[8]) === candidate.teamId)) return { candidate, spread: footballPregameSpread({ odds: [market] }), odds: [market], source: "verified closing odds" };
      }
      return null;
    }
    function preservePregameBaseline(game, previous) {
      if (!football2(game) || game.state === "upcoming" || !previous || game.sport !== previous.sport || String(game.id) !== String(previous.id)) return false;
      const ids = (g) => (g.teams || []).map((t) => String(t[8] || "")).sort();
      const currentIds = ids(game), priorIds = ids(previous);
      if (currentIds.length !== 2 || !currentIds[0] || currentIds[0] === currentIds[1] || currentIds.join("|") !== priorIds.join("|")) return false;
      const baseline = previous.pregameBaseline;
      if (baseline?.calibration !== CALIBRATION || !Number.isFinite(baseline.score)) return false;
      if (game.state === "completed" && baseline.source !== "observed") return false;
      game.pregameBaseline = JSON.parse(JSON.stringify(baseline));
      return true;
    }
    function prepareFootballOpening(core, game, competition, summary) {
      if (!football2(game) || game.state === "completed") return;
      const recorded = game.state !== "upcoming" && game.pregameBaseline?.calibration === CALIBRATION && game.pregameBaseline.source === "observed";
      if (!recorded) {
        const prior = game.pregameBaseline;
        const summaryOdds = summary?.pickcenter || summary?.header?.competitions?.[0]?.odds;
        const odds = game.state === "upcoming" && competition?.sportsRadarPregameMarketManaged ? competition.odds : competition?.odds?.length ? competition.odds : summaryOdds?.length ? summaryOdds : prior?.odds;
        const basis = { ...competition, season: { ...game.sourceEvent?.season, ...competition?.season }, odds };
        const opening = core.pregameRating(game.sport, game.sourceEvent, basis, game.context, "upcoming");
        game.pregameBaseline = {
          calibration: CALIBRATION,
          source: game.state === "upcoming" ? "observed" : "reconstructed",
          score: opening.score,
          rawPregameScore: opening.rawPregameScore,
          factors: opening.factors,
          odds: odds || [],
          spread: footballPregameSpread(basis),
          underdog: underdogCandidate2(game.sport, basis, odds?.[0])
        };
      }
      const baseline = game.pregameBaseline;
      if (!baseline.underdog) {
        const recovered = recoveredMarket(game, competition, summary);
        if (recovered) game.recoveredUnderdog = { ...recovered, gameId: String(game.id), teamIds: game.teams.map((t) => String(t[8])).sort() };
      }
      game.openingScore = baseline.score;
      game.openingFactors = baseline.factors.map((f) => ({ ...f }));
      game.rawPregameScore = baseline.rawPregameScore;
      if (game.state === "upcoming" && competition?.sportsRadarPregameMarketManaged) {
        game.score = baseline.score;
        game.baseScore = baseline.score;
        game.factors = baseline.factors.map((f) => ({ ...f }));
      }
      if (game.state === "live") game.underdog = baseline.underdog || game.recoveredUnderdog?.candidate || null;
    }
    function footballCompetitionEvidence(game, competition, progress, probability) {
      const maturity = smooth(progress / 0.5);
      const baseline = game.pregameBaseline;
      const spread = baseline?.spread ?? game.recoveredUnderdog?.spread;
      const competitors = competition?.competitors || [];
      const home = competitors.find((t) => t.homeAway === "home"), away = competitors.find((t) => t.homeAway === "away");
      const dog = baseline?.underdog || game.recoveredUnderdog?.candidate;
      const odds = baseline?.odds?.[0] || game.recoveredUnderdog?.odds?.[0] || {};
      const homeDog = dog ? String(dog.teamId) === String(home?.team?.id) : odds.homeTeamOdds?.underdog === true || odds.awayTeamOdds?.favorite === true;
      const knownDirection = dog || odds.homeTeamOdds?.favorite || odds.awayTeamOdds?.favorite || odds.homeTeamOdds?.underdog || odds.awayTeamOdds?.underdog;
      const margin = home?.score != null && away?.score != null ? Number(home.score) - Number(away.score) : 0;
      const remaining = Math.max(0.01, 1 - unit(progress));
      const edge = Number.isFinite(spread) ? knownDirection ? (homeDog ? -spread : spread) * remaining + margin : Math.max(0, spread * remaining - Math.abs(margin)) : null;
      const estimate = edge === null ? null : 1 / (1 + Math.exp(-edge / 7));
      const priorUncertainty = estimate === null ? 0.5 : 1 - 2 * Math.abs(estimate - 0.5);
      const observed = probability === null ? priorUncertainty : 1 - 2 * Math.abs(probability - 0.5);
      const uncertainty = priorUncertainty * (1 - maturity) + observed * maturity;
      return { maturity, priorUncertainty, uncertainty, probability: 0.5 + (0.5 - uncertainty / 2), source: probability === null ? "market-and-score-estimate" : "validated-ESPN" };
    }
    function transitionFootballBase(core, game, prepared, base) {
      const evidence = footballCompetitionEvidence(game, prepared.context.competition, prepared.progress, prepared.probability.probability);
      const m = evidence.maturity, state = base.state;
      const transient = Math.max(0, game.openingScore - state.persistentStakes);
      const replacements = {
        "Game-state baseline": 12 * m,
        "Pregame context carried into play": transient * (1 - m) + (base.factors.find((f) => f.label === "Pregame context carried into play")?.points || 0) * m,
        "Persistent postseason stakes": state.persistentStakes * (1 - m) + (base.factors.find((f) => f.label === "Persistent postseason stakes")?.points || 0) * m,
        "Current Tension": state.currentTensionPoints * m
      };
      const factors = base.factors.filter((f) => !(f.label in replacements)).map((f) => ({ ...f }));
      for (const [label, points] of Object.entries(replacements)) if (points) factors.push({ label, points: Number(points.toFixed(4)) });
      const baseScore = core.clampScore(factors.reduce((sum, f) => sum + f.points, 0));
      return { factors, baseScore, state: { ...state, factors, score: baseScore, currentTensionPoints: replacements["Current Tension"], footballEvidence: evidence } };
    }
    module2.exports = { CALIBRATION, preservePregameBaseline, prepareFootballOpening, footballCompetitionEvidence, transitionFootballBase };
  }
});

// scoring/event-occasion.cjs
var require_event_occasion = __commonJS({
  "scoring/event-occasion.cjs"(exports2, module2) {
    function eventOccasion(game, c) {
      if (game.sport !== "NCAAB") return null;
      const records = (c?.competitors || []).map((t) => (t.records || t.record || []).find((r) => r.type === "total")?.summary);
      const seasonOpener = records.length === 2 && records.every((r) => r === "0-0") && Number(game.sourceEvent?.season?.type) === 2;
      const address = c?.venue?.address || {}, country = String(address.country || address.state || ""), city = String(address.city || "");
      const countries = /^(?:Italy|France|Germany|Spain|United Kingdom|Ireland|Australia|Japan|Mexico|Bahamas|Greece)$/i;
      const name = (c?.notes || []).find((n) => n.type === "event")?.headline;
      const international = c?.neutralSite === true && Boolean(city) && countries.test(country) && Boolean(name);
      return seasonOpener || international ? { seasonOpener, international, city, name: international ? name : "" } : null;
    }
    function factorsFor(game, c) {
      const occasion = eventOccasion(game, c);
      if (!occasion) return [];
      game.eventOccasion = occasion;
      return [
        ...occasion.seasonOpener ? [{ label: "Season opener", contextType: "season_opener", contextText: "Both teams are opening their seasons", points: 3 }] : [],
        ...occasion.international ? [{ label: "International showcase", contextType: "international_showcase", contextText: `The ${occasion.name} takes place in ${occasion.city}`, points: 4 }] : []
      ];
    }
    module2.exports = { eventOccasion, factorsFor };
  }
});

// scoring/basketball-calibration.cjs
var require_basketball_calibration = __commonJS({
  "scoring/basketball-calibration.cjs"(exports2, module2) {
    var { clockSeconds } = require_time();
    var { numberFromLine } = require_market();
    function underdog(game, c, raw) {
      if (game.sport !== "NCAAB" || !raw || raw.isLive || /live|in[ -]?play/i.test([raw.type?.name || raw.type, raw.description, raw.marketType].join(" "))) return null;
      const market = raw.close || raw.closing || raw;
      const lines = ["home", "away"].map((side) => ({ side, value: numberFromLine(market.pointSpread?.[side]?.close?.line) }));
      if (lines.some((s) => s.value === null) || Math.abs(lines[0].value + lines[1].value) > 1e-6) return null;
      const dog = lines.find((s) => s.value > 4);
      if (!dog) return null;
      const team = c?.competitors?.find((t) => t.homeAway === dog.side);
      if (!team) return null;
      const x = Math.max(0, Math.min(1, (dog.value - 4) / 6));
      return {
        side: dog.side,
        teamId: String(team.team?.id),
        teamName: team.team?.displayName,
        type: "spread",
        value: dog.value,
        strength: Math.min(1, Math.max(0, (dog.value - 8) / 8)),
        activation: x * x * (3 - 2 * x),
        description: `${dog.value}-point underdog`
      };
    }
    function lateCollegeState(game, c) {
      if (game.sport !== "NCAAB" || Number(c?.status?.period) < 2) return null;
      const seconds = clockSeconds(c.status);
      if (seconds === null || seconds < 0) return null;
      const gap = Math.abs(Number(game.teams[0][2]) - Number(game.teams[1][2]));
      const x = Math.max(0, Math.min(1, (300 - seconds) / 180)), urgency = x * x * (3 - 2 * x);
      const closeness = Math.max(0, Math.min(1, (7 - gap) / 4));
      return { urgency: urgency * closeness };
    }
    function tensionPolicy(game, c) {
      const state = lateCollegeState(game, c);
      return state ? { kind: "margin-modifier", uncertaintyWeight: 0.35, currentTensionCeiling: 34 + 10 * state.urgency } : null;
    }
    function situation(game, c, impact) {
      const state = lateCollegeState(game, c);
      if (!state) return impact;
      return { ...impact, candidatePoints: Math.min(12, (impact.candidatePoints || 0) + Math.round(5 * state.urgency)) };
    }
    module2.exports = { tensionPolicy, situation, underdog };
  }
});

// scoring/opening-transition.cjs
var require_opening_transition = __commonJS({
  "scoring/opening-transition.cjs"(exports2, module2) {
    var football2 = require_football_transition();
    var { footballPregameSpread, moneylinePrices, underdogCandidate: underdogCandidate2 } = require_market();
    var { normalizedTime } = require_time();
    var { hockeyLiveTiming } = require_nhl();
    var { CONTEXT_LABELS } = require_config();
    var occasion = require_event_occasion();
    var college = require_basketball_calibration();
    var SPORTS = Object.freeze(["NHL", "NBA", "NCAAB", "MLB", "Soccer", "Tennis"]);
    var CALIBRATION = "2026-10-31.opening-transition.1";
    var unit = (n) => Math.max(0, Math.min(1, n));
    var smooth = (n) => {
      n = unit(n);
      return n * n * (3 - 2 * n);
    };
    var supports = (g) => SPORTS.includes(g.sport);
    function validBaseline(baseline) {
      if (baseline?.calibration !== CALIBRATION || !Number.isFinite(baseline.score) || !Number.isFinite(baseline.rawPregameScore) || !Array.isArray(baseline.factors) || !baseline.factors.length || baseline.factors.some((f) => !Number.isFinite(f.points))) return false;
      const raw = baseline.factors.reduce((sum, f) => sum + f.points, 0);
      return Math.abs(raw - baseline.rawPregameScore) < 1e-6 && baseline.score === Math.min(90, Math.max(1, Math.min(99, Math.round(raw))));
    }
    function preservePregameBaseline(game, previous) {
      if (!supports(game)) return football2.preservePregameBaseline(game, previous);
      if (game.state === "upcoming" || !previous || game.sport !== previous.sport || String(game.id) !== String(previous.id)) return false;
      const ids = (g) => (g.teams || []).map((t) => String(t[8] || "")).sort();
      const a = ids(game), b = ids(previous);
      if (a.length !== 2 || !a[0] || a[0] === a[1] || a.join("|") !== b.join("|")) return false;
      const baseline = previous.pregameBaseline;
      if (!validBaseline(baseline)) return false;
      if (game.state === "completed" && baseline.source !== "observed") return false;
      if (game.pregameBaseline?.source === "observed" && baseline.source !== "observed") return false;
      game.pregameBaseline = JSON.parse(JSON.stringify(baseline));
      return true;
    }
    function prepareOpening(core, game, competition, summary) {
      if (!supports(game)) return football2.prepareFootballOpening(core, game, competition, summary);
      if (game.state === "completed") return;
      const prior = game.pregameBaseline;
      const observed = game.state !== "upcoming" && validBaseline(prior) && prior.source === "observed";
      const occasionFactors = occasion.factorsFor(game, competition);
      const withOccasion = (opening) => {
        const factors = [...opening.factors, ...occasionFactors.filter((f) => !opening.factors.some((o) => o.contextType === f.contextType))];
        const rawPregameScore = factors.reduce((sum, f) => sum + f.points, 0);
        return { ...opening, factors, rawPregameScore, score: Math.min(90, core.clampScore(rawPregameScore)) };
      };
      if (!observed) {
        const summaryOdds = summary?.pickcenter || summary?.header?.competitions?.[0]?.odds;
        const odds = competition?.odds?.length ? competition.odds : summaryOdds?.length ? summaryOdds : prior?.odds || [];
        const basis = { ...competition, odds };
        const opening = withOccasion(core.pregameRating(game.sport, game.sourceEvent, basis, game.context, "upcoming"));
        game.pregameBaseline = {
          calibration: CALIBRATION,
          source: game.state === "upcoming" ? "observed" : "reconstructed",
          score: opening.score,
          rawPregameScore: opening.rawPregameScore,
          factors: opening.factors,
          odds,
          spread: footballPregameSpread(basis),
          underdog: underdogCandidate2(game.sport, basis, odds[0])
        };
      }
      const baseline = game.pregameBaseline;
      game.openingScore = baseline.score;
      game.rawPregameScore = baseline.rawPregameScore;
      game.openingFactors = baseline.factors.map((f) => ({ ...f }));
      const labels = /* @__PURE__ */ new Set([...Object.values(CONTEXT_LABELS), "Season opener", "International showcase"]);
      const enriched = withOccasion(core.pregameRating(game.sport, game.sourceEvent, { ...competition, odds: baseline.odds }, game.context, "upcoming"));
      game.liveOpeningContext = observed ? enriched.factors.filter((f) => labels.has(f.label)).reduce((sum, f) => sum + f.points - (baseline.factors.find((b) => b.label === f.label)?.points || 0), 0) : 0;
      if (game.state === "live") game.underdog = baseline.underdog || college.underdog(game, competition, baseline.odds?.[0]) || game.recoveredCollegeUnderdog || null;
      if (game.sport === "NCAAB" && summary && !game.underdog) {
        const raw = (summary.pickcenter || []).find((o) => o.close || o.closing || o.pointSpread?.home?.close?.line != null);
        const recovered = college.underdog(game, competition, raw);
        if (recovered) {
          game.recoveredCollegeUnderdog = recovered;
          game.underdog = recovered;
        }
      }
      if (game.state === "upcoming") {
        game.score = baseline.score;
        game.baseScore = baseline.score;
        game.factors = baseline.factors.map((f) => ({ ...f }));
      }
    }
    function gameplayProgress(game, competition, summary) {
      const status = competition?.status || {}, period = Number(status.period || 1);
      if (game.sport === "NHL") {
        const timing = hockeyLiveTiming(game.sourceEvent, competition, summary);
        return timing.shootout || timing.depth ? 1 : unit((timing.elapsed || 0) / 3600);
      }
      if (game.sport === "MLB") {
        const s = competition?.situation || {}, detail = [status.type?.detail, status.type?.shortDetail, status.inningHalf].join(" ");
        const bottom = /bottom|bot\b|middle|mid\b/i.test(detail);
        const outs = Math.max(0, Math.min(3, Number(s.outs) || 0));
        return unit(((period - 1) * 6 + (/end/i.test(detail) ? 6 : (bottom ? 3 : 0) + outs)) / 54);
      }
      if (game.sport === "Tennis") {
        const bestOf = Number(competition?.format?.regulation?.periods || competition?.format?.bestOf || 3);
        const competitors = competition?.competitors || [];
        const games = competitors.reduce((sum, t) => sum + (t.linescores || []).reduce((n, set) => n + (Number(set.value) || 0), 0), 0);
        const completed = competitors.reduce((sum, t) => sum + (Number(t.score) || 0), 0);
        return unit(Math.max(games, completed * 8) / (bestOf * 8));
      }
      const time2 = normalizedTime(game.sport, competition);
      if (time2.elapsedSeconds === null) return unit((period - 1) / ({ NBA: 4, NCAAB: 2, Soccer: 2 }[game.sport] || 1));
      return time2.progress;
    }
    function competitionEvidence(game, competition, progress, probability) {
      const maturity = smooth(progress / 0.5), baseline = game.pregameBaseline;
      const prices = moneylinePrices(baseline?.odds?.[0]);
      const implied = (p) => p < 0 ? -p / (-p + 100) : 100 / (p + 100);
      let uncertainty = 0.5;
      if (prices.length >= 2) {
        const a = implied(prices[0]), b = implied(prices[1]);
        uncertainty = 1 - 2 * Math.abs(a / (a + b) - 0.5);
      } else if (prices.length === 1) uncertainty = 1 - 2 * Math.abs(implied(prices[0]) - 0.5);
      else if (Number.isFinite(baseline?.spread)) {
        const scale = { NBA: 8, NCAAB: 8, NHL: 1.5, MLB: 2, Soccer: 1.5, Tennis: 2 }[game.sport];
        uncertainty = 2 / (1 + Math.exp(baseline.spread / scale));
      }
      const scores = (competition?.competitors || []).map((t) => Number(t.score));
      const gap = scores.length === 2 && scores.every(Number.isFinite) ? Math.abs(scores[0] - scores[1]) : null;
      const scoreboard = gap === null ? uncertainty : 1;
      const observed = probability === null ? scoreboard : 1 - 2 * Math.abs(probability - 0.5);
      const effective = uncertainty * (1 - maturity) + observed * maturity;
      return {
        maturity,
        priorUncertainty: uncertainty,
        uncertainty: effective,
        probability: 1 - effective / 2,
        source: probability === null ? "market-and-score-estimate" : "validated-ESPN"
      };
    }
    function transitionBase(core, game, prepared, base) {
      const evidence = competitionEvidence(game, prepared.context.competition, prepared.progress, prepared.probability.probability);
      const m = evidence.maturity, state = base.state, points = (label) => base.factors.find((f) => f.label === label)?.points || 0;
      const replacements = {
        "Game-state baseline": points("Game-state baseline") * m,
        "Pregame context carried into play": Math.max(0, game.openingScore - state.persistentStakes) * (1 - m) + points("Pregame context carried into play") * m,
        "Persistent postseason stakes": state.persistentStakes * (1 - m) + points("Persistent postseason stakes") * m,
        "Current Tension": points("Current Tension") * m
      };
      const newContext = (game.liveOpeningContext || 0) * (1 - m + state.retainedContextWeight * m);
      if (newContext) replacements["Verified context learned during play"] = newContext;
      const factors = base.factors.filter((f) => !(f.label in replacements)).map((f) => ({ ...f }));
      for (const [label, points2] of Object.entries(replacements)) if (points2) factors.push({ label, points: Number(points2.toFixed(4)) });
      const baseScore = core.clampScore(factors.reduce((sum, f) => sum + f.points, 0));
      return { factors, baseScore, state: { ...state, factors, score: baseScore, currentTensionPoints: replacements["Current Tension"], openingEvidence: evidence } };
    }
    function openingEventModel(sport, model) {
      const points = { NHL: 4, Soccer: 4, MLB: 2, NBA: 1, NCAAB: 1 }[sport];
      if (!points) return model;
      return { ...model, eventShock: (input) => model.eventShock?.(input) || (input.play.scoringPlay === true ? { value: points, label: "Opening scoring play" } : null) };
    }
    module2.exports = { SPORTS, CALIBRATION, supports, preservePregameBaseline, prepareOpening, gameplayProgress, competitionEvidence, transitionBase, openingEventModel };
  }
});

// calibration/shadow-candidate.cjs
var require_shadow_candidate = __commonJS({
  "calibration/shadow-candidate.cjs"(exports2, module2) {
    var { cfbImmediateTension } = require_cfb();
    var { SPORT_MODELS, analyzeTrajectory } = require_models();
    var { aggregateLiveBonus } = require_pressure();
    var { eventShockFor } = require_events();
    var { hockeyLiveTiming, hockeyPlayClockMode } = require_nhl();
    var { trajectoryAdjustment } = require_trajectory_policy();
    var { liveTrajectory, endgameFloorBudget, cfbContextRetention } = require_trajectory_live_policy();
    var openingTransition = require_opening_transition();
    var { footballCompetitionEvidence, transitionFootballBase } = require_football_transition();
    var collegeFinish = require_basketball_calibration();
    var DEFAULT_CURRENT_TENSION_POLICY = Object.freeze({
      kind: "margin-modifier",
      uncertaintyWeight: 0.35,
      currentTensionCeiling: 34
    });
    var CURRENT_TENSION_CEILING = DEFAULT_CURRENT_TENSION_POLICY.currentTensionCeiling;
    var PARAMETERIZED_CURRENT_TENSION_CEILING = 24;
    var GENERIC_LEVERAGE_CAP = 8;
    var GENERIC_LEVERAGE_START = 0.55;
    var GENERIC_LEVERAGE_SPAN = 0.4;
    var unit = (value) => Math.max(0, Math.min(1, Number(value) || 0));
    function currentClosenessFor(marginCloseness, effectiveUncertainty, policy = null) {
      const margin = unit(marginCloseness);
      const appliedPolicy = policy ?? DEFAULT_CURRENT_TENSION_POLICY;
      if (appliedPolicy.kind === "linear") {
        const marginWeight = appliedPolicy.marginWeight ?? 0.3;
        return unit(marginWeight) * margin + (1 - unit(marginWeight)) * effectiveUncertainty;
      }
      if (appliedPolicy.kind === "margin-modifier") {
        const uncertaintyWeight = unit(appliedPolicy.uncertaintyWeight ?? 0.35);
        return margin * (1 - uncertaintyWeight + uncertaintyWeight * effectiveUncertainty);
      }
      throw new Error(`Unsupported Current Tension policy kind: ${appliedPolicy.kind}`);
    }
    function candidateComponents(marginCloseness, currentWinProbability, uncertaintyCeiling = 1, progress = 0, policy = null) {
      const probability = currentWinProbability === null ? null : Number(currentWinProbability);
      const uncertainty = probability === null || !Number.isFinite(probability) ? null : unit(1 - 2 * Math.abs(probability - 0.5));
      const effectiveUncertainty = uncertainty === null ? null : Math.min(uncertainty, unit(uncertaintyCeiling));
      const currentCloseness = uncertainty === null ? unit(marginCloseness) : currentClosenessFor(marginCloseness, effectiveUncertainty, policy);
      const x = unit((unit(progress) - GENERIC_LEVERAGE_START) / GENERIC_LEVERAGE_SPAN);
      const urgency = x * x * (3 - 2 * x);
      const appliedPolicy = policy ?? DEFAULT_CURRENT_TENSION_POLICY;
      const currentTensionCeiling = Number.isFinite(Number(appliedPolicy.currentTensionCeiling)) ? Math.max(0, Number(appliedPolicy.currentTensionCeiling)) : PARAMETERIZED_CURRENT_TENSION_CEILING;
      return {
        marginCloseness: unit(marginCloseness),
        currentWinProbability: probability,
        uncertainty,
        uncertaintyCeiling: unit(uncertaintyCeiling),
        effectiveUncertainty,
        currentCloseness,
        currentTensionCeiling,
        currentTensionPoints: Math.round(currentTensionCeiling * currentCloseness),
        genericLeverageUrgency: urgency,
        genericLeveragePoints: Math.round(GENERIC_LEVERAGE_CAP * urgency * currentCloseness)
      };
    }
    function validateCurrentWinProbability(core, summary, progress, state = "live", sport = "") {
      if (!summary) return { points: 0, text: "", probability: null, uncertainty: null };
      return core.winProbabilityImpact(summary, progress, state, sport);
    }
    function candidateStateRating(core, openingScore, sport, gameState, gap, progress, homeWinProbability = null, context = null, openingFactors = [], policy = null) {
      const legacy = core.stateRating(
        openingScore,
        sport,
        gameState,
        gap,
        progress,
        homeWinProbability,
        context,
        openingFactors
      );
      if (gameState !== "live") {
        return {
          ...legacy,
          policy: "legacy-non-live",
          currentTensionPoints: legacy.closePoints,
          genericLeveragePoints: 0,
          currentCloseness: null,
          marginCloseness: null,
          currentWinProbability: null
        };
      }
      const closeLimit = core.CLOSE_MARGIN[sport] || 10;
      const modelState = SPORT_MODELS[sport]?.gameState?.({
        sport,
        gameState,
        gap,
        progress,
        context,
        closeLimit
      }) || {};
      const completedCloseLimit = modelState.completedCloseLimit ?? closeLimit;
      const marginCloseness = gap === null ? 0 : modelState.marginClose ?? Math.max(0, 1 - gap / completedCloseLimit);
      const probability = policy?.footballEvidence ? footballCompetitionEvidence(policy.footballEvidence.game, context.competition, progress, core.normalizeWinProbability(homeWinProbability)).probability : policy?.openingEvidence ? openingTransition.competitionEvidence(policy.openingEvidence.game, context.competition, progress, core.normalizeWinProbability(homeWinProbability)).probability : core.normalizeWinProbability(homeWinProbability);
      const candidate = candidateComponents(
        marginCloseness,
        probability,
        modelState.uncertaintyCeiling ?? 1,
        progress,
        policy
      );
      if (sport === "CFB" && policy?.cfbImmediateTension && Number(context?.competition?.status?.period || 0) <= 4) {
        const immediateMargin = cfbImmediateTension(gap, candidate.marginCloseness);
        const immediate = candidateComponents(immediateMargin, probability, modelState.uncertaintyCeiling ?? 1, progress, policy);
        candidate.immediateTensionMargin = immediateMargin;
        candidate.currentTensionPoints = immediate.currentTensionPoints;
      }
      const genericLabels = /* @__PURE__ */ new Set([
        "Score closeness and leverage",
        "Outcome uncertainty and score closeness",
        "Late-game leverage"
      ]);
      const factors = [];
      let inserted = false;
      const insertCandidate = () => {
        if (inserted) return;
        inserted = true;
        if (candidate.currentTensionPoints) {
          factors.push({ label: "Current Tension", points: candidate.currentTensionPoints });
        }
        if (candidate.genericLeveragePoints) {
          factors.push({ label: "Generic Leverage", points: candidate.genericLeveragePoints });
        }
      };
      for (const factor of legacy.factors) {
        if (genericLabels.has(factor.label)) {
          insertCandidate();
          continue;
        }
        if (!inserted && ["Limited comeback runway", "Wide margin"].includes(factor.label)) {
          insertCandidate();
        }
        factors.push({ ...factor });
      }
      insertCandidate();
      return {
        ...legacy,
        ...candidate,
        policy: "shadow-candidate-v1",
        score: core.clampScore(factors.reduce((sum, factor) => sum + factor.points, 0)),
        factors,
        closePoints: candidate.currentTensionPoints,
        phasePoints: 0
      };
    }
    function candidateLiveSnapshot(core, game, competition, summary, floorBudget = null, nhlAllocation = null, progressOverride = null, openingEvidence = null, collegeFinishEnabled = false) {
      const status = competition?.status || game.liveRawStatus;
      const situation = competition?.situation || game.liveRawSituation || {};
      const progress = progressOverride ?? core.gameProgress(game.sport, { ...competition, status });
      const scoreGap = Math.abs(Number(game.teams?.[0]?.[2]) - Number(game.teams?.[1]?.[2]));
      let sportImpact = SPORT_MODELS[game.sport]?.situation?.({
        game: floorBudget === null ? game : { ...game, baseScore: floorBudget.floorBaseScore },
        competition,
        summary,
        status,
        situation,
        progress,
        scoreGap,
        nhlAllocation
      }) || { points: 0, note: "", reasons: [], bases: null };
      if (collegeFinishEnabled) sportImpact = collegeFinish.situation(game, competition, sportImpact);
      if (floorBudget) sportImpact.competitiveFloor = Math.min(floorBudget.originalFloor, sportImpact.competitiveFloor);
      const legacy = core.liveSnapshot(game, competition, summary);
      const eventSummary = game._historicalEvidence?.summary || summary;
      const probabilityTelemetry = validateCurrentWinProbability(core, summary, core.gameProgress(game.sport, { ...competition, status }), "live", game.sport);
      const components = {
        ...legacy.components,
        probability: 0,
        situation: Math.min(12, Math.max(0, Number(sportImpact.candidatePoints ?? sportImpact.points) || 0))
      };
      if (game._historicalEvidence) components.eventShock = Math.max(components.eventShock, core.eventShockImpact(game.sport, eventSummary, status).points);
      if (nhlAllocation && game.sport === "NHL") {
        components.pressure = SPORT_MODELS.NHL.pressure.impact(summary, progress, scoreGap, competition, nhlAllocation).points;
        const clockMode = hockeyPlayClockMode(eventSummary || {});
        const retainedShock = eventShockFor("NHL", eventSummary, status, SPORT_MODELS.NHL, (value) => {
          const elapsed = hockeyLiveTiming(game.sourceEvent, { ...competition, status: value === status ? value : { ...value, clockMode } }, summary).elapsed;
          return elapsed === null ? null : elapsed / 3600;
        }).points;
        components.eventShock = game._historicalEvidence ? Math.max(components.eventShock, retainedShock) : retainedShock;
      }
      if (openingEvidence && openingEvidence.maturity < 1) {
        const model = openingTransition.openingEventModel(game.sport, SPORT_MODELS[game.sport] || {});
        const clockMode = game.sport === "NHL" ? hockeyPlayClockMode(eventSummary || {}) : null;
        const position = game.sport === "NHL" ? (value) => {
          const elapsed = hockeyLiveTiming(game.sourceEvent, { ...competition, status: value === status ? value : { ...value, clockMode } }, summary).elapsed;
          return elapsed === null ? null : elapsed / 3600;
        } : null;
        const shock = eventShockFor(game.sport, eventSummary, status, model, position);
        components.eventShock += Math.max(0, shock.points - components.eventShock) * (1 - openingEvidence.maturity);
      }
      const aggregation = aggregateLiveBonus({
        probabilityPoints: 0,
        situationPoints: components.situation,
        pressurePoints: components.pressure,
        milestonePoints: components.milestone,
        eventShockPoints: components.eventShock,
        sportImpact,
        decisiveFloorEnabled: Boolean(SPORT_MODELS[game.sport]?.decisiveFloor),
        preserveCompetitiveSupport: game.sport === "NHL" && Boolean(nhlAllocation),
        nfl: game.sport === "NFL"
      });
      let bonus = aggregation.bonus;
      const liveFloor = game.sport === "CFB" ? 0 : SPORT_MODELS[game.sport]?.liveFloor?.({ game, competition, progress, scoreGap });
      if (Number.isFinite(liveFloor) && liveFloor > 0) {
        bonus = Math.max(bonus, Math.round(liveFloor) - game.baseScore);
      }
      return {
        ...legacy,
        bonus,
        components,
        reasons: legacy.reasons.filter((reason) => !(sportImpact.genericTimeReasons || []).includes(reason)),
        probabilityTelemetry: { ...probabilityTelemetry, awardedPoints: 0 },
        aggregation,
        sportImpact
      };
    }
    function nonLiveCandidateRating(game, summary) {
      return {
        score: game.score,
        baseScore: game.baseScore,
        liveBonus: game.live?.bonus || 0,
        factors: game.factors,
        currentTensionPoints: 0,
        genericLeveragePoints: 0,
        currentWinProbability: null,
        trajectory: analyzeTrajectory(game.sport, summary, game.state === "completed" ? 1 : null, game.state),
        productionUnchanged: true
      };
    }
    function prepareCandidateGameRating(core, game, competition, summary, productionOpening = false) {
      const progress = productionOpening && openingTransition.supports(game) ? openingTransition.gameplayProgress(game, competition, summary) : core.gameProgress(game.sport, competition);
      const scores = game.teams.map((team) => Number(team[2]));
      const gap = scores.every(Number.isFinite) ? Math.abs(scores[0] - scores[1]) : null;
      const probability = validateCurrentWinProbability(core, summary, core.gameProgress(game.sport, competition), "live", game.sport);
      return {
        progress,
        gap,
        probability,
        context: {
          competition,
          teams: game.teams,
          championship: game.championshipStakes,
          situation: competition?.situation,
          summary
        },
        extraFactors: (game.factors || []).filter((factor) => ["Underdog threatens upset", "Verified live development"].includes(factor.label)).map((factor) => ({ ...factor })),
        trajectory: analyzeTrajectory(game.sport, summary, progress, "live")
      };
    }
    function candidateBaseForPolicy(core, game, prepared, policy) {
      const state = candidateStateRating(
        core,
        game.openingScore,
        game.sport,
        "live",
        prepared.gap,
        prepared.progress,
        prepared.probability.probability,
        prepared.context,
        game.openingFactors || [],
        policy
      );
      const factors = [...state.factors, ...prepared.extraFactors.map((factor) => ({ ...factor }))];
      const baseScore = core.clampScore(factors.reduce((sum, factor) => sum + factor.points, 0));
      return { state, factors, baseScore };
    }
    function finishCandidateGameRating(core, game, prepared, base, live, trajectoryPolicy = null, currentTensionPolicy = null) {
      if (game.sport === "CFB" && trajectoryPolicy?.cfbContextRetention) {
        const scale = trajectoryPolicy.cfbCurrentState;
        if (scale) {
          const x = unit(prepared.progress / scale.matureProgress);
          const currentTensionCeiling = scale.openingCeiling + (scale.matureCeiling - scale.openingCeiling) * x * x * (3 - 2 * x);
          base = candidateBaseForPolicy(core, game, prepared, { ...currentTensionPolicy || DEFAULT_CURRENT_TENSION_POLICY, currentTensionCeiling, cfbImmediateTension: trajectoryPolicy.cfbImmediateTension });
          base.factors = base.factors.map((f) => f.label === "Underdog threatens upset" && !f.liveSurprise ? { ...f, points: Math.round(f.points * scale.contextScale) } : f);
        }
        const retention = cfbContextRetention(core, game, base.state, scale?.contextScale ?? 1);
        const replace = (items) => {
          const label = "Pregame context carried into play";
          const factors2 = items.map((f) => f.label === label ? { ...f, points: retention.points } : { ...f });
          if (retention.points && !factors2.some((f) => f.label === label)) factors2.splice(1, 0, { label, points: retention.points });
          return factors2;
        };
        const stateFactors = replace(base.state.factors), factors = replace(base.factors);
        base = {
          state: {
            ...base.state,
            cfbContextRetention: retention,
            factors: stateFactors,
            score: core.clampScore(stateFactors.reduce((sum, f) => sum + f.points, 0))
          },
          factors,
          baseScore: core.clampScore(factors.reduce((sum, f) => sum + f.points, 0))
        };
        live = candidateLiveSnapshot(
          core,
          { ...game, baseScore: base.baseScore, factors: base.factors },
          prepared.context.competition,
          prepared.context.summary
        );
      }
      if (game.sport === "NHL" && trajectoryPolicy?.nhlAllocation) {
        base = candidateBaseForPolicy(core, game, { ...prepared, context: { ...prepared.context, nhlAllocation: true } }, currentTensionPolicy);
        const ordinary = (game.openingFactors || []).filter((f) => ["Sport baseline", "Schedule scarcity"].includes(f.label)).reduce((sum, f) => sum + Math.max(0, Number(f.points) || 0), 0);
        const ordinaryCarry = Math.round(Math.min(ordinary, Math.max(0, game.openingScore - base.state.persistentStakes)) * base.state.retainedContextWeight);
        const context = Math.max(0, (base.state.factors.find((f) => f.label === "Pregame context carried into play")?.points || 0) - ordinaryCarry);
        live = candidateLiveSnapshot(
          core,
          { ...game, sourceEvent: game.sourceEvent, baseScore: base.baseScore, factors: base.factors },
          prepared.context.competition,
          prepared.context.summary,
          null,
          { context }
        );
      }
      if (trajectoryPolicy?.openingTransition && openingTransition.supports(game)) {
        base = openingTransition.transitionBase(core, game, prepared, base);
        live = candidateLiveSnapshot(
          core,
          { ...game, sourceEvent: game.sourceEvent, baseScore: base.baseScore, factors: base.factors },
          prepared.context.competition,
          prepared.context.summary,
          null,
          game.sport === "NHL" ? live.sportImpact.allocation : null,
          prepared.progress,
          base.state.openingEvidence,
          trajectoryPolicy.collegeFinish
        );
      }
      if (trajectoryPolicy?.footballTransition && ["NFL", "CFB"].includes(game.sport)) {
        base = transitionFootballBase(core, game, prepared, base);
        live = candidateLiveSnapshot(
          core,
          { ...game, baseScore: base.baseScore, factors: base.factors },
          prepared.context.competition,
          prepared.context.summary
        );
      }
      const owned = trajectoryPolicy?.liveOwnership ? liveTrajectory(core, game, prepared, base, live, trajectoryPolicy) : null;
      const budget = trajectoryPolicy?.endgameAllocation && owned ? endgameFloorBudget(game, base, live, owned) : null;
      if (budget) {
        const originalLive = live;
        live = candidateLiveSnapshot(
          core,
          { ...game, baseScore: base.baseScore, factors: base.factors },
          prepared.context.competition,
          prepared.context.summary,
          budget
        );
        live = { ...live, endgameAllocation: {
          ...budget,
          originalFloor: originalLive.sportImpact.competitiveFloor,
          allocatedFloor: live.sportImpact.competitiveFloor,
          originalBonus: originalLive.bonus
        } };
      }
      const momentumPoints = owned?.momentumPoints ?? (Number(game.momentumPoints) || 0);
      const trajectoryScoring = owned?.trajectoryScoring ?? trajectoryAdjustment(prepared.trajectory, base.state.currentCloseness, trajectoryPolicy);
      const score = core.clampScore(base.baseScore + live.bonus + momentumPoints + trajectoryScoring.adjustment);
      return {
        score,
        trajectoryScoring,
        ...owned ? { historyOwnership: owned.historyOwnership } : {},
        baseScore: base.baseScore,
        liveBonus: live.bonus,
        momentumPoints,
        factors: base.factors,
        state: base.state,
        live,
        progress: prepared.progress,
        gap: prepared.gap,
        currentWinProbability: prepared.probability.probability,
        currentTensionPoints: base.state.currentTensionPoints,
        genericLeveragePoints: base.state.genericLeveragePoints,
        trajectory: prepared.trajectory,
        productionUnchanged: true
      };
    }
    function candidateGameRating(core, game, competition, summary, policy = null, trajectoryPolicy = null) {
      if (game.state !== "live") {
        return nonLiveCandidateRating(game, summary);
      }
      const prepared = prepareCandidateGameRating(core, game, competition, summary, trajectoryPolicy?.openingTransition);
      if (game._historicalEvidence) {
        prepared.historySummary = game._historicalEvidence.summary;
        prepared.trajectory = game._historicalEvidence.trajectory;
      }
      if (trajectoryPolicy?.footballTransition && ["NFL", "CFB"].includes(game.sport)) policy = { ...policy || DEFAULT_CURRENT_TENSION_POLICY, footballEvidence: { game } };
      if (trajectoryPolicy?.openingTransition && openingTransition.supports(game)) policy = { ...policy || DEFAULT_CURRENT_TENSION_POLICY, openingEvidence: { game } };
      const base = candidateBaseForPolicy(core, game, prepared, policy);
      const candidateGame = { ...game, baseScore: base.baseScore, factors: base.factors };
      const live = candidateLiveSnapshot(core, candidateGame, competition, summary);
      return finishCandidateGameRating(core, game, prepared, base, live, trajectoryPolicy, policy);
    }
    function candidateTrajectoryRatings(core, game, competition, summary, trajectoryPolicies = []) {
      if (game.state !== "live") return trajectoryPolicies.map(() => nonLiveCandidateRating(game, summary));
      const prepared = prepareCandidateGameRating(core, game, competition, summary);
      const base = candidateBaseForPolicy(core, game, prepared, null);
      const live = candidateLiveSnapshot(core, { ...game, baseScore: base.baseScore, factors: base.factors }, competition, summary);
      return trajectoryPolicies.map((policy) => finishCandidateGameRating(core, game, prepared, base, live, policy));
    }
    function candidateGameRatings(core, game, competition, summary, policies = []) {
      if (game.state !== "live") return policies.map(() => nonLiveCandidateRating(game, summary));
      const prepared = prepareCandidateGameRating(core, game, competition, summary);
      const bases = policies.map((policy) => candidateBaseForPolicy(core, game, prepared, policy));
      const liveByBase = /* @__PURE__ */ new Map();
      return bases.map((base) => {
        let live = liveByBase.get(base.baseScore);
        if (!live) {
          live = candidateLiveSnapshot(
            core,
            { ...game, baseScore: base.baseScore, factors: base.factors },
            competition,
            summary
          );
          liveByBase.set(base.baseScore, live);
        }
        return finishCandidateGameRating(core, game, prepared, base, live);
      });
    }
    module2.exports = {
      DEFAULT_CURRENT_TENSION_POLICY,
      CURRENT_TENSION_CEILING,
      GENERIC_LEVERAGE_CAP,
      GENERIC_LEVERAGE_START,
      GENERIC_LEVERAGE_SPAN,
      currentClosenessFor,
      candidateComponents,
      validateCurrentWinProbability,
      candidateStateRating,
      candidateLiveSnapshot,
      candidateGameRating,
      candidateTrajectoryRatings,
      candidateGameRatings
    };
  }
});

// scoring/live-evidence.cjs
var require_live_evidence = __commonJS({
  "scoring/live-evidence.cjs"(exports2, module2) {
    var { normalizedTime } = require_time();
    var { hockeyOnIceState, hockeyElapsed, hockeyPlayClockMode, hockeyOvertime } = require_nhl();
    var clone = (x) => JSON.parse(JSON.stringify(x));
    var identity = (g) => `${g.sport}:${g.id}:${(g.teams || []).map((t) => String(t[8])).sort().join(",")}`;
    var scores = (c) => Object.fromEntries((c?.competitors || []).map((t) => [String(t.team?.id || t.id), Number(t.score)]));
    var elapsed = (g, c) => normalizedTime(g.sport, c).elapsedSeconds;
    var lower = (a, b) => Object.keys(b || {}).some((id) => !Number.isFinite(a[id]) || a[id] < b[id]);
    function preserveLiveEvidence(game, previous) {
      if (game.state !== "live" || !previous || identity(game) !== identity(previous)) return;
      for (const key of ["verifiedLiveEvidence", "manpowerEvidence", "recoveredUnderdog"]) if (previous[key]) game[key] = clone(previous[key]);
      const prior = Object.fromEntries(previous.teams.map((t) => [String(t[8]), Number(t[2])])), current = Object.fromEntries(game.teams.map((t) => [String(t[8]), Number(t[2])]));
      if (lower(current, prior)) {
        delete game.verifiedLiveEvidence;
        delete game.manpowerEvidence;
        game.liveEvidenceReset = "score-correction";
      }
    }
    function compatible(game, c, e, now) {
      const t = elapsed(game, c), period = Number(c?.status?.period), regulation = { NFL: 4, CFB: 4, NBA: 4, NCAAB: 2, NHL: 3, Soccer: 2 }[game.sport] || 99;
      return e?.identity === identity(game) && now - e.observedAt >= 0 && now - e.observedAt <= 12e4 && t !== null && t >= e.elapsed && t - e.elapsed <= 120 && period >= e.period && period <= e.period + 1 && (period === e.period || period <= regulation) && !lower(scores(c), e.scores);
    }
    function compactPlay2(p) {
      return Object.fromEntries(["id", "sequenceNumber", "period", "clock", "homeScore", "awayScore", "text", "type", "scoringPlay", "team", "extraAttacker"].filter((k) => p[k] !== void 0).map((k) => [k, p[k]]));
    }
    function historicalSummary(summary) {
      const scoring = summary.scoringPlays?.length ? summary.scoringPlays : (summary.plays || []).filter((p) => p.scoringPlay);
      if (scoring.length > 100 || (summary.winprobability || []).length > 1024) return null;
      const plays = [...new Map([...scoring, ...(summary.plays || []).slice(-16)].map((p) => [String(p.id || JSON.stringify(p)), compactPlay2(p)])).values()];
      return { scoringPlays: scoring.map(compactPlay2), plays, winprobability: (summary.winprobability || []).map((p) => ({ homeWinPercentage: p.homeWinPercentage ?? p.homeWinProbability ?? p.homeWinPct ?? p.value })) };
    }
    function validLedger(summary, c, sport = "") {
      const totals = Object.fromEntries((c.competitors || []).map((t) => [t.homeAway, Number(t.score)]));
      let home = 0, away = 0;
      const scoring = summary.scoringPlays?.length ? summary.scoringPlays : (summary.plays || []).filter((p) => p.scoringPlay);
      const shootout = sport === "NHL" && hockeyOvertime(null, c, summary).shootout;
      for (const p of scoring) {
        if (shootout && Number(p.period?.number) > 4) continue;
        if (p.homeScore == null || p.awayScore == null) continue;
        const h = Number(p.homeScore), a = Number(p.awayScore);
        if (h < home || a < away || h > totals.home || a > totals.away) return false;
        home = h;
        away = a;
      }
      return true;
    }
    function historyFor(game, c, accepted, now = Date.now()) {
      const e = game.verifiedLiveEvidence;
      const incomplete = e?.summary?.scoringPlays?.length && !accepted?.scoringPlays?.length && (accepted?.plays || []).filter((p) => p.scoringPlay).length < e.summary.scoringPlays.length;
      if (accepted && !incomplete && (accepted.scoringPlays?.length || accepted.plays?.length || accepted.winprobability?.length)) return null;
      if (!compatible(game, c, e, now)) {
        delete game.verifiedLiveEvidence;
        return null;
      }
      return { summary: { ...clone(e.summary), header: { competitions: [c] } }, trajectory: clone(e.trajectory) };
    }
    function rememberHistory(game, c, summary, result, now = Date.now()) {
      if (!summary || !(summary.scoringPlays?.length || summary.plays?.length || summary.winprobability?.length)) return;
      if (!validLedger(summary, c, game.sport)) {
        delete game.verifiedLiveEvidence;
        return;
      }
      const compact = historicalSummary(summary), t = elapsed(game, c);
      if (!compact || t === null) return;
      const evidence = { identity: identity(game), observedAt: now, elapsed: t, period: Number(c.status?.period), scores: scores(c), summary: compact, trajectory: result.trajectory };
      if (JSON.stringify(evidence).length <= 24e3) game.verifiedLiveEvidence = evidence;
      else delete game.verifiedLiveEvidence;
    }
    function currentManpower(game, c, accepted, now = Date.now()) {
      if (game.sport !== "NHL") return accepted;
      const previous = game.manpowerEvidence, t = elapsed(game, c), period = Number(c.status?.period), current = scores(c);
      const sameScores = previous && Object.keys(current).length === Object.keys(previous.scores).length && Object.keys(current).every((id) => current[id] === previous.scores[id]);
      const goalieBlocks = accepted?.boxscore?.players?.filter((b) => (b.statistics || []).some((s) => /goalie/i.test(s.name || s.displayName || "")));
      let effective = accepted;
      if (accepted?.onIce?.length === 2 && !goalieBlocks?.length && previous && sameScores && period === previous.period && now - previous.observedAt <= 12e4)
        effective = { ...accepted, boxscore: { ...accepted.boxscore, players: previous.goalies } };
      const state = effective && hockeyOnIceState(effective, game.teams);
      const known = state?.sides?.length === 2 && new Set(state.sides.map((s) => s.id)).size === 2 && state.sides.every((s) => s.goalieKnown && s.count >= 4 && s.count <= 7 && game.teams.some((t2) => String(t2[8]) === s.id));
      if (known) {
        const mode2 = hockeyPlayClockMode(effective), penalties = (effective.plays || []).filter((p) => Number(p.type?.penaltyMinutes) > 0);
        const expires = penalties.map((p) => ({ p, time: hockeyElapsed({ period: p.period?.number, displayClock: p.clock?.displayValue, clockMode: mode2 }, false) })).filter((x) => x.time !== null && x.time <= t && t < x.time + Number(x.p.type.penaltyMinutes) * 60 && String(x.p.team?.id) !== state.powerPlayTeamId).reduce((end, x) => Math.max(end, x.time + Number(x.p.type.penaltyMinutes) * 60), t + 15);
        const goalies = (effective.boxscore?.players || []).map((b) => ({ team: { id: b.team?.id }, statistics: (b.statistics || []).filter((s) => /goalie/i.test(s.name || s.displayName || "")).map((s) => ({ name: s.name, athletes: (s.athletes || []).map((a) => ({ athlete: { id: a.athlete?.id || a.athleteid || a.athleteId } })) })) }));
        const onIce = effective.onIce.map((s) => ({ teamId: s.teamId || s.team?.id, entries: (s.entries || []).map((e) => ({ athleteid: e.athleteid || e.athleteId || e.athlete?.id })) }));
        game.manpowerEvidence = {
          identity: identity(game),
          observedAt: now,
          elapsed: t,
          period,
          scores: current,
          onIce,
          goalies,
          powerPlay: Boolean(state.powerPlayTeamId),
          expires,
          playIds: (effective.plays || []).slice(-16).map((p) => String(p.id))
        };
        return effective;
      }
      if (!previous || !previous.powerPlay || !compatible(game, c, previous, now) || !sameScores || period !== previous.period || t >= previous.expires || now - previous.observedAt > 12e4) {
        delete game.manpowerEvidence;
        return accepted;
      }
      const mode = hockeyPlayClockMode(accepted || {});
      const fresh = (accepted?.plays || []).filter((p) => {
        const at = hockeyElapsed({ period: p.period?.number, displayClock: p.clock?.displayValue, clockMode: mode }, false);
        return !previous.playIds.includes(String(p.id)) && at !== null && at >= previous.elapsed && at <= t;
      });
      if (fresh.some((p) => Number(p.type?.penaltyMinutes) > 0 || /penalty (?:end|expir)|penalty[- ]over/i.test(p.type?.text || p.text || "") || /shot|goal|save/i.test(p.type?.text || "") && /even.strength|short.handed/i.test(p.strength?.text || ""))) {
        delete game.manpowerEvidence;
        return accepted;
      }
      game.manpowerRetained = true;
      return { ...accepted, header: accepted?.header || { competitions: [c] }, onIce: clone(previous.onIce), boxscore: { ...accepted?.boxscore, players: clone(previous.goalies) } };
    }
    module2.exports = { preserveLiveEvidence, historyFor, rememberHistory, currentManpower, validLedger };
  }
});

// scoring/basketball-state.cjs
var require_basketball_state = __commonJS({
  "scoring/basketball-state.cjs"(exports2, module2) {
    var { normalizedTime } = require_time();
    var { normalizeWinProbability } = require_probability();
    var clone = (x) => JSON.parse(JSON.stringify(x));
    var supports = (g) => ["NCAAB", "NBA"].includes(g.sport);
    var identity = (g) => `${g.sport}:${g.id}:${g.teams.map((t) => String(t[8])).sort().join(",")}`;
    var position = (g, c) => normalizedTime(g.sport, c).elapsedSeconds;
    var seq = (p, eventId = "") => {
      const id = String(p?.id || "");
      return String(p?.sequenceNumber || (eventId && id.startsWith(String(eventId)) ? id.slice(String(eventId).length) : id)).replace(/^0+/, "");
    };
    var compare = (a, b) => a.length - b.length || a.localeCompare(b);
    var scoreMap = (c) => Object.fromEntries((c?.competitors || []).map((t) => [String(t.team?.id || t.id), Number(t.score)]));
    var sameScores = (a, b) => Object.keys(a).length === 2 && Object.keys(b).length === 2 && Object.keys(a).every((id) => a[id] === b[id]);
    var fingerprint = (c) => {
      const { lastPlay, ...situation } = c.situation || {};
      return JSON.stringify({
        period: c.status?.period,
        clock: c.status?.displayClock,
        teams: (c.competitors || []).map((t) => [t.team?.id, t.score, t.possession, t.fouls, t.timeoutsRemaining]),
        situation,
        lastPlay: lastPlay ? { id: lastPlay.id, type: lastPlay.type?.text, text: lastPlay.text, team: lastPlay.team?.id, scoreValue: lastPlay.scoreValue } : null
      });
    };
    function compactCompetition(c) {
      return clone({ status: c.status, situation: c.situation, competitors: (c.competitors || []).map((t) => ({ team: { id: t.team?.id, displayName: t.team?.displayName }, homeAway: t.homeAway, score: t.score, possession: t.possession, fouls: t.fouls, timeoutsRemaining: t.timeoutsRemaining })) });
    }
    function preserveBasketballState(game, previous) {
      if (supports(game) && game.state === "live" && previous?.basketballEvidence?.identity === identity(game)) {
        game.basketballEvidence = clone(previous.basketballEvidence);
        if (previous.recoveredCollegeUnderdog) game.recoveredCollegeUnderdog = clone(previous.recoveredCollegeUnderdog);
      }
    }
    function reconcileBasketball(game, c, summary) {
      if (!supports(game) || game.state !== "live" || !c) return { competition: c, summary };
      let e = game.basketballEvidence;
      if (e?.identity !== identity(game)) e = null;
      const prior = e?.competition, at = position(game, c), before = prior && position(game, prior);
      const nextId = seq(c.situation?.lastPlay, game.id), priorId = seq(prior?.situation?.lastPlay, game.id);
      const olderEvent = nextId && priorId && compare(nextId, priorId) < 0;
      const newerEvent = nextId && priorId && compare(nextId, priorId) > 0;
      const backward = at !== null && before !== null && at < before;
      const lowerScore = prior && Object.keys(scoreMap(c)).some((id) => scoreMap(c)[id] < scoreMap(prior)[id]);
      const corroboratedCorrection = summary?.header?.competitions?.[0] && sameScores(scoreMap(summary.header.competitions[0]), scoreMap(c));
      const explicitScoreCorrection = lowerScore && corroboratedCorrection && at !== null && before !== null && Math.abs(at - before) <= 2;
      const stale = prior && (olderEvent && !explicitScoreCorrection || backward && before - at > 2 && !newerEvent || lowerScore && !newerEvent && !corroboratedCorrection);
      if (stale) {
        c = { ...c, ...clone(prior) };
        game.basketballUpdateRejected = true;
      } else delete game.basketballUpdateRejected;
      const explicitPossession = Object.prototype.hasOwnProperty.call(c.situation || {}, "possession");
      const totals = scoreMap(c), oldTotals = scoreMap(prior), unchanged = sameScores(totals, oldTotals);
      const corrected = prior && Object.keys(totals).some((id) => totals[id] < oldTotals[id]);
      if (prior && unchanged && !newerEvent && Math.abs((position(game, c) ?? 0) - (before ?? 0)) <= 2) {
        c = { ...c, situation: { ...prior.situation, ...c.situation } };
        const oldPlay = prior.situation?.lastPlay, newPlay = c.situation?.lastPlay;
        if (oldPlay?.id && String(oldPlay.id) === String(newPlay?.id)) c.situation.lastPlay = { ...oldPlay, ...newPlay, type: { ...oldPlay.type, ...newPlay.type } };
        c.competitors = c.competitors.map((t) => ({ ...prior.competitors.find((p) => String(p.team?.id) === String(t.team?.id)), ...t }));
      }
      const holders = (c.competitors || []).filter((t) => t.possession === true);
      if (!explicitPossession && holders.length === 1) c = { ...c, situation: { ...c.situation, possession: String(holders[0].team?.id || holders[0].id) } };
      const header = summary?.header?.competitions?.[0];
      const headerMatches = header && sameScores(scoreMap(header), totals) && Number(header.status?.period) === Number(c.status?.period) && Math.abs((position(game, header) ?? -9999) - (position(game, c) ?? 0)) <= 2;
      const ids = new Set(Object.keys(totals));
      const compatibleHeader = header && (header.competitors || []).length === 2 && header.competitors.every((t) => ids.has(String(t.team?.id || t.id)));
      const currentKey = fingerprint(c);
      const playerPoints = new Map((e?.playerPoints || []).map((p) => [p.id, p]));
      if (headerMatches && !stale) for (const block of summary?.boxscore?.players || []) for (const group of block.statistics || []) {
        const index = (group.labels || []).findIndex((l) => /^PTS$|^POINTS$/i.test(l));
        if (index < 0) continue;
        for (const player of group.athletes || []) {
          const value = player.stats?.[index], points = Number(value), id = player.athlete?.id;
          if (id && value != null && value !== "" && Number.isFinite(points)) playerPoints.set(String(id), { id: String(id), name: player.athlete.displayName, points });
        }
      }
      const previousPlays = corrected ? (e?.plays || []).filter((p) => withinScore(p, c)) : e?.plays || [];
      const incoming = compatibleHeader && !stale ? [...summary?.scoringPlays || [], ...summary?.plays || []] : [];
      const playsById = new Map(previousPlays.map((p) => [String(p.id), p]));
      const end = position(game, c);
      for (const p of incoming) {
        const time2 = position(game, { status: { period: p.period?.number, displayClock: p.clock?.displayValue } });
        if (p.id == null || time2 === null || end === null || time2 > end + 2 || !withinScore(p, c)) continue;
        if (playsById.has(String(p.id)) && !headerMatches) continue;
        playsById.set(String(p.id), { ...playsById.get(String(p.id)), ...compactPlay2(p) });
      }
      let home = 0, away = 0;
      const playTime = (p) => position(game, { status: { period: p.period?.number, displayClock: p.clock?.displayValue } }) ?? 0;
      const plays = [...playsById.values()].sort((a, b) => playTime(a) - playTime(b) || (Date.parse(a.wallclock || "") - Date.parse(b.wallclock || "") || compare(seq(a, game.id), seq(b, game.id)))).filter((p) => {
        if (p.homeScore == null || p.awayScore == null) return true;
        if (Number(p.homeScore) < home || Number(p.awayScore) < away) return false;
        home = Number(p.homeScore);
        away = Number(p.awayScore);
        return true;
      });
      const known = new Set(plays.map((p) => String(p.id)));
      const priorById = new Map((e?.plays || []).map((p) => [String(p.id), p]));
      const changedScoreIds = new Set(plays.filter((p) => {
        const old = priorById.get(String(p.id));
        return old && (old.homeScore !== p.homeScore || old.awayScore !== p.awayScore);
      }).map((p) => String(p.id)));
      const probabilities = new Map((e?.probabilities || []).filter((p) => known.has(String(p.playId)) && !changedScoreIds.has(String(p.playId))).map((p) => [String(p.playId), p]));
      if (compatibleHeader && !stale) for (const p of summary?.winprobability || []) {
        const probability = normalizeWinProbability(p.homeWinPercentage ?? p.homeWinProbability ?? p.homeWinPct ?? p.value);
        if (known.has(String(p.playId)) && probability !== null) probabilities.set(String(p.playId), { playId: p.playId, homeWinPercentage: probability });
      }
      const orderedProbabilities = plays.flatMap((p) => probabilities.has(String(p.id)) ? [probabilities.get(String(p.id))] : []);
      const historical = { header: { competitions: [c] }, plays, scoringPlays: plays.filter((p) => p.scoringPlay), winprobability: orderedProbabilities };
      const last = orderedProbabilities.at(-1), lastPlay = last && plays.find((p) => String(p.id) === String(last.playId));
      const currentProbability = headerMatches && lastPlay && withinScore(lastPlay, c) && Number(lastPlay.homeScore) === Number(c.competitors.find((t) => t.homeAway === "home")?.score) && Number(lastPlay.awayScore) === Number(c.competitors.find((t) => t.homeAway === "away")?.score) && (!nextId || compare(seq(lastPlay, game.id), nextId) >= 0);
      let current = headerMatches ? { ...summary, header: { ...summary.header, competitions: [c] }, plays, scoringPlays: historical.scoringPlays, winprobability: currentProbability ? orderedProbabilities : [] } : null;
      const correctedClockOnly = prior && unchanged && !newerEvent && !olderEvent && Math.abs((position(game, c) ?? 0) - (before ?? 0)) <= 2 && fingerprint({ ...c, status: { ...c.status, displayClock: prior.status?.displayClock } }) === e.currentKey;
      if (!currentProbability && (e?.currentKey === currentKey || correctedClockOnly) && e.currentProbability) {
        current = { ...current, header: { competitions: [c] }, plays, scoringPlays: historical.scoringPlays, winprobability: clone(e.currentProbability) };
      }
      if (playerPoints.size) {
        current = { ...current, header: current?.header || { competitions: [c] }, boxscore: { ...current?.boxscore, players: [{ statistics: [{ labels: ["PTS"], athletes: [...playerPoints.values()].map((p) => ({ athlete: { id: p.id, displayName: p.name }, stats: [String(p.points)] })) }] }] } };
      }
      const evidence = {
        identity: identity(game),
        competition: compactCompetition(c),
        plays,
        probabilities: orderedProbabilities,
        currentKey,
        playerPoints: [...playerPoints.values()],
        currentProbability: current?.winprobability?.length ? current.winprobability : null
      };
      if (plays.length <= 3e3 && JSON.stringify(evidence).length <= 75e4) game.basketballEvidence = evidence;
      game.basketballFacts = basketballFacts(plays, c, game.sport);
      game.historicalEvidenceRetained = Boolean(e?.plays?.length && (!headerMatches || incoming.length < e.plays.length));
      game.liveRawStatus = c.status;
      game.liveRawSituation = c.situation;
      game.teams.forEach((t) => {
        if (Number.isFinite(totals[String(t[8])])) t[2] = String(totals[String(t[8])]);
      });
      delete game.summaryState;
      return { competition: c, summary: current, history: historical, rawCurrent: Boolean(headerMatches && !stale) };
    }
    function withinScore(p, c) {
      const home = Number(c.competitors?.find((t) => t.homeAway === "home")?.score), away = Number(c.competitors?.find((t) => t.homeAway === "away")?.score);
      return (p.homeScore == null || Number(p.homeScore) <= home) && (p.awayScore == null || Number(p.awayScore) <= away);
    }
    function compactPlay2(p) {
      return Object.fromEntries(["id", "sequenceNumber", "period", "clock", "homeScore", "awayScore", "text", "type", "scoringPlay", "team", "wallclock"].filter((k) => p[k] !== void 0).map((k) => [k, p[k]]));
    }
    function basketballFacts(plays, c, sport) {
      const deepest = { home: 0, away: 0 };
      let comeback = null, leader = 0, lateLeadChanges = 0;
      for (const p of plays.filter((p2) => p2.scoringPlay)) {
        const margin = Number(p.homeScore) - Number(p.awayScore);
        deepest.home = Math.max(deepest.home, -margin);
        deepest.away = Math.max(deepest.away, margin);
        for (const side of ["home", "away"]) if (deepest[side] >= 8 && (side === "home" ? margin >= 0 : margin <= 0) && (!comeback || deepest[side] > comeback.deficit))
          comeback = { team: c.competitors.find((t) => t.homeAway === side)?.team?.displayName, deficit: deepest[side] };
        const sign = Math.sign(margin), clock = String(p.clock?.displayValue || "").split(":").map(Number), remaining = clock[0] * 60 + clock[1];
        if (sign && leader && sign !== leader && Number(p.period?.number) >= (sport === "NBA" ? 4 : 2) && remaining <= 300) lateLeadChanges++;
        if (sign) leader = sign;
      }
      return { comeback, lateLeadChanges };
    }
    module2.exports = { supports, preserveBasketballState, reconcileBasketball };
  }
});

// scoring/detail-state.cjs
var require_detail_state = __commonJS({
  "scoring/detail-state.cjs"(exports2, module2) {
    function canonicalDetailSummary(game, summary) {
      if (!summary || !["NBA", "NCAAB"].includes(game.sport)) return summary;
      const byId = new Map(game.teams.map((t) => [String(t[8]), String(t[2])]));
      let mismatch = false;
      const competition = summary.header?.competitions?.[0];
      const competitors = (competition?.competitors || []).map((t) => {
        const score = byId.get(String(t.team?.id));
        if (score === void 0) return t;
        const lines = t.linescores || [], sum = lines.reduce((n, l) => n + Number(l.displayValue ?? l.value), 0);
        if (String(t.score) !== score || lines.length && sum !== Number(score)) mismatch = true;
        return { ...t, score, linescores: lines.length && sum === Number(score) ? lines : [] };
      });
      const teams = summary.basketballBoxScore?.teams?.map((t) => {
        const score = byId.get(String(t.teamId));
        if (score === void 0) return t;
        if (t.totals?.points != null && String(t.totals.points) !== score) mismatch = true;
        const periods = t.periods || [], sum = periods.reduce((n, p) => n + Number(p.value), 0);
        return { ...t, totals: { ...t.totals, points: score }, periods: sum === Number(score) ? periods : [] };
      });
      return {
        ...summary,
        header: { ...summary.header, competitions: [{ ...competition, competitors, status: game.liveRawStatus || competition?.status }] },
        ...teams ? { basketballBoxScore: { ...summary.basketballBoxScore, teams } } : {},
        sportsRadarFreshness: { ...summary.sportsRadarFreshness, statsPending: mismatch }
      };
    }
    module2.exports = { canonicalDetailSummary };
  }
});

// scoring/football-market.cjs
var require_football_market = __commonJS({
  "scoring/football-market.cjs"(exports2, module2) {
    var { parseLine: parseLine2 } = require_market();
    var MAX_QUOTE_AGE_MS = 48 * 36e5;
    var supports = (game) => ["NFL", "CFB"].includes(game.sport) && game.state === "upcoming";
    var timestamp = (value) => value == null || value === "" ? null : typeof value === "number" && Number.isFinite(value) ? value : Date.parse(value);
    function eligibility(raw, game, asOf, observedAt = null) {
      if (!raw) return { eligible: false, reason: "missing" };
      const listed = raw.close || raw.closing || raw;
      const type = [raw.type?.name || raw.type, listed.type?.name || listed.type, raw.marketType, raw.description].filter(Boolean).join(" ");
      if (raw.live === true || raw.isLive === true || listed.live === true || listed.isLive === true || /\blive\b|in[ -]?play/i.test(type))
        return { eligible: false, reason: "live" };
      const value = listed.lastUpdated ?? listed.lastModified ?? raw.lastUpdated ?? raw.lastModified;
      const quotedAt = timestamp(value), start = timestamp(game.startTime || game.sourceEvent?.date);
      if (value != null && value !== "" && !Number.isFinite(quotedAt)) return { eligible: false, reason: "invalid timestamp" };
      if (Number.isFinite(quotedAt) && Number.isFinite(start) && quotedAt > start) return { eligible: false, reason: "after kickoff" };
      const now = timestamp(asOf), at = Number.isFinite(quotedAt) ? quotedAt : timestamp(observedAt);
      if (Number.isFinite(at) && Number.isFinite(now)) {
        if (at > now + 5 * 6e4) return { eligible: false, reason: "future timestamp" };
        if (now - at > MAX_QUOTE_AGE_MS) return { eligible: false, reason: "stale" };
      }
      return { eligible: true, reason: quotedAt == null ? "untimestamped" : "current", quotedAt: Number.isFinite(quotedAt) ? quotedAt : null };
    }
    var sameGame = (a, b) => b && a.sport === b.sport && String(a.id) === String(b.id) && a.startTime === b.startTime && a.teams.map((t) => String(t[8])).sort().join("|") === b.teams?.map((t) => String(t[8])).sort().join("|");
    function fromDisplayedLine(line, competition) {
      if (!line || !line.spread && line.total == null) return null;
      const raw = { details: line.spread || "", overUnder: line.total, provider: { name: line.provider || "" } };
      const favorite = String(line.spread || "").match(/^(.+?)\s+-\d+(?:\.\d+)?$/)?.[1];
      const side = (competition?.competitors || []).find((t) => [t.team?.abbreviation, t.team?.displayName].includes(favorite))?.homeAway;
      if (side) {
        raw[`${side}TeamOdds`] = { favorite: true, underdog: false };
        raw[`${side === "home" ? "away" : "home"}TeamOdds`] = { favorite: false, underdog: true };
      }
      if (line.lastUpdated != null) raw.lastUpdated = line.lastUpdated;
      return raw;
    }
    function prepareUpcomingMarket(game, competition, summary = null, previous = null, asOf = game.marketAsOf, previousObservedAt = null) {
      if (!supports(game)) return competition;
      if (asOf != null) Object.defineProperty(game, "marketAsOf", { value: asOf, writable: true, configurable: true, enumerable: false });
      const now = timestamp(game.marketAsOf), prior = sameGame(game, previous) && previous.state === "upcoming" ? previous : null;
      const retained = prior?.pregameMarketQuote || game.pregameMarketQuote;
      const candidates = [
        ...competition?.odds || [],
        ...summary?.pickcenter || [],
        ...summary?.header?.competitions?.[0]?.odds || [],
        ...summary?.odds || []
      ];
      let selected = null;
      for (const raw of candidates) {
        if (eligibility(raw, game, now).eligible && parseLine2(raw, competition, game.sport)) {
          const unchanged = retained?.source === "provider" && JSON.stringify(raw) === JSON.stringify(retained.raw);
          const observedAt = unchanged && Number.isFinite(retained.observedAt) ? Number.isFinite(now) ? Math.min(retained.observedAt, now) : retained.observedAt : Number.isFinite(now) ? now : null;
          selected = { raw, observedAt, source: "provider" };
          break;
        }
      }
      const retainedAt = prior && retained?.source === "provider" ? timestamp(previousObservedAt) ?? timestamp(prior.marketAsOf) ?? retained.observedAt : retained?.observedAt;
      if (!selected && retained && eligibility(retained.raw, game, now, retainedAt).eligible && parseLine2(retained.raw, competition, game.sport))
        selected = { ...retained, observedAt: retainedAt, source: retained.source === "provider" ? "retained provider market" : retained.source };
      if (!selected && !retained && prior) {
        const raw = fromDisplayedLine(prior.line, competition);
        if (eligibility(raw, game, now, prior.marketAsOf).eligible && parseLine2(raw, competition, game.sport))
          selected = { raw, observedAt: timestamp(prior.marketAsOf) ?? (Number.isFinite(now) ? now : null), source: "retained displayed market" };
      }
      game.pregameMarketQuote = selected;
      game.line = selected ? parseLine2(selected.raw, competition, game.sport) : null;
      return { ...competition, odds: selected ? [selected.raw] : [], sportsRadarPregameMarketManaged: true };
    }
    module2.exports = { MAX_QUOTE_AGE_MS, eligibility, prepareUpcomingMarket, supports };
  }
});

// scoring/football-live.cjs
var require_football_live = __commonJS({
  "scoring/football-live.cjs"(exports2, module2) {
    var { footballPregameSpread, numberFromLine } = require_market();
    var { rankFor: rankFor2 } = require_records();
    var { eventPosition: eventPosition2 } = require_time();
    var { eligibility } = require_football_market();
    var unit = (x) => Math.max(0, Math.min(1, Number(x) || 0));
    var smooth = (x) => {
      x = unit(x);
      return x * x * (3 - 2 * x);
    };
    var id = (t) => String(t?.team?.id || t?.id || "");
    var numeric = (x) => x == null || x === "" || typeof x === "boolean" ? null : numberFromLine(x);
    var priceProbability = (x) => x > 0 ? 100 / (100 + x) : x < 0 ? -x / (100 - x) : null;
    function pregameMarket(game, competition, raw = competition?.odds?.[0]) {
      const teams = competition?.competitors || [];
      if (teams.length !== 2 || !raw) return null;
      const odds = raw.close || raw.closing || raw;
      if (raw.live === true || raw.isLive === true || /live|in.?play/i.test(String(raw.type || odds.type || ""))) return null;
      const start = Date.parse(game.startTime || game.sourceEvent?.date || "");
      const at = Date.parse(odds.lastUpdated || odds.lastModified || raw.lastUpdated || "");
      if (game.state === "upcoming") {
        if (!eligibility(raw, game, game.marketAsOf).eligible) return null;
      } else if (Number.isFinite(start) && Number.isFinite(at) && (at > start || start - at > 48 * 36e5)) return null;
      const spread = footballPregameSpread({ odds: [raw] });
      const sides = teams.map((t) => {
        const side = t.homeAway, data = odds[`${side}TeamOdds`] || {};
        const line = numeric(odds.pointSpread?.[side]?.close?.line ?? odds.pointSpread?.[side]?.open?.line);
        const money = numeric(odds.moneyline?.[side]?.close?.odds ?? odds.moneyline?.[side]?.open?.odds ?? data.moneyLine ?? data.moneyline);
        return { team: t, line, money, dog: data.underdog === true || data.favorite === false };
      });
      let dog = sides.find((s) => s.line > 0) || sides.find((s) => s.dog);
      if (!dog) {
        const named = String(odds.details || "").match(/^(.+?)\s+([+-])\d/);
        const favorite = named?.[2] === "-" && sides.find((s) => [s.team.team?.abbreviation, s.team.team?.displayName, s.team.team?.shortDisplayName].includes(named[1]));
        if (favorite) dog = sides.find((s) => s !== favorite);
      }
      if (!dog) dog = sides.find((s) => s.money > 100 && sides.some((o) => o !== s && o.money < 0));
      if (!dog || !id(dog.team)) return null;
      const probabilities = sides.map((s) => priceProbability(s.money));
      const probability = probabilities.every((p) => p !== null) ? probabilities[sides.indexOf(dog)] / probabilities.reduce((a, b) => a + b, 0) : null;
      const value = dog.line > 0 ? dog.line : spread;
      if (!(value > 0) && !(probability !== null && probability < 0.5)) return null;
      return {
        teamId: id(dog.team),
        teamName: dog.team.team?.displayName || "The underdog",
        side: dog.team.homeAway,
        spread: value,
        probability,
        source: "pregame market",
        reportedAt: Number.isFinite(at) ? at : null
      };
    }
    function rankedExpectation(game, competition) {
      if (game.sport !== "CFB") return null;
      const teams = competition?.competitors || [];
      if (teams.length !== 2) return null;
      const ranks = teams.map((t) => rankFor2(t, "CFB"));
      const favorite = ranks[0] && (!ranks[1] || ranks[0] < ranks[1]) ? 0 : ranks[1] && (!ranks[0] || ranks[1] < ranks[0]) ? 1 : -1;
      if (favorite < 0) return null;
      const dog = teams[1 - favorite];
      return {
        teamId: id(dog),
        teamName: dog.team?.displayName || "The unranked opponent",
        side: dog.homeAway,
        spread: null,
        probability: null,
        rankStrength: (26 - ranks[favorite]) / 25 * unit(((ranks[1 - favorite] || 35) - ranks[favorite]) / 25),
        source: "rankings"
      };
    }
    function liveSurprise(core, game, competition, summary, historySummary = summary) {
      const market = game.livePregameMarket || pregameMarket(game, competition) || rankedExpectation(game, competition);
      const zero = { points: 0, text: "", market, rawPoints: 0, overlap: 0 };
      if (!market || game.state !== "live") return zero;
      const dog = game.teams.find((t) => String(t[8]) === market.teamId), other = game.teams.find((t) => t !== dog);
      if (!dog || !other || [dog[2], other[2]].some((x) => x == null || x === "" || !Number.isFinite(Number(x)))) return zero;
      const margin = Number(dog[2]) - Number(other[2]);
      const p = unit(core.gameProgress(game.sport, competition));
      const spreadStrength = market.spread == null ? 0 : 1 - Math.exp(-Math.pow(market.spread / (game.sport === "CFB" ? 18 : 9), 1.7));
      const probabilityStrength = market.probability == null ? 0 : smooth((0.5 - market.probability) / 0.45);
      const strength = Math.max(spreadStrength, probabilityStrength, 0.55 * (market.rankStrength || 0));
      const reversal = 1 - Math.exp(-(Math.max(0, margin) + (market.spread || 0) * p) / 14);
      const threat = margin > 0 ? 0.35 + 0.65 * (1 - Math.exp(-margin / 7)) : smooth((p - 0.5) / 0.4) * Math.exp(-Math.pow(Math.abs(margin) / 7, 1.6)) * 0.65;
      const viability = margin < 0 ? core.footballLiveCloseness(game.sport, -margin, p, competition).comebackFeasibility : 1;
      let sustained = 0;
      const moments = (summary?.scoringPlays || []).map((play) => ({ play, pos: eventPosition2(game.sport, { status: { period: play.period?.number, displayClock: play.clock?.displayValue } }) }));
      let valid = moments.length > 0, prior = { home: 0, away: 0, pos: 0 }, leadSince = null;
      for (const { play, pos } of moments) {
        const home = numeric(play.homeScore), away = numeric(play.awayScore);
        if (home === null || away === null || pos === null || pos > p + 1e-8 || pos < prior.pos || home < prior.home || away < prior.away || home > prior.home && away > prior.away || home === prior.home && away === prior.away) {
          valid = false;
          break;
        }
        const leading = market.side === "home" ? home > away : away > home;
        leadSince = leading ? leadSince ?? pos : null;
        prior = { home, away, pos };
      }
      const scores = Object.fromEntries((competition?.competitors || []).map((t) => [t.homeAway, Number(t.score)]));
      if (valid && prior.home === scores.home && prior.away === scores.away && leadSince !== null) sustained = unit((p - leadSince) / 0.25);
      const wp = core.winProbabilityImpact(summary, p, "live", game.sport);
      const current = wp.probability == null ? null : market.side === "home" ? wp.probability : 1 - wp.probability;
      const probabilityGain = current === null || market.probability == null ? 0 : unit((current - market.probability) / 0.65);
      const cap = game.sport === "CFB" ? 30 : 22;
      const rawPoints = cap * strength * threat * viability * (0.2 + 0.8 * smooth(p / 0.8)) * (0.7 + 0.3 * reversal) * (1 + 0.08 * sustained + 0.05 * probabilityGain);
      const history = core.momentumImpact(game.sport, historySummary, p, "live");
      const correlated = (history.factors || []).filter((f) => /comeback|erased.*deficit|lead change|unanswered|win.chance|win.probability/i.test(f.label)).reduce((sum, f) => sum + Math.max(0, f.points), 0);
      const overlap = Math.min(0.35 * rawPoints, 0.22 * correlated);
      const points = Math.round(Math.min(cap, Math.max(0, rawPoints - overlap)));
      const description = market.spread ? `${market.spread}-point underdog` : market.probability != null ? "pregame moneyline underdog" : "lower-ranked opponent";
      return {
        points,
        rawPoints,
        overlap,
        market,
        margin,
        progress: p,
        sustained,
        probabilityGain,
        text: points ? `${market.teamName}, a ${description}, ${margin > 0 ? "leads" : margin === 0 ? "is tied" : "remains within one score"} ${dog[2]}\u2013${other[2]}` : ""
      };
    }
    var uncertain = /\b(?:may|might|could|questionable|doubtful|possible|possibly|reportedly|appears?|suspected|not ruled out|not injured|expected to|will return|set to return)\b/i;
    function confirmedDevelopment(text) {
      if (!text || uncertain.test(text)) return null;
      const quarterback = /\bquarterback\b|\bQB\b/i.test(text);
      const major = quarterback || /\bstar\b|all.pro|all.american|leading (?:rusher|receiver)|head coach|Heisman|MVP/i.test(text);
      if (!major) return null;
      const returned = /\b(?:returns? to (?:the )?(?:game|field|lineup)|returns? after|back in (?:the )?game|has returned)\b/i.test(text);
      const out = /\b(?:ruled out|will not return|won't return|ejected|suspended)\b/i.test(text);
      const injured = /\b(?:injured|injury|fractured|torn|concussion)\b/i.test(text) && /\b(?:leaves?|left|exits?|exited|suffers?|suffered|sustains?|sustained|injured|replaced)\b/i.test(text);
      const replacement = /\b(?:replaced by|replaces|takes over for)\b/i.test(text);
      const coaching = /head coach/i.test(text) && /\b(?:fired|dismissed|takes over|replaced by)\b/i.test(text);
      if (!returned && !out && !injured && !replacement && !coaching) return null;
      return {
        kind: returned ? "return" : /ejected/i.test(text) ? "ejection" : /suspended/i.test(text) ? "suspension" : coaching ? "coaching" : "injury",
        status: returned ? "returned" : out ? "out" : replacement ? "replaced" : "left",
        quarterback,
        text
      };
    }
    function mergeDevelopments(game, summary, previous = null) {
      if (!["NFL", "CFB"].includes(game.sport) || game.state === "upcoming") return [];
      const same = previous && previous.sport === game.sport && String(previous.id) === String(game.id);
      const retained = [...game.verifiedDevelopments || [], ...same ? previous.verifiedDevelopments || [] : []];
      const map = /* @__PURE__ */ new Map();
      const keep = (item) => {
        if (item?.verified !== true || item.eventId !== String(game.id) || !confirmedDevelopment(item.evidenceText || item.text) || !Number.isFinite(item.position)) return;
        const old = map.get(item.subjectKey);
        if (!old || item.position > old.position || item.position === old.position && item.reportedAt > old.reportedAt) map.set(item.subjectKey, item);
      };
      retained.forEach(keep);
      const start = Date.parse(game.startTime || game.sourceEvent?.date || "");
      const p = eventPosition2(game.sport, { status: game.liveRawStatus || game.sourceCompetition?.status });
      const articles = summary?.news?.articles || [];
      for (const article of articles) {
        const text = String(article.headline || "").trim();
        const evidenceText = [text, String(article.description || "").trim()].filter(Boolean).join(". ");
        const evidence = confirmedDevelopment(evidenceText);
        const reportedAt = Date.parse(article.published || "");
        if (!evidence || !Number.isFinite(start) || !Number.isFinite(reportedAt) || reportedAt < start || reportedAt > start + 8 * 36e5 || p === null) continue;
        const categories = article.categories || [];
        const eventMatch = categories.some((c) => c.type === "event" && String(c.eventId || c.event?.id) === String(game.id));
        const matchedTeams = game.teams.filter((t) => categories.some((c) => c.type === "team" && String(c.teamId || c.team?.id) === String(t[8])));
        const opponentNamed = game.teams.some((t) => !matchedTeams.includes(t) && [t[0], t[7]].filter(Boolean).some((n) => evidenceText.toLowerCase().includes(n.toLowerCase())));
        if (!eventMatch && !(matchedTeams.length === 1 && opponentNamed)) continue;
        const url = article.links?.web?.href || "";
        try {
          if (!/(^|\.)espn\.com$/i.test(new URL(url).hostname)) continue;
        } catch {
          continue;
        }
        const team = matchedTeams.length === 1 ? matchedTeams[0] : game.teams.find((t) => text.includes(t[0]));
        const name = text.match(/\b([A-Z][a-zA-Z'’-]+\s+[A-Z][a-zA-Z'’-]+)(?=\s+(?:is |has |was |out\b|returns|leaves|left|exits|exited|suffers|suffered|sustains|injured|ruled|ejected|suspended|fired|dismissed|takes over|replaced|back))/)?.[1];
        if (!name) continue;
        const subjectKey = name.toLowerCase();
        const old = map.get(subjectKey);
        if (old && reportedAt <= old.reportedAt) continue;
        const position = old?.kind === evidence.kind && old.status === evidence.status ? old.position : p;
        keep({ ...evidence, text, evidenceText, verified: true, eventId: String(game.id), subjectKey, subject: name, teamId: String(team?.[8] || ""), position, reportedAt, sourceUrl: url, sourceTitle: text });
      }
      const rosterMap = /* @__PURE__ */ new Map();
      for (const t of summary?.boxscore?.players || []) for (const s of t.statistics || []) for (const a of s.athletes || []) {
        const key = a.athlete?.id || a.athlete?.displayName;
        rosterMap.set(key, { athlete: a.athlete, teamId: id(t), passing: s.name === "passing" || rosterMap.get(key)?.passing === true });
      }
      const roster = [...rosterMap.values()];
      const alias = (r) => [
        r.athlete?.displayName,
        r.athlete?.shortName,
        r.athlete?.firstName && r.athlete?.lastName ? `${r.athlete.firstName[0]}.${r.athlete.lastName}` : ""
      ].filter(Boolean);
      const named = (r, text) => alias(r).some((name) => text.includes(name));
      const plays = [...new Map([...summary?.plays || [], ...(summary?.drives?.previous || []).flatMap((d) => d.plays || []), ...summary?.drives?.current?.plays || []].map((play) => [String(play.id || JSON.stringify(play)), play])).values()];
      const positionOf = (play) => eventPosition2(game.sport, { status: { period: play.period?.number, displayClock: play.clock?.displayValue } });
      for (const play of plays) {
        const text = String(play.text || "").trim();
        const player = roster.find((r) => named(r, text) && (/^(?:QB|quarterback)$/i.test(r.athlete.position?.abbreviation || r.athlete.position?.name || "") || map.get(r.athlete?.displayName?.toLowerCase())?.quarterback));
        const evidenceText = player ? `Quarterback ${text}` : text;
        const evidence = confirmedDevelopment(evidenceText);
        const position = positionOf(play);
        if (!evidence || position === null || p === null || position > p + 1e-8) continue;
        const name = player?.athlete.displayName || text.match(/\b([A-Z][a-zA-Z'’-]+\s+[A-Z][a-zA-Z'’-]+)(?=\s+(?:is |has |was |returns|leaves|left|exits|injured|ruled|ejected|replaced|back))/)?.[1];
        if (!name) continue;
        const teamId = player?.teamId || String(play.team?.id || "");
        const subjectKey = name.toLowerCase();
        const old = map.get(subjectKey);
        if (old?.status === "out" && evidence.kind === "injury" && position < old.position && /injured/i.test(text)) {
          map.set(subjectKey, { ...old, position, sourcePlayId: String(play.id || "") });
          continue;
        }
        if (old && old.position >= position) continue;
        const firstPosition = old?.kind === evidence.kind && old.status === evidence.status ? old.position : position;
        keep({
          ...evidence,
          text,
          evidenceText,
          verified: true,
          eventId: String(game.id),
          subjectKey,
          subject: name,
          teamId,
          position: firstPosition,
          reportedAt: 0,
          sourcePlayId: String(play.id || ""),
          sourceUrl: `https://www.espn.com/${game.sport === "NFL" ? "nfl" : "college-football"}/playbyplay/_/gameId/${encodeURIComponent(game.id)}`,
          sourceTitle: "ESPN play-by-play"
        });
      }
      for (const [key, development] of map) if (development.quarterback && development.status === "out" && development.sourcePlayId) {
        const passers = roster.filter((r) => r.passing && r.teamId === development.teamId && r.athlete?.displayName !== development.subject);
        const observed = plays.map((play) => ({ play, position: positionOf(play) })).filter((x) => x.position !== null && x.position > development.position && x.position <= p && /\bpass(?:es|ed)?\b/i.test(x.play.text || ""));
        const passing = (r, text) => alias(r).some((name) => new RegExp(name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "\\s+pass(?:\\s|es\\b|ed\\b)").test(text));
        const latest = observed.sort((a, b) => b.position - a.position).map((x) => ({ x, player: passers.find((r) => passing(r, x.play.text || "")) })).find((x) => x.player);
        if (latest) map.set(key, { ...development, replacementName: latest.player.athlete.displayName, replacementPlayId: String(latest.x.play.id || "") });
      }
      return [...map.values()].sort((a, b) => b.position - a.position || b.reportedAt - a.reportedAt || a.subjectKey.localeCompare(b.subjectKey)).slice(0, 8);
    }
    function developmentImpact(game, progress, gap) {
      const active = (game.verifiedDevelopments || []).filter((d) => d.verified && d.eventId === String(game.id) && d.position <= progress + 1e-8);
      const weight = active.reduce((sum, d) => sum + (d.quarterback ? 4 : 2) * Math.exp(-Math.max(0, progress - d.position) / 0.35), 0);
      return { points: Math.round(Math.min(5, weight) * Math.exp(-Math.pow(gap / 17, 2))), active };
    }
    function footballLiveExplanation(game) {
      if (!["NFL", "CFB"].includes(game.sport) || game.state !== "live" || game.teams?.length !== 2) return "";
      const [a, b] = game.teams, scores = game.teams.map((t) => Number(t[2]));
      if (!scores.every(Number.isFinite)) return "";
      const gap = Math.abs(scores[0] - scores[1]), leader = scores[0] > scores[1] ? a : b;
      const plural = (name) => /s$|men$|Sox$/i.test(String(name));
      const clock = String(game.liveRawStatus?.displayClock || "");
      const period = Number(game.liveRawStatus?.period);
      const phase = clock && period >= 1 && period <= 4 ? ` with ${clock} left in the ${["", "first", "second", "third", "fourth"][period]} quarter` : game.live?.phase && game.live.phase !== "Live" ? ` (${game.live.phase})` : "";
      const sentences = [gap === 0 ? `${a[0]} and ${b[0]} are tied ${scores[0]}\u2013${scores[1]}${phase}.` : `${leader[0]} ${plural(leader[0]) ? "lead" : "leads"} ${Math.max(...scores)}\u2013${Math.min(...scores)}${phase}.`];
      const developments = (game.verifiedDevelopments || []).filter((d) => d.verified && d.eventId === String(game.id));
      if (developments.length) {
        const development = developments[0];
        sentences.push(development.text.replace(`${development.subject} out for game`, `${development.subject} is out for the game`).replace(/[.!?]+$/, "") + ".");
        if (developments[0].replacementName) sentences.push(`${developments[0].replacementName} has thrown passes since ${developments[0].subject}'s departure.`);
      }
      if (game.liveSurprise?.points >= 2) {
        const s = game.liveSurprise, m = s.market;
        const expectation = m.spread ? `entering as a ${m.spread}-point underdog` : m.source === "rankings" ? "facing a higher-ranked opponent" : "entering as the moneyline underdog";
        const verb = plural(m.teamName) ? "are" : "is";
        sentences.push(`${m.teamName} ${verb} ${s.margin > 0 ? "threatening an upset" : s.margin === 0 ? "level" : "still within reach"} despite ${expectation}.`);
      } else {
        const factors = game.historyOwnership?.eventFactors || game.factors || [];
        const comeback = factors.find((f) => /comeback|erased.*deficit/i.test(f.label) && f.points > 0);
        const leadChanges = factors.find((f) => /lead change/i.test(f.label) && f.points > 0);
        const situation = game.footballSituation;
        const holder = game.teams.find((t) => String(t[8]) === situation?.possessionTeamId);
        if (comeback) {
          const detail = String(game.momentumText || "").split(", ").find((t) => /erased a deficit/i.test(t));
          sentences.push(detail ? detail.replace(/^./, (c) => c.toUpperCase()).replace(/[.!?]+$/, "") + "." : "A large deficit has been erased to bring the game back within reach.");
        } else if (leadChanges) {
          const count = leadChanges.label.match(/^(\d+) lead change/);
          sentences.push(count ? `The lead has changed ${count[1]} ${count[1] === "1" ? "time" : "times"}.` : "A recent lead change has shifted control.");
        } else if (holder && situation.downAndDistance) sentences.push(`${holder[0]} has possession, ${situation.downAndDistance}${situation.fieldPosition ? ` at ${situation.fieldPosition}` : ""}.`);
        else if (gap <= 8) {
          const stakes = (game.openingFactors || []).find((f) => /^(?:AFC|NFC) .* matchup$|rivalry|conference championship|postseason/i.test(f.label));
          if (stakes) sentences.push(`${stakes.label.replace(/ matchup$/, "")} stakes add to this ${gap === 0 ? "tied" : `${gap}-point`} game.`);
        }
      }
      return sentences.slice(0, 3).join(" ");
    }
    module2.exports = { pregameMarket, liveSurprise, confirmedDevelopment, mergeDevelopments, developmentImpact, footballLiveExplanation };
  }
});

// scoring/live-runtime.cjs
var require_live_runtime = __commonJS({
  "scoring/live-runtime.cjs"(exports2, module2) {
    var { isHalftimeStatus } = require_time();
    var legacy = require_rating_core();
    var { candidateGameRating } = require_shadow_candidate();
    var { LIVE_CFB_COMPETITION_POLICY: LIVE_POLICY } = require_trajectory_live_policy();
    var { prepareOpening, preservePregameBaseline } = require_opening_transition();
    var { preserveLiveEvidence, historyFor, rememberHistory, currentManpower, validLedger } = require_live_evidence();
    var basketball = require_basketball_state();
    var { analyzeTrajectory } = require_models();
    var basketballCalibration = require_basketball_calibration();
    var { canonicalDetailSummary } = require_detail_state();
    var footballLive = require_football_live();
    var footballMarket2 = require_football_market();
    var PRODUCTION_POLICY = Object.freeze({ ...LIVE_POLICY, id: LIVE_POLICY.id + "-opening-transition", footballTransition: true, openingTransition: true });
    var MODEL_VERSION = "2026-11-01.football-market.2";
    function retainSettledCfbPath(game, current, summary) {
      if (game.sport !== "CFB" || !summary || Number(current.status?.period) !== 4) return;
      const seconds = legacy.clockSeconds(current.status), gap = Math.abs(Number(game.teams[0][2]) - Number(game.teams[1][2]));
      if (seconds === null || seconds > 120 || gap === 0) return;
      const x = Math.max(0, Math.min(1, (120 - seconds) / 120)), weight = x * x * (3 - 2 * x);
      if (!weight) return;
      const competition = { ...current, status: { ...current.status, type: { state: "post", completed: true, detail: "Final" } } };
      const teams = game.teams.map((t) => ({ name: t[0], abbr: t[1], score: t[2], record: t[5], rank: t[6], id: t[8] }));
      const rating = legacy.rateGame("CFB", "completed", teams, game.sourceEvent, competition, game.context || "");
      const finalGame = { ...game, state: "completed", score: rating.score, factors: rating.factors, upsetPoints: rating.upsetPoints, sourceCompetition: competition };
      const finish2 = legacy.defensiveFinishFactor("CFB", summary)?.points || 0;
      const history = legacy.momentumImpact("CFB", summary, 1, "completed", { game: finalGame, finishPoints: finish2 });
      const target = legacy.clampScore(rating.score + history.points + finish2);
      const delta = Math.round(Math.max(0, target - game.score) * weight);
      if (delta) {
        game.score = legacy.clampScore(game.score + delta);
        game.factors.push({ label: "Competitive path retained as clock expires", points: delta });
      }
    }
    function applyLiveSnapshot2(game, competition, summary) {
      if (footballMarket2.supports(game)) competition = footballMarket2.prepareUpcomingMarket(game, competition || game.sourceCompetition, summary);
      const reconciled = basketball.reconcileBasketball(game, competition || game.sourceCompetition, summary);
      competition = reconciled.competition;
      summary = reconciled.summary;
      prepareOpening(legacy, game, competition || game.sourceCompetition, null);
      if (game.state !== "live") return;
      legacy.applyLiveSnapshot(game, competition, summary);
      const current = {
        ...competition || game.sourceCompetition,
        ...game.sport === "NFL" ? { season: { ...game.sourceEvent?.season, ...game.sourceCompetition?.season, ...competition?.season } } : {},
        status: game.liveRawStatus,
        situation: game.liveRawSituation
      };
      const accepted = game.lastSummaryAccepted && summary?.header?.competitions?.[0]?.status ? summary : null;
      const validHistory = !accepted || validLedger(accepted, current, game.sport);
      if (!validHistory) {
        delete game.verifiedLiveEvidence;
        delete game.manpowerEvidence;
      }
      const ratingSummary = validHistory ? accepted : { ...accepted, scoringPlays: [], plays: [], drives: void 0, winprobability: [] };
      delete game.manpowerRetained;
      const effective = currentManpower(game, current, ratingSummary);
      const history = basketball.supports(game) ? { summary: reconciled.history, trajectory: analyzeTrajectory(game.sport, reconciled.history, legacy.gameProgress(game.sport, current), "live") } : historyFor(game, current, accepted);
      const latestProbability = effective?.winprobability?.at(-1);
      const unanchoredProbability = history && latestProbability && (latestProbability.playId == null || !(effective.plays || []).some((p) => String(p.id) === String(latestProbability.playId)));
      const currentSummary = unanchoredProbability ? { ...effective, winprobability: [] } : effective;
      prepareOpening(legacy, game, competition || game.sourceCompetition, accepted);
      if (["NFL", "CFB", "NCAAB"].includes(game.sport)) {
        const upset = legacy.upsetImpact(game.underdog, game.teams, "live", legacy.gameProgress(game.sport, current), game.sport, current);
        game.factors = game.factors.filter((f) => f.label !== "Underdog threatens upset");
        if (upset.points) game.factors.push({ label: "Underdog threatens upset", points: upset.points });
        game.upsetPoints = upset.points;
        game.upsetText = upset.text;
      }
      let scoringGame = game;
      if (["NFL", "CFB"].includes(game.sport)) {
        game.livePregameMarket ||= footballLive.pregameMarket(game, current) || footballLive.pregameMarket(game, { ...current, odds: game.pregameBaseline?.odds }) || footballLive.pregameMarket(game, { ...current, odds: game.recoveredUnderdog?.odds });
        if (accepted) game.verifiedDevelopments = footballLive.mergeDevelopments(game, accepted);
        const surpriseSummary = history ? {
          ...currentSummary,
          header: { competitions: [current] },
          scoringPlays: history.summary?.scoringPlays,
          plays: history.summary?.plays,
          winprobability: currentSummary?.winprobability || []
        } : currentSummary;
        const surprise = footballLive.liveSurprise(legacy, game, current, surpriseSummary, history?.summary || surpriseSummary);
        const gap = Math.abs(Number(game.teams[0][2]) - Number(game.teams[1][2]));
        const developments = footballLive.developmentImpact(game, legacy.gameProgress(game.sport, current), gap);
        Object.assign(game, { liveSurprise: surprise, upsetPoints: surprise.points, upsetText: surprise.text });
        const factors = game.factors.filter((f) => !["Underdog threatens upset", "Verified live development"].includes(f.label));
        if (surprise.points) factors.push({ label: "Underdog threatens upset", points: surprise.points, liveSurprise: true });
        if (developments.points) factors.push({ label: "Verified live development", points: developments.points });
        const contradictedContexts = (game.qualitativeContexts || []).filter((c) => developments.active.some((d) => (c.text || "").toLowerCase().includes(d.subject.toLowerCase()) && (d.status === "returned" ? /absence/.test(c.type) : /return|first_game_back|confirmed_key_starters/.test(c.type))));
        const contradicted = (f) => contradictedContexts.some((c) => c.type === f.contextType);
        const removed = (game.openingFactors || []).filter(contradicted);
        game.suppressedContextTypes = contradictedContexts.map((c) => c.type);
        scoringGame = {
          ...game,
          sourceEvent: game.sourceEvent,
          sourceCompetition: game.sourceCompetition,
          factors,
          openingFactors: (game.openingFactors || []).filter((f) => !contradicted(f)),
          openingScore: game.openingScore - removed.reduce((sum, f) => sum + f.points, 0)
        };
      }
      const result = candidateGameRating(legacy, history ? { ...scoringGame, _historicalEvidence: history } : scoringGame, current, currentSummary, basketballCalibration.tensionPolicy(game, current), { ...PRODUCTION_POLICY, collegeFinish: true });
      Object.assign(game, {
        score: result.score,
        baseScore: result.baseScore,
        live: result.live,
        momentumPoints: result.momentumPoints,
        trajectoryScoring: result.trajectoryScoring,
        historyOwnership: result.historyOwnership,
        factors: [
          ...result.factors,
          ...result.historyOwnership?.eventFactors || [],
          ...result.trajectoryScoring.adjustment ? [{ label: "History relevance and trajectory", points: result.trajectoryScoring.adjustment }] : []
        ],
        modelVersion: MODEL_VERSION,
        scoringPolicy: PRODUCTION_POLICY.id,
        scoringPartial: basketball.supports(game) ? !reconciled.rawCurrent : !accepted || !validHistory
      });
      if (game.sport === "CFB" && isHalftimeStatus(game.liveRawStatus)) game.live.note = "";
      game.momentumText = (result.historyOwnership?.eventFactors || []).map((f) => f.label).join(", ");
      if (game.sport === "CFB") game.upsetPoints = result.factors.find((f) => f.label === "Underdog threatens upset")?.points || 0;
      retainSettledCfbPath(game, current, accepted);
      if (accepted && validHistory && !history) rememberHistory(game, current, accepted, result);
      if (!basketball.supports(game)) game.historicalEvidenceRetained = Boolean(history);
      delete game.basketballHistory;
      if (basketball.supports(game)) game.lastSummaryAccepted = reconciled.rawCurrent;
      delete game.staleEnrichment;
      return result;
    }
    function preserveEvidence(game, previous) {
      preserveLiveEvidence(game, previous);
      basketball.preserveBasketballState(game, previous);
    }
    module2.exports = { ...legacy, isHalftimeStatus, canonicalDetailSummary, applyLiveSnapshot: applyLiveSnapshot2, preservePregameBaseline, preserveLiveEvidence: preserveEvidence, footballLiveExplanation: footballLive.footballLiveExplanation, MODEL_VERSION, POLICY_ID: PRODUCTION_POLICY.id, PRODUCTION_POLICY };
  }
});

// scripts/finish-audit-entry.mjs
var finish_audit_entry_exports = {};
__export(finish_audit_entry_exports, {
  applyContextsToGame: () => applyContextsToGame2,
  enrichGame: () => enrichGame2,
  normalizeEvent: () => normalizeEvent2,
  preserveFootballContext: () => preserveFootballContext,
  preserveFootballPregameMarket: () => preserveFootballPregameMarket,
  preservePregameRecords: () => preservePregameRecords,
  runtime: () => import_live_runtime2.default
});
module.exports = __toCommonJS(finish_audit_entry_exports);

// alerts-worker/src/display-model.js
var import_time = __toESM(require_time(), 1);
function footballSituation(game, summary = null) {
  if (!["NFL", "CFB"].includes(game.sport) || game.state !== "live" || import_time.default.isHalftimeStatus(game.liveRawStatus)) return null;
  const liveSituation = game.liveRawSituation || {};
  const plays = summary?.drives?.current?.plays;
  const lastPlayEnd = Array.isArray(plays) ? plays.at(-1)?.end : null;
  const source = { ...lastPlayEnd ? { ...lastPlayEnd, possession: lastPlayEnd.team?.id } : {}, ...liveSituation };
  const possession = String(source.possession?.id ?? source.possession ?? "");
  const holders = game.teams.filter((team) => team[8] && String(team[8]) === possession);
  const text = String(liveSituation.shortDownDistanceText || liveSituation.downDistanceText || source.shortDownDistanceText || source.downDistanceText || "");
  const parsed = text.match(/\b([1-4])(?:st|nd|rd|th)\s*(?:&|and)\s*(goal|\d+)/i);
  const down = Number(source.down ?? parsed?.[1]);
  const distance = source.distance == null || source.distance === "" ? parsed && !/goal/i.test(parsed[2]) ? Number(parsed[2]) : null : Number(source.distance);
  const goalToGo = source.isGoalToGo === true || /\bgoal\b/i.test(text);
  const downAndDistance = Number.isInteger(down) && down >= 1 && down <= 4 && (goalToGo || distance !== null && Number.isFinite(distance) && distance >= 0) ? `${["", "1st", "2nd", "3rd", "4th"][down]} & ${goalToGo ? "Goal" : distance}` : "";
  const spot = `${liveSituation.possessionText || ""} ${liveSituation.downDistanceText || ""} ${source.possessionText || ""} ${source.downDistanceText || ""}`.match(/\b([A-Z][A-Z0-9]{1,5})\s+(\d{1,2})\b/);
  const fieldPosition = spot && Number(spot[2]) <= 50 && game.teams.some((team) => team[1] === spot[1]) ? `${spot[1]} ${Number(spot[2])}` : "";
  return { possessionTeamId: holders.length === 1 ? possession : null, downAndDistance, fieldPosition };
}
function baseballSituation(game) {
  if (game.sport !== "MLB" || game.state !== "live") return null;
  const source = game.liveRawSituation || {};
  const bases = {};
  for (const [key, field] of [["first", "onFirst"], ["second", "onSecond"], ["third", "onThird"]]) {
    const value = source[field] ?? source.runners?.[key];
    if (typeof value === "boolean") bases[key] = value;
  }
  const validCount = (value, max) => value !== null && value !== void 0 && value !== "" && Number.isInteger(Number(value)) && Number(value) >= 0 && Number(value) <= max ? Number(value) : null;
  const outs = validCount(source.outs, 3);
  const balls = validCount(source.balls, 3);
  const strikes = validCount(source.strikes, 2);
  return Object.keys(bases).length || outs !== null || balls !== null && strikes !== null ? { bases: Object.keys(bases).length ? bases : null, outs, count: balls !== null && strikes !== null ? `${balls}-${strikes}` : "" } : null;
}

// alerts-worker/src/game-model.js
var import_rating_core = __toESM(require_rating_core(), 1);
var import_watch_links = __toESM(require_watch_links(), 1);
var {
  SPORT_BASE,
  CLOSE_MARGIN,
  clampScore,
  factorText,
  recordFor,
  rankFor,
  parseLine,
  lineFromSummary,
  gameProgress,
  eventPosition,
  momentumImpact,
  underdogCandidate,
  upsetImpact,
  unbeatenStartImpact,
  stateRating,
  rateGame,
  applyLiveSnapshot
} = globalThis.SportsRadarScore;
var LEAGUE_LOGOS = {
  NFL: "https://a.espncdn.com/i/leaguelogos/500/nfl.png",
  MLB: "https://a.espncdn.com/i/leaguelogos/500/mlb.png",
  NHL: "https://a.espncdn.com/i/leaguelogos/500/nhl.png",
  CFB: "https://a.espncdn.com/i/leaguelogos/500/ncaaf.png",
  NBA: "https://a.espncdn.com/i/leaguelogos/500/nba.png",
  NCAAB: "https://a.espncdn.com/i/leaguelogos/500/ncaab.png",
  Tennis: "https://a.espncdn.com/i/leaguelogos/500/atp.png",
  Soccer: "https://a.espncdn.com/i/leaguelogos/500/soccer.png"
};
function iconFor(sport) {
  return {
    NFL: "\u25C8",
    MLB: "\u25C9",
    NHL: "\u2727",
    CFB: "\u25C6",
    NBA: "\u25CF",
    NCAAB: "\u25C7",
    Tennis: "\u25CC",
    Soccer: "\u2299"
  }[sport] || "\u2726";
}
function stateFromEvent(event) {
  const type = event.competitions?.[0]?.status?.type;
  if (type?.completed || type?.state === "post") return "completed";
  if (type?.state === "in") return "live";
  return "upcoming";
}
function scoreValue(competitor) {
  const value = Number(competitor.score);
  return Number.isFinite(value) ? String(value) : "\u2014";
}
function broadcastFor(competition) {
  const values = [];
  const add = (value) => {
    if (typeof value === "string" && value.trim()) {
      values.push(value.trim());
    }
  };
  (competition?.broadcasts || []).forEach((broadcast) => {
    (broadcast.names || []).forEach(add);
    add(broadcast.name);
    add(broadcast.shortName);
  });
  (competition?.geoBroadcasts || []).forEach((broadcast) => {
    add(broadcast.media?.shortName);
    add(broadcast.media?.name);
    add(broadcast.type?.shortName);
  });
  return [...new Set(values)].slice(0, 2).join(" \xB7 ");
}
function normalizeEvent(event, sport, leagueLogo, division) {
  const competition = event.competitions?.[0];
  const competitors = competition?.competitors || [];
  if (competitors.length < 2) return null;
  const sideOrder = (side) => side === "away" ? 0 : side === "home" ? 1 : 2;
  const orderedCompetitors = competitors.slice(0, 2).sort(
    (a, b) => sideOrder(a.homeAway) - sideOrder(b.homeAway)
  );
  const teams = orderedCompetitors.map((competitor) => ({
    id: String(competitor.team?.id || ""),
    name: competitor.team?.displayName || competitor.athlete?.displayName || "Unknown",
    shortName: competitor.team?.shortDisplayName || competitor.team?.name || competitor.athlete?.shortName || "",
    abbr: competitor.team?.abbreviation || competitor.abbreviation || "",
    score: scoreValue(competitor),
    logo: competitor.team?.logo || "",
    color: "white",
    record: recordFor(competitor),
    rank: rankFor(competitor, sport)
  }));
  const gameState = stateFromEvent(event);
  const status = competition?.status?.type?.shortDetail || competition?.status?.type?.detail || (gameState === "completed" ? "Final" : "Scheduled");
  const context = competition?.notes?.[0]?.headline || event.name || `${sport} matchup`;
  const rating = rateGame(
    sport,
    gameState,
    teams,
    event,
    competition,
    context
  );
  const eventId = event.id || `${sport}-${event.name}`;
  const game = {
    id: eventId,
    favorite: false,
    sport,
    division,
    icon: iconFor(sport),
    leagueLogo: leagueLogo || LEAGUE_LOGOS[sport],
    startTime: event.date,
    state: gameState,
    status,
    channel: broadcastFor(competition) || "Channel not listed",
    teams: teams.map((team) => [
      team.name,
      team.abbr,
      team.score,
      team.color,
      team.logo,
      team.record,
      team.rank,
      team.shortName,
      team.id
    ]),
    ...sport === "NFL" && gameState !== "completed" ? { pregameRecords: teams.map((team) => team.record) } : {},
    line: gameState === "upcoming" ? parseLine(
      competition?.odds?.[0],
      competition,
      sport
    ) : null,
    context,
    why: rating.reason,
    sub: competition?.venue?.fullName || competition?.venue?.address?.city || "Live scoreboard",
    score: rating.score,
    baseScore: rating.score,
    openingScore: rating.openingScore,
    rawPregameScore: rating.rawPregameScore,
    ...rating.championshipStakes ? { championshipStakes: true } : {},
    factors: rating.factors,
    underdog: rating.underdog,
    upsetText: rating.upsetText,
    upsetPoints: rating.upsetPoints,
    liveRawStatus: competition?.status,
    liveRawSituation: competition?.situation
  };
  Object.defineProperties(game, {
    sourceEvent: { value: event, enumerable: false },
    sourceCompetition: { value: competition, enumerable: false }
  });
  const watchLinks = globalThis.SportsRadarWatch.resolve(game, event).filter((link) => link.direct);
  if (watchLinks.length) game.watchLinks = watchLinks;
  applyLiveSnapshot(
    game,
    competition,
    null
  );
  if (["NFL", "CFB"].includes(sport)) game.footballSituation = footballSituation(game);
  if (sport === "MLB") game.baseballSituation = baseballSituation(game);
  return game;
}
function teamObjectsForRating(game) {
  return game.teams.map((team, index) => ({
    id: String(team[8] || ""),
    name: team[0],
    abbr: team[1],
    score: team[2],
    color: team[3],
    logo: team[4],
    record: team[5],
    rank: team[6],
    shortName: team[7],
    pregameRecord: game.pregameRecords?.[index]
  }));
}
function preservePregameRecords(game, previousGame) {
  if (game.sport !== "NFL" || !previousGame || game.state === "upcoming") return;
  const records = game.teams.map((team) => {
    const index = previousGame.teams?.findIndex((prior) => String(prior[8]) === String(team[8]));
    if (index == null || index < 0 || !team[8]) return null;
    return previousGame.pregameRecords?.[index] || (previousGame.state === "completed" ? null : previousGame.teams[index][5]);
  });
  if (records.some((record) => !record)) return;
  game.pregameRecords = records;
  if (game.state !== "completed" || game.factors.some((item) => item.label === "Ended unbeaten start")) return;
  const bonus = unbeatenStartImpact(game.sport, game.state, teamObjectsForRating(game));
  if (!bonus) return;
  game.factors.push({ label: "Ended unbeaten start", points: bonus });
  game.baseScore = clampScore(game.baseScore + bonus);
  game.score = clampScore(game.score + bonus);
}
function applyContextsToGame(game, factors) {
  if (!game.sourceEvent || !game.sourceCompetition || !Array.isArray(factors)) return false;
  const valid = factors.filter((factor) => factor?.verified !== false && Number(factor?.confidence) >= 0.7 && factor?.type && factor?.text);
  const accepted = (game.sport === "NFL" ? [...valid.reduce((byType, factor) => {
    if (!byType.has(factor.type)) byType.set(factor.type, factor);
    return byType;
  }, /* @__PURE__ */ new Map()).values()] : valid).slice(0, 6);
  game.sourceEvent.sportsRadarContextFactors = accepted.map((factor) => ({
    type: factor.type,
    text: factor.text,
    confidence: Number(factor.confidence),
    verified: true,
    sourceTitle: factor.sourceTitle,
    sourceUrl: factor.sourceUrl,
    ...factor.injuryEvidence ? { injuryEvidence: factor.injuryEvidence } : {}
  }));
  const rating = rateGame(
    game.sport,
    game.state,
    teamObjectsForRating(game),
    game.sourceEvent,
    game.sourceCompetition,
    game.context
  );
  game.score = rating.score;
  game.baseScore = rating.score;
  game.openingScore = rating.openingScore;
  game.rawPregameScore = rating.rawPregameScore;
  game.openingFactors = rating.openingFactors;
  if (rating.championshipStakes) game.championshipStakes = true;
  else delete game.championshipStakes;
  game.factors = rating.factors;
  game.why = rating.reason;
  game.underdog = rating.underdog;
  game.upsetText = rating.upsetText;
  game.upsetPoints = rating.upsetPoints;
  game.qualitativeContexts = accepted;
  applyLiveSnapshot(game, game.sourceCompetition, null);
  return true;
}
function playPosition(sport, play) {
  if (typeof eventPosition !== "function") return legacyPlayPosition(sport, play);
  const period = Number(play?.period?.number || play?.period?.value || play?.period || 0);
  if (!Number.isFinite(period) || period < 1) return null;
  return eventPosition(sport, { status: {
    period,
    displayClock: play?.clock?.displayValue || "",
    clock: play?.clock?.value,
    type: { detail: play?.period?.displayValue || play?.inningHalf || "" }
  } });
}
function legacyPlayPosition(sport, play) {
  const period = Number(
    play?.period?.number || play?.period?.value || play?.period || 0
  );
  if (!Number.isFinite(period) || period < 1) {
    return null;
  }
  if (sport === "MLB") {
    return Math.min(
      1,
      Math.max(
        0,
        (period - 1 + (/bottom|bot/i.test(
          String(
            play.period?.displayValue || play.inningHalf || ""
          )
        ) ? 0.75 : 0.25)) / 9
      )
    );
  }
  if (sport === "NHL") {
    const clock2 = String(
      play.clock?.displayValue || ""
    ).match(
      /^(\d+):(\d+)/
    );
    const elapsed = clock2 ? Number(clock2[1]) * 60 + Number(clock2[2]) : 600;
    return period > 3 ? Math.min(
      1,
      0.92 + Math.min(
        300,
        elapsed
      ) / 300 * 0.08
    ) : Math.min(
      0.92,
      ((period - 1) * 20 * 60 + elapsed) / (60 * 60) * 0.92
    );
  }
  const total = {
    NFL: 4,
    CFB: 4,
    NHL: 3,
    NBA: 4,
    NCAAB: 2,
    Soccer: 2
  }[sport];
  const length = {
    NFL: 15,
    CFB: 15,
    NHL: 20,
    NBA: 12,
    NCAAB: 20,
    Soccer: 45
  }[sport];
  if (!total || !length) {
    return null;
  }
  const clock = String(
    play.clock?.displayValue || ""
  ).match(
    /^(\d+):(\d+)/
  );
  const remaining = clock ? Math.min(
    length * 60,
    Number(clock[1]) * 60 + Number(clock[2])
  ) : length * 30;
  return Math.min(
    1,
    Math.max(
      0,
      (period - 1 + 1 - remaining / (length * 60)) / total
    )
  );
}
function scoringEvents(summary) {
  return summary?.scoringPlays?.length ? summary.scoringPlays : (summary?.plays || []).filter(
    (play) => play.scoringPlay === true
  );
}
function compactPlay(play) {
  const text = String(
    play?.text || play?.shortText || play?.type?.text || ""
  ).replace(/\s+/g, " ").trim();
  return text.length > 86 ? `${text.slice(0, 83)}\u2026` : text;
}
function summarySpecificWhy(game, summary) {
  const scoring = scoringEvents(summary).map((play) => ({
    play,
    position: playPosition(
      game.sport,
      play
    )
  })).filter(
    (item) => item.position !== null
  ).sort(
    (a, b) => a.position - b.position
  );
  const last = scoring[scoring.length - 1];
  if (!last) {
    return null;
  }
  const text = compactPlay(last.play);
  if (!text) {
    return null;
  }
  const time2 = `${last.play.period?.displayValue || ""} ${last.play.clock?.displayValue || ""}`.trim();
  if (game.state === "completed") {
    const decisive = /(0:00|last second|game[- ]winning|walk.off)/i.test(
      `${time2} ${text}`
    ) || Number(
      last.play.period?.number
    ) > {
      NHL: 3,
      NFL: 4,
      CFB: 4,
      NBA: 4,
      NCAAB: 2
    }[game.sport] && /goal|field goal|touchdown|basket/i.test(text);
    return {
      label: decisive ? "Decisive play" : "Last score",
      text: `${time2 ? `${time2} \xB7 ` : ""}${text}`
    };
  }
  const current = playPosition(
    game.sport,
    {
      period: {
        number: game.liveRawStatus?.period
      },
      clock: {
        displayValue: game.liveRawStatus?.displayClock
      }
    }
  ) ?? gameProgress(
    game.sport,
    {
      status: game.liveRawStatus || {}
    }
  );
  if (current - last.position > 0.12) {
    return null;
  }
  return {
    label: "Latest score",
    text: `${time2 ? `${time2} \xB7 ` : ""}${text}`
  };
}
function enrichGame(game, summary, previousGame = null) {
  const watchLinks = globalThis.SportsRadarWatch.resolve(game, summary).filter((link) => link.direct);
  if (watchLinks.length) game.watchLinks = watchLinks;
  let completedFinishHandled = false;
  if (previousGame?.summaryState) game.summaryState = previousGame.summaryState;
  const summaryCompetition = summary?.header?.competitions?.[0];
  const driveEnd = ["NFL", "CFB"].includes(game.sport) ? summary?.drives?.current?.plays?.at(-1)?.end : null;
  const normalizedCompetition = summaryCompetition && driveEnd ? { ...summaryCompetition, situation: { ...driveEnd, possession: driveEnd.team?.id, ...summaryCompetition.situation } } : summaryCompetition;
  if (game.state === "live") {
    applyLiveSnapshot(
      game,
      // The freshly-normalized event is the scoreboard authority.
      // Summary data may only enrich it after chronology validation.
      game.sourceCompetition || normalizedCompetition,
      summary
    );
  }
  const acceptedSummary = game.state === "live" && (!game.lastSummaryAccepted || !summaryCompetition?.status) ? null : summary;
  if (game.state === "live" && !acceptedSummary) {
    const priorLive = previousGame?.live;
    const priorProgress = previousGame?.summaryState?.status ? gameProgress(game.sport, { status: previousGame.summaryState.status }) : null;
    const currentProgress = gameProgress(game.sport, { status: game.liveRawStatus });
    const sameScores = previousGame?.teams?.every((team, index) => String(team[2]) === String(game.teams[index]?.[2]));
    if (priorLive && sameScores && priorProgress !== null && currentProgress >= priorProgress && currentProgress - priorProgress <= 0.04) {
      const historic = Number(previousGame.score) - Number(previousGame.baseScore) - Number(priorLive.components?.situation || 0);
      if (Number.isFinite(historic) && historic > 0) {
        game.score = clampScore(game.score + Math.floor(historic * 0.9));
        game.staleEnrichment = true;
      }
    }
    if (["NFL", "CFB"].includes(game.sport)) game.footballSituation = footballSituation(game);
    if (game.sport === "MLB") game.baseballSituation = baseballSituation(game);
    return;
  }
  if (["NFL", "CFB"].includes(game.sport)) game.footballSituation = footballSituation(game, acceptedSummary);
  if (game.sport === "MLB") game.baseballSituation = baseballSituation(game);
  const line = lineFromSummary(
    acceptedSummary,
    game.sport
  );
  if (line && (game.state !== "upcoming" || !game.line)) {
    game.line = line;
  }
  if (!game.underdog && game.state !== "upcoming") {
    const summaryCompetition2 = acceptedSummary?.header?.competitions?.[0];
    const candidate = underdogCandidate(
      game.sport,
      summaryCompetition2,
      acceptedSummary?.pickcenter?.[0] || summaryCompetition2?.odds?.[0]
    );
    if (candidate) {
      game.underdog = candidate;
      const impact = upsetImpact(
        candidate,
        game.teams,
        game.state,
        game.state === "completed" ? 1 : gameProgress(
          game.sport,
          summaryCompetition2
        ),
        game.sport,
        normalizedCompetition || summaryCompetition2
      );
      if (impact.points) {
        game.upsetPoints = impact.points;
        game.upsetText = impact.text;
        game.factors.push({
          label: game.state === "completed" ? "Underdog won outright" : "Underdog threatens upset",
          points: impact.points
        });
        game.baseScore = clampScore(
          game.baseScore + impact.points
        );
        game.score = clampScore(
          game.baseScore + (game.live?.bonus || 0)
        );
      }
    }
  }
  if (game.state !== "upcoming") {
    const momentum = momentumImpact(
      game.sport,
      acceptedSummary,
      game.state === "completed" ? 1 : gameProgress(
        game.sport,
        acceptedSummary?.header?.competitions?.[0] || {
          status: game.liveRawStatus
        }
      ),
      game.state,
      ["CFB", "NHL"].includes(game.sport) && game.state === "completed" ? { game, finishPoints: completedFinishPoints(game, summary) } : null
    );
    completedFinishHandled = Boolean(momentum.handlesFinish);
    if (momentum.points) {
      game.momentumText = momentum.text;
      game.momentumPoints = momentum.points;
      game.factors.push(
        ...momentum.factors
      );
      game.score = clampScore(
        game.score + momentum.points
      );
    }
  }
  const moment = summarySpecificWhy(
    game,
    summary
  );
  if (moment) {
    game.moment = moment.text;
    game.momentLabel = moment.label;
  }
  if (game.state !== "completed") {
    return;
  }
  const plays = scoringEvents(summary);
  const last = plays[plays.length - 1];
  const finalText = `${last?.clock?.displayValue || ""} ${compactPlay(last)}`;
  if (!completedFinishHandled && /(0:00|last second|game[- ]winning)/i.test(finalText) && /field goal|goal|home run|touchdown/i.test(finalText)) {
    game.factors.push({
      label: "Decisive last play",
      points: 14
    });
    game.score = clampScore(
      game.score + 14
    );
  } else {
    const finish2 = globalThis.SportsRadarScore.defensiveFinishFactor?.(game.sport, summary);
    if (finish2) {
      game.factors.push(finish2);
      game.score = clampScore(game.score + finish2.points);
    }
  }
}
function completedFinishPoints(game, summary) {
  const last = scoringEvents(summary).at(-1);
  const text = `${last?.clock?.displayValue || ""} ${compactPlay(last)}`;
  return /(0:00|last second|game[- ]winning)/i.test(text) && /field goal|goal|home run|touchdown/i.test(text) ? 14 : globalThis.SportsRadarScore.defensiveFinishFactor?.(game.sport, summary)?.points || 0;
}

// alerts-worker/src/live-game-model.js
var import_live_runtime = __toESM(require_live_runtime(), 1);
var import_football_live = __toESM(require_football_live(), 1);
var import_football_market = __toESM(require_football_market(), 1);
function preserveFootballPregameMarket(game, previous = null, now = game.marketAsOf ?? Date.now(), previousObservedAt = null) {
  if (!import_football_market.default.supports(game)) return;
  import_football_market.default.prepareUpcomingMarket(game, game.sourceCompetition, null, previous, now, previousObservedAt);
  finish(game);
}
function preserveFootballContext(game, previous = null, rerate = true) {
  if (!["NFL", "CFB"].includes(game.sport)) return;
  const same = previous && previous.sport === game.sport && String(previous.id) === String(game.id) && game.teams.map((t) => String(t[8])).sort().join("|") === previous.teams?.map((t) => String(t[8])).sort().join("|");
  const prior = same ? previous : null;
  const market = game.state === "upcoming" ? game.pregameMarketQuote && import_football_live.default.pregameMarket(game, game.sourceCompetition, game.pregameMarketQuote.raw) : prior?.livePregameMarket || game.livePregameMarket || import_football_live.default.pregameMarket(game, game.sourceCompetition);
  if (market) game.livePregameMarket = market;
  else if (game.state === "upcoming") delete game.livePregameMarket;
  const developments = import_football_live.default.mergeDevelopments(game, null, prior);
  if (developments.length) game.verifiedDevelopments = developments;
  if (rerate) finish(game);
}
function finish(game, summary = null) {
  if (!game) return game;
  import_live_runtime.default.applyLiveSnapshot(game, game.sourceCompetition, summary);
  game.modelVersion = import_live_runtime.default.MODEL_VERSION;
  return game;
}
function normalizeEvent2(...args) {
  const game = normalizeEvent(...args);
  if (game && import_football_market.default.supports(game)) Object.defineProperty(game, "marketAsOf", { value: Date.now(), writable: true, configurable: true, enumerable: false });
  return finish(game);
}
function applyContextsToGame2(game, factors) {
  const changed = applyContextsToGame(game, factors);
  if (changed) finish(game);
  return changed;
}
function enrichGame2(game, summary, previousGame = null) {
  if (import_football_market.default.supports(game)) import_football_market.default.prepareUpcomingMarket(game, game.sourceCompetition, summary, previousGame);
  preserveFootballContext(game, previousGame, false);
  import_live_runtime.default.preservePregameBaseline(game, previousGame);
  import_live_runtime.default.preserveLiveEvidence(game, previousGame);
  enrichGame(game, summary, game.liveEvidenceReset === "score-correction" ? null : previousGame?.modelVersion === import_live_runtime.default.MODEL_VERSION ? previousGame : null);
  finish(game, summary);
}

// scripts/finish-audit-entry.mjs
var import_live_runtime2 = __toESM(require_live_runtime(), 1);
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  applyContextsToGame,
  enrichGame,
  normalizeEvent,
  preserveFootballContext,
  preserveFootballPregameMarket,
  preservePregameRecords,
  runtime
});
